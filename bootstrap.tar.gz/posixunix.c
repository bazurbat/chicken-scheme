/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-28 22:52
   Version 4.1.4 - SVN rev. 15427
   linux-unix-gnu-x86 [ ptables applyhook ]
   compiled 2009-08-13 on x (Linux)
   command line: posixunix.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature debugbuild -scrutinize -types ./types.db -explicit-use -no-trace -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_unsetenv(s)      (unsetenv((char *)C_data_pointer(s)), C_SCHEME_TRUE)
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
# define C_unsetenv(s)      C_fix(putenv((char *)C_data_pointer(s)))
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define cpy_tmvec_to_tmstc08(ptm, v) \
    (memset((ptm), 0, sizeof(struct tm)), \
    (ptm)->tm_sec = C_unfix(C_block_item((v), 0)), \
    (ptm)->tm_min = C_unfix(C_block_item((v), 1)), \
    (ptm)->tm_hour = C_unfix(C_block_item((v), 2)), \
    (ptm)->tm_mday = C_unfix(C_block_item((v), 3)), \
    (ptm)->tm_mon = C_unfix(C_block_item((v), 4)), \
    (ptm)->tm_year = C_unfix(C_block_item((v), 5)), \
    (ptm)->tm_wday = C_unfix(C_block_item((v), 6)), \
    (ptm)->tm_yday = C_unfix(C_block_item((v), 7)), \
    (ptm)->tm_isdst = (C_block_item((v), 8) != C_SCHEME_FALSE))

#define cpy_tmvec_to_tmstc9(ptm, v) \
    (((struct tm *)ptm)->tm_gmtoff = C_unfix(C_block_item((v), 9)))

#define cpy_tmstc08_to_tmvec(v, ptm) \
    (C_set_block_item((v), 0, C_fix(((struct tm *)ptm)->tm_sec)), \
    C_set_block_item((v), 1, C_fix((ptm)->tm_min)), \
    C_set_block_item((v), 2, C_fix((ptm)->tm_hour)), \
    C_set_block_item((v), 3, C_fix((ptm)->tm_mday)), \
    C_set_block_item((v), 4, C_fix((ptm)->tm_mon)), \
    C_set_block_item((v), 5, C_fix((ptm)->tm_year)), \
    C_set_block_item((v), 6, C_fix((ptm)->tm_wday)), \
    C_set_block_item((v), 7, C_fix((ptm)->tm_yday)), \
    C_set_block_item((v), 8, ((ptm)->tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define cpy_tmstc9_to_tmvec(v, ptm) \
    (C_set_block_item((v), 9, C_fix((ptm)->tm_gmtoff)))

#define C_tm_set_08(v)  cpy_tmvec_to_tmstc08( &C_tm, (v) )
#define C_tm_set_9(v)   cpy_tmvec_to_tmstc9( &C_tm, (v) )

#define C_tm_get_08(v)  cpy_tmstc08_to_tmvec( (v), &C_tm )
#define C_tm_get_9(v)   cpy_tmstc9_to_tmvec( (v), &C_tm )

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  return v;
}

#else

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  C_tm_set_9( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  C_tm_get_9( v );
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[466];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,49,54,32,108,111,99,49,55,32,109,115,103,49,56,32,46,32,97,114,103,115,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,50,49,50,52,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,50,53,50,56,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,52,52,32,99,109,100,52,53,32,46,32,116,109,112,52,51,52,54,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,53,55,32,102,108,97,103,115,53,56,32,46,32,109,111,100,101,53,57,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,99,108,111,115,101,32,102,100,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,114,101,97,100,32,102,100,55,51,32,115,105,122,101,55,52,32,46,32,98,117,102,102,101,114,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,119,114,105,116,101,32,102,100,56,56,32,98,117,102,102,101,114,56,57,32,46,32,115,105,122,101,57,48,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,49,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,50,50,49,32,108,115,116,50,50,50,50,50,53,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,50,48,53,32,108,115,116,50,48,54,50,48,57,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,9),40,108,111,111,112,49,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,9),40,108,111,111,112,49,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,49,51,49,32,102,100,115,119,49,51,50,32,46,32,116,105,109,101,111,117,116,49,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,50,51,55,32,108,105,110,107,50,51,56,32,108,111,99,50,51,57,41,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,50,53,49,32,46,32,108,105,110,107,50,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,50,53,57,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,50,54,50,41,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,50,54,53,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,50,54,56,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,50,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,50,55,52,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,50,55,55,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,50,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,114,101,103,117,108,97,114,63,32,102,110,97,109,101,50,57,49,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,26),40,115,116,97,116,45,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,50,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,28),40,99,104,97,114,97,99,116,101,114,45,100,101,118,105,99,101,63,32,102,110,97,109,101,51,48,53,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,24),40,98,108,111,99,107,45,100,101,118,105,99,101,63,32,102,110,97,109,101,51,49,50,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,17),40,102,95,51,49,54,56,32,102,110,97,109,101,51,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,18),40,115,111,99,107,101,116,63,32,102,110,97,109,101,51,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,51,51,50,32,112,111,115,51,51,51,32,46,32,119,104,101,110,99,101,51,51,52,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,51,56,51,32,108,115,116,51,56,52,51,56,55,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,55,50,32,46,32,116,109,112,51,55,49,51,55,51,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,52,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,52,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,52,51,52,32,115,112,101,99,52,52,51,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,52,52,41,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,51,55,32,37,115,112,101,99,52,51,50,52,55,54,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,52,51,54,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,52,50,55,52,50,56,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,52,56,51,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,52,57,52,52,57,53,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,7),40,97,51,54,56,49,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,19),40,97,51,54,55,53,32,101,120,118,97,114,53,51,55,53,52,56,41,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,51,54,57,57,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,51,55,49,49,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,20),40,97,51,55,48,53,32,46,32,97,114,103,115,53,52,53,53,53,57,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,51,54,57,51,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,15),40,97,51,54,54,57,32,107,53,52,52,53,52,55,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,53,56,54,32,114,53,56,55,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,53,54,48,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,53,57,53,32,99,109,100,53,57,54,32,105,110,112,53,57,55,32,114,53,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,48,49,32,46,32,109,54,48,50,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,54,49,48,32,46,32,109,54,49,49,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,54,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,7),40,97,52,49,54,51,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,20),40,97,52,49,54,57,32,46,32,114,101,115,117,108,116,115,54,51,57,41,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,51,53,32,112,114,111,99,54,51,54,32,46,32,109,111,100,101,54,51,55,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,7),40,97,52,49,56,55,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,20),40,97,52,49,57,51,32,46,32,114,101,115,117,108,116,115,54,52,53,41,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,54,52,49,32,112,114,111,99,54,52,50,32,46,32,109,111,100,101,54,52,51,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,97,52,50,49,50,32,46,32,114,101,115,117,108,116,115,54,53,50,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,54,52,55,32,116,104,117,110,107,54,52,56,32,46,32,109,111,100,101,54,52,57,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,20),40,97,52,50,51,50,32,46,32,114,101,115,117,108,116,115,54,54,49,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,54,53,54,32,116,104,117,110,107,54,53,55,32,46,32,109,111,100,101,54,53,56,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,54,55,51,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,54,55,53,32,112,114,111,99,54,55,54,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,54,56,49,32,115,116,97,116,101,54,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,9),40,108,111,111,112,54,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,26),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,54,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,105,103,115,55,48,54,32,109,97,115,107,55,48,55,41,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,55,49,49,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,21),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,55,49,52,41,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,55,50,48,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,38),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,55,54,49,32,46,32,116,109,112,55,54,48,55,54,50,41,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,57,56,41,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,40),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,55,56,54,32,46,32,116,109,112,55,56,53,55,56,55,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,50,51,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,23),40,100,111,108,111,111,112,56,51,50,32,108,115,116,56,51,54,32,105,56,51,55,41,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,56,50,57,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,33),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,56,53,53,32,105,100,56,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,56,54,50,32,109,56,54,51,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,39),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,56,54,56,32,117,105,100,56,54,57,32,103,105,100,56,55,48,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,56,55,55,32,97,99,99,56,55,56,32,108,111,99,56,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,56,56,53,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,56,56,54,41};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,56,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,36),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,57,49,49,32,110,101,119,57,49,50,41,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,41),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,57,50,53,32,46,32,116,109,112,57,50,52,57,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,108,105,110,107,32,111,108,100,57,53,49,32,110,101,119,57,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,57,53,57,32,109,57,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,32),40,99,104,101,99,107,32,108,111,99,57,55,51,32,102,100,57,55,52,32,105,110,112,57,55,53,32,114,57,55,54,41};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,57,55,57,32,46,32,109,57,56,48,41,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,57,56,50,32,46,32,109,57,56,51,41};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,57,56,56,41,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,36),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,49,48,48,48,32,46,32,110,101,119,49,48,48,49,41,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,8),40,114,101,97,100,121,63,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,7),40,102,101,116,99,104,41,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,7),40,97,53,52,52,50,41,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,7),40,97,53,52,53,53,41,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,7),40,97,53,52,54,55,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,7),40,97,53,52,56,56,41,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,110,49,48,57,53,32,109,49,48,57,54,32,115,116,97,114,116,49,48,57,55,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,41),40,97,53,52,57,55,32,112,111,114,116,49,48,57,48,32,110,49,48,57,49,32,100,101,115,116,49,48,57,50,32,115,116,97,114,116,49,48,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,24),40,98,117,109,112,101,114,32,99,117,114,49,49,50,49,32,112,116,114,49,49,50,50,41};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,7),40,97,53,54,53,57,41,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,42),40,97,53,54,54,53,32,100,101,115,116,49,49,53,50,49,49,53,51,49,49,53,54,32,99,111,110,116,63,49,49,53,52,49,49,53,53,49,49,53,55,41,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,49,49,49,57,41,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,26),40,97,53,53,55,51,32,112,111,114,116,49,49,49,54,32,108,105,109,105,116,49,49,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,49,48,50,56,32,110,111,110,98,108,111,99,107,105,110,103,63,49,48,51,57,32,98,117,102,105,49,48,52,48,32,111,110,45,99,108,111,115,101,49,48,52,49,32,109,111,114,101,63,49,48,52,50,41,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,69),40,100,101,102,45,109,111,114,101,63,49,48,51,51,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,48,50,52,49,49,54,54,32,37,98,117,102,105,49,48,50,53,49,49,54,55,32,37,111,110,45,99,108,111,115,101,49,48,50,54,49,49,54,56,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,48,51,50,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,48,50,52,49,49,55,48,32,37,98,117,102,105,49,48,50,53,49,49,55,49,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,48,51,49,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,48,50,52,49,49,55,51,41,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,48,51,48,41,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,62),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,48,49,55,32,110,97,109,49,48,49,56,32,102,100,49,48,49,57,32,46,32,116,109,112,49,48,49,54,49,48,50,48,41,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,22),40,112,111,107,101,32,115,116,114,49,50,49,56,32,108,101,110,49,50,49,57,41,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,15),40,97,53,56,53,54,32,115,116,114,49,50,53,51,41,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,7),40,97,53,56,54,50,41,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,7),40,97,53,56,56,51,41,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,16),40,102,95,53,56,57,50,32,115,116,114,49,50,50,57,41};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,32,114,101,109,49,50,51,54,32,115,116,97,114,116,49,50,51,55,32,108,101,110,49,50,51,56,41};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,16),40,102,95,53,57,48,55,32,115,116,114,49,50,51,52,41};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,49),40,98,111,100,121,49,50,48,49,32,110,111,110,98,108,111,99,107,105,110,103,63,49,50,49,49,32,98,117,102,105,49,50,49,50,32,111,110,45,99,108,111,115,101,49,50,49,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,50,48,53,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,49,57,56,49,50,54,53,32,37,98,117,102,105,49,49,57,57,49,50,54,54,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,50,48,52,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,49,57,56,49,50,54,56,41,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,50,48,51,41,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,63),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,49,57,49,32,110,97,109,49,49,57,50,32,102,100,49,49,57,51,32,46,32,116,109,112,49,49,57,48,49,49,57,52,41,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,49,50,55,54,32,111,102,102,49,50,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,32,112,111,114,116,49,50,56,57,32,97,114,103,115,49,50,57,48,32,108,111,99,49,50,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,30),40,101,114,114,32,109,115,103,49,51,48,55,32,108,111,99,107,49,51,48,56,32,108,111,99,49,51,48,57,41,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,49,51,49,48,32,46,32,97,114,103,115,49,51,49,49,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,40),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,49,51,49,51,32,46,32,97,114,103,115,49,51,49,52,41};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,36),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,49,51,49,54,32,46,32,97,114,103,115,49,51,49,55,41,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,49,51,51,52,41,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,34),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,49,51,51,57,32,46,32,109,111,100,101,49,51,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,20),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,49,51,52,54,41,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,49,51,52,57,32,118,97,108,49,51,53,48,41};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,49,51,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,49,51,54,56,41,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,51,54,53,41,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,27),40,103,101,116,45,101,110,118,105,114,111,110,109,101,110,116,45,118,97,114,105,97,98,108,101,115,41,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,72),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,49,51,56,57,32,108,101,110,49,51,57,48,32,112,114,111,116,49,51,57,49,32,102,108,97,103,49,51,57,50,32,102,100,49,51,57,51,32,46,32,111,102,102,49,51,57,52,41};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,43),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,49,52,49,53,32,46,32,108,101,110,49,52,49,54,41,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,37),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,49,52,50,50,41,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,49,52,50,53,41,0,0,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,34),40,99,104,101,99,107,45,116,105,109,101,45,118,101,99,116,111,114,32,108,111,99,49,52,50,55,32,116,109,49,52,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,30),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,49,52,51,51,41,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,28),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,49,52,51,54,41,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,26),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,49,52,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,49,52,54,55,32,46,32,116,109,112,49,52,54,54,49,52,54,56,41,0,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,36),40,115,116,114,105,110,103,45,62,116,105,109,101,32,116,105,109,49,52,57,55,32,46,32,116,109,112,49,52,57,54,49,52,57,56,41,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,49,53,48,55,41,0,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,26),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,49,53,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,49,53,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,97,108,97,114,109,33,32,97,49,53,50,49,49,53,50,52,41,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,49,53,50,53,32,109,111,100,101,49,53,50,54,32,46,32,115,105,122,101,49,53,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,49,53,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,49,53,52,54,32,112,111,114,116,49,53,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,49,53,53,57,41};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,49,53,55,48,41};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,7),40,97,55,48,52,57,41,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,49,54,50,52,41,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,55),40,97,55,48,53,53,32,100,105,114,49,54,48,51,49,54,48,52,49,54,48,57,32,102,105,108,49,54,48,53,49,54,48,54,49,54,49,48,32,101,120,116,49,54,48,55,49,54,48,56,49,54,49,49,41,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,49,53,57,57,41,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,49,53,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,49,54,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,28),40,115,101,116,97,114,103,32,97,49,54,54,53,49,54,55,49,32,97,49,54,54,52,49,54,55,50,41,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,28),40,115,101,116,101,110,118,32,97,49,54,55,55,49,54,56,51,32,97,49,54,55,54,49,54,56,52,41,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,55,50,49,32,105,49,55,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,25),40,100,111,108,111,111,112,49,55,49,51,32,97,108,49,55,49,55,32,105,49,55,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,49,55,48,49,32,97,114,103,108,105,115,116,49,55,49,48,32,101,110,118,108,105,115,116,49,55,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,34),40,100,101,102,45,101,110,118,108,105,115,116,49,55,48,52,32,37,97,114,103,108,105,115,116,49,54,57,57,49,55,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,97,114,103,108,105,115,116,49,55,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,49,54,57,52,32,46,32,116,109,112,49,54,57,51,49,54,57,53,41,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,55,53,54,32,110,111,104,97,110,103,49,55,53,55,41,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,7),40,97,55,52,52,49,41,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,36),40,97,55,52,52,55,32,101,112,105,100,49,55,56,55,32,101,110,111,114,109,49,55,56,56,32,101,99,111,100,101,49,55,56,57,41,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,49,55,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,49,55,57,53,49,55,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,49,55,57,57,32,46,32,115,105,103,49,56,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,56,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,56,49,55,32,46,32,97,114,103,115,49,56,49,56,41,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,7),40,97,55,54,49,55,41,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,29),40,97,55,54,50,51,32,95,49,56,53,54,32,102,108,103,49,56,53,55,32,99,111,100,49,56,53,56,41,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,8),40,102,95,55,54,48,51,41};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,111,110,45,99,108,111,115,101,32,108,111,99,49,56,52,52,32,112,105,100,49,56,52,53,32,99,108,115,118,101,99,49,56,52,54,32,105,100,120,49,56,52,55,32,105,100,120,97,49,56,52,56,32,105,100,120,98,49,56,52,57,41,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,7),40,97,55,54,52,54,41,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,19),40,97,55,54,53,50,32,105,49,56,54,56,32,111,49,56,54,57,41,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,101,100,45,112,105,112,101,32,112,111,114,116,49,56,54,51,41,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,34),40,99,111,110,110,101,99,116,45,112,97,114,101,110,116,32,112,105,112,101,49,56,55,49,32,112,111,114,116,49,56,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,43),40,99,111,110,110,101,99,116,45,99,104,105,108,100,32,112,105,112,101,49,56,56,48,32,112,111,114,116,49,56,56,49,32,115,116,100,102,100,49,56,56,50,41,0,0,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,7),40,97,55,55,50,55,41,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,67),40,115,112,97,119,110,32,99,109,100,49,56,57,54,32,97,114,103,115,49,56,57,55,32,101,110,118,49,56,57,56,32,115,116,100,111,117,116,102,49,56,57,57,32,115,116,100,105,110,102,49,57,48,48,32,115,116,100,101,114,114,102,49,57,48,49,41,0,0,0,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,59),40,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,57,48,56,32,99,109,100,49,57,49,48,32,112,105,112,101,49,57,49,49,32,115,116,100,102,49,57,49,50,32,111,110,45,99,108,111,115,101,49,57,49,52,41,0,0,0,0,0};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,60),40,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,57,49,57,32,99,109,100,49,57,50,49,32,112,105,112,101,49,57,50,50,32,115,116,100,102,49,57,50,51,32,111,110,45,99,108,111,115,101,49,57,50,53,41,0,0,0,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,7),40,97,55,55,55,55,41,0};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,50),40,97,55,55,56,51,32,105,110,112,105,112,101,49,57,51,57,32,111,117,116,112,105,112,101,49,57,52,48,32,101,114,114,112,105,112,101,49,57,52,49,32,112,105,100,49,57,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,49,57,51,48,32,99,109,100,49,57,51,49,32,97,114,103,115,49,57,51,50,32,101,110,118,49,57,51,51,32,115,116,100,111,117,116,102,49,57,51,52,32,115,116,100,105,110,102,49,57,51,53,32,115,116,100,101,114,114,102,49,57,51,54,41,0,0,0,0,0};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,10),40,108,111,111,112,49,57,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,11),40,99,104,107,115,116,114,108,115,116,41,0,0,0,0,0};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,7),40,97,55,56,55,52,41,0};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,38),40,97,55,56,56,48,32,105,110,49,57,55,52,32,111,117,116,49,57,55,53,32,112,105,100,49,57,55,54,32,101,114,114,49,57,55,55,41,0,0};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,52),40,37,112,114,111,99,101,115,115,32,108,111,99,49,57,52,53,32,101,114,114,63,49,57,52,54,32,99,109,100,49,57,52,55,32,97,114,103,115,49,57,52,56,32,101,110,118,49,57,52,57,41,0,0,0,0};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,49,57,57,52,32,97,114,103,115,50,48,48,51,32,101,110,118,50,48,48,52,41,0,0,0,0,0};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,57,57,55,32,37,97,114,103,115,49,57,57,50,50,48,48,54,41,0,0,0,0,0};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,57,57,54,41,0,0};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,49,57,56,55,32,46,32,116,109,112,49,57,56,54,49,57,56,56,41,0};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,50,48,50,53,32,97,114,103,115,50,48,51,52,32,101,110,118,50,48,51,53,41,0,0,0,0,0};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,50,48,50,56,32,37,97,114,103,115,50,48,50,51,50,48,51,55,41,0,0,0,0,0};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,50,48,50,55,41,0,0};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,50,48,49,56,32,46,32,116,109,112,50,48,49,55,50,48,49,57,41};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,14),40,102,95,56,49,55,48,32,120,50,48,56,55,41,0,0};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,7),40,97,56,48,57,51,41,0};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,7),40,97,56,48,57,56,41,0};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,7),40,97,56,49,50,50,41,0};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,50,48,56,57,32,114,50,48,57,48,41,0,0,0,0,0};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,16),40,102,95,56,49,56,57,32,46,32,95,50,48,56,48,41};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,16),40,102,95,56,49,56,49,32,46,32,95,50,48,55,57,41};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,50,48,53,55,32,97,99,116,105,111,110,50,48,54,55,32,105,100,50,48,54,56,32,108,105,109,105,116,50,48,54,57,41,0,0};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,50,48,54,49,32,37,97,99,116,105,111,110,50,48,53,52,50,49,50,48,32,37,105,100,50,48,53,53,50,49,50,49,41,0,0,0,0,0};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,50,48,54,48,32,37,97,99,116,105,111,110,50,48,53,52,50,49,50,51,41,0,0,0,0};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,19),40,97,56,50,48,57,32,120,50,49,50,53,32,121,50,49,50,54,41,0,0,0,0,0};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,50,48,53,57,41};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,50,48,52,56,32,112,114,101,100,50,48,52,57,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,50,48,53,48,41,0,0,0,0,0};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,50,49,52,48,41,0,0,0};
static C_char C_TLS li239[] C_aligned={C_lihdr(0,0,14),40,97,56,51,48,56,32,112,105,100,56,57,55,41,0,0};
static C_char C_TLS li240[] C_aligned={C_lihdr(0,0,22),40,97,56,51,50,54,32,112,105,100,57,48,52,32,112,103,105,100,57,48,53,41,0,0};
static C_char C_TLS li241[] C_aligned={C_lihdr(0,0,7),40,97,56,51,52,55,41,0};
static C_char C_TLS li242[] C_aligned={C_lihdr(0,0,13),40,97,56,51,53,48,32,105,100,55,53,48,41,0,0,0};
static C_char C_TLS li243[] C_aligned={C_lihdr(0,0,7),40,97,56,51,54,53,41,0};
static C_char C_TLS li244[] C_aligned={C_lihdr(0,0,13),40,97,56,51,54,56,32,105,100,55,52,52,41,0,0,0};
static C_char C_TLS li245[] C_aligned={C_lihdr(0,0,7),40,97,56,51,56,51,41,0};
static C_char C_TLS li246[] C_aligned={C_lihdr(0,0,13),40,97,56,51,56,54,32,105,100,55,51,56,41,0,0,0};
static C_char C_TLS li247[] C_aligned={C_lihdr(0,0,7),40,97,56,52,48,49,41,0};
static C_char C_TLS li248[] C_aligned={C_lihdr(0,0,13),40,97,56,52,48,52,32,105,100,55,51,50,41,0,0,0};
static C_char C_TLS li249[] C_aligned={C_lihdr(0,0,12),40,97,56,52,49,57,32,110,55,50,53,41,0,0,0,0};
static C_char C_TLS li250[] C_aligned={C_lihdr(0,0,15),40,97,56,52,50,53,32,112,111,114,116,51,53,49,41,0};
static C_char C_TLS li251[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k8276 in set-root-directory! in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall stub2135(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2135(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k7499 */
static C_word C_fcall stub1796(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1796(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall stub1793(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1793(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall stub1791(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1791(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub1686(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1686(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k7205 */
static C_word C_fcall stub1679(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1679(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub1674(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1674(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k7186 */
static C_word C_fcall stub1667(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1667(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k7162 */
static C_word C_fcall stub1655(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1655(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub1642(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1642(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1584(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1584(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k6979 */
static C_word C_fcall stub1565(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1565(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k6956 */
static C_word C_fcall stub1555(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1555(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k6845 */
static C_word C_fcall stub1522(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1522(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k6823 */
static C_word C_fcall stub1517(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1517(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1512(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1512(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub1486(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1486(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub1456(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1456(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub1450(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1450(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k6630 */
static C_word C_fcall stub1440(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1440(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k6530 */
static C_word C_fcall stub1409(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1409(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k6468 */
static C_word C_fcall stub1378(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub1378(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k6367 */
static C_word C_fcall stub1360(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1360(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k5118 in k5114 in file-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall stub943(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub943(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k4821 */
static C_word C_fcall stub849(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub849(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k4690 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub806(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub806(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from k4683 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub802(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub802(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from k4597 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub775(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub775(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a8347 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall stub748(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub748(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a8365 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall stub742(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub742(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a8383 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall stub736(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub736(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a8401 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall stub730(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub730(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k2748 */
static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k2738 */
static C_word C_fcall stub121(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub121(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k2728 */
static C_word C_fcall stub116(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub116(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k2510 */
static C_word C_fcall stub33(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub33(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from k2459 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub26(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub26(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from k2452 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub22(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub22(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k2428 */
static C_word C_fcall stub12(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub12(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8426)
static void C_ccall f_8426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8442)
static void C_ccall f_8442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8433)
static void C_ccall f_8433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8420)
static void C_ccall f_8420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8405)
static void C_ccall f_8405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8415)
static void C_ccall f_8415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8402)
static void C_ccall f_8402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8387)
static void C_ccall f_8387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8397)
static void C_ccall f_8397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8384)
static void C_ccall f_8384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8379)
static void C_ccall f_8379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8366)
static void C_ccall f_8366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8351)
static void C_ccall f_8351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8348)
static void C_ccall f_8348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8343)
static void C_ccall f_8343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8309)
static void C_ccall f_8309(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8322)
static void C_ccall f_8322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8316)
static void C_ccall f_8316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8286)
static void C_ccall f_8286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8296)
static void C_fcall f_8296(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8027)
static void C_ccall f_8027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8027)
static void C_ccall f_8027r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8204)
static void C_fcall f_8204(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8210)
static void C_ccall f_8210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8199)
static void C_fcall f_8199(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8194)
static void C_fcall f_8194(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8029)
static void C_fcall f_8029(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8181)
static void C_ccall f_8181(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8036)
static void C_fcall f_8036(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8163)
static void C_ccall f_8163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8046)
static void C_ccall f_8046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8048)
static void C_fcall f_8048(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8067)
static void C_ccall f_8067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8149)
static void C_ccall f_8149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8156)
static void C_ccall f_8156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8143)
static void C_ccall f_8143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8123)
static void C_ccall f_8123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8099)
static void C_ccall f_8099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8121)
static void C_ccall f_8121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8107)
static void C_ccall f_8107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8114)
static void C_ccall f_8114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8111)
static void C_ccall f_8111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8094)
static void C_ccall f_8094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8092)
static void C_ccall f_8092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8170)
static void C_ccall f_8170(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7967)
static void C_ccall f_7967(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7967)
static void C_ccall f_7967r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7979)
static void C_fcall f_7979(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7974)
static void C_fcall f_7974(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7969)
static void C_fcall f_7969(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7919)
static void C_fcall f_7919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7914)
static void C_fcall f_7914(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7909)
static void C_fcall f_7909(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7830)
static void C_fcall f_7830(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7901)
static void C_ccall f_7901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7905)
static void C_ccall f_7905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7867)
static void C_fcall f_7867(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7832)
static C_word C_fcall f_7832(C_word t0,C_word t1);
C_noret_decl(f_7841)
static C_word C_fcall f_7841(C_word t0,C_word t1);
C_noret_decl(f_7772)
static void C_ccall f_7772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7784)
static void C_ccall f_7784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7815)
static void C_ccall f_7815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7795)
static void C_ccall f_7795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7799)
static void C_ccall f_7799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7807)
static void C_ccall f_7807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7803)
static void C_ccall f_7803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7778)
static void C_ccall f_7778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7761)
static void C_fcall f_7761(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7765)
static void C_ccall f_7765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7750)
static void C_fcall f_7750(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7754)
static void C_ccall f_7754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7705)
static void C_fcall f_7705(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7709)
static void C_ccall f_7709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7712)
static void C_ccall f_7712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7715)
static void C_ccall f_7715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7722)
static void C_fcall f_7722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7728)
static void C_ccall f_7728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7726)
static void C_ccall f_7726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7672)
static void C_fcall f_7672(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7685)
static void C_ccall f_7685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7597)
static void C_ccall f_7597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7658)
static void C_fcall f_7658(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7671)
static void C_ccall f_7671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7638)
static void C_fcall f_7638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7653)
static void C_ccall f_7653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7647)
static void C_ccall f_7647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7601)
static void C_fcall f_7601(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7603)
static void C_ccall f_7603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7624)
static void C_ccall f_7624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7618)
static void C_ccall f_7618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7545)
static void C_ccall f_7545(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7545)
static void C_ccall f_7545r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7552)
static void C_ccall f_7552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7571)
static void C_ccall f_7571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_ccall f_7575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7534)
static void C_ccall f_7534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7503)
static void C_ccall f_7503(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7503)
static void C_ccall f_7503r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7496)
static void C_ccall f_7496(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7490)
static void C_ccall f_7490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7412)
static void C_ccall f_7412(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7412)
static void C_ccall f_7412r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7448)
static void C_ccall f_7448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7442)
static void C_ccall f_7442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7395)
static void C_ccall f_7395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7213)
static void C_ccall f_7213(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7213)
static void C_ccall f_7213r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7347)
static void C_fcall f_7347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7342)
static void C_fcall f_7342(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7215)
static void C_fcall f_7215(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7225)
static void C_ccall f_7225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7233)
static void C_fcall f_7233(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7279)
static C_word C_fcall f_7279(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7246)
static void C_fcall f_7246(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7271)
static void C_ccall f_7271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7194)
static C_word C_fcall f_7194(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7175)
static C_word C_fcall f_7175(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7138)
static void C_ccall f_7138(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7138)
static void C_ccall f_7138r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7029)
static void C_ccall f_7029(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7029)
static void C_ccall f_7029r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7035)
static void C_fcall f_7035(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7056)
static void C_ccall f_7056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7130)
static void C_ccall f_7130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7060)
static void C_ccall f_7060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7063)
static void C_ccall f_7063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7072)
static void C_fcall f_7072(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7099)
static void C_ccall f_7099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7103)
static void C_ccall f_7103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6982)
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6986)
static void C_ccall f_6986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7006)
static void C_ccall f_7006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_ccall f_7010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6927)
static void C_fcall f_6927(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6908)
static void C_ccall f_6908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6853)
static void C_ccall f_6853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6868)
static void C_fcall f_6868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6826)
static void C_ccall f_6826(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6826)
static void C_ccall f_6826r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6799)
static void C_ccall f_6799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6784)
static void C_ccall f_6784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6742)
static void C_ccall f_6742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6669)
static void C_ccall f_6669(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6669)
static void C_ccall f_6669r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6673)
static void C_ccall f_6673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6676)
static void C_ccall f_6676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6698)
static void C_ccall f_6698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6685)
static void C_ccall f_6685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6640)
static void C_ccall f_6640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6614)
static void C_ccall f_6614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6605)
static void C_ccall f_6605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6586)
static void C_fcall f_6586(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6580)
static void C_ccall f_6580(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6536)
static void C_ccall f_6536(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6536)
static void C_ccall f_6536r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6549)
static void C_fcall f_6549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6376)
static void C_fcall f_6376(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6380)
static void C_ccall f_6380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6388)
static void C_fcall f_6388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6344)
static void C_ccall f_6344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6307)
static void C_ccall f_6307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6331)
static void C_ccall f_6331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6314)
static void C_ccall f_6314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6271)
static void C_fcall f_6271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6236)
static void C_ccall f_6236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6214)
static void C_ccall f_6214(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6214)
static void C_ccall f_6214r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6218)
static void C_ccall f_6218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6184)
static void C_ccall f_6184(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6184)
static void C_ccall f_6184r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_fcall f_6166(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6092)
static void C_fcall f_6092(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6114)
static void C_ccall f_6114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6120)
static void C_fcall f_6120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_fcall f_6063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5990)
static void C_fcall f_5990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5985)
static void C_fcall f_5985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5980)
static void C_fcall f_5980(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5796)
static void C_fcall f_5796(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5906)
static void C_ccall f_5906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5907)
static void C_ccall f_5907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5924)
static void C_fcall f_5924(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5892)
static void C_ccall f_5892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5848)
static void C_fcall f_5848(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5852)
static void C_ccall f_5852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_fcall f_5802(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5716)
static void C_fcall f_5716(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5711)
static void C_fcall f_5711(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5706)
static void C_fcall f_5706(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5701)
static void C_fcall f_5701(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5314)
static void C_fcall f_5314(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5580)
static void C_fcall f_5580(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5676)
static void C_ccall f_5676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5660)
static void C_ccall f_5660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5506)
static void C_fcall f_5506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5508)
static void C_fcall f_5508(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5489)
static void C_ccall f_5489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5456)
static void C_ccall f_5456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_ccall f_5443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5441)
static void C_ccall f_5441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_fcall f_5356(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_fcall f_5368(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5408)
static void C_ccall f_5408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5348)
static C_word C_fcall f_5348(C_word t0);
C_noret_decl(f_5325)
static void C_fcall f_5325(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5292)
static void C_fcall f_5292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5295)
static void C_ccall f_5295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5224)
static void C_ccall f_5224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5197)
static void C_fcall f_5197(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_fcall f_5160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5135)
static void C_ccall f_5135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_fcall f_5148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5090)
static void C_ccall f_5090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5065)
static void C_ccall f_5065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5068)
static void C_ccall f_5068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5046)
static void C_ccall f_5046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4952)
static void C_fcall f_4952(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_fcall f_4844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_fcall f_4766(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_fcall f_4709(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_fcall f_4608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_fcall f_4631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_fcall f_4502(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4423)
static void C_ccall f_4423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_fcall f_4376(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4348)
static C_word C_fcall f_4348(C_word t0);
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_fcall f_4052(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3844)
static void C_fcall f_3844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3863)
static void C_fcall f_3863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_fcall f_3907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_fcall f_3733(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3746)
static void C_ccall f_3746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_ccall f_3774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_fcall f_3661(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3522)
static void C_fcall f_3522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_fcall f_3517(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3419)
static void C_fcall f_3419(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_fcall f_3450(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_fcall f_3472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3255)
static void C_ccall f_3255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_fcall f_3270(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_fcall f_3007(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2972)
static C_word C_fcall f_2972(C_word t0,C_word t1);
C_noret_decl(f_2767)
static void C_fcall f_2767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static C_word C_fcall f_2930(C_word t0,C_word t1);
C_noret_decl(f_2773)
static void C_fcall f_2773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_fcall f_2776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_fcall f_2874(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_fcall f_2815(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_fcall f_2833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2628)
static void C_ccall f_2628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8296)
static void C_fcall trf_8296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8296(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8296(t0,t1);}

C_noret_decl(trf_8204)
static void C_fcall trf_8204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8204(t0,t1);}

C_noret_decl(trf_8199)
static void C_fcall trf_8199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8199(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8199(t0,t1,t2);}

C_noret_decl(trf_8194)
static void C_fcall trf_8194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8194(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8194(t0,t1,t2,t3);}

C_noret_decl(trf_8029)
static void C_fcall trf_8029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8029(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8029(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8036)
static void C_fcall trf_8036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8036(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8036(t0,t1);}

C_noret_decl(trf_8048)
static void C_fcall trf_8048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8048(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8048(t0,t1,t2,t3);}

C_noret_decl(trf_7979)
static void C_fcall trf_7979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7979(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7979(t0,t1);}

C_noret_decl(trf_7974)
static void C_fcall trf_7974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7974(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7974(t0,t1,t2);}

C_noret_decl(trf_7969)
static void C_fcall trf_7969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7969(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7969(t0,t1,t2,t3);}

C_noret_decl(trf_7919)
static void C_fcall trf_7919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7919(t0,t1);}

C_noret_decl(trf_7914)
static void C_fcall trf_7914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7914(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7914(t0,t1,t2);}

C_noret_decl(trf_7909)
static void C_fcall trf_7909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7909(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7909(t0,t1,t2,t3);}

C_noret_decl(trf_7830)
static void C_fcall trf_7830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7830(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7830(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7867)
static void C_fcall trf_7867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7867(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7867(t0,t1);}

C_noret_decl(trf_7761)
static void C_fcall trf_7761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7761(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7761(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7750)
static void C_fcall trf_7750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7750(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7750(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7705)
static void C_fcall trf_7705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7705(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7705(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7722)
static void C_fcall trf_7722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7722(t0,t1);}

C_noret_decl(trf_7672)
static void C_fcall trf_7672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7672(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7672(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7658)
static void C_fcall trf_7658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7658(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7658(t0,t1,t2,t3);}

C_noret_decl(trf_7638)
static void C_fcall trf_7638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7638(t0,t1,t2);}

C_noret_decl(trf_7601)
static void C_fcall trf_7601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7601(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7601(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7347)
static void C_fcall trf_7347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7347(t0,t1);}

C_noret_decl(trf_7342)
static void C_fcall trf_7342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7342(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7342(t0,t1,t2);}

C_noret_decl(trf_7215)
static void C_fcall trf_7215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7215(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7215(t0,t1,t2,t3);}

C_noret_decl(trf_7233)
static void C_fcall trf_7233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7233(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7233(t0,t1,t2,t3);}

C_noret_decl(trf_7246)
static void C_fcall trf_7246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7246(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7246(t0,t1);}

C_noret_decl(trf_7035)
static void C_fcall trf_7035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7035(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7035(t0,t1,t2);}

C_noret_decl(trf_7072)
static void C_fcall trf_7072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7072(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7072(t0,t1,t2);}

C_noret_decl(trf_6927)
static void C_fcall trf_6927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6927(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6927(t0,t1,t2);}

C_noret_decl(trf_6868)
static void C_fcall trf_6868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6868(t0,t1);}

C_noret_decl(trf_6586)
static void C_fcall trf_6586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6586(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6586(t0,t1,t2);}

C_noret_decl(trf_6549)
static void C_fcall trf_6549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6549(t0,t1);}

C_noret_decl(trf_6376)
static void C_fcall trf_6376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6376(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6376(t0,t1,t2);}

C_noret_decl(trf_6388)
static void C_fcall trf_6388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6388(t0,t1,t2);}

C_noret_decl(trf_6271)
static void C_fcall trf_6271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6271(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6271(t0,t1);}

C_noret_decl(trf_6166)
static void C_fcall trf_6166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6166(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6166(t0,t1,t2,t3);}

C_noret_decl(trf_6092)
static void C_fcall trf_6092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6092(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6092(t0,t1,t2,t3);}

C_noret_decl(trf_6120)
static void C_fcall trf_6120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6120(t0,t1);}

C_noret_decl(trf_6063)
static void C_fcall trf_6063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6063(t0,t1);}

C_noret_decl(trf_5990)
static void C_fcall trf_5990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5990(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5990(t0,t1);}

C_noret_decl(trf_5985)
static void C_fcall trf_5985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5985(t0,t1,t2);}

C_noret_decl(trf_5980)
static void C_fcall trf_5980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5980(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5980(t0,t1,t2,t3);}

C_noret_decl(trf_5796)
static void C_fcall trf_5796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5796(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5796(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5924)
static void C_fcall trf_5924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5924(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5924(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5848)
static void C_fcall trf_5848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5848(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5848(t0,t1);}

C_noret_decl(trf_5802)
static void C_fcall trf_5802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5802(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5802(t0,t1,t2,t3);}

C_noret_decl(trf_5716)
static void C_fcall trf_5716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5716(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5716(t0,t1);}

C_noret_decl(trf_5711)
static void C_fcall trf_5711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5711(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5711(t0,t1,t2);}

C_noret_decl(trf_5706)
static void C_fcall trf_5706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5706(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5706(t0,t1,t2,t3);}

C_noret_decl(trf_5701)
static void C_fcall trf_5701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5701(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5701(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5314)
static void C_fcall trf_5314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5314(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5314(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5580)
static void C_fcall trf_5580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5580(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5580(t0,t1,t2);}

C_noret_decl(trf_5506)
static void C_fcall trf_5506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5506(t0,t1);}

C_noret_decl(trf_5508)
static void C_fcall trf_5508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5508(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5508(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5356)
static void C_fcall trf_5356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5356(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5356(t0,t1);}

C_noret_decl(trf_5368)
static void C_fcall trf_5368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5368(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5368(t0,t1);}

C_noret_decl(trf_5325)
static void C_fcall trf_5325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5325(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5325(t0,t1);}

C_noret_decl(trf_5292)
static void C_fcall trf_5292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5292(t0,t1);}

C_noret_decl(trf_5197)
static void C_fcall trf_5197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5197(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5197(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5160)
static void C_fcall trf_5160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5160(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5160(t0,t1,t2);}

C_noret_decl(trf_5148)
static void C_fcall trf_5148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5148(t0,t1);}

C_noret_decl(trf_4952)
static void C_fcall trf_4952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4952(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4952(t0,t1,t2,t3);}

C_noret_decl(trf_4844)
static void C_fcall trf_4844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4844(t0,t1);}

C_noret_decl(trf_4766)
static void C_fcall trf_4766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4766(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4766(t0,t1,t2,t3);}

C_noret_decl(trf_4709)
static void C_fcall trf_4709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4709(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4709(t0,t1,t2);}

C_noret_decl(trf_4608)
static void C_fcall trf_4608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4608(t0,t1);}

C_noret_decl(trf_4631)
static void C_fcall trf_4631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4631(t0,t1,t2);}

C_noret_decl(trf_4502)
static void C_fcall trf_4502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4502(t0,t1);}

C_noret_decl(trf_4376)
static void C_fcall trf_4376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4376(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4376(t0,t1,t2,t3);}

C_noret_decl(trf_4052)
static void C_fcall trf_4052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4052(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4052(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3844)
static void C_fcall trf_3844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3844(t0,t1);}

C_noret_decl(trf_3863)
static void C_fcall trf_3863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3863(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3863(t0,t1);}

C_noret_decl(trf_3907)
static void C_fcall trf_3907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3907(t0,t1);}

C_noret_decl(trf_3733)
static void C_fcall trf_3733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3733(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3733(t0,t1,t2,t3);}

C_noret_decl(trf_3661)
static void C_fcall trf_3661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3661(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3661(t0,t1);}

C_noret_decl(trf_3522)
static void C_fcall trf_3522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3522(t0,t1);}

C_noret_decl(trf_3517)
static void C_fcall trf_3517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3517(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3517(t0,t1,t2);}

C_noret_decl(trf_3419)
static void C_fcall trf_3419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3419(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3419(t0,t1,t2,t3);}

C_noret_decl(trf_3450)
static void C_fcall trf_3450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3450(t0,t1);}

C_noret_decl(trf_3472)
static void C_fcall trf_3472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3472(t0,t1);}

C_noret_decl(trf_3270)
static void C_fcall trf_3270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3270(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3270(t0,t1,t2);}

C_noret_decl(trf_3007)
static void C_fcall trf_3007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3007(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3007(t0,t1,t2,t3);}

C_noret_decl(trf_2767)
static void C_fcall trf_2767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2767(t0,t1);}

C_noret_decl(trf_2773)
static void C_fcall trf_2773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2773(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2773(t0,t1);}

C_noret_decl(trf_2776)
static void C_fcall trf_2776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2776(t0,t1);}

C_noret_decl(trf_2874)
static void C_fcall trf_2874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2874(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2874(t0,t1,t2);}

C_noret_decl(trf_2815)
static void C_fcall trf_2815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2815(t0,t1);}

C_noret_decl(trf_2833)
static void C_fcall trf_2833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2833(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3360)){
C_save(t1);
C_rereclaim2(3360*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,466);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_h_intern(&lf[51],9,"file-open");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[53]=C_h_intern(&lf[53],17,"\003sysmake-c-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysexpand-home-path");
lf[55]=C_h_intern(&lf[55],10,"file-close");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],10,"file-write");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[65]=C_h_intern(&lf[65],12,"file-mkstemp");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[68]=C_h_intern(&lf[68],11,"file-select");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[70]=C_h_intern(&lf[70],8,"seek/set");
lf[71]=C_h_intern(&lf[71],8,"seek/end");
lf[72]=C_h_intern(&lf[72],8,"seek/cur");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[76]=C_h_intern(&lf[76],9,"file-stat");
lf[77]=C_h_intern(&lf[77],9,"file-size");
lf[78]=C_h_intern(&lf[78],22,"file-modification-time");
lf[79]=C_h_intern(&lf[79],16,"file-access-time");
lf[80]=C_h_intern(&lf[80],16,"file-change-time");
lf[81]=C_h_intern(&lf[81],10,"file-owner");
lf[82]=C_h_intern(&lf[82],16,"file-permissions");
lf[83]=C_h_intern(&lf[83],13,"regular-file\077");
lf[84]=C_h_intern(&lf[84],14,"symbolic-link\077");
lf[85]=C_h_intern(&lf[85],13,"stat-regular\077");
lf[86]=C_h_intern(&lf[86],15,"stat-directory\077");
lf[87]=C_h_intern(&lf[87],17,"character-device\077");
lf[88]=C_h_intern(&lf[88],17,"stat-char-device\077");
lf[89]=C_h_intern(&lf[89],13,"block-device\077");
lf[90]=C_h_intern(&lf[90],18,"stat-block-device\077");
lf[91]=C_h_intern(&lf[91],5,"fifo\077");
lf[92]=C_h_intern(&lf[92],10,"stat-fifo\077");
lf[93]=C_h_intern(&lf[93],13,"stat-symlink\077");
lf[94]=C_h_intern(&lf[94],7,"socket\077");
lf[95]=C_h_intern(&lf[95],12,"stat-socket\077");
lf[96]=C_h_intern(&lf[96],18,"set-file-position!");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[98]=C_h_intern(&lf[98],6,"stream");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[100]=C_h_intern(&lf[100],5,"port\077");
lf[101]=C_h_intern(&lf[101],13,"\000bounds-error");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[103]=C_h_intern(&lf[103],13,"file-position");
lf[104]=C_h_intern(&lf[104],16,"create-directory");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot stat file");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\026path segment is a file");
lf[109]=C_h_intern(&lf[109],12,"file-exists\077");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[111]=C_h_intern(&lf[111],12,"string-split");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[113]=C_h_intern(&lf[113],16,"change-directory");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[115]=C_h_intern(&lf[115],16,"delete-directory");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[117]=C_h_intern(&lf[117],10,"string-ref");
lf[118]=C_h_intern(&lf[118],6,"string");
lf[119]=C_h_intern(&lf[119],9,"directory");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[121]=C_h_intern(&lf[121],16,"\003sysmake-pointer");
lf[122]=C_h_intern(&lf[122],17,"current-directory");
lf[123]=C_h_intern(&lf[123],10,"directory\077");
lf[124]=C_h_intern(&lf[124],13,"\003sysfile-info");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[126]=C_h_intern(&lf[126],5,"null\077");
lf[127]=C_h_intern(&lf[127],6,"char=\077");
lf[128]=C_h_intern(&lf[128],8,"string=\077");
lf[129]=C_h_intern(&lf[129],16,"char-alphabetic\077");
lf[130]=C_h_intern(&lf[130],24,"get-environment-variable");
lf[131]=C_h_intern(&lf[131],17,"current-user-name");
lf[132]=C_h_intern(&lf[132],9,"condition");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[134]=C_h_intern(&lf[134],22,"with-exception-handler");
lf[135]=C_h_intern(&lf[135],30,"call-with-current-continuation");
lf[136]=C_h_intern(&lf[136],14,"canonical-path");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_h_intern(&lf[139],18,"string-intersperse");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[142]=C_h_intern(&lf[142],7,"reverse");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[154]=C_h_intern(&lf[154],13,"\003sysmake-port");
lf[155]=C_h_intern(&lf[155],21,"\003sysstream-port-class");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[157]=C_h_intern(&lf[157],15,"open-input-pipe");
lf[158]=C_h_intern(&lf[158],5,"\000text");
lf[159]=C_h_intern(&lf[159],7,"\000binary");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[161]=C_h_intern(&lf[161],16,"open-output-pipe");
lf[162]=C_h_intern(&lf[162],16,"close-input-pipe");
lf[163]=C_h_intern(&lf[163],23,"close-input/output-pipe");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[165]=C_h_intern(&lf[165],14,"\003syscheck-port");
lf[166]=C_h_intern(&lf[166],17,"close-output-pipe");
lf[167]=C_h_intern(&lf[167],20,"call-with-input-pipe");
lf[168]=C_h_intern(&lf[168],21,"call-with-output-pipe");
lf[169]=C_h_intern(&lf[169],20,"with-input-from-pipe");
lf[170]=C_h_intern(&lf[170],18,"\003sysstandard-input");
lf[171]=C_h_intern(&lf[171],19,"with-output-to-pipe");
lf[172]=C_h_intern(&lf[172],19,"\003sysstandard-output");
lf[173]=C_h_intern(&lf[173],11,"create-pipe");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[175]=C_h_intern(&lf[175],11,"signal/term");
lf[176]=C_h_intern(&lf[176],11,"signal/kill");
lf[177]=C_h_intern(&lf[177],10,"signal/int");
lf[178]=C_h_intern(&lf[178],10,"signal/hup");
lf[179]=C_h_intern(&lf[179],10,"signal/fpe");
lf[180]=C_h_intern(&lf[180],10,"signal/ill");
lf[181]=C_h_intern(&lf[181],11,"signal/segv");
lf[182]=C_h_intern(&lf[182],11,"signal/abrt");
lf[183]=C_h_intern(&lf[183],11,"signal/trap");
lf[184]=C_h_intern(&lf[184],11,"signal/quit");
lf[185]=C_h_intern(&lf[185],11,"signal/alrm");
lf[186]=C_h_intern(&lf[186],13,"signal/vtalrm");
lf[187]=C_h_intern(&lf[187],11,"signal/prof");
lf[188]=C_h_intern(&lf[188],9,"signal/io");
lf[189]=C_h_intern(&lf[189],10,"signal/urg");
lf[190]=C_h_intern(&lf[190],11,"signal/chld");
lf[191]=C_h_intern(&lf[191],11,"signal/cont");
lf[192]=C_h_intern(&lf[192],11,"signal/stop");
lf[193]=C_h_intern(&lf[193],11,"signal/tstp");
lf[194]=C_h_intern(&lf[194],11,"signal/pipe");
lf[195]=C_h_intern(&lf[195],11,"signal/xcpu");
lf[196]=C_h_intern(&lf[196],11,"signal/xfsz");
lf[197]=C_h_intern(&lf[197],11,"signal/usr1");
lf[198]=C_h_intern(&lf[198],11,"signal/usr2");
lf[199]=C_h_intern(&lf[199],12,"signal/winch");
lf[200]=C_h_intern(&lf[200],12,"signals-list");
lf[201]=C_h_intern(&lf[201],18,"\003sysinterrupt-hook");
lf[202]=C_h_intern(&lf[202],14,"signal-handler");
lf[203]=C_h_intern(&lf[203],19,"set-signal-handler!");
lf[204]=C_h_intern(&lf[204],16,"set-signal-mask!");
lf[205]=C_h_intern(&lf[205],14,"\000process-error");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[207]=C_h_intern(&lf[207],11,"signal-mask");
lf[208]=C_h_intern(&lf[208],14,"signal-masked\077");
lf[209]=C_h_intern(&lf[209],12,"signal-mask!");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[211]=C_h_intern(&lf[211],14,"signal-unmask!");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[213]=C_h_intern(&lf[213],18,"system-information");
lf[214]=C_h_intern(&lf[214],25,"\003syspeek-nonnull-c-string");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[216]=C_h_intern(&lf[216],15,"current-user-id");
lf[217]=C_h_intern(&lf[217],25,"current-effective-user-id");
lf[218]=C_h_intern(&lf[218],16,"current-group-id");
lf[219]=C_h_intern(&lf[219],26,"current-effective-group-id");
lf[220]=C_h_intern(&lf[220],16,"user-information");
lf[221]=C_h_intern(&lf[221],6,"vector");
lf[222]=C_h_intern(&lf[222],4,"list");
lf[223]=C_h_intern(&lf[223],27,"current-effective-user-name");
lf[224]=C_h_intern(&lf[224],17,"group-information");
lf[225]=C_h_intern(&lf[225],10,"get-groups");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[229]=C_h_intern(&lf[229],11,"set-groups!");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[232]=C_h_intern(&lf[232],17,"initialize-groups");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[234]=C_h_intern(&lf[234],10,"errno/perm");
lf[235]=C_h_intern(&lf[235],11,"errno/noent");
lf[236]=C_h_intern(&lf[236],10,"errno/srch");
lf[237]=C_h_intern(&lf[237],10,"errno/intr");
lf[238]=C_h_intern(&lf[238],8,"errno/io");
lf[239]=C_h_intern(&lf[239],12,"errno/noexec");
lf[240]=C_h_intern(&lf[240],10,"errno/badf");
lf[241]=C_h_intern(&lf[241],11,"errno/child");
lf[242]=C_h_intern(&lf[242],11,"errno/nomem");
lf[243]=C_h_intern(&lf[243],11,"errno/acces");
lf[244]=C_h_intern(&lf[244],11,"errno/fault");
lf[245]=C_h_intern(&lf[245],10,"errno/busy");
lf[246]=C_h_intern(&lf[246],12,"errno/notdir");
lf[247]=C_h_intern(&lf[247],11,"errno/isdir");
lf[248]=C_h_intern(&lf[248],11,"errno/inval");
lf[249]=C_h_intern(&lf[249],11,"errno/mfile");
lf[250]=C_h_intern(&lf[250],11,"errno/nospc");
lf[251]=C_h_intern(&lf[251],11,"errno/spipe");
lf[252]=C_h_intern(&lf[252],10,"errno/pipe");
lf[253]=C_h_intern(&lf[253],11,"errno/again");
lf[254]=C_h_intern(&lf[254],10,"errno/rofs");
lf[255]=C_h_intern(&lf[255],11,"errno/exist");
lf[256]=C_h_intern(&lf[256],16,"errno/wouldblock");
lf[257]=C_h_intern(&lf[257],10,"errno/2big");
lf[258]=C_h_intern(&lf[258],12,"errno/deadlk");
lf[259]=C_h_intern(&lf[259],9,"errno/dom");
lf[260]=C_h_intern(&lf[260],10,"errno/fbig");
lf[261]=C_h_intern(&lf[261],11,"errno/ilseq");
lf[262]=C_h_intern(&lf[262],11,"errno/mlink");
lf[263]=C_h_intern(&lf[263],17,"errno/nametoolong");
lf[264]=C_h_intern(&lf[264],11,"errno/nfile");
lf[265]=C_h_intern(&lf[265],11,"errno/nodev");
lf[266]=C_h_intern(&lf[266],11,"errno/nolck");
lf[267]=C_h_intern(&lf[267],11,"errno/nosys");
lf[268]=C_h_intern(&lf[268],14,"errno/notempty");
lf[269]=C_h_intern(&lf[269],11,"errno/notty");
lf[270]=C_h_intern(&lf[270],10,"errno/nxio");
lf[271]=C_h_intern(&lf[271],11,"errno/range");
lf[272]=C_h_intern(&lf[272],10,"errno/xdev");
lf[273]=C_h_intern(&lf[273],16,"change-file-mode");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[275]=C_h_intern(&lf[275],17,"change-file-owner");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[277]=C_h_intern(&lf[277],17,"file-read-access\077");
lf[278]=C_h_intern(&lf[278],18,"file-write-access\077");
lf[279]=C_h_intern(&lf[279],20,"file-execute-access\077");
lf[280]=C_h_intern(&lf[280],14,"create-session");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[282]=C_h_intern(&lf[282],16,"process-group-id");
lf[283]=C_h_intern(&lf[283],20,"create-symbolic-link");
lf[284]=C_h_intern(&lf[284],18,"create-symbol-link");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[286]=C_h_intern(&lf[286],9,"substring");
lf[287]=C_h_intern(&lf[287],18,"read-symbolic-link");
lf[288]=C_h_intern(&lf[288],12,"canonicalize");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[290]=C_h_intern(&lf[290],9,"file-link");
lf[291]=C_h_intern(&lf[291],9,"hard-link");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[293]=C_h_intern(&lf[293],12,"fileno/stdin");
lf[294]=C_h_intern(&lf[294],13,"fileno/stdout");
lf[295]=C_h_intern(&lf[295],13,"fileno/stderr");
lf[296]=C_h_intern(&lf[296],7,"\000append");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[304]=C_h_intern(&lf[304],16,"open-input-file*");
lf[305]=C_h_intern(&lf[305],17,"open-output-file*");
lf[306]=C_h_intern(&lf[306],12,"port->fileno");
lf[307]=C_h_intern(&lf[307],6,"socket");
lf[308]=C_h_intern(&lf[308],20,"\003systcp-port->fileno");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[311]=C_h_intern(&lf[311],25,"\003syspeek-unsigned-integer");
lf[312]=C_h_intern(&lf[312],16,"duplicate-fileno");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[314]=C_h_intern(&lf[314],15,"make-input-port");
lf[315]=C_h_intern(&lf[315],14,"set-port-name!");
lf[316]=C_h_intern(&lf[316],21,"\003syscustom-input-port");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[318]=C_h_intern(&lf[318],17,"\003systhread-yield!");
lf[319]=C_h_intern(&lf[319],25,"\003systhread-block-for-i/o!");
lf[320]=C_h_intern(&lf[320],18,"\003syscurrent-thread");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[325]=C_h_intern(&lf[325],17,"\003sysstring-append");
lf[326]=C_h_intern(&lf[326],15,"\003sysmake-string");
lf[327]=C_h_intern(&lf[327],20,"\003sysscan-buffer-line");
lf[328]=C_h_intern(&lf[328],4,"noop");
lf[329]=C_h_intern(&lf[329],16,"make-output-port");
lf[330]=C_h_intern(&lf[330],22,"\003syscustom-output-port");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[333]=C_h_intern(&lf[333],13,"file-truncate");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[336]=C_h_intern(&lf[336],4,"lock");
lf[337]=C_h_intern(&lf[337],9,"file-lock");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[339]=C_h_intern(&lf[339],18,"file-lock/blocking");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[341]=C_h_intern(&lf[341],14,"file-test-lock");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[343]=C_h_intern(&lf[343],11,"file-unlock");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[345]=C_h_intern(&lf[345],11,"create-fifo");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[348]=C_h_intern(&lf[348],6,"setenv");
lf[349]=C_h_intern(&lf[349],8,"unsetenv");
lf[350]=C_h_intern(&lf[350],25,"get-environment-variables");
lf[351]=C_h_intern(&lf[351],19,"current-environment");
lf[352]=C_h_intern(&lf[352],9,"prot/read");
lf[353]=C_h_intern(&lf[353],10,"prot/write");
lf[354]=C_h_intern(&lf[354],9,"prot/exec");
lf[355]=C_h_intern(&lf[355],9,"prot/none");
lf[356]=C_h_intern(&lf[356],9,"map/fixed");
lf[357]=C_h_intern(&lf[357],10,"map/shared");
lf[358]=C_h_intern(&lf[358],11,"map/private");
lf[359]=C_h_intern(&lf[359],13,"map/anonymous");
lf[360]=C_h_intern(&lf[360],8,"map/file");
lf[361]=C_h_intern(&lf[361],18,"map-file-to-memory");
lf[362]=C_h_intern(&lf[362],4,"mmap");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[364]=C_h_intern(&lf[364],20,"\003syspointer->address");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[366]=C_h_intern(&lf[366],16,"\003sysnull-pointer");
lf[367]=C_h_intern(&lf[367],22,"unmap-file-from-memory");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[369]=C_h_intern(&lf[369],26,"memory-mapped-file-pointer");
lf[370]=C_h_intern(&lf[370],19,"memory-mapped-file\077");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[373]=C_h_intern(&lf[373],19,"seconds->local-time");
lf[374]=C_h_intern(&lf[374],18,"\003sysdecode-seconds");
lf[375]=C_h_intern(&lf[375],17,"seconds->utc-time");
lf[376]=C_h_intern(&lf[376],15,"seconds->string");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[378]=C_h_intern(&lf[378],12,"time->string");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[381]=C_h_intern(&lf[381],12,"string->time");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[383]=C_h_intern(&lf[383],19,"local-time->seconds");
lf[384]=C_h_intern(&lf[384],15,"\003syscons-flonum");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[386]=C_h_intern(&lf[386],17,"utc-time->seconds");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[388]=C_h_intern(&lf[388],27,"local-timezone-abbreviation");
lf[389]=C_h_intern(&lf[389],5,"_exit");
lf[390]=C_h_intern(&lf[390],10,"set-alarm!");
lf[391]=C_h_intern(&lf[391],19,"set-buffering-mode!");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[393]=C_h_intern(&lf[393],5,"\000full");
lf[394]=C_h_intern(&lf[394],5,"\000line");
lf[395]=C_h_intern(&lf[395],5,"\000none");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[397]=C_h_intern(&lf[397],14,"terminal-port\077");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[400]=C_h_intern(&lf[400],13,"terminal-name");
lf[401]=C_h_intern(&lf[401],13,"terminal-size");
lf[402]=C_h_intern(&lf[402],6,"\000error");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[404]=C_h_intern(&lf[404],17,"\003sysmake-locative");
lf[405]=C_h_intern(&lf[405],8,"location");
lf[406]=C_h_intern(&lf[406],13,"get-host-name");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[408]=C_h_intern(&lf[408],6,"regexp");
lf[409]=C_h_intern(&lf[409],12,"string-match");
lf[410]=C_h_intern(&lf[410],12,"glob->regexp");
lf[411]=C_h_intern(&lf[411],13,"make-pathname");
lf[412]=C_h_intern(&lf[412],18,"decompose-pathname");
lf[413]=C_h_intern(&lf[413],4,"glob");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[416]=C_h_intern(&lf[416],12,"process-fork");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[418]=C_h_intern(&lf[418],24,"pathname-strip-directory");
lf[419]=C_h_intern(&lf[419],15,"process-execute");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[421]=C_h_intern(&lf[421],16,"\003sysprocess-wait");
lf[422]=C_h_intern(&lf[422],12,"process-wait");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[424]=C_h_intern(&lf[424],18,"current-process-id");
lf[425]=C_h_intern(&lf[425],17,"parent-process-id");
lf[426]=C_h_intern(&lf[426],5,"sleep");
lf[427]=C_h_intern(&lf[427],14,"process-signal");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[429]=C_h_intern(&lf[429],17,"\003sysshell-command");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[432]=C_h_intern(&lf[432],27,"\003sysshell-command-arguments");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[434]=C_h_intern(&lf[434],11,"process-run");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[436]=C_h_intern(&lf[436],11,"\003sysprocess");
lf[437]=C_h_intern(&lf[437],7,"process");
lf[438]=C_h_intern(&lf[438],8,"process*");
lf[439]=C_h_intern(&lf[439],10,"find-files");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[443]=C_h_intern(&lf[443],16,"\003sysdynamic-wind");
lf[444]=C_h_intern(&lf[444],13,"pathname-file");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[446]=C_h_intern(&lf[446],7,"regexp\077");
lf[447]=C_h_intern(&lf[447],19,"set-root-directory!");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[450]=C_h_intern(&lf[450],21,"set-process-group-id!");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[452]=C_h_intern(&lf[452],18,"getter-with-setter");
lf[453]=C_h_intern(&lf[453],26,"effective-group-id!-setter");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[455]=C_h_intern(&lf[455],12,"set-user-id!");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[457]=C_h_intern(&lf[457],25,"effective-user-id!-setter");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[460]=C_h_intern(&lf[460],23,"\003sysuser-interrupt-hook");
lf[461]=C_h_intern(&lf[461],11,"make-vector");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[464]=C_h_intern(&lf[464],17,"register-feature!");
lf[465]=C_h_intern(&lf[465],5,"posix");
C_register_lf2(lf,466,create_ptable());
t2=C_mutate(&lf[0] /* (set! c52 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2401,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k2399 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2402 in k2399 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2405 in k2402 in k2399 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 502  register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[464]+1)))(3,*((C_word*)lf[464]+1),t2,lf[465]);}

/* k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word ab[98],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2419,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2431,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* (set! file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2449,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! file-select-one ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2456,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1 /* (set! fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1 /* (set! fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1 /* (set! fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1 /* (set! fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1 /* (set! fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1 /* (set! open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1 /* (set! open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1 /* (set! open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1 /* (set! open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1 /* (set! perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1 /* (set! perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1 /* (set! perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1 /* (set! file-control ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2513,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[51]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2559,a[2]=t45,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[55]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2597,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[57]+1);
t49=C_mutate((C_word*)lf[58]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2612,a[2]=t48,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[62]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2654,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[65]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2693,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[68]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2751,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[70]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t54=C_mutate((C_word*)lf[71]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t55=C_mutate((C_word*)lf[72]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t56=C_mutate(&lf[73] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3007,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[76]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3044,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[77]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3076,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[78]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[79]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3088,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[80]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3094,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[81]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3100,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[82]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3106,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[83]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3112,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[84]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3121,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[85]+1 /* (set! stat-regular? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3130,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[86]+1 /* (set! stat-directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3139,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[87]+1 /* (set! character-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[88]+1 /* (set! stat-char-device? ...) */,*((C_word*)lf[87]+1));
t70=C_mutate((C_word*)lf[89]+1 /* (set! block-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3158,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[90]+1 /* (set! stat-block-device? ...) */,*((C_word*)lf[89]+1));
t72=C_mutate((C_word*)lf[91]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3168,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[92]+1 /* (set! stat-fifo? ...) */,*((C_word*)lf[91]+1));
t74=C_mutate((C_word*)lf[93]+1 /* (set! stat-symlink? ...) */,*((C_word*)lf[84]+1));
t75=C_mutate((C_word*)lf[94]+1 /* (set! socket? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3179,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[95]+1 /* (set! stat-socket? ...) */,*((C_word*)lf[94]+1));
t77=C_mutate((C_word*)lf[96]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3189,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t79=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8426,a[2]=((C_word)li250),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 846  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[452]+1)))(4,*((C_word*)lf[452]+1),t78,t79,*((C_word*)lf[96]+1));}

/* a8425 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8426,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8430,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8442,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 848  port? */
t5=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k8440 in a8425 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[98]);
if(C_truep(t3)){
t4=(C_word)C_ftell(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
f_8430(2,t5,t4);}
else{
t4=((C_word*)t0)[2];
f_8430(2,t4,C_fix(-1));}}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR));
t3=((C_word*)t0)[2];
f_8430(2,t3,t2);}
else{
/* posixunix.scm: 853  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[103],lf[463],((C_word*)t0)[3]);}}}

/* k8428 in a8425 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8433,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 855  posix-error */
t3=lf[3];
f_2431(6,t3,t2,lf[48],lf[103],lf[462],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k8431 in k8428 in a8425 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word ab[153],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=C_mutate((C_word*)lf[103]+1 /* (set! file-position ...) */,t1);
t3=C_mutate((C_word*)lf[104]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3251,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[113]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3369,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[115]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3393,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[117]+1);
t7=*((C_word*)lf[57]+1);
t8=*((C_word*)lf[118]+1);
t9=C_mutate((C_word*)lf[119]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3417,a[2]=t7,a[3]=t6,a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[123]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3574,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[122]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3597,a[2]=t11,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[126]+1);
t14=*((C_word*)lf[127]+1);
t15=*((C_word*)lf[128]+1);
t16=*((C_word*)lf[129]+1);
t17=*((C_word*)lf[117]+1);
t18=*((C_word*)lf[2]+1);
t19=*((C_word*)lf[130]+1);
t20=*((C_word*)lf[131]+1);
t21=*((C_word*)lf[122]+1);
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3661,a[2]=t21,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp);
t23=C_mutate((C_word*)lf[136]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3717,a[2]=t16,a[3]=t14,a[4]=t19,a[5]=t20,a[6]=t22,a[7]=t15,a[8]=t13,a[9]=t17,a[10]=t18,a[11]=((C_word)li51),tmp=(C_word)a,a+=12,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4052,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
t25=C_mutate((C_word*)lf[157]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4067,a[2]=t24,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp));
t26=C_mutate((C_word*)lf[161]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4103,a[2]=t24,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp));
t27=C_mutate((C_word*)lf[162]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4139,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[166]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[162]+1));
t29=*((C_word*)lf[157]+1);
t30=*((C_word*)lf[161]+1);
t31=*((C_word*)lf[162]+1);
t32=*((C_word*)lf[166]+1);
t33=C_mutate((C_word*)lf[167]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4155,a[2]=t29,a[3]=t31,a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp));
t34=C_mutate((C_word*)lf[168]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4179,a[2]=t30,a[3]=t32,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t35=C_mutate((C_word*)lf[169]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4203,a[2]=t29,a[3]=t31,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp));
t36=C_mutate((C_word*)lf[171]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4223,a[2]=t30,a[3]=t32,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t37=C_mutate((C_word*)lf[173]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4243,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[175]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t39=C_mutate((C_word*)lf[176]+1 /* (set! signal/kill ...) */,C_fix((C_word)SIGKILL));
t40=C_mutate((C_word*)lf[177]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t41=C_mutate((C_word*)lf[178]+1 /* (set! signal/hup ...) */,C_fix((C_word)SIGHUP));
t42=C_mutate((C_word*)lf[179]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t43=C_mutate((C_word*)lf[180]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t44=C_mutate((C_word*)lf[181]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t45=C_mutate((C_word*)lf[182]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t46=C_mutate((C_word*)lf[183]+1 /* (set! signal/trap ...) */,C_fix((C_word)SIGTRAP));
t47=C_mutate((C_word*)lf[184]+1 /* (set! signal/quit ...) */,C_fix((C_word)SIGQUIT));
t48=C_mutate((C_word*)lf[185]+1 /* (set! signal/alrm ...) */,C_fix((C_word)SIGALRM));
t49=C_mutate((C_word*)lf[186]+1 /* (set! signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t50=C_mutate((C_word*)lf[187]+1 /* (set! signal/prof ...) */,C_fix((C_word)SIGPROF));
t51=C_mutate((C_word*)lf[188]+1 /* (set! signal/io ...) */,C_fix((C_word)SIGIO));
t52=C_mutate((C_word*)lf[189]+1 /* (set! signal/urg ...) */,C_fix((C_word)SIGURG));
t53=C_mutate((C_word*)lf[190]+1 /* (set! signal/chld ...) */,C_fix((C_word)SIGCHLD));
t54=C_mutate((C_word*)lf[191]+1 /* (set! signal/cont ...) */,C_fix((C_word)SIGCONT));
t55=C_mutate((C_word*)lf[192]+1 /* (set! signal/stop ...) */,C_fix((C_word)SIGSTOP));
t56=C_mutate((C_word*)lf[193]+1 /* (set! signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t57=C_mutate((C_word*)lf[194]+1 /* (set! signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t58=C_mutate((C_word*)lf[195]+1 /* (set! signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t59=C_mutate((C_word*)lf[196]+1 /* (set! signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t60=C_mutate((C_word*)lf[197]+1 /* (set! signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t61=C_mutate((C_word*)lf[198]+1 /* (set! signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t62=C_mutate((C_word*)lf[199]+1 /* (set! signal/winch ...) */,C_fix((C_word)SIGWINCH));
t63=(C_word)C_a_i_list(&a,25,*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1),*((C_word*)lf[189]+1),*((C_word*)lf[190]+1),*((C_word*)lf[191]+1),*((C_word*)lf[192]+1),*((C_word*)lf[193]+1),*((C_word*)lf[194]+1),*((C_word*)lf[195]+1),*((C_word*)lf[196]+1),*((C_word*)lf[197]+1),*((C_word*)lf[198]+1),*((C_word*)lf[199]+1));
t64=C_mutate((C_word*)lf[200]+1 /* (set! signals-list ...) */,t63);
t65=*((C_word*)lf[201]+1);
t66=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[2],a[3]=t65,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1176 make-vector */
t67=*((C_word*)lf[461]+1);
((C_proc4)(void*)(*((C_word*)t67+1)))(4,t67,t66,C_fix(256),C_SCHEME_FALSE);}

/* k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4288,2,t0,t1);}
t2=C_mutate((C_word*)lf[202]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4290,a[2]=t1,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[203]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4299,a[2]=t1,a[3]=((C_word)li68),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[201]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4312,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[204]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4330,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[207]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4370,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[208]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4402,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[209]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4408,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[211]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4423,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8420,a[2]=((C_word)li249),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1232 set-signal-handler! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[203]+1)))(4,*((C_word*)lf[203]+1),t10,*((C_word*)lf[177]+1),t11);}

/* a8419 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8420,3,t0,t1,t2);}
/* posixunix.scm: 1234 ##sys#user-interrupt-hook */
((C_proc2)C_retrieve_proc(*((C_word*)lf[460]+1)))(2,*((C_word*)lf[460]+1),t1);}

/* k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4439,2,t0,t1);}
t2=C_mutate((C_word*)lf[213]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4441,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4481,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8402,a[2]=((C_word)li247),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8405,a[2]=((C_word)li248),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1258 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[452]+1)))(4,*((C_word*)lf[452]+1),t3,t4,t5);}

/* a8404 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8405,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8415,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1262 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8413 in a8404 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1263 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[455],lf[459],((C_word*)t0)[2]);}

/* a8401 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8402,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub730(C_SCHEME_UNDEFINED));}

/* k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4481,2,t0,t1);}
t2=C_mutate((C_word*)lf[216]+1 /* (set! current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4485,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8384,a[2]=((C_word)li245),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8387,a[2]=((C_word)li246),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1266 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[452]+1)))(4,*((C_word*)lf[452]+1),t3,t4,t5);}

/* a8386 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8387,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8397,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1270 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8395 in a8386 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1271 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[457],lf[458],((C_word*)t0)[2]);}

/* a8383 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8384,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub736(C_SCHEME_UNDEFINED));}

/* k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4485,2,t0,t1);}
t2=C_mutate((C_word*)lf[217]+1 /* (set! current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4489,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8366,a[2]=((C_word)li243),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8369,a[2]=((C_word)li244),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1275 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[452]+1)))(4,*((C_word*)lf[452]+1),t3,t4,t5);}

/* a8368 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8369,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8379,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1279 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8377 in a8368 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1280 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[455],lf[456],((C_word*)t0)[2]);}

/* a8365 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8366,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub742(C_SCHEME_UNDEFINED));}

/* k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4489,2,t0,t1);}
t2=C_mutate((C_word*)lf[218]+1 /* (set! current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8348,a[2]=((C_word)li241),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8351,a[2]=((C_word)li242),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1283 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[452]+1)))(4,*((C_word*)lf[452]+1),t3,t4,t5);}

/* a8350 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8351,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8361,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1287 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8359 in a8350 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1288 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[453],lf[454],((C_word*)t0)[2]);}

/* a8347 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8348,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub748(C_SCHEME_UNDEFINED));}

/* k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
t2=C_mutate((C_word*)lf[219]+1 /* (set! current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[220]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4495,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[131]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4562,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[223]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4576,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[224]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4601,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[225]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4694,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[229]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4757,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[232]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4831,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[234]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t11=C_mutate((C_word*)lf[235]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t12=C_mutate((C_word*)lf[236]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t13=C_mutate((C_word*)lf[237]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t14=C_mutate((C_word*)lf[238]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t15=C_mutate((C_word*)lf[239]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t16=C_mutate((C_word*)lf[240]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t17=C_mutate((C_word*)lf[241]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t18=C_mutate((C_word*)lf[242]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t19=C_mutate((C_word*)lf[243]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t20=C_mutate((C_word*)lf[244]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t21=C_mutate((C_word*)lf[245]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t22=C_mutate((C_word*)lf[246]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t23=C_mutate((C_word*)lf[247]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t24=C_mutate((C_word*)lf[248]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t25=C_mutate((C_word*)lf[249]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t26=C_mutate((C_word*)lf[250]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t27=C_mutate((C_word*)lf[251]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t28=C_mutate((C_word*)lf[252]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t29=C_mutate((C_word*)lf[253]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t30=C_mutate((C_word*)lf[254]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t31=C_mutate((C_word*)lf[255]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t32=C_mutate((C_word*)lf[256]+1 /* (set! errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t33=C_set_block_item(lf[257] /* errno/2big */,0,C_fix(0));
t34=C_set_block_item(lf[258] /* errno/deadlk */,0,C_fix(0));
t35=C_set_block_item(lf[259] /* errno/dom */,0,C_fix(0));
t36=C_set_block_item(lf[260] /* errno/fbig */,0,C_fix(0));
t37=C_set_block_item(lf[261] /* errno/ilseq */,0,C_fix(0));
t38=C_set_block_item(lf[262] /* errno/mlink */,0,C_fix(0));
t39=C_set_block_item(lf[263] /* errno/nametoolong */,0,C_fix(0));
t40=C_set_block_item(lf[264] /* errno/nfile */,0,C_fix(0));
t41=C_set_block_item(lf[265] /* errno/nodev */,0,C_fix(0));
t42=C_set_block_item(lf[266] /* errno/nolck */,0,C_fix(0));
t43=C_set_block_item(lf[267] /* errno/nosys */,0,C_fix(0));
t44=C_set_block_item(lf[268] /* errno/notempty */,0,C_fix(0));
t45=C_set_block_item(lf[269] /* errno/notty */,0,C_fix(0));
t46=C_set_block_item(lf[270] /* errno/nxio */,0,C_fix(0));
t47=C_set_block_item(lf[271] /* errno/range */,0,C_fix(0));
t48=C_set_block_item(lf[272] /* errno/xdev */,0,C_fix(0));
t49=C_mutate((C_word*)lf[273]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4895,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[275]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4922,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4952,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
t52=C_mutate((C_word*)lf[277]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4976,a[2]=t51,a[3]=((C_word)li91),tmp=(C_word)a,a+=4,tmp));
t53=C_mutate((C_word*)lf[278]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4982,a[2]=t51,a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[279]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4988,a[2]=t51,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[280]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4994,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t56=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5011,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8309,a[2]=((C_word)li239),tmp=(C_word)a,a+=3,tmp);
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8327,a[2]=((C_word)li240),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1503 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[452]+1)))(4,*((C_word*)lf[452]+1),t56,t57,t58);}

/* a8326 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8327,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[450]);
t5=(C_word)C_i_check_exact_2(t3,lf[450]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8343,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1515 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8341 in a8326 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1516 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[450],lf[451],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8308 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8309(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8309,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[282]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8316,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8322,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1508 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}}

/* k8320 in a8308 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1509 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[282],lf[449],((C_word*)t0)[2]);}

/* k8314 in a8308 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
t2=C_mutate((C_word*)lf[282]+1 /* (set! process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[283]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5013,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[286]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1536 make-string */
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word ab[257],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5050,2,t0,t1);}
t2=C_mutate((C_word*)lf[287]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5051,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li96),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[290]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5135,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[293]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[294]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[295]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5160,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5197,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
t9=C_mutate((C_word*)lf[304]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5212,a[2]=t7,a[3]=t8,a[4]=((C_word)li100),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[305]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5226,a[2]=t7,a[3]=t8,a[4]=((C_word)li101),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[306]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5240,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[312]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5285,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[314]+1);
t14=*((C_word*)lf[315]+1);
t15=C_mutate((C_word*)lf[316]+1 /* (set! custom-input-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5312,a[2]=t13,a[3]=t14,a[4]=((C_word)li123),tmp=(C_word)a,a+=5,tmp));
t16=*((C_word*)lf[329]+1);
t17=*((C_word*)lf[315]+1);
t18=C_mutate((C_word*)lf[330]+1 /* (set! custom-output-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5794,a[2]=t16,a[3]=t17,a[4]=((C_word)li135),tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[333]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6053,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6092,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6166,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[337]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6184,a[2]=t20,a[3]=t21,a[4]=((C_word)li139),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[339]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6199,a[2]=t20,a[3]=t21,a[4]=((C_word)li140),tmp=(C_word)a,a+=5,tmp));
t24=C_mutate((C_word*)lf[341]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6214,a[2]=t20,a[3]=t21,a[4]=((C_word)li141),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[343]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6236,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[345]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6264,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[91]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6307,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[348]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6333,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[349]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6350,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[350]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6370,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[351]+1 /* (set! current-environment ...) */,*((C_word*)lf[350]+1));
t32=C_mutate((C_word*)lf[352]+1 /* (set! prot/read ...) */,C_fix((C_word)PROT_READ));
t33=C_mutate((C_word*)lf[353]+1 /* (set! prot/write ...) */,C_fix((C_word)PROT_WRITE));
t34=C_mutate((C_word*)lf[354]+1 /* (set! prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t35=C_mutate((C_word*)lf[355]+1 /* (set! prot/none ...) */,C_fix((C_word)PROT_NONE));
t36=C_mutate((C_word*)lf[356]+1 /* (set! map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t37=C_mutate((C_word*)lf[357]+1 /* (set! map/shared ...) */,C_fix((C_word)MAP_SHARED));
t38=C_mutate((C_word*)lf[358]+1 /* (set! map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t39=C_mutate((C_word*)lf[359]+1 /* (set! map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t40=C_mutate((C_word*)lf[360]+1 /* (set! map/file ...) */,C_fix((C_word)MAP_FILE));
t41=C_mutate((C_word*)lf[361]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6474,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[367]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6536,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[369]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6571,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[370]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6580,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate(&lf[371] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6586,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[373]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6605,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[375]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6614,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[376]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6633,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[378]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6669,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[381]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6738,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[383]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6784,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[386]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6799,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[388]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6814,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[389]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6826,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[390]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6842,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[391]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6849,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[397]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6908,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate(&lf[398] /* (set! terminal-check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6927,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[400]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6959,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[401]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6982,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[406]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7017,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t62=*((C_word*)lf[408]+1);
t63=*((C_word*)lf[409]+1);
t64=*((C_word*)lf[410]+1);
t65=*((C_word*)lf[119]+1);
t66=*((C_word*)lf[411]+1);
t67=*((C_word*)lf[412]+1);
t68=C_mutate((C_word*)lf[413]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7029,a[2]=t64,a[3]=t62,a[4]=t65,a[5]=t63,a[6]=t66,a[7]=t67,a[8]=((C_word)li175),tmp=(C_word)a,a+=9,tmp));
t69=C_mutate((C_word*)lf[416]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7138,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7175,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp);
t71=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7194,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
t72=*((C_word*)lf[418]+1);
t73=C_mutate((C_word*)lf[419]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7213,a[2]=t72,a[3]=t71,a[4]=t70,a[5]=((C_word)li184),tmp=(C_word)a,a+=6,tmp));
t74=C_mutate((C_word*)lf[421]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7395,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[422]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7412,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[424]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7490,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[425]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7493,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[426]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7496,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[427]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7503,a[2]=((C_word)li192),tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[429]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7530,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp));
t81=C_mutate((C_word*)lf[432]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7539,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp));
t82=*((C_word*)lf[416]+1);
t83=*((C_word*)lf[419]+1);
t84=C_mutate((C_word*)lf[434]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7545,a[2]=t82,a[3]=t83,a[4]=((C_word)li195),tmp=(C_word)a,a+=5,tmp));
t85=*((C_word*)lf[173]+1);
t86=*((C_word*)lf[422]+1);
t87=*((C_word*)lf[416]+1);
t88=*((C_word*)lf[419]+1);
t89=*((C_word*)lf[312]+1);
t90=*((C_word*)lf[55]+1);
t91=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7601,a[2]=t86,a[3]=((C_word)li199),tmp=(C_word)a,a+=4,tmp);
t92=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7638,a[2]=t85,a[3]=((C_word)li202),tmp=(C_word)a,a+=4,tmp);
t93=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7658,a[2]=t90,a[3]=((C_word)li203),tmp=(C_word)a,a+=4,tmp);
t94=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7672,a[2]=t90,a[3]=((C_word)li204),tmp=(C_word)a,a+=4,tmp);
t95=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7705,a[2]=t92,a[3]=t87,a[4]=t94,a[5]=t88,a[6]=((C_word)li206),tmp=(C_word)a,a+=7,tmp);
t96=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7750,a[2]=t93,a[3]=((C_word)li207),tmp=(C_word)a,a+=4,tmp);
t97=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7761,a[2]=t93,a[3]=((C_word)li208),tmp=(C_word)a,a+=4,tmp);
t98=C_mutate((C_word*)lf[436]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7772,a[2]=t97,a[3]=t91,a[4]=t96,a[5]=t95,a[6]=((C_word)li211),tmp=(C_word)a,a+=7,tmp));
t99=C_set_block_item(lf[437] /* process */,0,C_SCHEME_UNDEFINED);
t100=C_set_block_item(lf[438] /* process* */,0,C_SCHEME_UNDEFINED);
t101=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7830,a[2]=((C_word)li216),tmp=(C_word)a,a+=3,tmp);
t102=C_mutate((C_word*)lf[437]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7907,a[2]=t101,a[3]=((C_word)li220),tmp=(C_word)a,a+=4,tmp));
t103=C_mutate((C_word*)lf[438]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7967,a[2]=t101,a[3]=((C_word)li224),tmp=(C_word)a,a+=4,tmp));
t104=*((C_word*)lf[413]+1);
t105=*((C_word*)lf[409]+1);
t106=*((C_word*)lf[411]+1);
t107=*((C_word*)lf[123]+1);
t108=C_mutate((C_word*)lf[439]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8027,a[2]=t107,a[3]=t106,a[4]=t104,a[5]=t105,a[6]=((C_word)li237),tmp=(C_word)a,a+=7,tmp));
t109=C_mutate((C_word*)lf[447]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8286,a[2]=((C_word)li238),tmp=(C_word)a,a+=3,tmp));
t110=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t110+1)))(2,t110,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8286,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[447]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8296,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8278,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t7=(C_word)C_i_foreign_string_argumentp(t5);
/* ##sys#make-c-string */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t7=(C_word)stub2135(C_SCHEME_UNDEFINED,C_SCHEME_FALSE);
t8=t4;
f_8296(t8,(C_word)C_fixnum_lessp(t7,C_fix(0)));}}

/* k8276 in set-root-directory! in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub2135(C_SCHEME_UNDEFINED,t1);
t3=((C_word*)t0)[2];
f_8296(t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* k8294 in set-root-directory! in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_8296(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2400 posix-error */
t2=lf[3];
f_2431(6,t2,((C_word*)t0)[3],lf[48],lf[447],lf[448],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_8027r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8027r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8027r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li232),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8194,a[2]=t5,a[3]=((C_word)li233),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8199,a[2]=t6,a[3]=((C_word)li234),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8204,a[2]=t7,a[3]=((C_word)li236),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action20592124 */
t9=t8;
f_8204(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id20602122 */
t11=t7;
f_8199(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit20612119 */
t13=t6;
f_8194(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body20572066 */
t15=t5;
f_8029(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action2059 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_8204(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8204,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8210,a[2]=((C_word)li235),tmp=(C_word)a,a+=3,tmp);
/* def-id20602122 */
t3=((C_word*)t0)[2];
f_8199(t3,t1,t2);}

/* a8209 in def-action2059 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8210,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id2060 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_8199(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8199,NULL,3,t0,t1,t2);}
/* def-limit20612119 */
t3=((C_word*)t0)[2];
f_8194(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit2061 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_8194(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8194,NULL,4,t0,t1,t2,t3);}
/* body20572066 */
t4=((C_word*)t0)[2];
f_8029(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_8029(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8029,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[439]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8036,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
if(C_truep((C_word)C_fixnump(t4))){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8189,a[2]=t4,a[3]=t7,a[4]=((C_word)li230),tmp=(C_word)a,a+=5,tmp);
t11=t8;
f_8036(t11,t10);}
else{
t10=t4;
t11=t8;
f_8036(t11,t10);}}
else{
t10=t8;
f_8036(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8181,a[2]=((C_word)li231),tmp=(C_word)a,a+=3,tmp));}}

/* f_8181 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8181(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8181,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_8189 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8189(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8189,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_8036(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8036,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_8169(2,t4,t2);}
else{
/* posixunix.scm: 2372 regexp? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[446]+1)))(3,*((C_word*)lf[446]+1),t3,((C_word*)t0)[11]);}}

/* k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8169,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8170,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word)li225),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8046,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8163,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2375 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[445]);}

/* k8161 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2375 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8046,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8048,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li229),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_8048(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_8048(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8048,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8067,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2381 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8067,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2382 pathname-file */
t3=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8149,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2389 pproc */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8147 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8149,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8156,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2389 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2390 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_8048(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k8154 in k8147 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2389 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8048(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8143,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[440]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[441]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2382 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_8048(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8082,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2383 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8080 in k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8082,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8092,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8094,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,a[5]=((C_word)li226),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word)li227),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8123,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,a[5]=((C_word)li228),tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[443]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8133,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8136,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2388 pproc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k8134 in k8080 in k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2388 action */
t2=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[5];
/* posixunix.scm: 2388 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8048(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k8131 in k8080 in k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2388 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8048(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8122 in k8080 in k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8123,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8098 in k8080 in k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8107,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8121,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2386 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],lf[442]);}

/* k8119 in a8098 in k8080 in k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2386 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8105 in a8098 in k8080 in k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8111,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8114,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2387 pproc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k8112 in k8105 in a8098 in k8080 in k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2387 action */
t2=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[5];
/* posixunix.scm: 2386 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8048(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k8109 in k8105 in a8098 in k8080 in k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2386 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8048(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8093 in k8080 in k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8094,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8090 in k8080 in k8141 in k8065 in loop in k8044 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2384 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8048(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8170 in k8167 in k8034 in body2057 in find-files in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_8170(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8170,3,t0,t1,t2);}
/* posixunix.scm: 2373 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7967(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_7967r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7967r(t0,t1,t2,t3);}}

static void C_ccall f_7967r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7969,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li221),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7974,a[2]=t4,a[3]=((C_word)li222),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7979,a[2]=t5,a[3]=((C_word)li223),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args20272038 */
t7=t6;
f_7979(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env20282036 */
t9=t5;
f_7974(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body20252033 */
t11=t4;
f_7969(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args2027 in process* in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7979,NULL,2,t0,t1);}
/* def-env20282036 */
t2=((C_word*)t0)[2];
f_7974(t2,t1,C_SCHEME_FALSE);}

/* def-env2028 in process* in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7974(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7974,NULL,3,t0,t1,t2);}
/* body20252033 */
t3=((C_word*)t0)[2];
f_7969(t3,t1,t2,C_SCHEME_FALSE);}

/* body2025 in process* in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7969(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7969,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2350 %process */
f_7830(t1,lf[438],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_7907r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7907r(t0,t1,t2,t3);}}

static void C_ccall f_7907r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7909,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li217),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7914,a[2]=t4,a[3]=((C_word)li218),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7919,a[2]=t5,a[3]=((C_word)li219),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args19962007 */
t7=t6;
f_7919(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env19972005 */
t9=t5;
f_7914(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body19942002 */
t11=t4;
f_7909(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args1996 in process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7919,NULL,2,t0,t1);}
/* def-env19972005 */
t2=((C_word*)t0)[2];
f_7914(t2,t1,C_SCHEME_FALSE);}

/* def-env1997 in process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7914(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7914,NULL,3,t0,t1,t2);}
/* body19942002 */
t3=((C_word*)t0)[2];
f_7909(t3,t1,t2,C_SCHEME_FALSE);}

/* body1994 in process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7909(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7909,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2347 %process */
f_7830(t1,lf[437],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7830(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7830,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7841,a[2]=t2,a[3]=((C_word)li212),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7832,a[2]=t9,a[3]=t2,a[4]=((C_word)li213),tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7867,a[2]=t1,a[3]=t3,a[4]=t8,a[5]=t7,a[6]=t2,a[7]=t10,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2336 chkstrlst */
t13=t12;
f_7867(t13,f_7832(t10,((C_word*)t8)[1]));}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7901,a[2]=t12,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2338 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[432]+1)))(3,*((C_word*)lf[432]+1),t13,((C_word*)t7)[1]);}}

/* k7899 in %process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7901,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2339 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[429]+1)))(2,*((C_word*)lf[429]+1),t3);}

/* k7903 in k7899 in %process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7867(t3,t2);}

/* k7865 in %process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7867(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7867,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[8])?f_7832(((C_word*)t0)[7],((C_word*)t0)[8]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li214),tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[3],a[3]=((C_word)li215),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a7880 in k7865 in %process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7881,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2343 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2344 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a7874 in k7865 in %process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
/* posixunix.scm: 2341 ##sys#process */
t2=*((C_word*)lf[436]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall f_7832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_list_2(t1,((C_word*)t0)[3]);
return(f_7841(((C_word*)t0)[2],t1));}

/* loop1954 in %process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall f_7841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=(C_word)C_slot(t1,C_fix(1));
t7=t4;
t1=t7;
goto loop;}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* ##sys#process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7772,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7778,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word)li209),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,a[10]=((C_word)li210),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a7783 in ##sys#process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7784,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7795,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7815,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2317 make-on-close */
t12=((C_word*)t0)[3];
f_7601(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k7813 in a7783 in ##sys#process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2316 input-port */
t2=((C_word*)t0)[7];
f_7750(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7793 in a7783 in ##sys#process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7799,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2319 make-on-close */
t4=((C_word*)t0)[6];
f_7601(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k7809 in k7793 in a7783 in ##sys#process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2318 output-port */
t2=((C_word*)t0)[7];
f_7761(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7797 in k7793 in a7783 in ##sys#process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7803,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7807,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2322 make-on-close */
t4=((C_word*)t0)[3];
f_7601(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k7805 in k7797 in k7793 in a7783 in ##sys#process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2321 input-port */
t2=((C_word*)t0)[7];
f_7750(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7801 in k7797 in k7793 in a7783 in ##sys#process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2315 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7777 in ##sys#process in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7778,2,t0,t1);}
/* posixunix.scm: 2310 spawn */
t2=((C_word*)t0)[8];
f_7705(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7761(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7761,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7765,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2306 connect-parent */
t8=((C_word*)t0)[2];
f_7658(t8,t7,t4,t5);}

/* k7763 in output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2307 ##sys#custom-output-port */
((C_proc8)C_retrieve_proc(*((C_word*)lf[330]+1)))(8,*((C_word*)lf[330]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7750(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7750,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7754,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2302 connect-parent */
t8=((C_word*)t0)[2];
f_7658(t8,t7,t4,t5);}

/* k7752 in input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2303 ##sys#custom-input-port */
((C_proc8)C_retrieve_proc(*((C_word*)lf[316]+1)))(8,*((C_word*)lf[316]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7705(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7705,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2289 needed-pipe */
t9=((C_word*)t0)[2];
f_7638(t9,t8,t6);}

/* k7707 in spawn in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2290 needed-pipe */
t3=((C_word*)t0)[2];
f_7638(t3,t2,((C_word*)t0)[5]);}

/* k7710 in k7707 in spawn in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2291 needed-pipe */
t3=((C_word*)t0)[2];
f_7638(t3,t2,((C_word*)t0)[6]);}

/* k7713 in k7710 in k7707 in spawn in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=((C_word*)t0)[4];
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_i_car(t3);
t6=t2;
f_7722(t6,(C_word)C_a_i_cons(&a,2,t4,t5));}
else{
t4=t2;
f_7722(t4,C_SCHEME_FALSE);}}

/* k7720 in k7713 in k7710 in k7707 in spawn in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7722,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7726,a[2]=((C_word*)t0)[12],a[3]=t1,a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word)li205),tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2294 process-fork */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a7727 in k7720 in k7713 in k7710 in k7707 in spawn in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7732,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2296 connect-child */
t3=((C_word*)t0)[7];
f_7672(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[293]+1));}

/* k7730 in a7727 in k7720 in k7713 in k7710 in k7707 in spawn in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7735,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_i_car(t3);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
/* posixunix.scm: 2297 connect-child */
t7=((C_word*)t0)[5];
f_7672(t7,t2,t6,((C_word*)t0)[2],*((C_word*)lf[294]+1));}
else{
/* posixunix.scm: 2297 connect-child */
t4=((C_word*)t0)[5];
f_7672(t4,t2,C_SCHEME_FALSE,((C_word*)t0)[2],*((C_word*)lf[294]+1));}}

/* k7733 in k7730 in a7727 in k7720 in k7713 in k7710 in k7707 in spawn in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7738,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[4];
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_i_car(t3);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
/* posixunix.scm: 2298 connect-child */
t7=((C_word*)t0)[3];
f_7672(t7,t2,t6,((C_word*)t0)[2],*((C_word*)lf[295]+1));}
else{
/* posixunix.scm: 2298 connect-child */
t4=((C_word*)t0)[3];
f_7672(t4,t2,C_SCHEME_FALSE,((C_word*)t0)[2],*((C_word*)lf[295]+1));}}

/* k7736 in k7733 in k7730 in a7727 in k7720 in k7713 in k7710 in k7707 in spawn in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2299 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7724 in k7720 in k7713 in k7710 in k7707 in spawn in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2292 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* connect-child in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7672(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7672,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7685,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2280 file-close */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k7683 in connect-child in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7685,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7597,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2254 duplicate-fileno */
t6=*((C_word*)lf[312]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k7595 in k7683 in connect-child in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2255 file-close */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7658(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7658,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7671,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2274 file-close */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k7669 in connect-parent in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7638,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7647,a[2]=((C_word*)t0)[2],a[3]=((C_word)li200),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7653,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a7652 in needed-pipe in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7653,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a7646 in needed-pipe in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7647,2,t0,t1);}
/* posixunix.scm: 2269 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* make-on-close in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7601(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7601,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7603,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,a[9]=((C_word)li198),tmp=(C_word)a,a+=10,tmp));}

/* f_7603 in make-on-close in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7603,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li196),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7624,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li197),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* a7623 */
static void C_ccall f_7624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7624,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* posixunix.scm: 2264 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[205],((C_word*)t0)[3],lf[435],((C_word*)t0)[2],t4);}}

/* a7617 */
static void C_ccall f_7618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7618,2,t0,t1);}
/* posixunix.scm: 2262 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7545(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7545r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7545r(t0,t1,t2,t3);}}

static void C_ccall f_7545r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7552,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2218 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k7550 in process-run in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7552,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2220 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2222 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[429]+1)))(2,*((C_word*)lf[429]+1),t3);}}
else{
t3=t1;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7569 in k7550 in process-run in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7575,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2222 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[432]+1)))(3,*((C_word*)lf[432]+1),t2,((C_word*)t0)[2]);}

/* k7573 in k7569 in k7550 in process-run in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2222 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7539,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[433],t2));}

/* ##sys#shell-command in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7534,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2208 get-environment-variable */
t3=*((C_word*)lf[130]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[431]);}

/* k7532 in ##sys#shell-command in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[430]);}}

/* process-signal in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7503(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7503r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7503r(t0,t1,t2,t3);}}

static void C_ccall f_7503r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[427]);
t7=(C_word)C_i_check_exact_2(t5,lf[427]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2205 posix-error */
t10=lf[3];
f_2431(7,t10,t1,lf[205],lf[427],lf[428],t2,t5);}
else{
t10=C_SCHEME_UNDEFINED;
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}}

/* sleep in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7496(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7496,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1796(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7493,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1793(C_SCHEME_UNDEFINED));}

/* current-process-id in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7490,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1791(C_SCHEME_UNDEFINED));}

/* process-wait in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7412(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_7412r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7412r(t0,t1,t2);}}

static void C_ccall f_7412r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[422]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7442,a[2]=t8,a[3]=t11,a[4]=((C_word)li186),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7448,a[2]=t11,a[3]=((C_word)li187),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t13,t14);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* a7447 in process-wait in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7448,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2191 posix-error */
t6=lf[3];
f_2431(6,t6,t1,lf[205],lf[422],lf[423],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2192 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a7441 in process-wait in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7442,2,t0,t1);}
/* posixunix.scm: 2189 ##sys#process-wait */
((C_proc4)C_retrieve_proc(*((C_word*)lf[421]+1)))(4,*((C_word*)lf[421]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7395,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
if(C_truep(t6)){
t7=(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status));
/* posixunix.scm: 2176 values */
C_values(5,0,t1,t5,t6,t7);}
else{
if(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))){
t7=(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status));
/* posixunix.scm: 2176 values */
C_values(5,0,t1,t5,t6,t7);}
else{
t7=(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status));
/* posixunix.scm: 2176 values */
C_values(5,0,t1,t5,t6,t7);}}}

/* process-execute in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7213(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_7213r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7213r(t0,t1,t2,t3);}}

static void C_ccall f_7213r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li181),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7342,a[2]=t4,a[3]=((C_word)li182),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7347,a[2]=t5,a[3]=((C_word)li183),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist17031750 */
t7=t6;
f_7347(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist17041748 */
t9=t5;
f_7342(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body17011709 */
t11=t4;
f_7215(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist1703 in process-execute in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7347,NULL,2,t0,t1);}
/* def-envlist17041748 */
t2=((C_word*)t0)[2];
f_7342(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist1704 in process-execute in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7342(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7342,NULL,3,t0,t1,t2);}
/* body17011709 */
t3=((C_word*)t0)[2];
f_7215(t3,t1,t2,C_SCHEME_FALSE);}

/* body1701 in process-execute in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7215(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7215,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[419]);
t5=(C_word)C_i_check_list_2(t2,lf[419]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7225,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2144 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k7223 in body1701 in process-execute in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7225,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_7175(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7233,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li180),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_7233(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* doloop1713 in k7223 in body1701 in process-execute in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7233(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7233,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_7175(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7246,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[419]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7279,a[2]=((C_word*)t0)[3],a[3]=((C_word)li179),tmp=(C_word)a,a+=4,tmp);
t8=t5;
f_7246(t8,f_7279(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_7246(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[419]);
t6=(C_word)C_block_size(t4);
t7=f_7175(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* doloop1721 in doloop1713 in k7223 in body1701 in process-execute in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall f_7279(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_7194(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[419]);
t5=(C_word)C_block_size(t3);
t6=f_7194(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k7244 in doloop1713 in k7223 in body1701 in process-execute in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7246(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7246,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7271,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2158 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k7269 in k7244 in doloop1713 in k7223 in body1701 in process-execute in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2158 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7247 in k7244 in doloop1713 in k7223 in body1701 in process-execute in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub1674(C_SCHEME_UNDEFINED);
t5=(C_word)stub1686(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2165 posix-error */
t6=lf[3];
f_2431(6,t6,((C_word*)t0)[3],lf[205],lf[419],lf[420],((C_word*)t0)[2]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* setenv in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall f_7194(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub1679(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall f_7175(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub1667(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7138(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7138r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7138r(t0,t1,t2);}}

static void C_ccall f_7138r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub1642(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2129 posix-error */
t5=lf[3];
f_2431(5,t5,t1,lf[205],lf[416],lf[417]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7160,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_vector_ref(t2,C_fix(0));
t9=t8;
((C_proc2)C_retrieve_proc(t9))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k7158 in process-fork in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t3=(C_word)stub1655(C_SCHEME_UNDEFINED,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7029(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_7029r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7029r(t0,t1,t2);}}

static void C_ccall f_7029r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=((C_word)li174),tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_7035(t6,t1,t2);}

/* conc-loop in glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7035(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7035,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7050,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word)li171),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word)li173),tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a7055 in conc-loop in glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7056,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7130,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t7=t3;
/* posixunix.scm: 2114 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}
else{
/* posixunix.scm: 2114 make-pathname */
t7=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,C_SCHEME_FALSE,lf[415],t4);}}

/* k7128 in a7055 in conc-loop in glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2114 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7058 in a7055 in conc-loop in glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2115 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k7061 in k7058 in a7055 in conc-loop in glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7070,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=((C_word*)t0)[5];
/* posixunix.scm: 2116 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}
else{
/* posixunix.scm: 2116 directory */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[414],C_SCHEME_TRUE);}}

/* k7068 in k7061 in k7058 in a7055 in conc-loop in glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7070,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7072,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li172),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_7072(t5,((C_word*)t0)[2],t1);}

/* loop in k7068 in k7061 in k7058 in a7055 in conc-loop in glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_7072(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7072,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixunix.scm: 2117 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_7035(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7089,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixunix.scm: 2118 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k7087 in loop in k7068 in k7061 in k7058 in a7055 in conc-loop in glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7089,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7099,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixunix.scm: 2119 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixunix.scm: 2120 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7072(t3,((C_word*)t0)[6],t2);}}

/* k7097 in k7087 in loop in k7068 in k7061 in k7058 in a7055 in conc-loop in glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7103,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixunix.scm: 2119 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7072(t4,t2,t3);}

/* k7101 in k7097 in k7087 in loop in k7068 in k7061 in k7058 in a7055 in conc-loop in glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7103,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a7049 in conc-loop in glob in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7050,2,t0,t1);}
/* posixunix.scm: 2113 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7021,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub1584(t3),C_fix(0));}

/* k7019 in get-host-name in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7024,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* posixunix.scm: 2095 posix-error */
t3=lf[3];
f_2431(5,t3,t2,lf[402],lf[406],lf[407]);}}

/* k7022 in k7019 in get-host-name in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6982,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6986,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2076 ##sys#terminal-check */
f_6927(t3,lf[401],t2);}

/* k6984 in terminal-size in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6986,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7006,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[404]+1)))(6,*((C_word*)lf[404]+1),t4,t2,C_fix(0),C_SCHEME_FALSE,lf[405]);}

/* k7004 in k6984 in terminal-size in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[404]+1)))(6,*((C_word*)lf[404]+1),t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[405]);}

/* k7008 in k7004 in k6984 in terminal-size in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_7010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_pointer_argumentp(t3);
t6=(C_word)C_i_foreign_pointer_argumentp(t1);
t7=(C_word)stub1565(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(C_word)C_eqp(C_fix(0),t7);
if(C_truep(t8)){
/* posixunix.scm: 2083 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2084 posix-error */
t9=lf[3];
f_2431(6,t9,((C_word*)t0)[4],lf[402],lf[401],lf[403],((C_word*)t0)[6]);}}

/* terminal-name in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6959,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6963,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2068 ##sys#terminal-check */
f_6927(t3,lf[400],t2);}

/* k6961 in terminal-name in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6963,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub1555(t4,t5);
/* ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* ##sys#terminal-check in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_6927(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6927,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6931,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2060 ##sys#check-port */
t5=*((C_word*)lf[165]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k6929 in ##sys#terminal-check in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[98],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* posixunix.scm: 2063 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[399],((C_word*)t0)[4]);}}

/* terminal-port? in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6908,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6912,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2055 ##sys#check-port */
t4=*((C_word*)lf[165]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[397]);}

/* k6910 in terminal-port? in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2056 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[311]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k6913 in k6910 in terminal-port? in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_tty_portp(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* set-buffering-mode! in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_6849r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_6849r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6849r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6853,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2040 ##sys#check-port */
t6=*((C_word*)lf[165]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[391]);}

/* k6851 in set-buffering-mode! in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6853,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[393]);
if(C_truep(t6)){
t7=t5;
f_6859(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[394]);
if(C_truep(t7)){
t8=C_fix((C_word)_IOLBF);
t9=t5;
f_6859(2,t9,t8);}
else{
t8=(C_word)C_eqp(t4,lf[395]);
if(C_truep(t8)){
t9=C_fix((C_word)_IONBF);
t10=t5;
f_6859(2,t10,t9);}
else{
/* posixunix.scm: 2046 ##sys#error */
t9=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[391],lf[396],((C_word*)t0)[4],((C_word*)t0)[2]);}}}}

/* k6857 in k6851 in set-buffering-mode! in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6859,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[391]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6868,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(7));
t5=(C_word)C_eqp(lf[98],t4);
if(C_truep(t5)){
t6=(C_word)C_setvbuf(((C_word*)t0)[2],t1,((C_word*)t0)[4]);
t7=t3;
f_6868(t7,(C_word)C_fixnum_lessp(t6,C_fix(0)));}
else{
t6=t3;
f_6868(t6,C_SCHEME_TRUE);}}

/* k6866 in k6857 in k6851 in set-buffering-mode! in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_6868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2052 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],lf[391],lf[392],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-alarm! in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6842,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1522(C_SCHEME_UNDEFINED,t3));}

/* _exit in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6826(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6826r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6826r(t0,t1,t2);}}

static void C_ccall f_6826r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
t4=t1;
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub1517(C_SCHEME_UNDEFINED,t5));}
else{
t3=t1;
t4=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub1517(C_SCHEME_UNDEFINED,t4));}}

/* local-timezone-abbreviation in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6814,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub1512(t2),C_fix(0));}

/* utc-time->seconds in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6799,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6803,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2008 check-time-vector */
f_6586(t3,lf[386],t2);}

/* k6801 in utc-time->seconds in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 2010 ##sys#cons-flonum */
t2=*((C_word*)lf[384]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2011 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[386],lf[387],((C_word*)t0)[3]);}}

/* local-time->seconds in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6784,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6788,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2002 check-time-vector */
f_6586(t3,lf[383],t2);}

/* k6786 in local-time->seconds in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 2004 ##sys#cons-flonum */
t2=*((C_word*)lf[384]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2005 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[383],lf[385],((C_word*)t0)[3]);}}

/* string->time in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6738r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6738r(t0,t1,t2,t3);}}

static void C_ccall f_6738r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6742,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_6742(2,t5,lf[382]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_6742(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k6740 in string->time in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6742,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[381]);
t3=(C_word)C_i_check_string_2(t1,lf[381]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6755,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1999 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* k6753 in k6740 in string->time in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6759,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1999 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6757 in k6753 in k6740 in string->time in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6759,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub1486(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6669(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6669r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6669r(t0,t1,t2,t3);}}

static void C_ccall f_6669r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6673,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_6673(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_6673(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k6671 in time->string in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1983 check-time-vector */
f_6586(t2,lf[378],((C_word*)t0)[2]);}

/* k6674 in k6671 in time->string in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6676,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[378]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6695,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1987 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1450(t4,t3),C_fix(0));}}

/* k6696 in k6674 in k6671 in time->string in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1991 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1992 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[378],lf[380],((C_word*)t0)[2]);}}

/* k6693 in k6674 in k6671 in time->string in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6695,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub1456(t3,t2,t1),C_fix(0));}

/* k6683 in k6674 in k6671 in time->string in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1988 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[378],lf[379],((C_word*)t0)[2]);}}

/* seconds->string in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6633(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6633,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[376]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6640,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t7=(C_word)C_i_foreign_integer_argumentp(t5);
t8=(C_word)stub1440(t6,t7);
/* ##sys#peek-c-string */
t9=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t4,t8,C_fix(0));}

/* k6638 in seconds->string in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1976 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1977 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[376],lf[377],((C_word*)t0)[2]);}}

/* seconds->utc-time in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6614,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[375]);
/* posixunix.scm: 1968 ##sys#decode-seconds */
t4=*((C_word*)lf[374]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6605,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[373]);
/* posixunix.scm: 1964 ##sys#decode-seconds */
t4=*((C_word*)lf[374]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* check-time-vector in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_6586(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6586,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1960 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[372],t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* memory-mapped-file? in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6580(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6580,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[362]));}

/* memory-mapped-file-pointer in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6571,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[362],lf[369]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6536(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6536r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6536r(t0,t1,t2,t3);}}

static void C_ccall f_6536r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[362],lf[367]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6549,a[2]=t6,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t8)){
t9=(C_word)C_i_foreign_pointer_argumentp(t8);
t10=(C_word)C_i_foreign_integer_argumentp(t6);
t11=(C_word)stub1409(C_SCHEME_UNDEFINED,t9,t10);
t12=t7;
f_6549(t12,(C_word)C_eqp(C_fix(0),t11));}
else{
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub1409(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t9);
t11=t7;
f_6549(t11,(C_word)C_eqp(C_fix(0),t10));}}

/* k6547 in unmap-file-from-memory in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_6549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1946 posix-error */
t2=lf[3];
f_2431(7,t2,((C_word*)t0)[4],lf[48],lf[367],lf[368],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* map-file-to-memory in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_6474r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_6474r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_6474r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6478,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_6478(2,t10,t2);}
else{
/* posixunix.scm: 1931 ##sys#null-pointer */
t10=*((C_word*)lf[366]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k6476 in map-file-to-memory in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6478,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6484,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_blockp(t1))){
if(C_truep((C_word)C_specialp(t1))){
t5=t4;
f_6484(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1934 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[60],lf[361],lf[365],t1);}}
else{
/* posixunix.scm: 1934 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[60],lf[361],lf[365],t1);}}

/* k6482 in k6476 in map-file-to-memory in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6484,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub1378(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6490,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6503,a[2]=t14,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t15,tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1936 ##sys#pointer->address */
t17=*((C_word*)lf[364]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,t14);}

/* k6501 in k6482 in k6476 in map-file-to-memory in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6503,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1937 posix-error */
t3=lf[3];
f_2431(11,t3,((C_word*)t0)[10],lf[48],lf[361],lf[363],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,3,lf[362],((C_word*)t0)[2],((C_word*)t0)[8]));}}

/* k6488 in k6482 in k6476 in map-file-to-memory in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6490,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[362],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* get-environment-variables in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6370,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6376,a[2]=t3,a[3]=((C_word)li148),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6376(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_6376(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6376,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6380,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1360(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k6378 in loop in get-environment-variables in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6380,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6388,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li147),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_6388(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k6378 in loop in get-environment-variables in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_6388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6388,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6414,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1895 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1898 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k6412 in scan in k6378 in loop in get-environment-variables in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6418,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1896 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k6416 in k6412 in scan in k6378 in loop in get-environment-variables in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6418,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6406,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1897 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6376(t5,t3,t4);}

/* k6404 in k6416 in k6412 in scan in k6378 in loop in get-environment-variables in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6406,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6350,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[349]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6358,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1884 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6356 in unsetenv in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_unsetenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6333,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[348]);
t5=(C_word)C_i_check_string_2(t3,lf[348]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6344,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1879 ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k6342 in setenv in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6348,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1879 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6346 in k6342 in setenv in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6307,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[91]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6314,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6331,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1867 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k6329 in fifo? in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1867 ##sys#file-info */
t2=*((C_word*)lf[124]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6312 in fifo? in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1870 posix-error */
t2=lf[3];
f_2431(6,t2,((C_word*)t0)[3],lf[48],lf[91],lf[347],((C_word*)t0)[2]);}}

/* create-fifo in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6264r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6264r(t0,t1,t2,t3);}}

static void C_ccall f_6264r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[345]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6271,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_6271(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_6271(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k6269 in create-fifo in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_6271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6271,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[345]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6292,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1861 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k6290 in k6269 in create-fifo in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1861 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6286 in k6269 in create-fifo in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1862 posix-error */
t3=lf[3];
f_2431(7,t3,((C_word*)t0)[3],lf[48],lf[345],lf[346],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* file-unlock in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6236,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[336],lf[343]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1851 posix-error */
t9=lf[3];
f_2431(6,t9,t1,lf[48],lf[343],lf[344],t2);}
else{
t9=C_SCHEME_UNDEFINED;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* file-test-lock in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6214(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6214r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6214r(t0,t1,t2,t3);}}

static void C_ccall f_6214r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6218,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1842 setup */
f_6092(t4,t2,t3,lf[341]);}

/* k6216 in file-test-lock in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1844 err */
f_6166(((C_word*)t0)[3],lf[342],t1,lf[341]);}}

/* file-lock/blocking in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6199r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6199r(t0,t1,t2,t3);}}

static void C_ccall f_6199r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6203,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1836 setup */
f_6092(t4,t2,t3,lf[339]);}

/* k6201 in file-lock/blocking in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1838 err */
f_6166(((C_word*)t0)[2],lf[340],t1,lf[339]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* file-lock in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6184(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6184r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6184r(t0,t1,t2,t3);}}

static void C_ccall f_6184r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6188,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1830 setup */
f_6092(t4,t2,t3,lf[337]);}

/* k6186 in file-lock in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1832 err */
f_6166(((C_word*)t0)[2],lf[338],t1,lf[337]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* err in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_6166(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6166,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1827 posix-error */
t8=lf[3];
f_2431(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_6092(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6092,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6114,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1819 ##sys#check-port */
t16=*((C_word*)lf[165]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k6112 in setup in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6114,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_6120(t6,t5);}
else{
t5=t3;
f_6120(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k6118 in k6112 in setup in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_6120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6120,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[336],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6053,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[333]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6063,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6070,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6077,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6081,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1802 ##sys#expand-home-path */
t9=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t7=(C_word)C_ftruncate(t2,t3);
t8=t5;
f_6063(t8,(C_word)C_fixnum_lessp(t7,C_fix(0)));}
else{
/* posixunix.scm: 1804 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[333],lf[335],t2);}}}

/* k6079 in file-truncate in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1802 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6075 in file-truncate in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_truncate(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_6063(t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* k6068 in file-truncate in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6063(t2,(C_word)C_fixnum_lessp(t1,C_fix(0)));}

/* k6061 in file-truncate in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_6063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 1806 posix-error */
t2=lf[3];
f_2431(7,t2,((C_word*)t0)[4],lf[48],lf[333],lf[334],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_5794r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5794r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5794r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li131),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5980,a[2]=t6,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5985,a[2]=t7,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5990,a[2]=t8,a[3]=((C_word)li134),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?12031269 */
t10=t9;
f_5990(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi12041267 */
t12=t8;
f_5985(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close12051264 */
t14=t7;
f_5980(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* body12011210 */
t16=t6;
f_5796(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-nonblocking?1203 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5990,NULL,2,t0,t1);}
/* def-bufi12041267 */
t2=((C_word*)t0)[2];
f_5985(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1204 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5985,NULL,3,t0,t1,t2);}
/* def-on-close12051264 */
t3=((C_word*)t0)[2];
f_5980(t3,t1,t2,C_fix(0));}

/* def-on-close1205 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5980(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5980,NULL,4,t0,t1,t2,t3);}
/* body12011210 */
t4=((C_word*)t0)[2];
f_5796(t4,t1,t2,t3,*((C_word*)lf[328]+1));}

/* body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5796(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5796,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5800,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1744 ##sys#file-nonblocking! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_5800(2,t6,C_SCHEME_UNDEFINED);}}

/* k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5800,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word)li124),tmp=(C_word)a,a+=7,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_5848(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5892,a[2]=t3,a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5906,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1763 ##sys#make-string */
t12=*((C_word*)lf[326]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_5906(2,t12,((C_word*)t0)[6]);}}}

/* k5904 in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5906,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_5848(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5907,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li130),tmp=(C_word)a,a+=7,tmp));}

/* f_5907 in k5904 in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5907,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5924,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word)li129),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_5924(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1779 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5802(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}

/* loop */
static void C_fcall f_5924(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5924,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5934,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1769 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5802(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_difference(t4,t2);
/* posixunix.scm: 1774 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k5932 in loop */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1771 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5924(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_5892 in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5892,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1762 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5802(t4,t1,t2,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5846 in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5848(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5848,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5852,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5857,a[2]=((C_word*)t0)[9],a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li126),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5884,a[2]=((C_word*)t0)[9],a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1782 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t5,t6,t7,t8);}

/* a5883 in k5846 in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5884,2,t0,t1);}
/* posixunix.scm: 1792 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* a5862 in k5846 in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5863,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5873,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1789 posix-error */
t3=lf[3];
f_2431(7,t3,t2,lf[48],((C_word*)t0)[3],lf[332],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1790 on-close */
t3=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}}}

/* k5871 in a5862 in k5846 in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1790 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a5856 in k5846 in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5857(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5857,3,t0,t1,t2);}
/* posixunix.scm: 1784 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* k5850 in k5846 in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5852,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5855,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1793 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k5853 in k5850 in k5846 in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5802(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5802,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5818,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1752 ##sys#thread-yield! */
t8=*((C_word*)lf[318]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1754 posix-error */
t7=lf[3];
f_2431(7,t7,t1,((C_word*)t0)[3],lf[48],lf[331],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5837,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1756 ##sys#substring */
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k5835 in poke in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1756 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5802(t3,((C_word*)t0)[2],t1,t2);}

/* k5816 in poke in k5798 in body1201 in ##sys#custom-output-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1753 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5802(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_5312r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5312r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5312r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,a[7]=((C_word)li118),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5701,a[2]=t6,a[3]=((C_word)li119),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5706,a[2]=t7,a[3]=((C_word)li120),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5711,a[2]=t8,a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5716,a[2]=t9,a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?10301174 */
t11=t10;
f_5716(t11,t1);}
else{
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi10311172 */
t13=t9;
f_5711(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close10321169 */
t15=t8;
f_5706(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?10331165 */
t17=t7;
f_5701(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
/* body10281038 */
t19=t6;
f_5314(t19,t1,t11,t13,t15,t17);}
else{
/* ##sys#error */
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[0],t18);}}}}}}

/* def-nonblocking?1030 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5716(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5716,NULL,2,t0,t1);}
/* def-bufi10311172 */
t2=((C_word*)t0)[2];
f_5711(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1031 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5711(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5711,NULL,3,t0,t1,t2);}
/* def-on-close10321169 */
t3=((C_word*)t0)[2];
f_5706(t3,t1,t2,C_fix(1));}

/* def-on-close1032 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5706(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5706,NULL,4,t0,t1,t2,t3);}
/* def-more?10331165 */
t4=((C_word*)t0)[2];
f_5701(t4,t1,t2,t3,*((C_word*)lf[328]+1));}

/* def-more?1033 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5701(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5701,NULL,5,t0,t1,t2,t3,t4);}
/* body10281038 */
t5=((C_word*)t0)[2];
f_5314(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5314(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5314,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5318,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1618 ##sys#file-nonblocking! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_5318(2,t7,C_SCHEME_UNDEFINED);}}

/* k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5318,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1620 ##sys#make-string */
t5=*((C_word*)lf[326]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_5324(2,t5,((C_word*)t0)[10]);}}

/* k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5325,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li104),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5348,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5356,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,a[10]=((C_word)li106),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5438,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5443,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word)li107),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5456,a[2]=t6,a[3]=t3,a[4]=t5,a[5]=((C_word)li108),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5468,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=((C_word)li109),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5489,a[2]=t8,a[3]=t7,a[4]=((C_word)li110),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5498,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li112),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5574,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,a[6]=((C_word)li117),tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1668 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t18))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a5573 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5574,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5580,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li116),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_5580(t7,t1,C_SCHEME_FALSE);}

/* loop in a5573 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5580(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5580,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5582,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li113),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5660,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word)li114),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5666,a[2]=((C_word*)t0)[2],a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5676,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1733 fetch */
t5=((C_word*)t0)[5];
f_5356(t5,t4);}}

/* k5674 in loop in a5573 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1735 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5580(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a5665 in loop in a5573 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5666,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1730 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5580(t4,t1,t2);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* a5659 in loop in a5573 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5660,2,t0,t1);}
/* posixunix.scm: 1728 ##sys#scan-buffer-line */
((C_proc6)C_retrieve_proc(*((C_word*)lf[327]+1)))(6,*((C_word*)lf[327]+1),t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a5573 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5582,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5589,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_5589(2,t8,(C_truep(t7)?t7:lf[324]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5632,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1710 ##sys#make-string */
t8=*((C_word*)lf[326]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k5630 in bumper in loop in a5573 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1716 ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[325]+1)))(4,*((C_word*)lf[325]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=t1;
t7=((C_word*)t0)[2];
f_5589(2,t7,t6);}}

/* k5587 in bumper in loop in a5573 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5589,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5599,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1720 fetch */
t5=((C_word*)t0)[3];
f_5356(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1725 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k5597 in k5587 in bumper in loop in a5573 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1721 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5497 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5498,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5506,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_5506(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_5506(t8,(C_word)C_fixnum_difference(t7,t5));}}

/* k5504 in a5497 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5506,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5508,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li111),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_5508(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k5504 in a5497 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5508(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5508,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* posixunix.scm: 1696 loop */
t19=t1;
t20=t13;
t21=t14;
t22=t15;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5556,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1698 fetch */
t7=((C_word*)t0)[2];
f_5356(t7,t6);}}}

/* k5554 in loop in k5504 in a5497 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* posixunix.scm: 1701 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5508(t3,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* a5488 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1686 fetch */
t3=((C_word*)t0)[2];
f_5356(t3,t2);}

/* k5491 in a5488 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1687 peek */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5348(((C_word*)t0)[2]));}

/* a5467 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5468,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5478,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1683 posix-error */
t3=lf[3];
f_2431(7,t3,t2,lf[48],((C_word*)t0)[3],lf[323],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1684 on-close */
t3=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}}}

/* k5476 in a5467 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1684 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a5455 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5456,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1678 ready? */
t3=((C_word*)t0)[2];
f_5325(t3,t1);}}

/* a5442 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5447,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1670 fetch */
t3=((C_word*)t0)[2];
f_5356(t3,t2);}

/* k5445 in a5442 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_5348(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k5436 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5438,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5441,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1737 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k5439 in k5436 in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5356(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5356,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5368,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li105),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_5368(t5,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop in fetch in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5368(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5368,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5384,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1645 ##sys#thread-block-for-i/o! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[319]+1)))(5,*((C_word*)lf[319]+1),t5,*((C_word*)lf[320]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1648 posix-error */
t5=lf[3];
f_2431(7,t5,t1,lf[48],((C_word*)t0)[6],lf[321],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5405,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1652 more? */
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k5403 in loop in fetch in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5405,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5408,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1654 ##sys#thread-yield! */
t3=*((C_word*)lf[318]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5414,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t3)[1]);
t9=C_set_block_item(((C_word*)t0)[4],0,C_fix(0));
t10=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
/* posixunix.scm: 1660 posix-error */
t7=lf[3];
f_2431(7,t7,t4,lf[48],((C_word*)t0)[3],lf[322],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t3)[1]);
t7=C_set_block_item(((C_word*)t0)[4],0,C_fix(0));
t8=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}}

/* k5412 in k5403 in loop in fetch in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5406 in k5403 in loop in fetch in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1655 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5368(t2,((C_word*)t0)[2]);}

/* k5382 in loop in fetch in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1646 ##sys#thread-yield! */
t3=*((C_word*)lf[318]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5385 in k5382 in loop in fetch in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1647 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5368(t2,((C_word*)t0)[2]);}

/* peek in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall f_5348(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]))){
return(C_SCHEME_END_OF_FILE);}
else{
t1=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);
return(t1);}}

/* ready? in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5325(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5325,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1626 ##sys#file-select-one */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[3]);}

/* k5327 in ready? in k5322 in k5316 in body1028 in ##sys#custom-input-port in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* posixunix.scm: 1630 posix-error */
t4=lf[3];
f_2431(7,t4,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[317],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t1));}}

/* duplicate-fileno in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5285r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5285r(t0,t1,t2,t3);}}

static void C_ccall f_5285r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[312]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5292,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_5292(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[312]);
t8=t5;
f_5292(t8,(C_word)C_dup2(t2,t6));}}

/* k5290 in duplicate-fileno in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5292,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5295,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1611 posix-error */
t3=lf[3];
f_2431(6,t3,t2,lf[48],lf[312],lf[313],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k5293 in k5290 in duplicate-fileno in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5240,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5244,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1593 ##sys#check-port */
t4=*((C_word*)lf[165]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[306]);}

/* k5242 in port->fileno in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5244,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[307],t2);
if(C_truep(t3)){
/* posixunix.scm: 1594 ##sys#tcp-port->fileno */
((C_proc3)C_retrieve_proc(*((C_word*)lf[308]+1)))(3,*((C_word*)lf[308]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1595 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[311]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k5277 in k5242 in port->fileno in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1600 posix-error */
t2=lf[3];
f_2431(6,t2,((C_word*)t0)[3],lf[60],lf[306],lf[309],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5262,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1598 posix-error */
t4=lf[3];
f_2431(6,t4,t3,lf[48],lf[306],lf[310],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k5260 in k5277 in k5242 in port->fileno in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5226r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5226r(t0,t1,t2,t3);}}

static void C_ccall f_5226r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[305]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5238,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1589 mode */
f_5160(t5,C_SCHEME_FALSE,t3);}

/* k5236 in open-output-file* in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5238,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1589 check */
f_5197(((C_word*)t0)[2],lf[305],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5212(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5212r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5212r(t0,t1,t2,t3);}}

static void C_ccall f_5212r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[304]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5224,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1585 mode */
f_5160(t5,C_SCHEME_TRUE,t3);}

/* k5222 in open-input-file* in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5224,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1585 check */
f_5197(((C_word*)t0)[2],lf[304],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5197(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5197,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1578 posix-error */
t6=lf[3];
f_2431(6,t6,t1,lf[48],t2,lf[302],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5210,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1579 ##sys#make-port */
t7=*((C_word*)lf[154]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[155]+1),lf[303],lf[98]);}}

/* k5208 in check in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* mode in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5160(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5160,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5168,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[296]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1572 ##sys#error */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[297],t5);}
else{
/* posixunix.scm: 1568 ##sys#make-c-string */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,lf[298]);}}
else{
/* posixunix.scm: 1573 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[299],t5);}}
else{
if(C_truep(t2)){
/* posixunix.scm: 1568 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[300]);}
else{
/* posixunix.scm: 1568 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[301]);}}}

/* k5166 in mode in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1568 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5135,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[290]);
t5=(C_word)C_i_check_string_2(t3,lf[290]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5148,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=t3;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5116,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t10=(C_word)C_i_foreign_string_argumentp(t7);
/* ##sys#make-c-string */
t11=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
t10=t9;
f_5116(2,t10,C_SCHEME_FALSE);}}

/* k5114 in file-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=(C_word)stub943(C_SCHEME_UNDEFINED,t1,C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
f_5148(t4,(C_word)C_fixnum_lessp(t3,C_fix(0)));}}

/* k5118 in k5114 in file-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub943(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_5148(t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* k5146 in file-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_5148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 1553 posix-error */
t2=lf[3];
f_2431(7,t2,((C_word*)t0)[4],lf[48],lf[291],lf[292],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* read-symbolic-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5051r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5051r(t0,t1,t2,t3);}}

static void C_ccall f_5051r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5055,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5055(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5055(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5053 in read-symbolic-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5055,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[287]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5062,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5090,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1539 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}

/* k5088 in k5053 in read-symbolic-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1539 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5060 in k5053 in read-symbolic-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5062,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5065,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1541 posix-error */
t4=lf[3];
f_2431(6,t4,t3,lf[48],lf[287],lf[289],((C_word*)t0)[2]);}
else{
t4=t3;
f_5065(2,t4,C_SCHEME_UNDEFINED);}}

/* k5063 in k5060 in k5053 in read-symbolic-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5068,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1542 substring */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5066 in k5063 in k5060 in k5053 in read-symbolic-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5074,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 1543 symbolic-link? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t2,t1);}
else{
t3=t1;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5072 in k5066 in k5063 in k5060 in k5053 in read-symbolic-link in k5048 in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 1544 read-symbolic-link */
((C_proc4)C_retrieve_proc(*((C_word*)lf[287]+1)))(4,*((C_word*)lf[287]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[288]);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* create-symbolic-link in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5013,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[283]);
t5=(C_word)C_i_check_string_2(t3,lf[283]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5034,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5046,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1527 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5044 in create-symbolic-link in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1527 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5032 in create-symbolic-link in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5042,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1528 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5040 in k5032 in create-symbolic-link in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1528 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5036 in k5032 in create-symbolic-link in k5009 in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1530 posix-error */
t3=lf[3];
f_2431(7,t3,((C_word*)t0)[4],lf[48],lf[284],lf[285],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* create-session in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4994,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4998,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5004,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1498 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k5002 in create-session in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1499 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[280],lf[281]);}

/* k4996 in create-session in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4988,3,t0,t1,t2);}
/* posixunix.scm: 1493 check */
f_4952(t1,t2,C_fix((C_word)X_OK),lf[279]);}

/* file-write-access? in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4982,3,t0,t1,t2);}
/* posixunix.scm: 1492 check */
f_4952(t1,t2,C_fix((C_word)W_OK),lf[278]);}

/* file-read-access? in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4976,3,t0,t1,t2);}
/* posixunix.scm: 1491 check */
f_4952(t1,t2,C_fix((C_word)R_OK),lf[277]);}

/* check in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_4952(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4952,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4970,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4974,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1488 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4972 in check in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1488 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4968 in check in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4970,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4962,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* posixunix.scm: 1489 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4960 in k4968 in check in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4922,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[275]);
t6=(C_word)C_i_check_exact_2(t3,lf[275]);
t7=(C_word)C_i_check_exact_2(t4,lf[275]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4946,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4950,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1478 ##sys#expand-home-path */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k4948 in change-file-owner in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1478 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4944 in change-file-owner in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1479 posix-error */
t3=lf[3];
f_2431(8,t3,((C_word*)t0)[3],lf[48],lf[275],lf[276],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* change-file-mode in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4895,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[273]);
t5=(C_word)C_i_check_exact_2(t3,lf[273]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4916,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4920,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1470 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4918 in change-file-mode in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1470 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4914 in change-file-mode in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1471 posix-error */
t3=lf[3];
f_2431(7,t3,((C_word*)t0)[3],lf[48],lf[273],lf[274],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* initialize-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4831,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[232]);
t5=(C_word)C_i_check_exact_2(t3,lf[232]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4844,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=t3;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4819,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t10=(C_word)C_i_foreign_string_argumentp(t7);
/* ##sys#make-c-string */
t11=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
t10=(C_word)C_i_foreign_fixnum_argumentp(t8);
t11=(C_word)stub849(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t10);
t12=t6;
f_4844(t12,(C_word)C_fixnum_lessp(t11,C_fix(0)));}}

/* k4817 in initialize-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t3=(C_word)stub849(C_SCHEME_UNDEFINED,t1,t2);
t4=((C_word*)t0)[2];
f_4844(t4,(C_word)C_fixnum_lessp(t3,C_fix(0)));}

/* k4842 in initialize-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_4844(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4844,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1391 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4845 in k4842 in initialize-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1392 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[232],lf[233],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4757,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4761,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
if(C_truep((C_word)stub806(C_SCHEME_UNDEFINED,t5))){
t6=t3;
f_4761(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1374 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[229],lf[231]);}}

/* k4759 in set-groups! in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4761,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4766,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li85),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4766(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop832 in k4759 in set-groups! in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_4766(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4766,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1379 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[229]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t12=t1;
t13=t7;
t14=t8;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k4780 in doloop832 in k4759 in set-groups! in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1380 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[229],lf[230],((C_word*)t0)[2]);}

/* get-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4694,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4698,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4752,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1360 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4698(2,t4,C_SCHEME_UNDEFINED);}}

/* k4750 in get-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1361 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[225],lf[228]);}

/* k4696 in get-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
if(C_truep((C_word)stub806(C_SCHEME_UNDEFINED,t3))){
t4=t2;
f_4701(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1363 ##sys#error */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[225],lf[227]);}}

/* k4699 in k4696 in get-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub802(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4733,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1365 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_4704(2,t5,C_SCHEME_UNDEFINED);}}

/* k4731 in k4699 in k4696 in get-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1366 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[225],lf[226]);}

/* k4702 in k4699 in k4696 in get-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4709,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li83),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4709(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k4702 in k4699 in k4696 in get-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_4709(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4709,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4723,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1370 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k4721 in loop in k4702 in k4699 in k4696 in get-groups in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4723,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* group-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4601r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4601r(t0,t1,t2,t3);}}

static void C_ccall f_4601r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4605,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4605(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4605(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4603 in group-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4608,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_4608(t3,(C_word)C_getgrgid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[224]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4659,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1334 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4657 in k4603 in group-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4608(t2,(C_word)C_getgrnam(t1));}

/* k4606 in k4603 in group-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_4608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4608,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4616 in k4606 in k4603 in group-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4622,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k4620 in k4616 in k4606 in k4603 in group-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4626,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4631,a[2]=t4,a[3]=((C_word)li81),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4631(t6,t2,C_fix(0));}

/* loop in k4620 in k4616 in k4606 in k4603 in group-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_4631(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4631,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4635,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub775(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4633 in loop in k4620 in k4616 in k4606 in k4603 in group-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4645,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1343 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4631(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k4643 in k4633 in loop in k4620 in k4616 in k4606 in k4603 in group-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4624 in k4620 in k4616 in k4606 in k4603 in group-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(((C_word*)t0)[5])){
t2=*((C_word*)lf[221]+1);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}
else{
t2=*((C_word*)lf[222]+1);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}}

/* current-effective-user-name in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4584,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4588,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1319 current-effective-user-id */
((C_proc2)C_retrieve_proc(*((C_word*)lf[217]+1)))(2,*((C_word*)lf[217]+1),t3);}

/* k4586 in current-effective-user-name in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1319 user-information */
((C_proc3)C_retrieve_proc(*((C_word*)lf[220]+1)))(3,*((C_word*)lf[220]+1),((C_word*)t0)[2],t1);}

/* k4582 in current-effective-user-name in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4570,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4574,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1316 current-user-id */
((C_proc2)C_retrieve_proc(*((C_word*)lf[216]+1)))(2,*((C_word*)lf[216]+1),t3);}

/* k4572 in current-user-name in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1316 user-information */
((C_proc3)C_retrieve_proc(*((C_word*)lf[220]+1)))(3,*((C_word*)lf[220]+1),((C_word*)t0)[2],t1);}

/* k4568 in current-user-name in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* user-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4495(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4495r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4495r(t0,t1,t2,t3);}}

static void C_ccall f_4495r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4499,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4499(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4499(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4497 in user-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_4502(t3,(C_word)C_getpwuid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[220]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4541,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1304 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4539 in k4497 in user-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4502(t2,(C_word)C_getpwnam(t1));}

/* k4500 in k4497 in user-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_4502(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4502,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4510 in k4500 in k4497 in user-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4516,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k4514 in k4510 in k4500 in k4497 in user-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4520,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k4518 in k4514 in k4510 in k4500 in k4497 in user-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4524,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k4522 in k4518 in k4514 in k4510 in k4500 in k4497 in user-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4528,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k4526 in k4522 in k4518 in k4514 in k4510 in k4500 in k4497 in user-information in k4491 in k4487 in k4483 in k4479 in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(((C_word*)t0)[7])){
t2=*((C_word*)lf[221]+1);
t3=t2;
((C_proc9)C_retrieve_proc(t3))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}
else{
t2=*((C_word*)lf[222]+1);
t3=t2;
((C_proc9)C_retrieve_proc(t3))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

/* system-information in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4445,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4474,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1249 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4445(2,t3,C_SCHEME_UNDEFINED);}}

/* k4472 in system-information in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1250 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[213],lf[215]);}

/* k4443 in system-information in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4452,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k4450 in k4443 in system-information in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4456,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k4454 in k4450 in k4443 in system-information in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4460,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k4458 in k4454 in k4450 in k4443 in system-information in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4464,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k4462 in k4458 in k4454 in k4450 in k4443 in system-information in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4468,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k4466 in k4462 in k4458 in k4454 in k4450 in k4443 in system-information in k4437 in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4423,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[211]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1228 posix-error */
t5=lf[3];
f_2431(5,t5,t1,lf[205],lf[211],lf[212]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* signal-mask! in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4408,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[209]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1222 posix-error */
t5=lf[3];
f_2431(5,t5,t1,lf[205],lf[209],lf[210]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* signal-masked? in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4402,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[208]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4376,a[2]=t3,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4376(t5,t1,*((C_word*)lf[200]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_4376(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4376,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_sigismember(t4))){
t6=(C_word)C_a_i_cons(&a,2,t4,t3);
/* posixunix.scm: 1212 loop */
t10=t1;
t11=t5;
t12=t6;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
t6=t3;
/* posixunix.scm: 1212 loop */
t10=t1;
t11=t5;
t12=t6;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}}

/* set-signal-mask! in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4330,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[204]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4348,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
t6=f_4348(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1205 posix-error */
t7=lf[3];
f_2431(5,t7,t1,lf[205],lf[204],lf[206]);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* loop690 in set-signal-mask! in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall f_4348(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_check_exact_2(t2,lf[204]);
t4=(C_word)C_sigaddset(t2);
t5=(C_word)C_slot(t1,C_fix(1));
t8=t5;
t1=t8;
goto loop;}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* ##sys#interrupt-hook in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4312,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4322,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1191 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1193 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k4320 in ##sys#interrupt-hook in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1192 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4299,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[203]);
if(C_truep(t3)){
t5=t2;
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}
else{
t5=(C_word)C_establish_signal_handler(t2,C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}}

/* signal-handler in k4286 in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4290,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[202]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4247,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1108 posix-error */
t3=lf[3];
f_2431(5,t3,t2,lf[48],lf[173],lf[174]);}
else{
/* posixunix.scm: 1109 values */
C_values(4,0,t1,C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}}

/* k4245 in create-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1109 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4223r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4223r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4223r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[172]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4227,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4225 in with-output-to-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4227,2,t0,t1);}
t2=C_mutate((C_word*)lf[172]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4233,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1096 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4232 in k4225 in with-output-to-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4233r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4233r(t0,t1,t2);}}

static void C_ccall f_4233r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4237,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1098 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4235 in a4232 in k4225 in with-output-to-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[172]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4203r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4203r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4203r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[170]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4207,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4205 in with-input-from-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4207,2,t0,t1);}
t2=C_mutate((C_word*)lf[170]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4213,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1086 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4212 in k4205 in with-input-from-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4213r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4213r(t0,t1,t2);}}

static void C_ccall f_4213r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4217,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1088 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4215 in a4212 in k4205 in with-input-from-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[170]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4179r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4179r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4179r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4183,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4181 in call-with-output-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4188,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4194,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1076 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4193 in k4181 in call-with-output-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4194r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4194r(t0,t1,t2);}}

static void C_ccall f_4194r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4198,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1079 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4196 in a4193 in k4181 in call-with-output-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4187 in k4181 in call-with-output-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
/* posixunix.scm: 1077 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4155r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4155r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4155r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4159,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4157 in call-with-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4164,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4170,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1068 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4169 in k4157 in call-with-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4170r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4170r(t0,t1,t2);}}

static void C_ccall f_4170r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4174,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1071 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4172 in a4169 in k4157 in call-with-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4163 in k4157 in call-with-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
/* posixunix.scm: 1069 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4139,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4143,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1055 ##sys#check-port */
t4=*((C_word*)lf[165]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[162]);}

/* k4141 in close-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4143,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4146,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1057 posix-error */
t5=lf[3];
f_2431(6,t5,t3,lf[48],lf[163],lf[164],((C_word*)t0)[3]);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k4144 in k4141 in close-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4103(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4103r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4103r(t0,t1,t2,t3);}}

static void C_ccall f_4103r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_string_2(t2,lf[161]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[158]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4117,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[158]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4124,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1050 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[159]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4134,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1051 ##sys#make-c-string */
t11=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixunix.scm: 1024 ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,lf[160],t6);}}}

/* k4132 in open-output-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4134,2,t0,t1);}
t2=(C_word)open_binary_output_pipe(&a,1,t1);
/* posixunix.scm: 1046 check */
f_4052(((C_word*)t0)[3],lf[161],((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* k4122 in open-output-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4124,2,t0,t1);}
t2=(C_word)open_text_output_pipe(&a,1,t1);
/* posixunix.scm: 1046 check */
f_4052(((C_word*)t0)[3],lf[161],((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* k4115 in open-output-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1046 check */
f_4052(((C_word*)t0)[3],lf[161],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4067r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4067r(t0,t1,t2,t3);}}

static void C_ccall f_4067r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_string_2(t2,lf[157]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[158]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4081,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[158]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4088,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1039 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[159]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4098,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1040 ##sys#make-c-string */
t11=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixunix.scm: 1024 ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,lf[160],t6);}}}

/* k4096 in open-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4098,2,t0,t1);}
t2=(C_word)open_binary_input_pipe(&a,1,t1);
/* posixunix.scm: 1035 check */
f_4052(((C_word*)t0)[3],lf[157],((C_word*)t0)[2],C_SCHEME_TRUE,t2);}

/* k4086 in open-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
t2=(C_word)open_text_input_pipe(&a,1,t1);
/* posixunix.scm: 1035 check */
f_4052(((C_word*)t0)[3],lf[157],((C_word*)t0)[2],C_SCHEME_TRUE,t2);}

/* k4079 in open-input-pipe in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1035 check */
f_4052(((C_word*)t0)[3],lf[157],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_4052(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4052,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1027 posix-error */
t6=lf[3];
f_2431(6,t6,t1,lf[48],t2,lf[153],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4065,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1028 ##sys#make-port */
t7=*((C_word*)lf[154]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[155]+1),lf[156],lf[98]);}}

/* k4063 in check in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3717,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[136]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3724,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3838,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 972  cwd */
t8=((C_word*)t0)[6];
f_3661(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=t4,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4024,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 974  sref */
t10=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_3844(t9,C_SCHEME_FALSE);}}}

/* k4022 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3844(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3844(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3844,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
t3=((C_word*)t0)[9];
f_3724(2,t3,t2);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3857,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 977  cwd */
t5=((C_word*)t0)[7];
f_3661(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3999,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4010,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 978  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k4008 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 978  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k3997 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3999,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4006,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 979  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[4];
f_3863(t2,C_SCHEME_FALSE);}}

/* k4004 in k3997 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3863(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3863,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3870,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 981  get-environment-variable */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[150]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3901,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 986  cwd */
t5=((C_word*)t0)[5];
f_3661(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3992,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 987  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k3990 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 987  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3969 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3988,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 988  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3907(t2,C_SCHEME_FALSE);}}

/* k3986 in k3969 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 988  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3975 in k3969 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 989  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3907(t2,C_SCHEME_FALSE);}}

/* k3982 in k3975 in k3969 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3907(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3905 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3907,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[8]);
/* posixunix.scm: 990  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[7],((C_word*)t0)[8],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3920,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3968,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 991  sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k3966 in k3905 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 991  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k3945 in k3905 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3964,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 992  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3920(2,t2,C_SCHEME_FALSE);}}

/* k3962 in k3945 in k3905 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 992  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3951 in k3945 in k3905 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3953,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3960,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 993  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3920(2,t2,C_SCHEME_FALSE);}}

/* k3958 in k3951 in k3945 in k3905 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 993  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3918 in k3905 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3920,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[6]);
/* posixunix.scm: 994  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[5],((C_word*)t0)[6],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 995  sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],C_fix(0));}}

/* k3942 in k3918 in k3905 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3944,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
f_3724(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 998  cwd */
t5=((C_word*)t0)[2];
f_3661(t5,t4);}}

/* k3938 in k3942 in k3918 in k3905 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 998  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[152],((C_word*)t0)[2]);}

/* k3899 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 986  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[151],((C_word*)t0)[2]);}

/* k3868 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3873(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3888,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 982  user */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k3886 in k3868 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 982  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[149],t1);}

/* k3871 in k3868 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3877,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 983  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k3875 in k3871 in k3868 in k3861 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 980  sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3855 in k3842 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 977  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[148],((C_word*)t0)[2]);}

/* k3836 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 972  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[147]);}

/* k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=t1;
/* string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[111]+1)))(4,*((C_word*)lf[111]+1),t2,t3,lf[146]);}

/* k3729 in k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li50),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3733(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k3729 in k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3733(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3733,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1001 null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3738 in loop in k3729 in k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3740,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3746,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1002 null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 1013 string=? */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[145],t4);}}

/* k3802 in k3738 in loop in k3729 in k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3804,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* posixunix.scm: 1011 loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3733(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3813,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 1015 string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[144],t3);}}

/* k3811 in k3802 in k3738 in loop in k3729 in k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3813,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
/* posixunix.scm: 1011 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3733(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[6]);
/* posixunix.scm: 1011 loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3733(t4,((C_word*)t0)[4],((C_word*)t0)[3],t3);}}

/* k3744 in k3738 in loop in k3729 in k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3746,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[137]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3782,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 1004 sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k3780 in k3744 in k3738 in loop in k3729 in k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3782,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3759,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3763,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_a_i_cons(&a,2,lf[141],((C_word*)t0)[2]);
/* posixunix.scm: 1007 reverse */
t7=*((C_word*)lf[142]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3778,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1010 reverse */
t6=*((C_word*)lf[142]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3776 in k3780 in k3744 in k3738 in loop in k3729 in k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-intersperse */
((C_proc4)C_retrieve_proc(*((C_word*)lf[139]+1)))(4,*((C_word*)lf[139]+1),((C_word*)t0)[2],t1,lf[140]);}

/* k3772 in k3780 in k3744 in k3738 in loop in k3729 in k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1008 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[143],t1);}

/* k3761 in k3780 in k3744 in k3738 in loop in k3729 in k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-intersperse */
((C_proc4)C_retrieve_proc(*((C_word*)lf[139]+1)))(4,*((C_word*)lf[139]+1),((C_word*)t0)[2],t1,lf[140]);}

/* k3757 in k3780 in k3744 in k3738 in loop in k3729 in k3722 in canonical-path in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1005 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[138],t1);}

/* cwd in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3661(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3661,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3668,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[2],a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a3669 in cwd in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3670,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3676,a[2]=t2,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3694,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[134]+1)))(4,*((C_word*)lf[134]+1),t1,t3,t4);}

/* a3693 in a3669 in cwd in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[3],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[2],a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3705 in a3693 in a3669 in cwd in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3706r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3706r(t0,t1,t2);}}

static void C_ccall f_3706r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3712,a[2]=t2,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
/* k544547 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3711 in a3705 in a3693 in a3669 in cwd in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3712,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3699 in a3693 in a3669 in cwd in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
/* posixunix.scm: 967  cw */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3675 in a3669 in cwd in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3676,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3682,a[2]=t2,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
/* k544547 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3681 in a3675 in a3669 in cwd in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[2],lf[132]))){
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[133]);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[133]);}}

/* k3666 in cwd in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* current-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3597r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3597r(t0,t1,t2);}}

static void C_ccall f_3597r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3601,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3601(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3601(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3599 in current-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3601,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 946  change-directory */
t2=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 947  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k3608 in k3599 in current-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 950  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 951  posix-error */
t3=lf[3];
f_2431(5,t3,((C_word*)t0)[2],lf[48],lf[122],lf[125]);}}

/* directory? in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3574,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[123]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3581,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3595,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 939  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3593 in directory? in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 939  ##sys#file-info */
t2=*((C_word*)lf[124]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3579 in directory? in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_3417r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3417r(t0,t1,t2);}}

static void C_ccall f_3417r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li36),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3517,a[2]=t3,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3522,a[2]=t4,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec436477 */
t6=t5;
f_3522(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?437475 */
t8=t4;
f_3517(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body434442 */
t10=t3;
f_3419(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec436 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3522,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3530,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 912  current-directory */
t3=*((C_word*)lf[122]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3528 in def-spec436 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?437475 */
t2=((C_word*)t0)[3];
f_3517(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?437 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3517(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3517,NULL,3,t0,t1,t2);}
/* body434442 */
t3=((C_word*)t0)[2];
f_3419(t3,t1,t2,C_SCHEME_FALSE);}

/* body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3419(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3419,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[119]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3426,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 914  make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k3424 in body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 915  ##sys#make-pointer */
t3=*((C_word*)lf[121]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3427 in k3424 in body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 916  ##sys#make-pointer */
t3=*((C_word*)lf[121]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3430 in k3427 in k3424 in body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3516,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 917  ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k3514 in k3430 in k3427 in k3424 in body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 917  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3434 in k3430 in k3427 in k3424 in body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3436,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 919  posix-error */
t3=lf[3];
f_2431(6,t3,((C_word*)t0)[7],lf[48],lf[119],lf[120],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word)li35),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3450(t6,((C_word*)t0)[7]);}}

/* loop in k3434 in k3430 in k3427 in k3424 in body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3450,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 927  ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k3458 in loop in k3434 in k3430 in k3427 in k3424 in body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 928  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_fix(0));}

/* k3461 in k3458 in loop in k3434 in k3430 in k3427 in k3424 in body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 929  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_3466(2,t3,C_SCHEME_FALSE);}}

/* k3464 in k3461 in k3458 in loop in k3434 in k3430 in k3427 in k3424 in body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_3472(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]);
t7=t2;
f_3472(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}
else{
t6=t2;
f_3472(t6,(C_word)C_i_not(((C_word*)t0)[2]));}}}
else{
t4=t2;
f_3472(t4,C_SCHEME_FALSE);}}

/* k3470 in k3464 in k3461 in k3458 in loop in k3434 in k3430 in k3427 in k3424 in body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3472,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 934  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3450(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 935  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3450(t3,t2);}}

/* k3480 in k3470 in k3464 in k3461 in k3458 in loop in k3434 in k3430 in k3427 in k3424 in body434 in directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3482,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3393,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[115]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3411,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3415,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 905  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3413 in delete-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 905  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3409 in delete-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* posixunix.scm: 906  posix-error */
t3=lf[3];
f_2431(6,t3,((C_word*)t0)[3],lf[48],lf[115],lf[116],((C_word*)t0)[2]);}}

/* change-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3369,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[113]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3387,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3391,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 899  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3389 in change-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 899  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3385 in change-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* posixunix.scm: 900  posix-error */
t3=lf[3];
f_2431(6,t3,((C_word*)t0)[3],lf[48],lf[113],lf[114],((C_word*)t0)[2]);}}

/* create-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3251r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3251r(t0,t1,t2,t3);}}

static void C_ccall f_3251r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3255,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3255(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3255(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3253 in create-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3255,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[104]);
if(C_truep(t1)){
t3=((C_word*)t0)[3];
t4=lf[105];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 887  string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[111]+1)))(4,*((C_word*)lf[111]+1),t6,t3,lf[112]);}
else{
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3348,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 863  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k3346 in k3253 in create-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* posixunix.scm: 864  posix-error */
t3=lf[3];
f_2431(6,t3,((C_word*)t0)[3],lf[48],lf[104],lf[106],((C_word*)t0)[2]);}}

/* k3266 in k3253 in create-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3268,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3270,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3270(t5,((C_word*)t0)[2],t1);}

/* loop383 in k3266 in k3253 in create-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3270(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3270,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3284,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 885  string-append */
t5=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[3])[1],lf[110],t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3282 in loop383 in k3266 in k3253 in create-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3284,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=((C_word*)((C_word*)t0)[5])[1];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3297,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3314,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 868  file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[109]+1)))(3,*((C_word*)lf[109]+1),t6,t3);}

/* k3312 in k3282 in loop383 in k3266 in k3253 in create-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 869  ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3297(2,t2,C_SCHEME_FALSE);}}

/* k3332 in k3312 in k3282 in loop383 in k3266 in k3253 in create-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_stat(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 870  posix-error */
t3=lf[3];
f_2431(6,t3,((C_word*)t0)[3],lf[48],lf[104],lf[107],((C_word*)t0)[2]);}
else{
t3=C_mk_bool(C_isdir);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_3297(2,t4,t3);}
else{
/* posixunix.scm: 873  posix-error */
t4=lf[3];
f_2431(6,t4,((C_word*)t0)[3],lf[48],lf[104],lf[108],((C_word*)t0)[2]);}}}

/* k3295 in k3282 in loop383 in k3266 in k3253 in create-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3297,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=((C_word*)((C_word*)t0)[5])[1];
f_3270(t3,((C_word*)t0)[4],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 863  ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3309 in k3295 in k3282 in loop383 in k3266 in k3253 in create-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=((C_word*)((C_word*)t0)[5])[1];
f_3270(t4,((C_word*)t0)[4],t3);}
else{
/* posixunix.scm: 864  posix-error */
t3=lf[3];
f_2431(6,t3,((C_word*)t0)[3],lf[48],lf[104],lf[106],((C_word*)t0)[2]);}}

/* k3285 in k3282 in loop383 in k3266 in k3253 in create-directory in k3247 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3270(t3,((C_word*)t0)[2],t2);}

/* set-file-position! in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3189r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3189r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3189r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[96]);
t8=(C_word)C_i_check_exact_2(t6,lf[96]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3202,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 837  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[101],lf[96],lf[102],t3,t2);}
else{
t10=t9;
f_3202(2,t10,C_SCHEME_UNDEFINED);}}

/* k3200 in set-file-position! in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3208,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3214,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 838  port? */
t4=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k3212 in k3200 in set-file-position! in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[98]);
if(C_truep(t3)){
t4=(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
f_3208(2,t5,t4);}
else{
t4=((C_word*)t0)[2];
f_3208(2,t4,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3208(2,t3,t2);}
else{
/* posixunix.scm: 842  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[96],lf[99],((C_word*)t0)[5]);}}}

/* k3206 in k3200 in set-file-position! in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 843  posix-error */
t2=lf[3];
f_2431(7,t2,((C_word*)t0)[4],lf[48],lf[96],lf[97],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* socket? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3179,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[94]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3186,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 827  ##sys#stat */
f_3007(t4,t2,C_SCHEME_FALSE,lf[94]);}

/* k3184 in socket? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* f_3168 in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3168,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[92]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3175,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 819  ##sys#stat */
f_3007(t4,t2,C_SCHEME_FALSE,lf[92]);}

/* k3173 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* block-device? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3158,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3165,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 812  ##sys#stat */
f_3007(t4,t2,C_SCHEME_FALSE,lf[89]);}

/* k3163 in block-device? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* character-device? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3148,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3155,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 805  ##sys#stat */
f_3007(t4,t2,C_SCHEME_FALSE,lf[87]);}

/* k3153 in character-device? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3139,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3146,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 800  ##sys#stat */
f_3007(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k3144 in stat-directory? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3130,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3137,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 795  ##sys#stat */
f_3007(t4,t2,C_SCHEME_FALSE,lf[85]);}

/* k3135 in stat-regular? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3121,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3128,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 790  ##sys#stat */
f_3007(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k3126 in symbolic-link? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3112,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[83]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3119,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 785  ##sys#stat */
f_3007(t4,t2,C_SCHEME_TRUE,lf[83]);}

/* k3117 in regular-file? in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3106,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 781  ##sys#stat */
f_3007(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k3108 in file-permissions in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3100,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3104,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 780  ##sys#stat */
f_3007(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k3102 in file-owner in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3094,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3098,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#stat */
f_3007(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k3096 in file-change-time in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3098,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3088,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3092,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 778  ##sys#stat */
f_3007(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k3090 in file-access-time in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3092,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3082,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3086,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 777  ##sys#stat */
f_3007(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k3084 in file-modification-time in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3086,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3076,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3080,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 776  ##sys#stat */
f_3007(t3,t2,C_SCHEME_FALSE,lf[77]);}

/* k3078 in file-size in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3080,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3044r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3044r(t0,t1,t2,t3);}}

static void C_ccall f_3044r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3048,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3055,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* posixunix.scm: 769  ##sys#stat */
f_3007(t4,t2,C_SCHEME_FALSE,lf[76]);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=(C_word)C_i_car(t3);
/* posixunix.scm: 769  ##sys#stat */
f_3007(t4,t2,t7,lf[76]);}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k3053 in file-stat in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 769  ##sys#stat */
f_3007(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[76]);}

/* k3046 in file-stat in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_3007(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3007,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3011,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_3011(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3032,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3039,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 760  ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 764  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[75],t2);}}}

/* k3037 in ##sys#stat in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 760  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3030 in ##sys#stat in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
t2=(C_word)C_lstat(t1);
t3=((C_word*)t0)[2];
f_3011(2,t3,t2);}
else{
t2=(C_word)C_stat(t1);
t3=((C_word*)t0)[2];
f_3011(2,t3,t2);}}

/* k3009 in ##sys#stat in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 766  posix-error */
t2=lf[3];
f_2431(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[74],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* file-select in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2751r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2751r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2751r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(13);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t10=(C_word)stub116(C_SCHEME_UNDEFINED,t9);
t11=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t12=(C_word)stub116(C_SCHEME_UNDEFINED,t11);
t13=(C_word)C_i_not(t2);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2767,a[2]=t6,a[3]=t8,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t13)){
t15=t14;
f_2767(t15,t13);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t15=C_set_block_item(t6,0,t2);
t16=t2;
t17=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t18=(C_word)C_i_foreign_fixnum_argumentp(t16);
t19=t14;
f_2767(t19,(C_word)stub121(C_SCHEME_UNDEFINED,t17,t18));}
else{
t15=(C_word)C_i_check_list_2(t2,lf[68]);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2972,a[2]=t6,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
t17=t14;
f_2767(t17,f_2972(t16,t2));}}}

/* loop150 in file-select in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall f_2972(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[2])[1],t2));
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t6=(C_word)C_i_foreign_fixnum_argumentp(t2);
t7=(C_word)stub121(C_SCHEME_UNDEFINED,t5,t6);
t8=(C_word)C_slot(t1,C_fix(1));
t11=t8;
t1=t11;
goto loop;}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* k2765 in file-select in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_2767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2767,NULL,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2773(t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[6]);
t5=((C_word*)t0)[6];
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=t3;
f_2773(t8,(C_word)stub121(C_SCHEME_UNDEFINED,t6,t7));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[6],lf[68]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[2],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t6=t3;
f_2773(t6,f_2930(t5,((C_word*)t0)[6]));}}}

/* loop175 in k2765 in file-select in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static C_word C_fcall f_2930(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[2])[1],t2));
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t6=(C_word)C_i_foreign_fixnum_argumentp(t2);
t7=(C_word)stub121(C_SCHEME_UNDEFINED,t5,t6);
t8=(C_word)C_slot(t1,C_fix(1));
t11=t8;
t1=t11;
goto loop;}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* k2771 in k2765 in file-select in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_2773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2773,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[68]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_2776(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_2776(t4,(C_word)C_C_select(t3));}}

/* k2774 in k2771 in k2765 in file-select in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_2776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2776,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 715  posix-error */
t2=lf[3];
f_2431(7,t2,((C_word*)t0)[4],lf[48],lf[68],lf[69],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[3]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
/* posixunix.scm: 716  values */
C_values(4,0,((C_word*)t0)[4],t4,C_SCHEME_END_OF_LIST);}
else{
/* posixunix.scm: 716  values */
C_values(4,0,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2815,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t4=((C_word*)t0)[3];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=t3;
f_2815(t7,(C_word)stub127(C_SCHEME_UNDEFINED,t5,t6));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2872,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2874,a[2]=t8,a[3]=t5,a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2874(t10,t6,((C_word*)t0)[3]);}}
else{
t4=t3;
f_2815(t4,C_SCHEME_FALSE);}}}}

/* loop205 in k2774 in k2771 in k2765 in file-select in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_2874(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2874,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
if(C_truep((C_word)stub127(C_SCHEME_UNDEFINED,t4,t5))){
t6=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=(C_word)C_slot(t2,C_fix(1));
t12=t1;
t13=t8;
t1=t12;
t2=t13;
goto loop;}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2870 in k2774 in k2771 in k2765 in file-select in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
f_2815(t3,t2);}

/* k2813 in k2774 in k2771 in k2765 in file-select in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_2815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2815,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[3];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)stub127(C_SCHEME_UNDEFINED,t3,t4);
/* posixunix.scm: 718  values */
C_values(4,0,((C_word*)t0)[2],t1,t5);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2831,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2833,a[2]=t6,a[3]=t3,a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2833(t8,t4,((C_word*)t0)[3]);}}
else{
/* posixunix.scm: 718  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* loop221 in k2813 in k2774 in k2771 in k2765 in file-select in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_fcall f_2833(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2833,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
if(C_truep((C_word)stub127(C_SCHEME_UNDEFINED,t4,t5))){
t6=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=(C_word)C_slot(t2,C_fix(1));
t12=t1;
t13=t8;
t1=t12;
t2=t13;
goto loop;}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2829 in k2813 in k2774 in k2771 in k2765 in file-select in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
/* posixunix.scm: 718  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* file-mkstemp in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2693,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[65]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2700,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 667  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2698 in file-mkstemp in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2700,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2706,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 671  posix-error */
t6=lf[3];
f_2431(6,t6,t4,lf[48],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t6=t4;
f_2706(2,t6,C_SCHEME_UNDEFINED);}}

/* k2704 in k2698 in file-mkstemp in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2713,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 672  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2711 in k2704 in k2698 in file-mkstemp in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 672  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2654r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2654r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2654r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[62]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2661,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_byteblockp(t3))){
t7=t6;
f_2661(2,t7,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 656  ##sys#signal-hook */
t7=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[60],lf[62],lf[64],t3);}}
else{
/* posixunix.scm: 656  ##sys#signal-hook */
t7=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[60],lf[62],lf[64],t3);}}

/* k2659 in file-write in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[62]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2670,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 661  posix-error */
t8=lf[3];
f_2431(7,t8,t6,lf[48],lf[62],lf[63],((C_word*)t0)[3],t3);}
else{
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t5);}}

/* k2668 in k2659 in file-write in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2612r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2612r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2612r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2622,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_2622(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixunix.scm: 644  make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k2620 in file-read in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(t1))){
if(C_truep((C_word)C_byteblockp(t1))){
t3=t2;
f_2625(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 646  ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[60],lf[58],lf[61],t1);}}
else{
/* posixunix.scm: 646  ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[60],lf[58],lf[61],t1);}}

/* k2623 in k2620 in file-read in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2625,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2628,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 649  posix-error */
t5=lf[3];
f_2431(7,t5,t3,lf[48],lf[58],lf[59],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2));}}

/* k2626 in k2623 in k2620 in file-read in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2628,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2597,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[55]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 637  posix-error */
t4=lf[3];
f_2431(6,t4,t1,lf[48],lf[55],lf[56],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* file-open in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2559r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2559r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2559r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[51]);
t8=(C_word)C_i_check_exact_2(t3,lf[51]);
t9=(C_word)C_i_check_exact_2(t6,lf[51]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2576,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2589,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 628  ##sys#expand-home-path */
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k2587 in file-open in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 628  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2574 in file-open in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2576,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2579,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 630  posix-error */
t5=lf[3];
f_2431(8,t5,t3,lf[48],lf[51],lf[52],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k2577 in k2574 in file-open in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2513r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2513r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2513r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2517,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2517(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2517(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k2515 in file-control in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[47]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[47]);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_integer_argumentp(t1);
t9=(C_word)stub33(C_SCHEME_UNDEFINED,t6,t7,t8);
t10=(C_word)C_eqp(t9,C_fix(-1));
if(C_truep(t10)){
/* posixunix.scm: 618  posix-error */
t11=lf[3];
f_2431(7,t11,((C_word*)t0)[2],lf[48],lf[47],lf[49],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t9);}}

/* ##sys#file-select-one in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2456,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub26(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-nonblocking! in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2449,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub22(C_SCHEME_UNDEFINED,t3));}

/* posix-error in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_2431r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2431r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2431r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2435,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 508  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k2433 in posix-error in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub12(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k2444 in k2433 in posix-error in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 509  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k2440 in k2433 in posix-error in k2417 in k2414 in k2411 in k2408 in k2405 in k2402 in k2399 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[611] = {
{"toplevel:posixunix_scm",(void*)C_posix_toplevel},
{"f_2401:posixunix_scm",(void*)f_2401},
{"f_2404:posixunix_scm",(void*)f_2404},
{"f_2407:posixunix_scm",(void*)f_2407},
{"f_2410:posixunix_scm",(void*)f_2410},
{"f_2413:posixunix_scm",(void*)f_2413},
{"f_2416:posixunix_scm",(void*)f_2416},
{"f_2419:posixunix_scm",(void*)f_2419},
{"f_8426:posixunix_scm",(void*)f_8426},
{"f_8442:posixunix_scm",(void*)f_8442},
{"f_8430:posixunix_scm",(void*)f_8430},
{"f_8433:posixunix_scm",(void*)f_8433},
{"f_3249:posixunix_scm",(void*)f_3249},
{"f_4288:posixunix_scm",(void*)f_4288},
{"f_8420:posixunix_scm",(void*)f_8420},
{"f_4439:posixunix_scm",(void*)f_4439},
{"f_8405:posixunix_scm",(void*)f_8405},
{"f_8415:posixunix_scm",(void*)f_8415},
{"f_8402:posixunix_scm",(void*)f_8402},
{"f_4481:posixunix_scm",(void*)f_4481},
{"f_8387:posixunix_scm",(void*)f_8387},
{"f_8397:posixunix_scm",(void*)f_8397},
{"f_8384:posixunix_scm",(void*)f_8384},
{"f_4485:posixunix_scm",(void*)f_4485},
{"f_8369:posixunix_scm",(void*)f_8369},
{"f_8379:posixunix_scm",(void*)f_8379},
{"f_8366:posixunix_scm",(void*)f_8366},
{"f_4489:posixunix_scm",(void*)f_4489},
{"f_8351:posixunix_scm",(void*)f_8351},
{"f_8361:posixunix_scm",(void*)f_8361},
{"f_8348:posixunix_scm",(void*)f_8348},
{"f_4493:posixunix_scm",(void*)f_4493},
{"f_8327:posixunix_scm",(void*)f_8327},
{"f_8343:posixunix_scm",(void*)f_8343},
{"f_8309:posixunix_scm",(void*)f_8309},
{"f_8322:posixunix_scm",(void*)f_8322},
{"f_8316:posixunix_scm",(void*)f_8316},
{"f_5011:posixunix_scm",(void*)f_5011},
{"f_5050:posixunix_scm",(void*)f_5050},
{"f_8286:posixunix_scm",(void*)f_8286},
{"f_8278:posixunix_scm",(void*)f_8278},
{"f_8296:posixunix_scm",(void*)f_8296},
{"f_8027:posixunix_scm",(void*)f_8027},
{"f_8204:posixunix_scm",(void*)f_8204},
{"f_8210:posixunix_scm",(void*)f_8210},
{"f_8199:posixunix_scm",(void*)f_8199},
{"f_8194:posixunix_scm",(void*)f_8194},
{"f_8029:posixunix_scm",(void*)f_8029},
{"f_8181:posixunix_scm",(void*)f_8181},
{"f_8189:posixunix_scm",(void*)f_8189},
{"f_8036:posixunix_scm",(void*)f_8036},
{"f_8169:posixunix_scm",(void*)f_8169},
{"f_8163:posixunix_scm",(void*)f_8163},
{"f_8046:posixunix_scm",(void*)f_8046},
{"f_8048:posixunix_scm",(void*)f_8048},
{"f_8067:posixunix_scm",(void*)f_8067},
{"f_8149:posixunix_scm",(void*)f_8149},
{"f_8156:posixunix_scm",(void*)f_8156},
{"f_8143:posixunix_scm",(void*)f_8143},
{"f_8082:posixunix_scm",(void*)f_8082},
{"f_8136:posixunix_scm",(void*)f_8136},
{"f_8133:posixunix_scm",(void*)f_8133},
{"f_8123:posixunix_scm",(void*)f_8123},
{"f_8099:posixunix_scm",(void*)f_8099},
{"f_8121:posixunix_scm",(void*)f_8121},
{"f_8107:posixunix_scm",(void*)f_8107},
{"f_8114:posixunix_scm",(void*)f_8114},
{"f_8111:posixunix_scm",(void*)f_8111},
{"f_8094:posixunix_scm",(void*)f_8094},
{"f_8092:posixunix_scm",(void*)f_8092},
{"f_8170:posixunix_scm",(void*)f_8170},
{"f_7967:posixunix_scm",(void*)f_7967},
{"f_7979:posixunix_scm",(void*)f_7979},
{"f_7974:posixunix_scm",(void*)f_7974},
{"f_7969:posixunix_scm",(void*)f_7969},
{"f_7907:posixunix_scm",(void*)f_7907},
{"f_7919:posixunix_scm",(void*)f_7919},
{"f_7914:posixunix_scm",(void*)f_7914},
{"f_7909:posixunix_scm",(void*)f_7909},
{"f_7830:posixunix_scm",(void*)f_7830},
{"f_7901:posixunix_scm",(void*)f_7901},
{"f_7905:posixunix_scm",(void*)f_7905},
{"f_7867:posixunix_scm",(void*)f_7867},
{"f_7881:posixunix_scm",(void*)f_7881},
{"f_7875:posixunix_scm",(void*)f_7875},
{"f_7832:posixunix_scm",(void*)f_7832},
{"f_7841:posixunix_scm",(void*)f_7841},
{"f_7772:posixunix_scm",(void*)f_7772},
{"f_7784:posixunix_scm",(void*)f_7784},
{"f_7815:posixunix_scm",(void*)f_7815},
{"f_7795:posixunix_scm",(void*)f_7795},
{"f_7811:posixunix_scm",(void*)f_7811},
{"f_7799:posixunix_scm",(void*)f_7799},
{"f_7807:posixunix_scm",(void*)f_7807},
{"f_7803:posixunix_scm",(void*)f_7803},
{"f_7778:posixunix_scm",(void*)f_7778},
{"f_7761:posixunix_scm",(void*)f_7761},
{"f_7765:posixunix_scm",(void*)f_7765},
{"f_7750:posixunix_scm",(void*)f_7750},
{"f_7754:posixunix_scm",(void*)f_7754},
{"f_7705:posixunix_scm",(void*)f_7705},
{"f_7709:posixunix_scm",(void*)f_7709},
{"f_7712:posixunix_scm",(void*)f_7712},
{"f_7715:posixunix_scm",(void*)f_7715},
{"f_7722:posixunix_scm",(void*)f_7722},
{"f_7728:posixunix_scm",(void*)f_7728},
{"f_7732:posixunix_scm",(void*)f_7732},
{"f_7735:posixunix_scm",(void*)f_7735},
{"f_7738:posixunix_scm",(void*)f_7738},
{"f_7726:posixunix_scm",(void*)f_7726},
{"f_7672:posixunix_scm",(void*)f_7672},
{"f_7685:posixunix_scm",(void*)f_7685},
{"f_7597:posixunix_scm",(void*)f_7597},
{"f_7658:posixunix_scm",(void*)f_7658},
{"f_7671:posixunix_scm",(void*)f_7671},
{"f_7638:posixunix_scm",(void*)f_7638},
{"f_7653:posixunix_scm",(void*)f_7653},
{"f_7647:posixunix_scm",(void*)f_7647},
{"f_7601:posixunix_scm",(void*)f_7601},
{"f_7603:posixunix_scm",(void*)f_7603},
{"f_7624:posixunix_scm",(void*)f_7624},
{"f_7618:posixunix_scm",(void*)f_7618},
{"f_7545:posixunix_scm",(void*)f_7545},
{"f_7552:posixunix_scm",(void*)f_7552},
{"f_7571:posixunix_scm",(void*)f_7571},
{"f_7575:posixunix_scm",(void*)f_7575},
{"f_7539:posixunix_scm",(void*)f_7539},
{"f_7530:posixunix_scm",(void*)f_7530},
{"f_7534:posixunix_scm",(void*)f_7534},
{"f_7503:posixunix_scm",(void*)f_7503},
{"f_7496:posixunix_scm",(void*)f_7496},
{"f_7493:posixunix_scm",(void*)f_7493},
{"f_7490:posixunix_scm",(void*)f_7490},
{"f_7412:posixunix_scm",(void*)f_7412},
{"f_7448:posixunix_scm",(void*)f_7448},
{"f_7442:posixunix_scm",(void*)f_7442},
{"f_7395:posixunix_scm",(void*)f_7395},
{"f_7213:posixunix_scm",(void*)f_7213},
{"f_7347:posixunix_scm",(void*)f_7347},
{"f_7342:posixunix_scm",(void*)f_7342},
{"f_7215:posixunix_scm",(void*)f_7215},
{"f_7225:posixunix_scm",(void*)f_7225},
{"f_7233:posixunix_scm",(void*)f_7233},
{"f_7279:posixunix_scm",(void*)f_7279},
{"f_7246:posixunix_scm",(void*)f_7246},
{"f_7271:posixunix_scm",(void*)f_7271},
{"f_7249:posixunix_scm",(void*)f_7249},
{"f_7194:posixunix_scm",(void*)f_7194},
{"f_7175:posixunix_scm",(void*)f_7175},
{"f_7138:posixunix_scm",(void*)f_7138},
{"f_7160:posixunix_scm",(void*)f_7160},
{"f_7029:posixunix_scm",(void*)f_7029},
{"f_7035:posixunix_scm",(void*)f_7035},
{"f_7056:posixunix_scm",(void*)f_7056},
{"f_7130:posixunix_scm",(void*)f_7130},
{"f_7060:posixunix_scm",(void*)f_7060},
{"f_7063:posixunix_scm",(void*)f_7063},
{"f_7070:posixunix_scm",(void*)f_7070},
{"f_7072:posixunix_scm",(void*)f_7072},
{"f_7089:posixunix_scm",(void*)f_7089},
{"f_7099:posixunix_scm",(void*)f_7099},
{"f_7103:posixunix_scm",(void*)f_7103},
{"f_7050:posixunix_scm",(void*)f_7050},
{"f_7017:posixunix_scm",(void*)f_7017},
{"f_7021:posixunix_scm",(void*)f_7021},
{"f_7024:posixunix_scm",(void*)f_7024},
{"f_6982:posixunix_scm",(void*)f_6982},
{"f_6986:posixunix_scm",(void*)f_6986},
{"f_7006:posixunix_scm",(void*)f_7006},
{"f_7010:posixunix_scm",(void*)f_7010},
{"f_6959:posixunix_scm",(void*)f_6959},
{"f_6963:posixunix_scm",(void*)f_6963},
{"f_6927:posixunix_scm",(void*)f_6927},
{"f_6931:posixunix_scm",(void*)f_6931},
{"f_6908:posixunix_scm",(void*)f_6908},
{"f_6912:posixunix_scm",(void*)f_6912},
{"f_6915:posixunix_scm",(void*)f_6915},
{"f_6849:posixunix_scm",(void*)f_6849},
{"f_6853:posixunix_scm",(void*)f_6853},
{"f_6859:posixunix_scm",(void*)f_6859},
{"f_6868:posixunix_scm",(void*)f_6868},
{"f_6842:posixunix_scm",(void*)f_6842},
{"f_6826:posixunix_scm",(void*)f_6826},
{"f_6814:posixunix_scm",(void*)f_6814},
{"f_6799:posixunix_scm",(void*)f_6799},
{"f_6803:posixunix_scm",(void*)f_6803},
{"f_6784:posixunix_scm",(void*)f_6784},
{"f_6788:posixunix_scm",(void*)f_6788},
{"f_6738:posixunix_scm",(void*)f_6738},
{"f_6742:posixunix_scm",(void*)f_6742},
{"f_6755:posixunix_scm",(void*)f_6755},
{"f_6759:posixunix_scm",(void*)f_6759},
{"f_6669:posixunix_scm",(void*)f_6669},
{"f_6673:posixunix_scm",(void*)f_6673},
{"f_6676:posixunix_scm",(void*)f_6676},
{"f_6698:posixunix_scm",(void*)f_6698},
{"f_6695:posixunix_scm",(void*)f_6695},
{"f_6685:posixunix_scm",(void*)f_6685},
{"f_6633:posixunix_scm",(void*)f_6633},
{"f_6640:posixunix_scm",(void*)f_6640},
{"f_6614:posixunix_scm",(void*)f_6614},
{"f_6605:posixunix_scm",(void*)f_6605},
{"f_6586:posixunix_scm",(void*)f_6586},
{"f_6580:posixunix_scm",(void*)f_6580},
{"f_6571:posixunix_scm",(void*)f_6571},
{"f_6536:posixunix_scm",(void*)f_6536},
{"f_6549:posixunix_scm",(void*)f_6549},
{"f_6474:posixunix_scm",(void*)f_6474},
{"f_6478:posixunix_scm",(void*)f_6478},
{"f_6484:posixunix_scm",(void*)f_6484},
{"f_6503:posixunix_scm",(void*)f_6503},
{"f_6490:posixunix_scm",(void*)f_6490},
{"f_6370:posixunix_scm",(void*)f_6370},
{"f_6376:posixunix_scm",(void*)f_6376},
{"f_6380:posixunix_scm",(void*)f_6380},
{"f_6388:posixunix_scm",(void*)f_6388},
{"f_6414:posixunix_scm",(void*)f_6414},
{"f_6418:posixunix_scm",(void*)f_6418},
{"f_6406:posixunix_scm",(void*)f_6406},
{"f_6350:posixunix_scm",(void*)f_6350},
{"f_6358:posixunix_scm",(void*)f_6358},
{"f_6333:posixunix_scm",(void*)f_6333},
{"f_6344:posixunix_scm",(void*)f_6344},
{"f_6348:posixunix_scm",(void*)f_6348},
{"f_6307:posixunix_scm",(void*)f_6307},
{"f_6331:posixunix_scm",(void*)f_6331},
{"f_6314:posixunix_scm",(void*)f_6314},
{"f_6264:posixunix_scm",(void*)f_6264},
{"f_6271:posixunix_scm",(void*)f_6271},
{"f_6292:posixunix_scm",(void*)f_6292},
{"f_6288:posixunix_scm",(void*)f_6288},
{"f_6236:posixunix_scm",(void*)f_6236},
{"f_6214:posixunix_scm",(void*)f_6214},
{"f_6218:posixunix_scm",(void*)f_6218},
{"f_6199:posixunix_scm",(void*)f_6199},
{"f_6203:posixunix_scm",(void*)f_6203},
{"f_6184:posixunix_scm",(void*)f_6184},
{"f_6188:posixunix_scm",(void*)f_6188},
{"f_6166:posixunix_scm",(void*)f_6166},
{"f_6092:posixunix_scm",(void*)f_6092},
{"f_6114:posixunix_scm",(void*)f_6114},
{"f_6120:posixunix_scm",(void*)f_6120},
{"f_6053:posixunix_scm",(void*)f_6053},
{"f_6081:posixunix_scm",(void*)f_6081},
{"f_6077:posixunix_scm",(void*)f_6077},
{"f_6070:posixunix_scm",(void*)f_6070},
{"f_6063:posixunix_scm",(void*)f_6063},
{"f_5794:posixunix_scm",(void*)f_5794},
{"f_5990:posixunix_scm",(void*)f_5990},
{"f_5985:posixunix_scm",(void*)f_5985},
{"f_5980:posixunix_scm",(void*)f_5980},
{"f_5796:posixunix_scm",(void*)f_5796},
{"f_5800:posixunix_scm",(void*)f_5800},
{"f_5906:posixunix_scm",(void*)f_5906},
{"f_5907:posixunix_scm",(void*)f_5907},
{"f_5924:posixunix_scm",(void*)f_5924},
{"f_5934:posixunix_scm",(void*)f_5934},
{"f_5892:posixunix_scm",(void*)f_5892},
{"f_5848:posixunix_scm",(void*)f_5848},
{"f_5884:posixunix_scm",(void*)f_5884},
{"f_5863:posixunix_scm",(void*)f_5863},
{"f_5873:posixunix_scm",(void*)f_5873},
{"f_5857:posixunix_scm",(void*)f_5857},
{"f_5852:posixunix_scm",(void*)f_5852},
{"f_5855:posixunix_scm",(void*)f_5855},
{"f_5802:posixunix_scm",(void*)f_5802},
{"f_5837:posixunix_scm",(void*)f_5837},
{"f_5818:posixunix_scm",(void*)f_5818},
{"f_5312:posixunix_scm",(void*)f_5312},
{"f_5716:posixunix_scm",(void*)f_5716},
{"f_5711:posixunix_scm",(void*)f_5711},
{"f_5706:posixunix_scm",(void*)f_5706},
{"f_5701:posixunix_scm",(void*)f_5701},
{"f_5314:posixunix_scm",(void*)f_5314},
{"f_5318:posixunix_scm",(void*)f_5318},
{"f_5324:posixunix_scm",(void*)f_5324},
{"f_5574:posixunix_scm",(void*)f_5574},
{"f_5580:posixunix_scm",(void*)f_5580},
{"f_5676:posixunix_scm",(void*)f_5676},
{"f_5666:posixunix_scm",(void*)f_5666},
{"f_5660:posixunix_scm",(void*)f_5660},
{"f_5582:posixunix_scm",(void*)f_5582},
{"f_5632:posixunix_scm",(void*)f_5632},
{"f_5589:posixunix_scm",(void*)f_5589},
{"f_5599:posixunix_scm",(void*)f_5599},
{"f_5498:posixunix_scm",(void*)f_5498},
{"f_5506:posixunix_scm",(void*)f_5506},
{"f_5508:posixunix_scm",(void*)f_5508},
{"f_5556:posixunix_scm",(void*)f_5556},
{"f_5489:posixunix_scm",(void*)f_5489},
{"f_5493:posixunix_scm",(void*)f_5493},
{"f_5468:posixunix_scm",(void*)f_5468},
{"f_5478:posixunix_scm",(void*)f_5478},
{"f_5456:posixunix_scm",(void*)f_5456},
{"f_5443:posixunix_scm",(void*)f_5443},
{"f_5447:posixunix_scm",(void*)f_5447},
{"f_5438:posixunix_scm",(void*)f_5438},
{"f_5441:posixunix_scm",(void*)f_5441},
{"f_5356:posixunix_scm",(void*)f_5356},
{"f_5368:posixunix_scm",(void*)f_5368},
{"f_5405:posixunix_scm",(void*)f_5405},
{"f_5414:posixunix_scm",(void*)f_5414},
{"f_5408:posixunix_scm",(void*)f_5408},
{"f_5384:posixunix_scm",(void*)f_5384},
{"f_5387:posixunix_scm",(void*)f_5387},
{"f_5348:posixunix_scm",(void*)f_5348},
{"f_5325:posixunix_scm",(void*)f_5325},
{"f_5329:posixunix_scm",(void*)f_5329},
{"f_5285:posixunix_scm",(void*)f_5285},
{"f_5292:posixunix_scm",(void*)f_5292},
{"f_5295:posixunix_scm",(void*)f_5295},
{"f_5240:posixunix_scm",(void*)f_5240},
{"f_5244:posixunix_scm",(void*)f_5244},
{"f_5279:posixunix_scm",(void*)f_5279},
{"f_5262:posixunix_scm",(void*)f_5262},
{"f_5226:posixunix_scm",(void*)f_5226},
{"f_5238:posixunix_scm",(void*)f_5238},
{"f_5212:posixunix_scm",(void*)f_5212},
{"f_5224:posixunix_scm",(void*)f_5224},
{"f_5197:posixunix_scm",(void*)f_5197},
{"f_5210:posixunix_scm",(void*)f_5210},
{"f_5160:posixunix_scm",(void*)f_5160},
{"f_5168:posixunix_scm",(void*)f_5168},
{"f_5135:posixunix_scm",(void*)f_5135},
{"f_5116:posixunix_scm",(void*)f_5116},
{"f_5120:posixunix_scm",(void*)f_5120},
{"f_5148:posixunix_scm",(void*)f_5148},
{"f_5051:posixunix_scm",(void*)f_5051},
{"f_5055:posixunix_scm",(void*)f_5055},
{"f_5090:posixunix_scm",(void*)f_5090},
{"f_5062:posixunix_scm",(void*)f_5062},
{"f_5065:posixunix_scm",(void*)f_5065},
{"f_5068:posixunix_scm",(void*)f_5068},
{"f_5074:posixunix_scm",(void*)f_5074},
{"f_5013:posixunix_scm",(void*)f_5013},
{"f_5046:posixunix_scm",(void*)f_5046},
{"f_5034:posixunix_scm",(void*)f_5034},
{"f_5042:posixunix_scm",(void*)f_5042},
{"f_5038:posixunix_scm",(void*)f_5038},
{"f_4994:posixunix_scm",(void*)f_4994},
{"f_5004:posixunix_scm",(void*)f_5004},
{"f_4998:posixunix_scm",(void*)f_4998},
{"f_4988:posixunix_scm",(void*)f_4988},
{"f_4982:posixunix_scm",(void*)f_4982},
{"f_4976:posixunix_scm",(void*)f_4976},
{"f_4952:posixunix_scm",(void*)f_4952},
{"f_4974:posixunix_scm",(void*)f_4974},
{"f_4970:posixunix_scm",(void*)f_4970},
{"f_4962:posixunix_scm",(void*)f_4962},
{"f_4922:posixunix_scm",(void*)f_4922},
{"f_4950:posixunix_scm",(void*)f_4950},
{"f_4946:posixunix_scm",(void*)f_4946},
{"f_4895:posixunix_scm",(void*)f_4895},
{"f_4920:posixunix_scm",(void*)f_4920},
{"f_4916:posixunix_scm",(void*)f_4916},
{"f_4831:posixunix_scm",(void*)f_4831},
{"f_4819:posixunix_scm",(void*)f_4819},
{"f_4844:posixunix_scm",(void*)f_4844},
{"f_4847:posixunix_scm",(void*)f_4847},
{"f_4757:posixunix_scm",(void*)f_4757},
{"f_4761:posixunix_scm",(void*)f_4761},
{"f_4766:posixunix_scm",(void*)f_4766},
{"f_4782:posixunix_scm",(void*)f_4782},
{"f_4694:posixunix_scm",(void*)f_4694},
{"f_4752:posixunix_scm",(void*)f_4752},
{"f_4698:posixunix_scm",(void*)f_4698},
{"f_4701:posixunix_scm",(void*)f_4701},
{"f_4733:posixunix_scm",(void*)f_4733},
{"f_4704:posixunix_scm",(void*)f_4704},
{"f_4709:posixunix_scm",(void*)f_4709},
{"f_4723:posixunix_scm",(void*)f_4723},
{"f_4601:posixunix_scm",(void*)f_4601},
{"f_4605:posixunix_scm",(void*)f_4605},
{"f_4659:posixunix_scm",(void*)f_4659},
{"f_4608:posixunix_scm",(void*)f_4608},
{"f_4618:posixunix_scm",(void*)f_4618},
{"f_4622:posixunix_scm",(void*)f_4622},
{"f_4631:posixunix_scm",(void*)f_4631},
{"f_4635:posixunix_scm",(void*)f_4635},
{"f_4645:posixunix_scm",(void*)f_4645},
{"f_4626:posixunix_scm",(void*)f_4626},
{"f_4576:posixunix_scm",(void*)f_4576},
{"f_4588:posixunix_scm",(void*)f_4588},
{"f_4584:posixunix_scm",(void*)f_4584},
{"f_4562:posixunix_scm",(void*)f_4562},
{"f_4574:posixunix_scm",(void*)f_4574},
{"f_4570:posixunix_scm",(void*)f_4570},
{"f_4495:posixunix_scm",(void*)f_4495},
{"f_4499:posixunix_scm",(void*)f_4499},
{"f_4541:posixunix_scm",(void*)f_4541},
{"f_4502:posixunix_scm",(void*)f_4502},
{"f_4512:posixunix_scm",(void*)f_4512},
{"f_4516:posixunix_scm",(void*)f_4516},
{"f_4520:posixunix_scm",(void*)f_4520},
{"f_4524:posixunix_scm",(void*)f_4524},
{"f_4528:posixunix_scm",(void*)f_4528},
{"f_4441:posixunix_scm",(void*)f_4441},
{"f_4474:posixunix_scm",(void*)f_4474},
{"f_4445:posixunix_scm",(void*)f_4445},
{"f_4452:posixunix_scm",(void*)f_4452},
{"f_4456:posixunix_scm",(void*)f_4456},
{"f_4460:posixunix_scm",(void*)f_4460},
{"f_4464:posixunix_scm",(void*)f_4464},
{"f_4468:posixunix_scm",(void*)f_4468},
{"f_4423:posixunix_scm",(void*)f_4423},
{"f_4408:posixunix_scm",(void*)f_4408},
{"f_4402:posixunix_scm",(void*)f_4402},
{"f_4370:posixunix_scm",(void*)f_4370},
{"f_4376:posixunix_scm",(void*)f_4376},
{"f_4330:posixunix_scm",(void*)f_4330},
{"f_4348:posixunix_scm",(void*)f_4348},
{"f_4312:posixunix_scm",(void*)f_4312},
{"f_4322:posixunix_scm",(void*)f_4322},
{"f_4299:posixunix_scm",(void*)f_4299},
{"f_4290:posixunix_scm",(void*)f_4290},
{"f_4243:posixunix_scm",(void*)f_4243},
{"f_4247:posixunix_scm",(void*)f_4247},
{"f_4223:posixunix_scm",(void*)f_4223},
{"f_4227:posixunix_scm",(void*)f_4227},
{"f_4233:posixunix_scm",(void*)f_4233},
{"f_4237:posixunix_scm",(void*)f_4237},
{"f_4203:posixunix_scm",(void*)f_4203},
{"f_4207:posixunix_scm",(void*)f_4207},
{"f_4213:posixunix_scm",(void*)f_4213},
{"f_4217:posixunix_scm",(void*)f_4217},
{"f_4179:posixunix_scm",(void*)f_4179},
{"f_4183:posixunix_scm",(void*)f_4183},
{"f_4194:posixunix_scm",(void*)f_4194},
{"f_4198:posixunix_scm",(void*)f_4198},
{"f_4188:posixunix_scm",(void*)f_4188},
{"f_4155:posixunix_scm",(void*)f_4155},
{"f_4159:posixunix_scm",(void*)f_4159},
{"f_4170:posixunix_scm",(void*)f_4170},
{"f_4174:posixunix_scm",(void*)f_4174},
{"f_4164:posixunix_scm",(void*)f_4164},
{"f_4139:posixunix_scm",(void*)f_4139},
{"f_4143:posixunix_scm",(void*)f_4143},
{"f_4146:posixunix_scm",(void*)f_4146},
{"f_4103:posixunix_scm",(void*)f_4103},
{"f_4134:posixunix_scm",(void*)f_4134},
{"f_4124:posixunix_scm",(void*)f_4124},
{"f_4117:posixunix_scm",(void*)f_4117},
{"f_4067:posixunix_scm",(void*)f_4067},
{"f_4098:posixunix_scm",(void*)f_4098},
{"f_4088:posixunix_scm",(void*)f_4088},
{"f_4081:posixunix_scm",(void*)f_4081},
{"f_4052:posixunix_scm",(void*)f_4052},
{"f_4065:posixunix_scm",(void*)f_4065},
{"f_3717:posixunix_scm",(void*)f_3717},
{"f_4024:posixunix_scm",(void*)f_4024},
{"f_3844:posixunix_scm",(void*)f_3844},
{"f_4010:posixunix_scm",(void*)f_4010},
{"f_3999:posixunix_scm",(void*)f_3999},
{"f_4006:posixunix_scm",(void*)f_4006},
{"f_3863:posixunix_scm",(void*)f_3863},
{"f_3992:posixunix_scm",(void*)f_3992},
{"f_3971:posixunix_scm",(void*)f_3971},
{"f_3988:posixunix_scm",(void*)f_3988},
{"f_3977:posixunix_scm",(void*)f_3977},
{"f_3984:posixunix_scm",(void*)f_3984},
{"f_3907:posixunix_scm",(void*)f_3907},
{"f_3968:posixunix_scm",(void*)f_3968},
{"f_3947:posixunix_scm",(void*)f_3947},
{"f_3964:posixunix_scm",(void*)f_3964},
{"f_3953:posixunix_scm",(void*)f_3953},
{"f_3960:posixunix_scm",(void*)f_3960},
{"f_3920:posixunix_scm",(void*)f_3920},
{"f_3944:posixunix_scm",(void*)f_3944},
{"f_3940:posixunix_scm",(void*)f_3940},
{"f_3901:posixunix_scm",(void*)f_3901},
{"f_3870:posixunix_scm",(void*)f_3870},
{"f_3888:posixunix_scm",(void*)f_3888},
{"f_3873:posixunix_scm",(void*)f_3873},
{"f_3877:posixunix_scm",(void*)f_3877},
{"f_3857:posixunix_scm",(void*)f_3857},
{"f_3838:posixunix_scm",(void*)f_3838},
{"f_3724:posixunix_scm",(void*)f_3724},
{"f_3731:posixunix_scm",(void*)f_3731},
{"f_3733:posixunix_scm",(void*)f_3733},
{"f_3740:posixunix_scm",(void*)f_3740},
{"f_3804:posixunix_scm",(void*)f_3804},
{"f_3813:posixunix_scm",(void*)f_3813},
{"f_3746:posixunix_scm",(void*)f_3746},
{"f_3782:posixunix_scm",(void*)f_3782},
{"f_3778:posixunix_scm",(void*)f_3778},
{"f_3774:posixunix_scm",(void*)f_3774},
{"f_3763:posixunix_scm",(void*)f_3763},
{"f_3759:posixunix_scm",(void*)f_3759},
{"f_3661:posixunix_scm",(void*)f_3661},
{"f_3670:posixunix_scm",(void*)f_3670},
{"f_3694:posixunix_scm",(void*)f_3694},
{"f_3706:posixunix_scm",(void*)f_3706},
{"f_3712:posixunix_scm",(void*)f_3712},
{"f_3700:posixunix_scm",(void*)f_3700},
{"f_3676:posixunix_scm",(void*)f_3676},
{"f_3682:posixunix_scm",(void*)f_3682},
{"f_3668:posixunix_scm",(void*)f_3668},
{"f_3597:posixunix_scm",(void*)f_3597},
{"f_3601:posixunix_scm",(void*)f_3601},
{"f_3610:posixunix_scm",(void*)f_3610},
{"f_3574:posixunix_scm",(void*)f_3574},
{"f_3595:posixunix_scm",(void*)f_3595},
{"f_3581:posixunix_scm",(void*)f_3581},
{"f_3417:posixunix_scm",(void*)f_3417},
{"f_3522:posixunix_scm",(void*)f_3522},
{"f_3530:posixunix_scm",(void*)f_3530},
{"f_3517:posixunix_scm",(void*)f_3517},
{"f_3419:posixunix_scm",(void*)f_3419},
{"f_3426:posixunix_scm",(void*)f_3426},
{"f_3429:posixunix_scm",(void*)f_3429},
{"f_3432:posixunix_scm",(void*)f_3432},
{"f_3516:posixunix_scm",(void*)f_3516},
{"f_3436:posixunix_scm",(void*)f_3436},
{"f_3450:posixunix_scm",(void*)f_3450},
{"f_3460:posixunix_scm",(void*)f_3460},
{"f_3463:posixunix_scm",(void*)f_3463},
{"f_3466:posixunix_scm",(void*)f_3466},
{"f_3472:posixunix_scm",(void*)f_3472},
{"f_3482:posixunix_scm",(void*)f_3482},
{"f_3393:posixunix_scm",(void*)f_3393},
{"f_3415:posixunix_scm",(void*)f_3415},
{"f_3411:posixunix_scm",(void*)f_3411},
{"f_3369:posixunix_scm",(void*)f_3369},
{"f_3391:posixunix_scm",(void*)f_3391},
{"f_3387:posixunix_scm",(void*)f_3387},
{"f_3251:posixunix_scm",(void*)f_3251},
{"f_3255:posixunix_scm",(void*)f_3255},
{"f_3348:posixunix_scm",(void*)f_3348},
{"f_3268:posixunix_scm",(void*)f_3268},
{"f_3270:posixunix_scm",(void*)f_3270},
{"f_3284:posixunix_scm",(void*)f_3284},
{"f_3314:posixunix_scm",(void*)f_3314},
{"f_3334:posixunix_scm",(void*)f_3334},
{"f_3297:posixunix_scm",(void*)f_3297},
{"f_3311:posixunix_scm",(void*)f_3311},
{"f_3287:posixunix_scm",(void*)f_3287},
{"f_3189:posixunix_scm",(void*)f_3189},
{"f_3202:posixunix_scm",(void*)f_3202},
{"f_3214:posixunix_scm",(void*)f_3214},
{"f_3208:posixunix_scm",(void*)f_3208},
{"f_3179:posixunix_scm",(void*)f_3179},
{"f_3186:posixunix_scm",(void*)f_3186},
{"f_3168:posixunix_scm",(void*)f_3168},
{"f_3175:posixunix_scm",(void*)f_3175},
{"f_3158:posixunix_scm",(void*)f_3158},
{"f_3165:posixunix_scm",(void*)f_3165},
{"f_3148:posixunix_scm",(void*)f_3148},
{"f_3155:posixunix_scm",(void*)f_3155},
{"f_3139:posixunix_scm",(void*)f_3139},
{"f_3146:posixunix_scm",(void*)f_3146},
{"f_3130:posixunix_scm",(void*)f_3130},
{"f_3137:posixunix_scm",(void*)f_3137},
{"f_3121:posixunix_scm",(void*)f_3121},
{"f_3128:posixunix_scm",(void*)f_3128},
{"f_3112:posixunix_scm",(void*)f_3112},
{"f_3119:posixunix_scm",(void*)f_3119},
{"f_3106:posixunix_scm",(void*)f_3106},
{"f_3110:posixunix_scm",(void*)f_3110},
{"f_3100:posixunix_scm",(void*)f_3100},
{"f_3104:posixunix_scm",(void*)f_3104},
{"f_3094:posixunix_scm",(void*)f_3094},
{"f_3098:posixunix_scm",(void*)f_3098},
{"f_3088:posixunix_scm",(void*)f_3088},
{"f_3092:posixunix_scm",(void*)f_3092},
{"f_3082:posixunix_scm",(void*)f_3082},
{"f_3086:posixunix_scm",(void*)f_3086},
{"f_3076:posixunix_scm",(void*)f_3076},
{"f_3080:posixunix_scm",(void*)f_3080},
{"f_3044:posixunix_scm",(void*)f_3044},
{"f_3055:posixunix_scm",(void*)f_3055},
{"f_3048:posixunix_scm",(void*)f_3048},
{"f_3007:posixunix_scm",(void*)f_3007},
{"f_3039:posixunix_scm",(void*)f_3039},
{"f_3032:posixunix_scm",(void*)f_3032},
{"f_3011:posixunix_scm",(void*)f_3011},
{"f_2751:posixunix_scm",(void*)f_2751},
{"f_2972:posixunix_scm",(void*)f_2972},
{"f_2767:posixunix_scm",(void*)f_2767},
{"f_2930:posixunix_scm",(void*)f_2930},
{"f_2773:posixunix_scm",(void*)f_2773},
{"f_2776:posixunix_scm",(void*)f_2776},
{"f_2874:posixunix_scm",(void*)f_2874},
{"f_2872:posixunix_scm",(void*)f_2872},
{"f_2815:posixunix_scm",(void*)f_2815},
{"f_2833:posixunix_scm",(void*)f_2833},
{"f_2831:posixunix_scm",(void*)f_2831},
{"f_2693:posixunix_scm",(void*)f_2693},
{"f_2700:posixunix_scm",(void*)f_2700},
{"f_2706:posixunix_scm",(void*)f_2706},
{"f_2713:posixunix_scm",(void*)f_2713},
{"f_2654:posixunix_scm",(void*)f_2654},
{"f_2661:posixunix_scm",(void*)f_2661},
{"f_2670:posixunix_scm",(void*)f_2670},
{"f_2612:posixunix_scm",(void*)f_2612},
{"f_2622:posixunix_scm",(void*)f_2622},
{"f_2625:posixunix_scm",(void*)f_2625},
{"f_2628:posixunix_scm",(void*)f_2628},
{"f_2597:posixunix_scm",(void*)f_2597},
{"f_2559:posixunix_scm",(void*)f_2559},
{"f_2589:posixunix_scm",(void*)f_2589},
{"f_2576:posixunix_scm",(void*)f_2576},
{"f_2579:posixunix_scm",(void*)f_2579},
{"f_2513:posixunix_scm",(void*)f_2513},
{"f_2517:posixunix_scm",(void*)f_2517},
{"f_2456:posixunix_scm",(void*)f_2456},
{"f_2449:posixunix_scm",(void*)f_2449},
{"f_2431:posixunix_scm",(void*)f_2431},
{"f_2435:posixunix_scm",(void*)f_2435},
{"f_2446:posixunix_scm",(void*)f_2446},
{"f_2442:posixunix_scm",(void*)f_2442},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
