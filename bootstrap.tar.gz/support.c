/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-28 22:56
   Version 4.1.4 - SVN rev. 15427
   linux-unix-gnu-x86 [ ptables applyhook ]
   compiled 2009-08-13 on x (Linux)
   command line: support.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature debugbuild -scrutinize -types ./types.db -no-lambda-info -local -extend private-namespace.scm -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[497];
static double C_possibly_force_alignment;


/* from k3814 */
static C_word C_fcall stub270(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub270(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k3807 */
static C_word C_fcall stub266(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub266(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11112)
static void C_ccall f_11112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11116)
static void C_ccall f_11116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11200)
static void C_ccall f_11200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11122)
static void C_ccall f_11122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11187)
static void C_ccall f_11187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11190)
static void C_ccall f_11190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11193)
static void C_ccall f_11193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11128)
static void C_ccall f_11128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11135)
static void C_ccall f_11135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11137)
static void C_fcall f_11137(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11169)
static void C_ccall f_11169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11165)
static void C_ccall f_11165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11150)
static void C_ccall f_11150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11106)
static void C_ccall f_11106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11100)
static void C_ccall f_11100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11094)
static void C_ccall f_11094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11066)
static void C_ccall f_11066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11066)
static void C_ccall f_11066r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11070)
static void C_ccall f_11070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11045)
static void C_ccall f_11045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11049)
static void C_ccall f_11049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11012)
static void C_ccall f_11012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11018)
static void C_ccall f_11018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10979)
static void C_ccall f_10979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10985)
static void C_ccall f_10985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10955)
static void C_ccall f_10955(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10886)
static void C_ccall f_10886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10890)
static void C_ccall f_10890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10895)
static void C_fcall f_10895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10899)
static void C_ccall f_10899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10950)
static void C_ccall f_10950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10929)
static void C_ccall f_10929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10941)
static void C_ccall f_10941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10944)
static void C_ccall f_10944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10917)
static void C_ccall f_10917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10853)
static void C_ccall f_10853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10863)
static void C_ccall f_10863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10866)
static void C_ccall f_10866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10729)
static void C_ccall f_10729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10738)
static void C_fcall f_10738(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10751)
static void C_ccall f_10751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10757)
static void C_ccall f_10757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10760)
static void C_ccall f_10760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10763)
static void C_ccall f_10763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10766)
static void C_ccall f_10766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10769)
static void C_ccall f_10769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10772)
static void C_ccall f_10772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10831)
static void C_fcall f_10831(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10844)
static void C_ccall f_10844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10775)
static void C_ccall f_10775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10790)
static void C_ccall f_10790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10793)
static void C_ccall f_10793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10801)
static void C_fcall f_10801(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10811)
static void C_ccall f_10811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10814)
static void C_ccall f_10814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10796)
static void C_ccall f_10796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10781)
static void C_ccall f_10781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10733)
static void C_ccall f_10733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10726)
static void C_ccall f_10726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10708)
static void C_ccall f_10708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10662)
static void C_ccall f_10662(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10681)
static void C_ccall f_10681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10692)
static void C_ccall f_10692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10688)
static void C_ccall f_10688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10641)
static void C_ccall f_10641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10647)
static void C_ccall f_10647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10651)
static void C_ccall f_10651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10654)
static void C_ccall f_10654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10657)
static void C_ccall f_10657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10629)
static void C_ccall f_10629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10633)
static void C_ccall f_10633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10538)
static void C_ccall f_10538(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10538)
static void C_ccall f_10538r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10557)
static void C_ccall f_10557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10582)
static void C_ccall f_10582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10586)
static void C_ccall f_10586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10588)
static void C_fcall f_10588(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10595)
static void C_ccall f_10595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10608)
static void C_ccall f_10608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10611)
static void C_ccall f_10611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10614)
static void C_ccall f_10614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10617)
static void C_ccall f_10617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10620)
static void C_ccall f_10620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10624)
static void C_ccall f_10624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10541)
static void C_fcall f_10541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10545)
static void C_ccall f_10545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10551)
static void C_ccall f_10551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10532)
static void C_ccall f_10532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10473)
static void C_ccall f_10473(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10473)
static void C_ccall f_10473r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10481)
static void C_ccall f_10481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10508)
static void C_ccall f_10508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10484)
static void C_ccall f_10484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10487)
static void C_ccall f_10487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10504)
static void C_ccall f_10504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10490)
static void C_ccall f_10490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10500)
static void C_ccall f_10500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10493)
static void C_ccall f_10493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10496)
static void C_ccall f_10496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10464)
static void C_ccall f_10464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10458)
static void C_ccall f_10458(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10452)
static void C_ccall f_10452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10440)
static void C_ccall f_10440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10444)
static void C_ccall f_10444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10447)
static void C_ccall f_10447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10402)
static void C_ccall f_10402(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10402)
static void C_ccall f_10402r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10406)
static void C_ccall f_10406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f13068)
static void C_ccall f13068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10409)
static void C_ccall f_10409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10416)
static void C_ccall f_10416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10360)
static void C_ccall f_10360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10369)
static void C_fcall f_10369(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10331)
static void C_ccall f_10331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10341)
static void C_fcall f_10341(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10143)
static void C_ccall f_10143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10326)
static void C_ccall f_10326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10297)
static void C_fcall f_10297(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10303)
static void C_fcall f_10303(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10316)
static void C_ccall f_10316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10146)
static void C_fcall f_10146(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10165)
static void C_fcall f_10165(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10259)
static void C_ccall f_10259(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10271)
static void C_ccall f_10271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10229)
static void C_ccall f_10229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10240)
static void C_ccall f_10240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10220)
static void C_ccall f_10220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10184)
static void C_ccall f_10184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10190)
static void C_ccall f_10190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10194)
static void C_ccall f_10194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10019)
static void C_ccall f_10019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10025)
static void C_fcall f_10025(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10103)
static void C_fcall f_10103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10108)
static void C_fcall f_10108(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10118)
static void C_ccall f_10118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10076)
static void C_fcall f_10076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10047)
static void C_fcall f_10047(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10052)
static void C_fcall f_10052(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10062)
static void C_ccall f_10062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10023)
static void C_ccall f_10023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9721)
static void C_ccall f_9721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9920)
static void C_fcall f_9920(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9941)
static void C_fcall f_9941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9405)
static void C_ccall f_9405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9715)
static void C_ccall f_9715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9417)
static void C_ccall f_9417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9427)
static void C_fcall f_9427(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9445)
static void C_ccall f_9445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9479)
static void C_fcall f_9479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9080)
static void C_ccall f_9080(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9399)
static void C_ccall f_9399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9096)
static void C_fcall f_9096(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9105)
static void C_fcall f_9105(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9117)
static void C_fcall f_9117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9129)
static void C_fcall f_9129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9135)
static void C_ccall f_9135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9040)
static void C_ccall f_9040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9074)
static void C_ccall f_9074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9046)
static void C_ccall f_9046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9050)
static void C_ccall f_9050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9009)
static void C_ccall f_9009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9022)
static void C_ccall f_9022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8978)
static void C_ccall f_8978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8991)
static void C_ccall f_8991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7925)
static void C_ccall f_7925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8972)
static void C_ccall f_8972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7931)
static void C_ccall f_7931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7937)
static void C_fcall f_7937(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7966)
static void C_fcall f_7966(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7985)
static void C_fcall f_7985(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8004)
static void C_fcall f_8004(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8074)
static void C_fcall f_8074(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8093)
static void C_fcall f_8093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8175)
static void C_fcall f_8175(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8214)
static void C_fcall f_8214(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8233)
static void C_fcall f_8233(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8252)
static void C_fcall f_8252(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8332)
static void C_fcall f_8332(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8417)
static void C_fcall f_8417(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8492)
static void C_ccall f_8492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8526)
static void C_fcall f_8526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8596)
static void C_ccall f_8596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8529)
static void C_ccall f_8529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8335)
static void C_ccall f_8335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8366)
static void C_fcall f_8366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8255)
static void C_ccall f_8255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8096)
static void C_ccall f_8096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8127)
static void C_fcall f_8127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8007)
static void C_ccall f_8007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8038)
static void C_fcall f_8038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7873)
static void C_ccall f_7873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7888)
static void C_ccall f_7888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7894)
static void C_fcall f_7894(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7792)
static void C_ccall f_7792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7804)
static void C_ccall f_7804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7814)
static void C_ccall f_7814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7817)
static void C_ccall f_7817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7820)
static void C_ccall f_7820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7823)
static void C_ccall f_7823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7829)
static void C_ccall f_7829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7832)
static void C_ccall f_7832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7841)
static void C_ccall f_7841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7844)
static void C_ccall f_7844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7853)
static void C_ccall f_7853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7859)
static void C_ccall f_7859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7862)
static void C_ccall f_7862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7865)
static void C_ccall f_7865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7868)
static void C_ccall f_7868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7798)
static void C_ccall f_7798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7705)
static void C_ccall f_7705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7711)
static C_word C_fcall f_7711(C_word t0,C_word t1);
C_noret_decl(f_7700)
static void C_ccall f_7700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7675)
static void C_ccall f_7675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7685)
static void C_ccall f_7685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7626)
static void C_ccall f_7626(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7632)
static void C_ccall f_7632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7673)
static void C_ccall f_7673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7645)
static void C_ccall f_7645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7589)
static void C_ccall f_7589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7595)
static void C_ccall f_7595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7624)
static void C_ccall f_7624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7602)
static void C_fcall f_7602(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7605)
static void C_ccall f_7605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7548)
static void C_ccall f_7548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7554)
static void C_ccall f_7554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7561)
static void C_fcall f_7561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7564)
static void C_ccall f_7564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7480)
static void C_ccall f_7480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7370)
static void C_ccall f_7370(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7376)
static void C_ccall f_7376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7392)
static void C_fcall f_7392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7406)
static void C_ccall f_7406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7414)
static void C_ccall f_7414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7175)
static void C_ccall f_7175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7354)
static void C_ccall f_7354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7360)
static void C_ccall f_7360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7250)
static void C_fcall f_7250(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7272)
static void C_ccall f_7272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7285)
static void C_fcall f_7285(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7316)
static void C_ccall f_7316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7207)
static void C_fcall f_7207(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7178)
static void C_fcall f_7178(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7202)
static void C_ccall f_7202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_fcall f_7118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7122)
static void C_ccall f_7122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7169)
static void C_ccall f_7169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6920)
static void C_ccall f_6920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6967)
static void C_ccall f_6967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7104)
static void C_ccall f_7104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6971)
static void C_ccall f_6971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6979)
static void C_ccall f_6979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6986)
static void C_ccall f_6986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7097)
static void C_ccall f_7097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_fcall f_7010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7082)
static void C_ccall f_7082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7037)
static void C_ccall f_7037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7040)
static void C_fcall f_7040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7047)
static void C_ccall f_7047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6937)
static void C_ccall f_6937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6939)
static void C_fcall f_6939(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6911)
static void C_ccall f_6911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6889)
static void C_ccall f_6889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6885)
static void C_ccall f_6885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6835)
static void C_ccall f_6835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6839)
static void C_ccall f_6839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_ccall f_6801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6807)
static void C_fcall f_6807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6821)
static void C_ccall f_6821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6825)
static void C_ccall f_6825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6599)
static void C_ccall f_6599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6603)
static void C_ccall f_6603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6611)
static void C_fcall f_6611(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6784)
static void C_ccall f_6784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6792)
static void C_ccall f_6792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6723)
static void C_ccall f_6723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6774)
static void C_ccall f_6774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6778)
static void C_ccall f_6778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6772)
static void C_ccall f_6772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6749)
static void C_ccall f_6749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6765)
static void C_ccall f_6765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6757)
static void C_ccall f_6757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6741)
static void C_ccall f_6741(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6736)
static void C_ccall f_6736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6681)
static void C_ccall f_6681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_ccall f_6684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6657)
static void C_ccall f_6657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6506)
static void C_ccall f_6506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6512)
static void C_ccall f_6512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6528)
static void C_ccall f_6528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6591)
static void C_ccall f_6591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_fcall f_6550(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6536)
static void C_ccall f_6536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6518)
static void C_ccall f_6518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6458)
static void C_ccall f_6458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6464)
static void C_fcall f_6464(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6165)
static void C_fcall f_6165(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_fcall f_6399(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6429)
static void C_ccall f_6429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6425)
static void C_ccall f_6425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6337)
static void C_fcall f_6337(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6386)
static void C_ccall f_6386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6259)
static void C_ccall f_6259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6239)
static void C_ccall f_6239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6251)
static void C_ccall f_6251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6247)
static void C_ccall f_6247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6189)
static void C_ccall f_6189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6138)
static void C_ccall f_6138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5629)
static void C_ccall f_5629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6005)
static void C_fcall f_6005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6048)
static void C_ccall f_6048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_fcall f_6062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6066)
static void C_ccall f_6066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6042)
static void C_ccall f_6042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5841)
static void C_fcall f_5841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5844)
static void C_ccall f_5844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5767)
static void C_ccall f_5767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5714)
static void C_fcall f_5714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5717)
static void C_ccall f_5717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5065)
static void C_fcall f_5065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5213)
static void C_fcall f_5213(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5239)
static void C_fcall f_5239(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5315)
static void C_fcall f_5315(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5296)
static void C_ccall f_5296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5124)
static void C_fcall f_5124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_fcall f_5148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_fcall f_5172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5086)
static void C_ccall f_5086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5101)
static void C_ccall f_5101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5046)
static void C_ccall f_5046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5015)
static void C_fcall f_5015(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_fcall f_4983(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4897)
static void C_ccall f_4897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4897)
static void C_ccall f_4897r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_fcall f_4678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_fcall f_4593(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4544)
static void C_fcall f_4544(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4381)
static void C_ccall f_4381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4374)
static void C_ccall f_4374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4179)
static void C_fcall f_4179(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_fcall f_4207(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_fcall f_4071(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3946)
static void C_fcall f_3946(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_fcall f_3893(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_fcall f_3846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_fcall f_3672(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3694)
static void C_fcall f_3694(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_fcall f_3701(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3616)
static void C_fcall f_3616(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3602)
static void C_ccall f_3602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3522)
static C_word C_fcall f_3522(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3472)
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3451)
static void C_fcall f_3451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3411)
static void C_fcall f_3411(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3348)
static void C_fcall f_3348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_fcall f_3362(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3300)
static void C_fcall f_3300(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_fcall f_3264(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_11137)
static void C_fcall trf_11137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11137(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11137(t0,t1,t2);}

C_noret_decl(trf_10895)
static void C_fcall trf_10895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10895(t0,t1);}

C_noret_decl(trf_10738)
static void C_fcall trf_10738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10738(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10738(t0,t1,t2,t3);}

C_noret_decl(trf_10831)
static void C_fcall trf_10831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10831(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10831(t0,t1,t2);}

C_noret_decl(trf_10801)
static void C_fcall trf_10801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10801(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10801(t0,t1,t2);}

C_noret_decl(trf_10588)
static void C_fcall trf_10588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10588(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10588(t0,t1,t2,t3);}

C_noret_decl(trf_10541)
static void C_fcall trf_10541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10541(t0,t1);}

C_noret_decl(trf_10369)
static void C_fcall trf_10369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10369(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10369(t0,t1,t2);}

C_noret_decl(trf_10341)
static void C_fcall trf_10341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10341(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10341(t0,t1);}

C_noret_decl(trf_10297)
static void C_fcall trf_10297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10297(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10297(t0,t1,t2,t3);}

C_noret_decl(trf_10303)
static void C_fcall trf_10303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10303(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10303(t0,t1,t2);}

C_noret_decl(trf_10146)
static void C_fcall trf_10146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10146(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10146(t0,t1,t2,t3);}

C_noret_decl(trf_10165)
static void C_fcall trf_10165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10165(t0,t1);}

C_noret_decl(trf_10025)
static void C_fcall trf_10025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10025(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10025(t0,t1,t2);}

C_noret_decl(trf_10103)
static void C_fcall trf_10103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10103(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10103(t0,t1);}

C_noret_decl(trf_10108)
static void C_fcall trf_10108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10108(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10108(t0,t1,t2);}

C_noret_decl(trf_10076)
static void C_fcall trf_10076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10076(t0,t1);}

C_noret_decl(trf_10047)
static void C_fcall trf_10047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10047(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10047(t0,t1);}

C_noret_decl(trf_10052)
static void C_fcall trf_10052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10052(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10052(t0,t1,t2);}

C_noret_decl(trf_9920)
static void C_fcall trf_9920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9920(t0,t1);}

C_noret_decl(trf_9941)
static void C_fcall trf_9941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9941(t0,t1);}

C_noret_decl(trf_9427)
static void C_fcall trf_9427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9427(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9427(t0,t1);}

C_noret_decl(trf_9479)
static void C_fcall trf_9479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9479(t0,t1);}

C_noret_decl(trf_9096)
static void C_fcall trf_9096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9096(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9096(t0,t1);}

C_noret_decl(trf_9105)
static void C_fcall trf_9105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9105(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9105(t0,t1);}

C_noret_decl(trf_9117)
static void C_fcall trf_9117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9117(t0,t1);}

C_noret_decl(trf_9129)
static void C_fcall trf_9129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9129(t0,t1);}

C_noret_decl(trf_7937)
static void C_fcall trf_7937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7937(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7937(t0,t1,t2);}

C_noret_decl(trf_7966)
static void C_fcall trf_7966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7966(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7966(t0,t1);}

C_noret_decl(trf_7985)
static void C_fcall trf_7985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7985(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7985(t0,t1);}

C_noret_decl(trf_8004)
static void C_fcall trf_8004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8004(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8004(t0,t1);}

C_noret_decl(trf_8074)
static void C_fcall trf_8074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8074(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8074(t0,t1);}

C_noret_decl(trf_8093)
static void C_fcall trf_8093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8093(t0,t1);}

C_noret_decl(trf_8175)
static void C_fcall trf_8175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8175(t0,t1);}

C_noret_decl(trf_8214)
static void C_fcall trf_8214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8214(t0,t1);}

C_noret_decl(trf_8233)
static void C_fcall trf_8233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8233(t0,t1);}

C_noret_decl(trf_8252)
static void C_fcall trf_8252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8252(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8252(t0,t1);}

C_noret_decl(trf_8332)
static void C_fcall trf_8332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8332(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8332(t0,t1);}

C_noret_decl(trf_8417)
static void C_fcall trf_8417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8417(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8417(t0,t1);}

C_noret_decl(trf_8526)
static void C_fcall trf_8526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8526(t0,t1);}

C_noret_decl(trf_8366)
static void C_fcall trf_8366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8366(t0,t1);}

C_noret_decl(trf_8127)
static void C_fcall trf_8127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8127(t0,t1);}

C_noret_decl(trf_8038)
static void C_fcall trf_8038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8038(t0,t1);}

C_noret_decl(trf_7894)
static void C_fcall trf_7894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7894(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7894(t0,t1,t2);}

C_noret_decl(trf_7602)
static void C_fcall trf_7602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7602(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7602(t0,t1);}

C_noret_decl(trf_7561)
static void C_fcall trf_7561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7561(t0,t1);}

C_noret_decl(trf_7392)
static void C_fcall trf_7392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7392(t0,t1);}

C_noret_decl(trf_7250)
static void C_fcall trf_7250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7250(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7250(t0,t1,t2,t3);}

C_noret_decl(trf_7285)
static void C_fcall trf_7285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7285(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7285(t0,t1,t2,t3);}

C_noret_decl(trf_7207)
static void C_fcall trf_7207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7207(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7207(t0,t1,t2,t3);}

C_noret_decl(trf_7178)
static void C_fcall trf_7178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7178(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7178(t0,t1,t2,t3);}

C_noret_decl(trf_7118)
static void C_fcall trf_7118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7118(t0,t1);}

C_noret_decl(trf_7010)
static void C_fcall trf_7010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7010(t0,t1);}

C_noret_decl(trf_7040)
static void C_fcall trf_7040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7040(t0,t1);}

C_noret_decl(trf_6939)
static void C_fcall trf_6939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6939(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6939(t0,t1,t2);}

C_noret_decl(trf_6807)
static void C_fcall trf_6807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6807(t0,t1,t2);}

C_noret_decl(trf_6611)
static void C_fcall trf_6611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6611(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6611(t0,t1,t2,t3);}

C_noret_decl(trf_6550)
static void C_fcall trf_6550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6550(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6550(t0,t1);}

C_noret_decl(trf_6464)
static void C_fcall trf_6464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6464(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6464(t0,t1,t2);}

C_noret_decl(trf_6165)
static void C_fcall trf_6165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6165(t0,t1);}

C_noret_decl(trf_6399)
static void C_fcall trf_6399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6399(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6399(t0,t1);}

C_noret_decl(trf_6337)
static void C_fcall trf_6337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6337(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6337(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6005)
static void C_fcall trf_6005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6005(t0,t1);}

C_noret_decl(trf_6062)
static void C_fcall trf_6062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6062(t0,t1);}

C_noret_decl(trf_5841)
static void C_fcall trf_5841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5841(t0,t1);}

C_noret_decl(trf_5714)
static void C_fcall trf_5714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5714(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5714(t0,t1);}

C_noret_decl(trf_5065)
static void C_fcall trf_5065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5065(t0,t1);}

C_noret_decl(trf_5213)
static void C_fcall trf_5213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5213(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5213(t0,t1,t2);}

C_noret_decl(trf_5239)
static void C_fcall trf_5239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5239(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5239(t0,t1);}

C_noret_decl(trf_5315)
static void C_fcall trf_5315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5315(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5315(t0,t1);}

C_noret_decl(trf_5124)
static void C_fcall trf_5124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5124(t0,t1);}

C_noret_decl(trf_5148)
static void C_fcall trf_5148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5148(t0,t1);}

C_noret_decl(trf_5172)
static void C_fcall trf_5172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5172(t0,t1);}

C_noret_decl(trf_5015)
static void C_fcall trf_5015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5015(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5015(t0,t1,t2);}

C_noret_decl(trf_4983)
static void C_fcall trf_4983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4983(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4983(t0,t1);}

C_noret_decl(trf_4678)
static void C_fcall trf_4678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4678(t0,t1,t2);}

C_noret_decl(trf_4593)
static void C_fcall trf_4593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4593(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4593(t0,t1,t2);}

C_noret_decl(trf_4544)
static void C_fcall trf_4544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4544(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4544(t0,t1,t2);}

C_noret_decl(trf_4179)
static void C_fcall trf_4179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4179(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4179(t0,t1,t2);}

C_noret_decl(trf_4207)
static void C_fcall trf_4207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4207(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4207(t0,t1);}

C_noret_decl(trf_4071)
static void C_fcall trf_4071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4071(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4071(t0,t1);}

C_noret_decl(trf_3946)
static void C_fcall trf_3946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3946(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3946(t0,t1,t2,t3);}

C_noret_decl(trf_3893)
static void C_fcall trf_3893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3893(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3893(t0,t1,t2);}

C_noret_decl(trf_3846)
static void C_fcall trf_3846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3846(t0,t1);}

C_noret_decl(trf_3672)
static void C_fcall trf_3672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3672(t0,t1,t2);}

C_noret_decl(trf_3694)
static void C_fcall trf_3694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3694(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3694(t0,t1);}

C_noret_decl(trf_3701)
static void C_fcall trf_3701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3701(t0,t1);}

C_noret_decl(trf_3616)
static void C_fcall trf_3616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3616(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3616(t0,t1,t2,t3);}

C_noret_decl(trf_3472)
static void C_fcall trf_3472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3472(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3472(t0,t1,t2,t3);}

C_noret_decl(trf_3451)
static void C_fcall trf_3451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3451(t0,t1);}

C_noret_decl(trf_3411)
static void C_fcall trf_3411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3411(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3411(t0,t1,t2);}

C_noret_decl(trf_3348)
static void C_fcall trf_3348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3348(t0,t1);}

C_noret_decl(trf_3362)
static void C_fcall trf_3362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3362(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3362(t0,t1,t2);}

C_noret_decl(trf_3300)
static void C_fcall trf_3300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3300(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3300(t0,t1);}

C_noret_decl(trf_3264)
static void C_fcall trf_3264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3264(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3264(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5150)){
C_save(t1);
C_rereclaim2(5150*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,497);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],30,"\010compilercompiler-cleanup-hook");
lf[3]=C_h_intern(&lf[3],26,"\010compilerdebugging-chicken");
lf[4]=C_h_intern(&lf[4],26,"\010compilerdisabled-warnings");
lf[5]=C_h_intern(&lf[5],13,"\010compilerbomb");
lf[6]=C_h_intern(&lf[6],5,"error");
lf[7]=C_h_intern(&lf[7],13,"string-append");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[10]=C_h_intern(&lf[10],18,"\010compilerdebugging");
lf[11]=C_h_intern(&lf[11],19,"\003sysstandard-output");
lf[12]=C_h_intern(&lf[12],12,"flush-output");
lf[13]=C_h_intern(&lf[13],7,"newline");
lf[14]=C_h_intern(&lf[14],19,"\003syswrite-char/port");
lf[15]=C_h_intern(&lf[15],5,"write");
lf[16]=C_h_intern(&lf[16],5,"force");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_h_intern(&lf[19],25,"\010compilercompiler-warning");
lf[20]=C_h_intern(&lf[20],7,"fprintf");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\012\012Warning: ");
lf[22]=C_h_intern(&lf[22],18,"current-error-port");
lf[23]=C_h_intern(&lf[23],20,"\003syswarnings-enabled");
lf[24]=C_h_intern(&lf[24],4,"quit");
lf[25]=C_h_intern(&lf[25],4,"exit");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\010\012Error: ");
lf[27]=C_h_intern(&lf[27],21,"\003syssyntax-error-hook");
lf[28]=C_h_intern(&lf[28],16,"print-call-chain");
lf[29]=C_h_intern(&lf[29],18,"\003syscurrent-thread");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\031Syntax error (~a): ~a~%~%");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\024Syntax error: ~a~%~%");
lf[34]=C_h_intern(&lf[34],12,"syntax-error");
lf[35]=C_h_intern(&lf[35],31,"\010compileremit-syntax-trace-info");
lf[36]=C_h_intern(&lf[36],9,"map-llist");
lf[37]=C_h_intern(&lf[37],24,"\010compilercheck-signature");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[39]=C_h_intern(&lf[39],18,"\010compilerreal-name");
lf[40]=C_h_intern(&lf[40],13,"\010compilerposq");
lf[41]=C_h_intern(&lf[41],18,"\010compilerstringify");
lf[42]=C_h_intern(&lf[42],14,"symbol->string");
lf[43]=C_h_intern(&lf[43],17,"get-output-string");
lf[44]=C_h_intern(&lf[44],18,"open-output-string");
lf[45]=C_h_intern(&lf[45],18,"\010compilersymbolify");
lf[46]=C_h_intern(&lf[46],14,"string->symbol");
lf[47]=C_h_intern(&lf[47],26,"\010compilerbuild-lambda-list");
lf[48]=C_h_intern(&lf[48],29,"\010compilerstring->c-identifier");
lf[49]=C_h_intern(&lf[49],24,"\003sysstring->c-identifier");
lf[50]=C_h_intern(&lf[50],21,"\010compilerc-ify-string");
lf[51]=C_h_intern(&lf[51],16,"\003syslist->string");
lf[52]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[53]=C_h_intern(&lf[53],6,"append");
lf[54]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[55]=C_h_intern(&lf[55],16,"\003sysstring->list");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[59]=C_h_intern(&lf[59],28,"\010compilervalid-c-identifier\077");
lf[60]=C_h_intern(&lf[60],3,"any");
lf[61]=C_h_intern(&lf[61],8,"->string");
lf[62]=C_h_intern(&lf[62],14,"\010compilerwords");
lf[63]=C_h_intern(&lf[63],21,"\010compilerwords->bytes");
lf[64]=C_h_intern(&lf[64],34,"\010compilercheck-and-open-input-file");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[66]=C_h_intern(&lf[66],18,"current-input-port");
lf[67]=C_h_intern(&lf[67],15,"open-input-file");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\037Can not open file ~s in line ~s");
lf[70]=C_h_intern(&lf[70],12,"file-exists\077");
lf[71]=C_h_intern(&lf[71],33,"\010compilerclose-checked-input-file");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[73]=C_h_intern(&lf[73],16,"close-input-port");
lf[74]=C_h_intern(&lf[74],19,"\010compilerfold-inner");
lf[75]=C_h_intern(&lf[75],7,"reverse");
lf[76]=C_h_intern(&lf[76],28,"\010compilerfollow-without-loop");
lf[77]=C_h_intern(&lf[77],21,"\010compilersort-symbols");
lf[78]=C_h_intern(&lf[78],8,"string<\077");
lf[79]=C_h_intern(&lf[79],4,"sort");
lf[80]=C_h_intern(&lf[80],18,"\010compilerconstant\077");
lf[81]=C_h_intern(&lf[81],5,"quote");
lf[82]=C_h_intern(&lf[82],29,"\010compilercollapsable-literal\077");
lf[83]=C_h_intern(&lf[83],19,"\010compilerimmediate\077");
lf[84]=C_h_intern(&lf[84],20,"\010compilerbig-fixnum\077");
lf[85]=C_h_intern(&lf[85],23,"\010compilerbasic-literal\077");
lf[86]=C_h_intern(&lf[86],5,"every");
lf[87]=C_h_intern(&lf[87],12,"vector->list");
lf[88]=C_h_intern(&lf[88],32,"\010compilercanonicalize-begin-body");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[91]=C_h_intern(&lf[91],3,"let");
lf[92]=C_h_intern(&lf[92],6,"gensym");
lf[93]=C_h_intern(&lf[93],1,"t");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[95]=C_h_intern(&lf[95],21,"\010compilerstring->expr");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot parse expression: ~s [~a]~%");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[98]=C_h_intern(&lf[98],5,"begin");
lf[99]=C_h_intern(&lf[99],10,"\003sysappend");
lf[100]=C_h_intern(&lf[100],4,"read");
lf[101]=C_h_intern(&lf[101],6,"unfold");
lf[102]=C_h_intern(&lf[102],11,"eof-object\077");
lf[103]=C_h_intern(&lf[103],6,"values");
lf[104]=C_h_intern(&lf[104],22,"with-input-from-string");
lf[105]=C_h_intern(&lf[105],22,"with-exception-handler");
lf[106]=C_h_intern(&lf[106],30,"call-with-current-continuation");
lf[107]=C_h_intern(&lf[107],30,"\010compilerdecompose-lambda-list");
lf[108]=C_h_intern(&lf[108],25,"\003sysdecompose-lambda-list");
lf[109]=C_h_intern(&lf[109],37,"\010compilerprocess-lambda-documentation");
lf[110]=C_h_intern(&lf[110],21,"\010compilerllist-length");
lf[111]=C_h_intern(&lf[111],30,"\010compilerexpand-profile-lambda");
lf[112]=C_h_intern(&lf[112],29,"\010compilerprofile-lambda-index");
lf[113]=C_h_intern(&lf[113],28,"\010compilerprofile-lambda-list");
lf[114]=C_h_intern(&lf[114],33,"\010compilerprofile-info-vector-name");
lf[115]=C_h_intern(&lf[115],17,"\003sysprofile-entry");
lf[116]=C_h_intern(&lf[116],6,"lambda");
lf[117]=C_h_intern(&lf[117],5,"apply");
lf[118]=C_h_intern(&lf[118],16,"\003sysprofile-exit");
lf[119]=C_h_intern(&lf[119],16,"\003sysdynamic-wind");
lf[120]=C_h_intern(&lf[120],10,"alist-cons");
lf[121]=C_h_intern(&lf[121],37,"\010compilerinitialize-analysis-database");
lf[122]=C_h_intern(&lf[122],8,"internal");
lf[123]=C_h_intern(&lf[123],8,"\003sysput!");
lf[124]=C_h_intern(&lf[124],18,"\010compilerintrinsic");
lf[125]=C_h_intern(&lf[125],9,"\003syserror");
lf[126]=C_h_intern(&lf[126],26,"\010compilerinternal-bindings");
lf[127]=C_h_intern(&lf[127],26,"\010compilerfoldable-bindings");
lf[128]=C_h_intern(&lf[128],17,"\010compilerfoldable");
lf[129]=C_h_intern(&lf[129],8,"extended");
lf[130]=C_h_intern(&lf[130],17,"extended-bindings");
lf[131]=C_h_intern(&lf[131],8,"standard");
lf[132]=C_h_intern(&lf[132],17,"standard-bindings");
lf[133]=C_h_intern(&lf[133],12,"\010compilerget");
lf[134]=C_h_intern(&lf[134],18,"\003syshash-table-ref");
lf[135]=C_h_intern(&lf[135],16,"\010compilerget-all");
lf[136]=C_h_intern(&lf[136],10,"filter-map");
lf[137]=C_h_intern(&lf[137],13,"\010compilerput!");
lf[138]=C_h_intern(&lf[138],19,"\003syshash-table-set!");
lf[139]=C_h_intern(&lf[139],17,"\010compilercollect!");
lf[140]=C_h_intern(&lf[140],15,"\010compilercount!");
lf[141]=C_h_intern(&lf[141],17,"\010compilerget-list");
lf[142]=C_h_intern(&lf[142],17,"\010compilerget-line");
lf[143]=C_h_intern(&lf[143],24,"\003sysline-number-database");
lf[144]=C_h_intern(&lf[144],19,"\010compilerget-line-2");
lf[145]=C_h_intern(&lf[145],30,"\010compilerfind-lambda-container");
lf[146]=C_h_intern(&lf[146],12,"contained-in");
lf[147]=C_h_intern(&lf[147],37,"\010compilerdisplay-line-number-database");
lf[148]=C_h_intern(&lf[148],7,"\003sysmap");
lf[149]=C_h_intern(&lf[149],3,"cdr");
lf[150]=C_h_intern(&lf[150],23,"\003syshash-table-for-each");
lf[151]=C_h_intern(&lf[151],34,"\010compilerdisplay-analysis-database");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\005\011css=");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\006\011refs=");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\005\011val=");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\006\011lval=");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\006\011pval=");
lf[157]=C_h_intern(&lf[157],7,"unknown");
lf[158]=C_h_intern(&lf[158],8,"captured");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\015inline-target\376\001\000\000\003ilt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020inline-transient\376\001\000\000\003itr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\012boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[160]=C_h_intern(&lf[160],4,"caar");
lf[161]=C_h_intern(&lf[161],5,"value");
lf[162]=C_h_intern(&lf[162],4,"cdar");
lf[163]=C_h_intern(&lf[163],11,"local-value");
lf[164]=C_h_intern(&lf[164],15,"potential-value");
lf[165]=C_h_intern(&lf[165],10,"replacable");
lf[166]=C_h_intern(&lf[166],10,"references");
lf[167]=C_h_intern(&lf[167],10,"call-sites");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[169]=C_h_intern(&lf[169],4,"home");
lf[170]=C_h_intern(&lf[170],8,"contains");
lf[171]=C_h_intern(&lf[171],8,"use-expr");
lf[172]=C_h_intern(&lf[172],12,"closure-size");
lf[173]=C_h_intern(&lf[173],14,"rest-parameter");
lf[174]=C_h_intern(&lf[174],16,"o-r/access-count");
lf[175]=C_h_intern(&lf[175],18,"captured-variables");
lf[176]=C_h_intern(&lf[176],13,"explicit-rest");
lf[177]=C_h_intern(&lf[177],8,"assigned");
lf[178]=C_h_intern(&lf[178],5,"boxed");
lf[179]=C_h_intern(&lf[179],6,"global");
lf[180]=C_h_intern(&lf[180],12,"contractable");
lf[181]=C_h_intern(&lf[181],16,"standard-binding");
lf[182]=C_h_intern(&lf[182],16,"assigned-locally");
lf[183]=C_h_intern(&lf[183],11,"collapsable");
lf[184]=C_h_intern(&lf[184],9,"removable");
lf[185]=C_h_intern(&lf[185],9,"undefined");
lf[186]=C_h_intern(&lf[186],9,"replacing");
lf[187]=C_h_intern(&lf[187],6,"unused");
lf[188]=C_h_intern(&lf[188],6,"simple");
lf[189]=C_h_intern(&lf[189],9,"inlinable");
lf[190]=C_h_intern(&lf[190],13,"inline-export");
lf[191]=C_h_intern(&lf[191],21,"has-unused-parameters");
lf[192]=C_h_intern(&lf[192],16,"extended-binding");
lf[193]=C_h_intern(&lf[193],12,"customizable");
lf[194]=C_h_intern(&lf[194],8,"constant");
lf[195]=C_h_intern(&lf[195],10,"boxed-rest");
lf[196]=C_h_intern(&lf[196],11,"hidden-refs");
lf[197]=C_h_intern(&lf[197],34,"\010compilerdefault-standard-bindings");
lf[198]=C_h_intern(&lf[198],34,"\010compilerdefault-extended-bindings");
lf[199]=C_h_intern(&lf[199],9,"make-node");
lf[200]=C_h_intern(&lf[200],4,"node");
lf[201]=C_h_intern(&lf[201],5,"node\077");
lf[202]=C_h_intern(&lf[202],15,"node-class-set!");
lf[203]=C_h_intern(&lf[203],14,"\003sysblock-set!");
lf[204]=C_h_intern(&lf[204],10,"node-class");
lf[205]=C_h_intern(&lf[205],20,"node-parameters-set!");
lf[206]=C_h_intern(&lf[206],15,"node-parameters");
lf[207]=C_h_intern(&lf[207],24,"node-subexpressions-set!");
lf[208]=C_h_intern(&lf[208],19,"node-subexpressions");
lf[209]=C_h_intern(&lf[209],16,"\010compilervarnode");
lf[210]=C_h_intern(&lf[210],13,"\004corevariable");
lf[211]=C_h_intern(&lf[211],14,"\010compilerqnode");
lf[212]=C_h_intern(&lf[212],25,"\010compilerbuild-node-graph");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[214]=C_h_intern(&lf[214],15,"\004coreglobal-ref");
lf[215]=C_h_intern(&lf[215],2,"if");
lf[216]=C_h_intern(&lf[216],14,"\004coreundefined");
lf[217]=C_h_intern(&lf[217],8,"truncate");
lf[218]=C_h_intern(&lf[218],4,"type");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000;literal \047~s\047 is out of range - will be truncated to integer");
lf[220]=C_h_intern(&lf[220],6,"fixnum");
lf[221]=C_h_intern(&lf[221],11,"number-type");
lf[222]=C_h_intern(&lf[222],6,"unzip1");
lf[223]=C_h_intern(&lf[223],11,"\004corelambda");
lf[224]=C_h_intern(&lf[224],14,"\004coreprimitive");
lf[225]=C_h_intern(&lf[225],11,"\004coreinline");
lf[226]=C_h_intern(&lf[226],13,"\004corecallunit");
lf[227]=C_h_intern(&lf[227],9,"\004coreproc");
lf[228]=C_h_intern(&lf[228],4,"set!");
lf[229]=C_h_intern(&lf[229],9,"\004coreset!");
lf[230]=C_h_intern(&lf[230],29,"\004coreforeign-callback-wrapper");
lf[231]=C_h_intern(&lf[231],5,"sixth");
lf[232]=C_h_intern(&lf[232],5,"fifth");
lf[233]=C_h_intern(&lf[233],20,"\004coreinline_allocate");
lf[234]=C_h_intern(&lf[234],8,"\004coreapp");
lf[235]=C_h_intern(&lf[235],9,"\004corecall");
lf[236]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[237]=C_h_intern(&lf[237],24,"\010compilersource-filename");
lf[238]=C_h_intern(&lf[238],28,"\003syssymbol->qualified-string");
lf[239]=C_h_intern(&lf[239],7,"\003sysget");
lf[240]=C_h_intern(&lf[240],34,"\010compileralways-bound-to-procedure");
lf[241]=C_h_intern(&lf[241],15,"\004coreinline_ref");
lf[242]=C_h_intern(&lf[242],18,"\004coreinline_update");
lf[243]=C_h_intern(&lf[243],19,"\004coreinline_loc_ref");
lf[244]=C_h_intern(&lf[244],22,"\004coreinline_loc_update");
lf[245]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[246]=C_h_intern(&lf[246],1,"o");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[248]=C_h_intern(&lf[248],30,"\010compilerbuild-expression-tree");
lf[249]=C_h_intern(&lf[249],12,"\004coreclosure");
lf[250]=C_h_intern(&lf[250],4,"last");
lf[251]=C_h_intern(&lf[251],3,"map");
lf[252]=C_h_intern(&lf[252],4,"list");
lf[253]=C_h_intern(&lf[253],7,"butlast");
lf[254]=C_h_intern(&lf[254],5,"cons*");
lf[255]=C_h_intern(&lf[255],9,"\004corebind");
lf[256]=C_h_intern(&lf[256],10,"\004coreunbox");
lf[257]=C_h_intern(&lf[257],8,"\004coreref");
lf[258]=C_h_intern(&lf[258],11,"\004coreupdate");
lf[259]=C_h_intern(&lf[259],13,"\004coreupdate_i");
lf[260]=C_h_intern(&lf[260],8,"\004corebox");
lf[261]=C_h_intern(&lf[261],9,"\004corecond");
lf[262]=C_h_intern(&lf[262],21,"\010compilerfold-boolean");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[264]=C_h_intern(&lf[264],31,"\010compilerinline-lambda-bindings");
lf[265]=C_h_intern(&lf[265],8,"split-at");
lf[266]=C_h_intern(&lf[266],10,"fold-right");
lf[267]=C_h_intern(&lf[267],4,"take");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[269]=C_h_intern(&lf[269],34,"\010compilercopy-node-tree-and-rename");
lf[270]=C_h_intern(&lf[270],9,"alist-ref");
lf[271]=C_h_intern(&lf[271],3,"eq\077");
lf[272]=C_h_intern(&lf[272],1,"f");
lf[273]=C_h_intern(&lf[273],4,"cons");
lf[274]=C_h_intern(&lf[274],16,"inline-transient");
lf[275]=C_h_intern(&lf[275],18,"\010compilertree-copy");
lf[276]=C_h_intern(&lf[276],19,"\010compilercopy-node!");
lf[277]=C_h_intern(&lf[277],20,"\010compilernode->sexpr");
lf[278]=C_h_intern(&lf[278],20,"\010compilersexpr->node");
lf[279]=C_h_intern(&lf[279],32,"\010compileremit-global-inline-file");
lf[280]=C_h_intern(&lf[280],5,"print");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[282]=C_h_intern(&lf[282],1,"i");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[285]=C_h_intern(&lf[285],2,"pp");
lf[286]=C_h_intern(&lf[286],3,"yes");
lf[287]=C_h_intern(&lf[287],2,"no");
lf[288]=C_h_intern(&lf[288],24,"\010compilerinline-max-size");
lf[289]=C_h_intern(&lf[289],15,"\010compilerinline");
lf[290]=C_h_intern(&lf[290],22,"\010compilerinline-global");
lf[291]=C_h_intern(&lf[291],26,"\010compilervariable-visible\077");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[295]=C_h_intern(&lf[295],15,"chicken-version");
lf[296]=C_h_intern(&lf[296],19,"with-output-to-file");
lf[297]=C_h_intern(&lf[297],25,"\010compilerload-inline-file");
lf[298]=C_h_intern(&lf[298],20,"with-input-from-file");
lf[299]=C_h_intern(&lf[299],19,"\010compilermatch-node");
lf[300]=C_h_intern(&lf[300],1,"a");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[302]=C_h_intern(&lf[302],37,"\010compilerexpression-has-side-effects\077");
lf[303]=C_h_intern(&lf[303],24,"foreign-callback-stub-id");
lf[304]=C_h_intern(&lf[304],4,"find");
lf[305]=C_h_intern(&lf[305],22,"foreign-callback-stubs");
lf[306]=C_h_intern(&lf[306],28,"\010compilersimple-lambda-node\077");
lf[307]=C_h_intern(&lf[307],31,"\010compilerdump-undefined-globals");
lf[308]=C_h_intern(&lf[308],8,"keyword\077");
lf[309]=C_h_intern(&lf[309],29,"\010compilerdump-defined-globals");
lf[310]=C_h_intern(&lf[310],25,"\010compilerdump-global-refs");
lf[311]=C_h_intern(&lf[311],28,"\003systoplevel-definition-hook");
lf[312]=C_h_intern(&lf[312],22,"\010compilerhide-variable");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[314]=C_h_intern(&lf[314],36,"\010compilercompute-database-statistics");
lf[315]=C_h_intern(&lf[315],29,"\010compilercurrent-program-size");
lf[316]=C_h_intern(&lf[316],30,"\010compileroriginal-program-size");
lf[317]=C_h_intern(&lf[317],33,"\010compilerprint-program-statistics");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\027;   database entries: \011");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known call sites: \011");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\027;   global variables: \011");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known procedures: \011");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\042;   variables with known values: \011");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\032 \011original program size: \011");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\023;   program size: \011");
lf[325]=C_h_intern(&lf[325],1,"s");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[327]=C_h_intern(&lf[327],35,"\010compilerpprint-expressions-to-file");
lf[328]=C_h_intern(&lf[328],17,"close-output-port");
lf[329]=C_h_intern(&lf[329],12,"pretty-print");
lf[330]=C_h_intern(&lf[330],19,"with-output-to-port");
lf[331]=C_h_intern(&lf[331],16,"open-output-file");
lf[332]=C_h_intern(&lf[332],19,"current-output-port");
lf[333]=C_h_intern(&lf[333],27,"\010compilerforeign-type-check");
lf[334]=C_h_intern(&lf[334],4,"char");
lf[335]=C_h_intern(&lf[335],13,"unsigned-char");
lf[336]=C_h_intern(&lf[336],6,"unsafe");
lf[337]=C_h_intern(&lf[337],25,"\003sysforeign-char-argument");
lf[338]=C_h_intern(&lf[338],3,"int");
lf[339]=C_h_intern(&lf[339],27,"\003sysforeign-fixnum-argument");
lf[340]=C_h_intern(&lf[340],5,"float");
lf[341]=C_h_intern(&lf[341],27,"\003sysforeign-flonum-argument");
lf[342]=C_h_intern(&lf[342],7,"pointer");
lf[343]=C_h_intern(&lf[343],26,"\003sysforeign-block-argument");
lf[344]=C_h_intern(&lf[344],15,"nonnull-pointer");
lf[345]=C_h_intern(&lf[345],8,"u8vector");
lf[346]=C_h_intern(&lf[346],34,"\003sysforeign-number-vector-argument");
lf[347]=C_h_intern(&lf[347],16,"nonnull-u8vector");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[349]=C_h_intern(&lf[349],7,"integer");
lf[350]=C_h_intern(&lf[350],28,"\003sysforeign-integer-argument");
lf[351]=C_h_intern(&lf[351],16,"unsigned-integer");
lf[352]=C_h_intern(&lf[352],37,"\003sysforeign-unsigned-integer-argument");
lf[353]=C_h_intern(&lf[353],9,"c-pointer");
lf[354]=C_h_intern(&lf[354],28,"\003sysforeign-pointer-argument");
lf[355]=C_h_intern(&lf[355],17,"nonnull-c-pointer");
lf[356]=C_h_intern(&lf[356],8,"c-string");
lf[357]=C_h_intern(&lf[357],17,"\003sysmake-c-string");
lf[358]=C_h_intern(&lf[358],27,"\003sysforeign-string-argument");
lf[359]=C_h_intern(&lf[359],16,"nonnull-c-string");
lf[360]=C_h_intern(&lf[360],6,"symbol");
lf[361]=C_h_intern(&lf[361],18,"\003syssymbol->string");
lf[362]=C_h_intern(&lf[362],3,"ref");
lf[363]=C_h_intern(&lf[363],8,"instance");
lf[364]=C_h_intern(&lf[364],12,"instance-ref");
lf[365]=C_h_intern(&lf[365],4,"this");
lf[366]=C_h_intern(&lf[366],8,"slot-ref");
lf[367]=C_h_intern(&lf[367],16,"nonnull-instance");
lf[368]=C_h_intern(&lf[368],5,"const");
lf[369]=C_h_intern(&lf[369],4,"enum");
lf[370]=C_h_intern(&lf[370],8,"function");
lf[371]=C_h_intern(&lf[371],27,"\010compilerforeign-type-table");
lf[372]=C_h_intern(&lf[372],17,"nonnull-c-string*");
lf[373]=C_h_intern(&lf[373],26,"nonnull-unsigned-c-string*");
lf[374]=C_h_intern(&lf[374],9,"c-string*");
lf[375]=C_h_intern(&lf[375],17,"unsigned-c-string");
lf[376]=C_h_intern(&lf[376],18,"unsigned-c-string*");
lf[377]=C_h_intern(&lf[377],13,"c-string-list");
lf[378]=C_h_intern(&lf[378],14,"c-string-list*");
lf[379]=C_h_intern(&lf[379],18,"unsigned-integer32");
lf[380]=C_h_intern(&lf[380],13,"unsigned-long");
lf[381]=C_h_intern(&lf[381],4,"long");
lf[382]=C_h_intern(&lf[382],9,"integer32");
lf[383]=C_h_intern(&lf[383],17,"nonnull-u16vector");
lf[384]=C_h_intern(&lf[384],16,"nonnull-s8vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-s16vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-u32vector");
lf[387]=C_h_intern(&lf[387],17,"nonnull-s32vector");
lf[388]=C_h_intern(&lf[388],17,"nonnull-f32vector");
lf[389]=C_h_intern(&lf[389],17,"nonnull-f64vector");
lf[390]=C_h_intern(&lf[390],9,"u16vector");
lf[391]=C_h_intern(&lf[391],8,"s8vector");
lf[392]=C_h_intern(&lf[392],9,"s16vector");
lf[393]=C_h_intern(&lf[393],9,"u32vector");
lf[394]=C_h_intern(&lf[394],9,"s32vector");
lf[395]=C_h_intern(&lf[395],9,"f32vector");
lf[396]=C_h_intern(&lf[396],9,"f64vector");
lf[397]=C_h_intern(&lf[397],22,"nonnull-scheme-pointer");
lf[398]=C_h_intern(&lf[398],12,"nonnull-blob");
lf[399]=C_h_intern(&lf[399],19,"nonnull-byte-vector");
lf[400]=C_h_intern(&lf[400],11,"byte-vector");
lf[401]=C_h_intern(&lf[401],4,"blob");
lf[402]=C_h_intern(&lf[402],14,"scheme-pointer");
lf[403]=C_h_intern(&lf[403],6,"double");
lf[404]=C_h_intern(&lf[404],6,"number");
lf[405]=C_h_intern(&lf[405],12,"unsigned-int");
lf[406]=C_h_intern(&lf[406],5,"short");
lf[407]=C_h_intern(&lf[407],14,"unsigned-short");
lf[408]=C_h_intern(&lf[408],4,"byte");
lf[409]=C_h_intern(&lf[409],13,"unsigned-byte");
lf[410]=C_h_intern(&lf[410],5,"int32");
lf[411]=C_h_intern(&lf[411],14,"unsigned-int32");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[413]=C_h_intern(&lf[413],36,"\010compilerforeign-type-convert-result");
lf[414]=C_h_intern(&lf[414],38,"\010compilerforeign-type-convert-argument");
lf[415]=C_h_intern(&lf[415],27,"\010compilerfinal-foreign-type");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[417]=C_h_intern(&lf[417],37,"\010compilerestimate-foreign-result-size");
lf[418]=C_h_intern(&lf[418],9,"integer64");
lf[419]=C_h_intern(&lf[419],4,"bool");
lf[420]=C_h_intern(&lf[420],4,"void");
lf[421]=C_h_intern(&lf[421],13,"scheme-object");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[423]=C_h_intern(&lf[423],46,"\010compilerestimate-foreign-result-location-size");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\0005cannot compute size of location for foreign type `~S\047");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[426]=C_h_intern(&lf[426],30,"\010compilerfinish-foreign-result");
lf[427]=C_h_intern(&lf[427],17,"\003syspeek-c-string");
lf[428]=C_h_intern(&lf[428],25,"\003syspeek-nonnull-c-string");
lf[429]=C_h_intern(&lf[429],26,"\003syspeek-and-free-c-string");
lf[430]=C_h_intern(&lf[430],34,"\003syspeek-and-free-nonnull-c-string");
lf[431]=C_h_intern(&lf[431],17,"\003sysintern-symbol");
lf[432]=C_h_intern(&lf[432],22,"\003syspeek-c-string-list");
lf[433]=C_h_intern(&lf[433],31,"\003syspeek-and-free-c-string-list");
lf[434]=C_h_intern(&lf[434],35,"\010tinyclosmake-instance-from-pointer");
lf[435]=C_h_intern(&lf[435],4,"make");
lf[436]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[437]=C_h_intern(&lf[437],28,"\010compilerscan-used-variables");
lf[438]=C_h_intern(&lf[438],28,"\010compilerscan-free-variables");
lf[439]=C_h_intern(&lf[439],11,"lset-adjoin");
lf[440]=C_h_intern(&lf[440],23,"\010compilerchop-separator");
lf[441]=C_h_intern(&lf[441],9,"substring");
lf[442]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[443]=C_h_intern(&lf[443],23,"\010compilerchop-extension");
lf[444]=C_h_intern(&lf[444],22,"\010compilerprint-version");
lf[445]=C_h_intern(&lf[445],6,"print*");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2009 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[447]=C_h_intern(&lf[447],20,"\010compilerprint-usage");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\027\246Usage: chicken FILENAME OPTION ...\012\012  `chicken\047 is the CHICKEN compiler.\012  "
"\012  FILENAME should be a complete source file name with extension, or \042-\042 for\012  s"
"tandard input. OPTION may be one of the following:\012\012  General options:\012\012    -hel"
"p                        display this text and exit\012    -version                "
"     display compiler version and exit\012    -release                     print re"
"lease number and exit\012    -verbose                     display information on co"
"mpilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME     "
"   specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME     "
"  specifies alternative path for included files\012    -to-stdout                  "
" write compiled file to stdout instead of file\012\012  Language options:\012\012    -featur"
"e SYMBOL              register feature identifier\012\012  Syntax related options:\012\012  "
"  -case-insensitive            don\047t preserve case of read symbols\012    -keyword-"
"style STYLE         allow alternative keyword syntax\012                           "
"       (prefix, suffix or none)\012    -no-parentheses-synonyms     disables list d"
"elimiter synonyms\012    -no-symbol-escape            disables support for escaped "
"symbols\012    -r5rs-syntax                 disables the Chicken extensions to\012    "
"                              R5RS syntax\012    -compile-syntax              macro"
"s are made available at run-time\012    -emit-import-library MODULE  write compile-"
"time module information into\012                                  separate file\012   "
" -no-compiler-syntax          disable expansion of compiler-macros\012\012  Translatio"
"n options:\012\012    -explicit-use                do not use units \047library\047 and \047eva"
"l\047 by\012                                  default\012    -check-syntax               "
" stop compilation after macro-expansion\012    -analyze-only                stop co"
"mpilation after first analysis pass\012\012  Debugging options:\012\012    -no-warnings     "
"            disable warnings\012    -disable-warning CLASS       disable specific c"
"lass of warnings\012    -debug-level NUMBER          set level of available debuggi"
"ng information\012    -no-trace                    disable tracing information\012    "
"-profile                     executable emits profiling information \012    -profil"
"e-name FILENAME       name of the generated profile information file\012    -accumu"
"late-profile          executable emits profiling information in\012                "
"                  append mode\012    -no-lambda-info              omit additional p"
"rocedure-information\012    -scrutinize                  perform local flow analysi"
"s\012    -types FILENAME              load additional type database\012\012  Optimization"
" options:\012\012    -optimize-level NUMBER       enable certain sets of optimization "
"options\012    -optimize-leaf-routines      enable leaf routine optimization\012    -l"
"ambda-lift                 enable lambda-lifting\012    -no-usual-integrations     "
"  standard procedures may be redefined\012    -unsafe                      disable "
"all safety checks\012    -local                       assume globals are only modif"
"ied in current\012                                  file\012    -block                "
"       enable block-compilation\012    -disable-interrupts          disable interru"
"pts in compiled code\012    -fixnum-arithmetic           assume all numbers are fix"
"nums\012    -benchmark-mode              equivalent to \047block -optimize-level 4\012   "
"                               -debug-level 0 -fixnum-arithmetic -lambda-lift\012  "
"                                -inline -disable-interrupts\047\012    -disable-stack-"
"overflow-checks  disables detection of stack-overflows\012    -inline              "
"        enable inlining\012    -inline-limit                set inlining threshold\012"
"    -inline-global               enable cross-module inlining\012    -emit-inline-f"
"ile FILENAME   generate file with globally inlinable\012                           "
"       procedures (implies -inline -local)\012    -consult-inline-file FILENAME  ex"
"plicitly load inline file\012    -no-argc-checks              disable argument coun"
"t checks\012    -no-bound-checks             disable bound variable checks\012    -no-"
"procedure-checks         disable procedure call checks\012    -no-procedure-checks-"
"for-usual-bindings\012                                 disable procedure call check"
"s only for usual\012                                  bindings\012\012  Configuration opt"
"ions:\012\012    -unit NAME                   compile file as a library unit\012    -uses"
" NAME                   declare library unit as used.\012    -heap-size NUMBER     "
"       specifies heap-size of compiled executable\012    -heap-initial-size NUMBER "
"   specifies heap-size at startup time\012    -heap-growth PERCENTAGE      specifie"
"s growth-rate of expanding heap\012    -heap-shrinkage PERCENTAGE   specifies shrin"
"k-rate of contracting heap\012    -nursery NUMBER  -stack-size NUMBER\012             "
"                    specifies nursery size of compiled executable\012    -extend FI"
"LENAME             load file before compilation commences\012    -prelude EXPRESSIO"
"N          add expression to front of source file\012    -postlude EXPRESSION      "
"   add expression to end of source file\012    -prologue FILENAME           include"
" file before main source file\012    -epilogue FILENAME           include file afte"
"r main source file\012    -dynamic                     compile as dynamically loada"
"ble code\012    -require-extension NAME      require and import extension NAME\012    "
"-static-extension NAME       import extension NAME but link statically\012         "
"                         (if available)\012\012  Obscure options:\012\012    -debug MODES   "
"              display debugging output for the given modes\012    -unsafe-libraries"
"            marks the generated file as being linked with\012                      "
"            the unsafe runtime system\012    -raw                         do not ge"
"nerate implicit init- and exit code                           \012    -emit-externa"
"l-prototypes-first\012                                 emit prototypes for callback"
"s before foreign\012                                  declarations\012    -ignore-repo"
"sitory           do not refer to repository for extensions\012");
lf[449]=C_h_intern(&lf[449],36,"\010compilermake-block-variable-literal");
lf[450]=C_h_intern(&lf[450],22,"block-variable-literal");
lf[451]=C_h_intern(&lf[451],32,"\010compilerblock-variable-literal\077");
lf[452]=C_h_intern(&lf[452],36,"\010compilerblock-variable-literal-name");
lf[453]=C_h_intern(&lf[453],25,"\010compilermake-random-name");
lf[454]=C_h_intern(&lf[454],6,"random");
lf[455]=C_h_intern(&lf[455],15,"current-seconds");
lf[456]=C_h_intern(&lf[456],23,"\010compilerset-real-name!");
lf[457]=C_h_intern(&lf[457],24,"\010compilerreal-name-table");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[459]=C_h_intern(&lf[459],19,"\010compilerreal-name2");
lf[460]=C_h_intern(&lf[460],32,"\010compilerdisplay-real-name-table");
lf[461]=C_h_intern(&lf[461],28,"\010compilersource-info->string");
lf[462]=C_h_intern(&lf[462],4,"conc");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[465]=C_h_intern(&lf[465],11,"make-string");
lf[466]=C_h_intern(&lf[466],3,"max");
lf[467]=C_h_intern(&lf[467],26,"\010compilersource-info->line");
lf[468]=C_h_intern(&lf[468],12,"string-null\077");
lf[469]=C_h_intern(&lf[469],19,"\010compilerdump-nodes");
lf[470]=C_h_intern(&lf[470],18,"\003sysuser-read-hook");
lf[471]=C_h_intern(&lf[471],15,"foreign-declare");
lf[472]=C_h_intern(&lf[472],7,"declare");
lf[473]=C_h_intern(&lf[473],34,"\010compilerscan-sharp-greater-string");
lf[474]=C_h_intern(&lf[474],18,"\003sysread-char/port");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[476]=C_h_intern(&lf[476],6,"hidden");
lf[477]=C_h_intern(&lf[477],19,"\010compilervisibility");
lf[478]=C_h_intern(&lf[478],24,"\010compilerexport-variable");
lf[479]=C_h_intern(&lf[479],8,"exported");
lf[480]=C_h_intern(&lf[480],26,"\010compilerblock-compilation");
lf[481]=C_h_intern(&lf[481],22,"\010compilermark-variable");
lf[482]=C_h_intern(&lf[482],22,"\010compilervariable-mark");
lf[483]=C_h_intern(&lf[483],19,"\010compilerintrinsic\077");
lf[484]=C_h_intern(&lf[484],9,"foldable\077");
lf[485]=C_h_intern(&lf[485],33,"\010compilerload-identifier-database");
lf[486]=C_h_intern(&lf[486],7,"\004coredb");
lf[487]=C_h_intern(&lf[487],9,"read-file");
lf[488]=C_h_intern(&lf[488],21,"\010compilerverbose-mode");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\034loading identifier database ");
lf[491]=C_h_intern(&lf[491],13,"make-pathname");
lf[492]=C_h_intern(&lf[492],15,"repository-path");
lf[493]=C_h_intern(&lf[493],27,"condition-property-accessor");
lf[494]=C_h_intern(&lf[494],3,"exn");
lf[495]=C_h_intern(&lf[495],7,"message");
lf[496]=C_h_intern(&lf[496],19,"condition-predicate");
C_register_lf2(lf,497,create_ptable());
t2=C_mutate(&lf[0] /* (set! c514 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3181 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3184 in k3181 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3189,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3187 in k3184 in k3181 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3192,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3195,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3198,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3198,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3202,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[3] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[4] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[5]+1 /* (set! bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3207,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3234,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[19]+1 /* (set! compiler-warning ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3293,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[24]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3322,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[27]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3341,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[34]+1 /* (set! syntax-error ...) */,*((C_word*)lf[27]+1));
t11=C_mutate((C_word*)lf[35]+1 /* (set! emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3402,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[36]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3405,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[37]+1 /* (set! check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3448,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[40]+1 /* (set! posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3516,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[41]+1 /* (set! stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3552,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[45]+1 /* (set! symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3579,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[47]+1 /* (set! build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3610,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[48]+1 /* (set! string->c-identifier ...) */,C_retrieve(lf[49]));
t19=C_mutate((C_word*)lf[50]+1 /* (set! c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3654,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[59]+1 /* (set! valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3748,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[62]+1 /* (set! words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3804,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[63]+1 /* (set! words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3811,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[64]+1 /* (set! check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3818,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[71]+1 /* (set! close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3865,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[74]+1 /* (set! fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3877,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[76]+1 /* (set! follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3940,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[77]+1 /* (set! sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3971,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[80]+1 /* (set! constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3991,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[82]+1 /* (set! collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4037,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[83]+1 /* (set! immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4067,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[85]+1 /* (set! basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4113,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[88]+1 /* (set! canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4173,tmp=(C_word)a,a+=2,tmp));
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4270,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 255  condition-predicate");
((C_proc3)C_retrieve_symbol_proc(lf[496]))(3,*((C_word*)lf[496]+1),t33,lf[494]);}

/* k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4273,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 256  condition-property-accessor");
((C_proc4)C_retrieve_symbol_proc(lf[493]))(4,*((C_word*)lf[493]+1),t2,lf[494],lf[495]);}

/* k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word ab[177],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4273,2,t0,t1);}
t2=C_mutate((C_word*)lf[95]+1 /* (set! string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[107]+1 /* (set! decompose-lambda-list ...) */,C_retrieve(lf[108]));
t4=C_mutate((C_word*)lf[109]+1 /* (set! process-lambda-documentation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4381,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[110]+1 /* (set! llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4384,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[111]+1 /* (set! expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4387,tmp=(C_word)a,a+=2,tmp));
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[121]+1 /* (set! initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4528,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[133]+1 /* (set! get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4763,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[135]+1 /* (set! get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4781,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[137]+1 /* (set! put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4799,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[139]+1 /* (set! collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4845,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[140]+1 /* (set! count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4897,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[141]+1 /* (set! get-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4954,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[142]+1 /* (set! get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4963,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[144]+1 /* (set! get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4973,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[145]+1 /* (set! find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5009,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[147]+1 /* (set! display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5033,tmp=(C_word)a,a+=2,tmp));
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate((C_word*)lf[151]+1 /* (set! display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5061,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[199]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5536,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[201]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5542,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[202]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5548,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[204]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5557,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[205]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5566,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[206]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5575,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[207]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5584,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[208]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5593,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[199]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5602,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[209]+1 /* (set! varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5608,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[211]+1 /* (set! qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5617,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[212]+1 /* (set! build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5626,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[248]+1 /* (set! build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6140,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[262]+1 /* (set! fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6458,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[264]+1 /* (set! inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6506,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[269]+1 /* (set! copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6599,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[275]+1 /* (set! tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6801,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[276]+1 /* (set! copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6835,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[277]+1 /* (set! node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6859,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[278]+1 /* (set! sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6895,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[279]+1 /* (set! emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6920,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[297]+1 /* (set! load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7106,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[299]+1 /* (set! match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7175,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[302]+1 /* (set! expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7370,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[306]+1 /* (set! simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7456,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[307]+1 /* (set! dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7548,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[309]+1 /* (set! dump-defined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7589,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[310]+1 /* (set! dump-global-refs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7626,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[311]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7675,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[314]+1 /* (set! compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7696,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[317]+1 /* (set! print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7792,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[327]+1 /* (set! pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7873,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[333]+1 /* (set! foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7925,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[413]+1 /* (set! foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8978,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[414]+1 /* (set! foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9009,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[415]+1 /* (set! final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9040,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[417]+1 /* (set! estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9080,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[423]+1 /* (set! estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9405,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[426]+1 /* (set! finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9721,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[437]+1 /* (set! scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10019,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[438]+1 /* (set! scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10143,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[440]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10331,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[443]+1 /* (set! chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10360,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[444]+1 /* (set! print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10402,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[447]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10440,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[449]+1 /* (set! make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10452,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[451]+1 /* (set! block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10458,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[452]+1 /* (set! block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10464,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[453]+1 /* (set! make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10473,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[456]+1 /* (set! set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10532,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[39]+1 /* (set! real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10538,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[459]+1 /* (set! real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10629,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[460]+1 /* (set! display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10641,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[461]+1 /* (set! source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10662,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[467]+1 /* (set! source-info->line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10708,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[468]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10726,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[469]+1 /* (set! dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10729,tmp=(C_word)a,a+=2,tmp));
t80=C_retrieve(lf[470]);
t81=C_mutate((C_word*)lf[470]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10853,a[2]=t80,tmp=(C_word)a,a+=3,tmp));
t82=C_mutate((C_word*)lf[473]+1 /* (set! scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10886,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[84]+1 /* (set! big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10955,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[312]+1 /* (set! hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10979,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[478]+1 /* (set! export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11012,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[291]+1 /* (set! variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11045,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[481]+1 /* (set! mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11066,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[482]+1 /* (set! variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11094,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[483]+1 /* (set! intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11100,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[484]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11106,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[485]+1 /* (set! load-identifier-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11112,tmp=(C_word)a,a+=2,tmp));
t92=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t92+1)))(2,t92,C_SCHEME_UNDEFINED);}

/* ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11112,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11116,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1472 repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[492]))(2,*((C_word*)lf[492]+1),t3);}

/* k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11116,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11122,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11200,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1473 make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[491]))(4,*((C_word*)lf[491]+1),t3,t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11198 in k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1473 file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],t1);}

/* k11120 in k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11122,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11128,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[488]))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11187,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t4,lf[490],t3);}
else{
t3=t2;
f_11128(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11185 in k11120 in k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k11188 in k11185 in k11120 in k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[489],((C_word*)t0)[2]);}

/* k11191 in k11188 in k11185 in k11120 in k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k11126 in k11120 in k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11135,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1481 read-file");
((C_proc3)C_retrieve_symbol_proc(lf[487]))(3,*((C_word*)lf[487]+1),t2,((C_word*)t0)[2]);}

/* k11133 in k11126 in k11120 in k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11135,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11137,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_11137(t5,((C_word*)t0)[2],t1);}

/* loop3049 in k11133 in k11126 in k11120 in k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_11137(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11137,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11150,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11165,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11169,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_car(t3);
C_trace("support.scm: 1480 ##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t7,t8,lf[486]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11167 in loop3049 in k11133 in k11126 in k11120 in k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11169,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
C_trace("support.scm: 1480 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[2],t2,t4);}

/* k11163 in loop3049 in k11133 in k11126 in k11120 in k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1478 ##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[486],t1);}

/* k11148 in loop3049 in k11133 in k11126 in k11120 in k11114 in ##compiler#load-identifier-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11137(t3,((C_word*)t0)[2],t2);}

/* foldable? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11106,3,t0,t1,t2);}
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t1,t2,lf[128]);}

/* ##compiler#intrinsic? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11100,3,t0,t1,t2);}
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t1,t2,lf[124]);}

/* ##compiler#variable-mark in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11094,4,t0,t1,t2,t3);}
C_trace("support.scm: 1463 ##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t1,t2,t3);}

/* ##compiler#mark-variable in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11066r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11066r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11066r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11070,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("support.scm: 1460 ##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,t3,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=(C_word)C_i_car(t4);
C_trace("support.scm: 1460 ##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,t3,t7);}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11068 in ##compiler#mark-variable in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1460 ##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#variable-visible? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11045,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11049,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1453 ##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t3,t2,lf[477]);}

/* k11047 in ##compiler#variable-visible? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[476]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(t1,lf[479]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_i_not(C_retrieve(lf[480]))));}}

/* ##compiler#export-variable in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11012,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[479]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11018,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,lf[477],C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,lf[477],t6);}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k11016 in ##compiler#export-variable in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_11018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[477],t1);}

/* ##compiler#hide-variable in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10979,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[476]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10985,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,lf[477],C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t1,t2,lf[477],t6);}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k10983 in ##compiler#hide-variable in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[477],t1);}

/* ##compiler#big-fixnum? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10955(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10955,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnump(t2))){
if(C_truep((C_word)C_fudge(C_fix(3)))){
t3=(C_word)C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#scan-sharp-greater-string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10886,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10890,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1415 open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[44]))(2,*((C_word*)lf[44]+1),t3);}

/* k10888 in ##compiler#scan-sharp-greater-string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10890,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10895,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10895(t5,((C_word*)t0)[2]);}

/* loop in k10888 in ##compiler#scan-sharp-greater-string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10895,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("read-char/port");
t3=C_retrieve(lf[474]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10897 in loop in k10888 in ##compiler#scan-sharp-greater-string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10899,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
C_trace("support.scm: 1418 quit");
((C_proc3)C_retrieve_proc(*((C_word*)lf[24]+1)))(3,*((C_word*)lf[24]+1),((C_word*)t0)[5],lf[475]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10917,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1420 newline");
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10929,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("read-char/port");
t3=C_retrieve(lf[474]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10950,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k10948 in k10897 in loop in k10888 in ##compiler#scan-sharp-greater-string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1432 loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_10895(t2,((C_word*)t0)[2]);}

/* k10927 in k10897 in loop in k10888 in ##compiler#scan-sharp-greater-string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10929,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
C_trace("support.scm: 1425 get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10941,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t4=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k10939 in k10927 in k10897 in loop in k10888 in ##compiler#scan-sharp-greater-string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10944,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10942 in k10939 in k10927 in k10897 in loop in k10888 in ##compiler#scan-sharp-greater-string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1429 loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_10895(t2,((C_word*)t0)[2]);}

/* k10915 in k10897 in loop in k10888 in ##compiler#scan-sharp-greater-string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1421 loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_10895(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10853,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10863,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("read-char/port");
t6=C_retrieve(lf[474]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
C_trace("support.scm: 1412 old-hook");
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k10861 in ##sys#user-read-hook in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10866,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1410 scan-sharp-greater-string");
((C_proc3)C_retrieve_symbol_proc(lf[473]))(3,*((C_word*)lf[473]+1),t2,((C_word*)t0)[2]);}

/* k10864 in k10861 in ##sys#user-read-hook in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10866,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[471],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[472],t4));}

/* ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10729,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10733,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10738,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_10738(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10738(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10738,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10751,a[2]=t5,a[3]=t7,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
C_trace("support.scm: 1388 make-string");
((C_proc4)C_retrieve_proc(*((C_word*)lf[465]+1)))(4,*((C_word*)lf[465]+1),t10,t2,C_make_character(32));}

/* k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10751,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10757,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
C_trace("write-char/port");
t5=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(10),t3);}

/* k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(60),((C_word*)t0)[3]);}

/* k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10766,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10772,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10770 in k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10775,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10831(t6,t2,((C_word*)t0)[2]);}

/* loop2877 in k10770 in k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10831(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10831,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10844,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("loop2856");
t5=((C_word*)((C_word*)t0)[3])[1];
f_10738(t5,t4,((C_word*)t0)[2],t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10842 in loop2877 in k10770 in k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10831(t3,((C_word*)t0)[2],t2);}

/* k10773 in k10770 in k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10775,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10781,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(4)))){
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10790,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t6=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_make_character(91),t4);}
else{
C_trace("write-char/port");
t4=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[11]+1));}}

/* k10788 in k10773 in k10770 in k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,t3,((C_word*)t0)[2]);}

/* k10791 in k10788 in k10773 in k10770 in k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10796,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10801,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10801(t6,t2,C_fix(5));}

/* doloop2898 in k10791 in k10788 in k10773 in k10770 in k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10801(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10801,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10811,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("write-char/port");
t5=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(32),t3);}}

/* k10809 in doloop2898 in k10791 in k10788 in k10773 in k10770 in k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10814,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[6]);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,t3,((C_word*)t0)[2]);}

/* k10812 in k10809 in doloop2898 in k10791 in k10788 in k10773 in k10770 in k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10801(t3,((C_word*)t0)[2],t2);}

/* k10794 in k10791 in k10788 in k10773 in k10770 in k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[11]+1));}

/* k10779 in k10773 in k10770 in k10767 in k10764 in k10761 in k10758 in k10755 in k10749 in loop in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[11]+1));}

/* k10731 in ##compiler#dump-nodes in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1400 newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* string-null? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10726,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_null_p(C_retrieve(lf[325])));}

/* ##compiler#source-info->line in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10708,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}
else{
if(C_truep(t2)){
C_trace("support.scm: 1372 ->string");
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* ##compiler#source-info->string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10662(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10662,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10681,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1365 ->string");
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t6,t4);}
else{
if(C_truep(t2)){
C_trace("support.scm: 1367 ->string");
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k10679 in ##compiler#source-info->string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10688,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10692,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_string_length(t1);
t5=(C_word)C_fixnum_difference(C_fix(4),t4);
C_trace("support.scm: 1366 max");
((C_proc4)C_retrieve_proc(*((C_word*)lf[466]+1)))(4,*((C_word*)lf[466]+1),t3,C_fix(0),t5);}

/* k10690 in k10679 in ##compiler#source-info->string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1366 make-string");
((C_proc4)C_retrieve_proc(*((C_word*)lf[465]+1)))(4,*((C_word*)lf[465]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k10686 in k10679 in ##compiler#source-info->string in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1366 conc");
((C_proc8)C_retrieve_symbol_proc(lf[462]))(8,*((C_word*)lf[462]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[463],((C_word*)t0)[3],t1,lf[464],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10647,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 1355 ##sys#hash-table-for-each");
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t2,C_retrieve(lf[457]));}

/* a10646 in ##compiler#display-real-name-table in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10647,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10651,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t5,t2,t4);}

/* k10649 in a10646 in ##compiler#display-real-name-table in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(9),((C_word*)t0)[3]);}

/* k10652 in k10649 in a10646 in ##compiler#display-real-name-table in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10655 in k10652 in k10649 in a10646 in ##compiler#display-real-name-table in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##compiler#real-name2 in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10629,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10633,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1351 ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[457]),t2);}

/* k10631 in ##compiler#real-name2 in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 1352 real-name");
((C_proc4)C_retrieve_symbol_proc(lf[39]))(4,*((C_word*)lf[39]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10538(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_10538r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_10538r(t0,t1,t2,t3);}}

static void C_ccall f_10538r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10541,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10557,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 1335 resolve");
f_10541(t5,t2);}

/* k10555 in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10557,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[5]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 1339 ##sys#symbol->qualified-string");
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),t4,t1);}
else{
C_trace("support.scm: 1348 ##sys#symbol->qualified-string");
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),((C_word*)t0)[3],t1);}}
else{
C_trace("support.scm: 1336 ##sys#symbol->qualified-string");
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k10580 in k10555 in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10586,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 1340 get");
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[146]);}

/* k10584 in k10580 in k10555 in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10586,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10588,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10588(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k10584 in k10580 in k10555 in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10588(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10588,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10595,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 1342 resolve");
f_10541(t4,t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k10593 in loop in k10584 in k10580 in k10555 in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10595,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10608,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[44]))(2,*((C_word*)lf[44]+1),t3);}}

/* k10606 in k10593 in loop in k10584 in k10580 in k10555 in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10611,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],t1);}

/* k10609 in k10606 in k10593 in loop in k10584 in k10580 in k10555 in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[458],((C_word*)t0)[3]);}

/* k10612 in k10609 in k10606 in k10593 in loop in k10584 in k10580 in k10555 in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10617,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10615 in k10612 in k10609 in k10606 in k10593 in loop in k10584 in k10580 in k10555 in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k10618 in k10615 in k10612 in k10609 in k10606 in k10593 in loop in k10584 in k10580 in k10555 in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10624,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1346 get");
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[146]);}

/* k10622 in k10618 in k10615 in k10612 in k10609 in k10606 in k10593 in loop in k10584 in k10580 in k10555 in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1345 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_10588(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10541(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10541,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10545,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1330 ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t3,C_retrieve(lf[457]),t2);}

/* k10543 in resolve in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10545,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10551,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1332 ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t2,C_retrieve(lf[457]),t1);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10549 in k10543 in resolve in ##compiler#real-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#set-real-name! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10532,4,t0,t1,t2,t3);}
C_trace("support.scm: 1326 ##sys#hash-table-set!");
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),t1,C_retrieve(lf[457]),t2,t3);}

/* ##compiler#make-random-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10473(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_10473r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10473r(t0,t1,t2);}}

static void C_ccall f_10473r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10481,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[44]))(2,*((C_word*)lf[44]+1),t3);}

/* k10479 in ##compiler#make-random-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10484,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10508,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("support.scm: 1313 gensym");
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,t6,t1);}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k10506 in k10479 in ##compiler#make-random-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10482 in k10479 in ##compiler#make-random-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(45),((C_word*)t0)[2]);}

/* k10485 in k10482 in k10479 in ##compiler#make-random-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10504,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1314 current-seconds");
((C_proc2)C_retrieve_symbol_proc(lf[455]))(2,*((C_word*)lf[455]+1),t3);}

/* k10502 in k10485 in k10482 in k10479 in ##compiler#make-random-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10488 in k10485 in k10482 in k10479 in ##compiler#make-random-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10500,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1315 random");
((C_proc3)C_retrieve_symbol_proc(lf[454]))(3,*((C_word*)lf[454]+1),t3,C_fix(1000));}

/* k10498 in k10488 in k10485 in k10482 in k10479 in ##compiler#make-random-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10491 in k10488 in k10485 in k10482 in k10479 in ##compiler#make-random-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10496,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k10494 in k10491 in k10488 in k10485 in k10482 in k10479 in ##compiler#make-random-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1311 string->symbol");
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10464,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[450]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10458(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10458,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[450]));}

/* ##compiler#make-block-variable-literal in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10452,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[450],t2));}

/* ##compiler#print-usage in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10444,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1174 print-version");
((C_proc2)C_retrieve_symbol_proc(lf[444]))(2,*((C_word*)lf[444]+1),t2);}

/* k10442 in ##compiler#print-usage in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1175 newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),t2);}

/* k10445 in k10442 in ##compiler#print-usage in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1176 display");
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),((C_word*)t0)[2],lf[448]);}

/* ##compiler#print-version in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10402(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_10402r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10402r(t0,t1,t2);}}

static void C_ccall f_10402r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10406,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_10406(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_10406(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k10404 in ##compiler#print-version in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
C_trace("support.scm: 1170 print*");
((C_proc3)C_retrieve_proc(*((C_word*)lf[445]+1)))(3,*((C_word*)lf[445]+1),t2,lf[446]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f13068,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1171 chicken-version");
((C_proc3)C_retrieve_symbol_proc(lf[295]))(3,*((C_word*)lf[295]+1),t3,C_SCHEME_TRUE);}}

/* f13068 in k10404 in ##compiler#print-version in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f13068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1171 print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[280]+1)))(3,*((C_word*)lf[280]+1),((C_word*)t0)[2],t1);}

/* k10407 in k10404 in ##compiler#print-version in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1171 chicken-version");
((C_proc3)C_retrieve_symbol_proc(lf[295]))(3,*((C_word*)lf[295]+1),t2,C_SCHEME_TRUE);}

/* k10414 in k10407 in k10404 in ##compiler#print-version in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1171 print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[280]+1)))(3,*((C_word*)lf[280]+1),((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10360,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10369,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10369(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10369(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10369,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[3];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(46),t4);
if(C_truep(t5)){
C_trace("support.scm: 1163 substring");
((C_proc5)C_retrieve_proc(*((C_word*)lf[441]+1)))(5,*((C_word*)lf[441]+1),t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t6=(C_word)C_fixnum_decrease(t2);
C_trace("support.scm: 1164 loop");
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}

/* ##compiler#chop-separator in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10331,3,t0,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_decrease(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10341,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t6=(C_word)C_i_string_ref(t2,t4);
t7=t5;
f_10341(t7,(C_word)C_i_memq(t6,lf[442]));}
else{
t6=t5;
f_10341(t6,C_SCHEME_FALSE);}}

/* k10339 in ##compiler#chop-separator in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10341(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 1156 substring");
((C_proc5)C_retrieve_proc(*((C_word*)lf[441]+1)))(5,*((C_word*)lf[441]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10143,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10146,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10297,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10326,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1146 walk");
t14=((C_word*)t8)[1];
f_10146(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k10324 in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1147 values");
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10297(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10297,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10303,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_10303(t7,t1,t2);}

/* loop2711 in walkeach in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10303(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10303,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10316,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1144 walk");
t5=((C_word*)((C_word*)t0)[3])[1];
f_10146(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10314 in loop2711 in walkeach in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10303(t3,((C_word*)t0)[2],t2);}

/* walk in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10146(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10146,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[81]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t7,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t10)){
t12=t11;
f_10165(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[216]);
if(C_truep(t12)){
t13=t11;
f_10165(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[224]);
if(C_truep(t13)){
t14=t11;
f_10165(t14,t13);}
else{
t14=(C_word)C_eqp(t9,lf[227]);
t15=t11;
f_10165(t15,(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[241])));}}}}

/* k10163 in walk in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10165,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[210]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[7]))){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10184,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 1126 lset-adjoin");
((C_proc5)C_retrieve_symbol_proc(lf[439]))(5,*((C_word*)lf[439]+1),t4,*((C_word*)lf[271]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[228]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[7]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("support.scm: 1132 walk");
t6=((C_word*)((C_word*)t0)[3])[1];
f_10146(t6,((C_word*)t0)[10],t5,((C_word*)t0)[7]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10220,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 1131 lset-adjoin");
((C_proc5)C_retrieve_symbol_proc(lf[439]))(5,*((C_word*)lf[439]+1),t5,*((C_word*)lf[271]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[91]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10229,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("support.scm: 1134 walk");
t7=((C_word*)((C_word*)t0)[3])[1];
f_10146(t7,t5,t6,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[223]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10259,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1137 decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[10],t6,t7);}
else{
C_trace("support.scm: 1141 walkeach");
t6=((C_word*)((C_word*)t0)[2])[1];
f_10297(t6,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* a10258 in k10163 in walk in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10259(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10259,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10271,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1140 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t6,t2,((C_word*)t0)[2]);}

/* k10269 in a10258 in k10163 in walk in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1140 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_10146(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10227 in k10163 in walk in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10229,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10240,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1135 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10238 in k10227 in k10163 in walk in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 1135 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_10146(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10218 in k10163 in walk in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("support.scm: 1132 walk");
t4=((C_word*)((C_word*)t0)[4])[1];
f_10146(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k10182 in k10163 in walk in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10184,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 1127 variable-visible?");
((C_proc3)C_retrieve_symbol_proc(lf[291]))(3,*((C_word*)lf[291]+1),t3,((C_word*)t0)[2]);}

/* k10188 in k10182 in k10163 in walk in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10190,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10194,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1128 lset-adjoin");
((C_proc5)C_retrieve_symbol_proc(lf[439]))(5,*((C_word*)lf[439]+1),t2,*((C_word*)lf[271]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k10192 in k10188 in k10182 in k10163 in walk in ##compiler#scan-free-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10019,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10023,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10025,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_10025(t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10025(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10025,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[210]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,lf[228]));
if(C_truep(t8)){
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10047,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10076,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t14=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[3])[1]);
t15=t13;
f_10076(t15,(C_word)C_i_not(t14));}
else{
t14=t13;
f_10076(t14,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[81]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10103,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_10103(t11,t9);}
else{
t11=(C_word)C_eqp(t6,lf[216]);
t12=t10;
f_10103(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[224])));}}}

/* k10101 in walk in ##compiler#scan-used-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10103(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10103,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10108,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_10108(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop2646 in k10101 in walk in ##compiler#scan-used-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10108(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10108,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10118,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2603");
t5=((C_word*)((C_word*)t0)[2])[1];
f_10025(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10116 in loop2646 in k10101 in walk in ##compiler#scan-used-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10108(t3,((C_word*)t0)[2],t2);}

/* k10074 in walk in ##compiler#scan-used-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10076,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_10047(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_10047(t2,C_SCHEME_UNDEFINED);}}

/* k10045 in walk in ##compiler#scan-used-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10047(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10047,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10052,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_10052(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2626 in k10045 in walk in ##compiler#scan-used-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_10052(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10052,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10062,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2603");
t5=((C_word*)((C_word*)t0)[2])[1];
f_10025(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10060 in loop2626 in k10045 in walk in ##compiler#scan-used-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10052(t3,((C_word*)t0)[2],t2);}

/* k10021 in ##compiler#scan-used-variables in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_10023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9721,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[356]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,lf[375]));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[81],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[427],t10));}
else{
t7=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t7)){
t8=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[81],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t3,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[428],t11));}
else{
t8=(C_word)C_eqp(t4,lf[374]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t4,lf[376]));
if(C_truep(t9)){
t10=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[81],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t3,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,lf[429],t13));}
else{
t10=(C_word)C_eqp(t4,lf[372]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[373]));
if(C_truep(t11)){
t12=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,lf[81],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,t3,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_a_i_cons(&a,2,lf[430],t15));}
else{
t12=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t12)){
t13=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,lf[81],t13);
t15=(C_word)C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t3,t15);
t17=(C_word)C_a_i_cons(&a,2,lf[427],t16);
t18=(C_word)C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,lf[431],t18));}
else{
t13=(C_word)C_eqp(t4,lf[377]);
if(C_truep(t13)){
t14=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[81],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[432],t17));}
else{
t14=(C_word)C_eqp(t4,lf[378]);
if(C_truep(t14)){
t15=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[81],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,t3,t17);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_cons(&a,2,lf[433],t18));}
else{
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9920,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t16=(C_word)C_i_length(t2);
t17=(C_word)C_eqp(C_fix(3),t16);
if(C_truep(t17)){
t18=(C_word)C_i_car(t2);
t19=t15;
f_9920(t19,(C_word)C_i_memq(t18,lf[436]));}
else{
t18=t15;
f_9920(t18,C_SCHEME_FALSE);}}
else{
t16=t15;
f_9920(t16,C_SCHEME_FALSE);}}}}}}}}}

/* k9918 in ##compiler#finish-foreign-result in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_9920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9920,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[434],t4));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_eqp(C_fix(3),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t2;
f_9941(t6,(C_word)C_eqp(lf[367],t5));}
else{
t5=t2;
f_9941(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_9941(t3,C_SCHEME_FALSE);}}}

/* k9939 in k9918 in ##compiler#finish-foreign-result in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_9941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9941,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[81],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[435],t7));}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#estimate-foreign-result-location-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9405,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9417,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9715,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1050 follow-without-loop");
((C_proc5)C_retrieve_proc(*((C_word*)lf[76]+1)))(5,*((C_word*)lf[76]+1),t1,t2,t3,t4);}

/* a9714 in ##compiler#estimate-foreign-result-location-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9715,2,t0,t1);}
C_trace("support.scm: 1071 quit");
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t1,lf[425],((C_word*)t0)[2]);}

/* a9416 in ##compiler#estimate-foreign-result-location-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9417,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9427,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9427(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_9427(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t8)){
t9=t6;
f_9427(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t9)){
t10=t6;
f_9427(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t10)){
t11=t6;
f_9427(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t11)){
t12=t6;
f_9427(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t12)){
t13=t6;
f_9427(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[381]);
if(C_truep(t13)){
t14=t6;
f_9427(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[380]);
if(C_truep(t14)){
t15=t6;
f_9427(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t15)){
t16=t6;
f_9427(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t16)){
t17=t6;
f_9427(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[353]);
if(C_truep(t17)){
t18=t6;
f_9427(t18,t17);}
else{
t18=(C_word)C_eqp(t4,lf[342]);
if(C_truep(t18)){
t19=t6;
f_9427(t19,t18);}
else{
t19=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t19)){
t20=t6;
f_9427(t20,t19);}
else{
t20=(C_word)C_eqp(t4,lf[351]);
if(C_truep(t20)){
t21=t6;
f_9427(t21,t20);}
else{
t21=(C_word)C_eqp(t4,lf[349]);
if(C_truep(t21)){
t22=t6;
f_9427(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[340]);
if(C_truep(t22)){
t23=t6;
f_9427(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t23)){
t24=t6;
f_9427(t24,t23);}
else{
t24=(C_word)C_eqp(t4,lf[360]);
if(C_truep(t24)){
t25=t6;
f_9427(t25,t24);}
else{
t25=(C_word)C_eqp(t4,lf[402]);
if(C_truep(t25)){
t26=t6;
f_9427(t26,t25);}
else{
t26=(C_word)C_eqp(t4,lf[397]);
if(C_truep(t26)){
t27=t6;
f_9427(t27,t26);}
else{
t27=(C_word)C_eqp(t4,lf[410]);
if(C_truep(t27)){
t28=t6;
f_9427(t28,t27);}
else{
t28=(C_word)C_eqp(t4,lf[411]);
if(C_truep(t28)){
t29=t6;
f_9427(t29,t28);}
else{
t29=(C_word)C_eqp(t4,lf[382]);
if(C_truep(t29)){
t30=t6;
f_9427(t30,t29);}
else{
t30=(C_word)C_eqp(t4,lf[379]);
if(C_truep(t30)){
t31=t6;
f_9427(t31,t30);}
else{
t31=(C_word)C_eqp(t4,lf[375]);
if(C_truep(t31)){
t32=t6;
f_9427(t32,t31);}
else{
t32=(C_word)C_eqp(t4,lf[376]);
if(C_truep(t32)){
t33=t6;
f_9427(t33,t32);}
else{
t33=(C_word)C_eqp(t4,lf[373]);
if(C_truep(t33)){
t34=t6;
f_9427(t34,t33);}
else{
t34=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t34)){
t35=t6;
f_9427(t35,t34);}
else{
t35=(C_word)C_eqp(t4,lf[374]);
if(C_truep(t35)){
t36=t6;
f_9427(t36,t35);}
else{
t36=(C_word)C_eqp(t4,lf[372]);
if(C_truep(t36)){
t37=t6;
f_9427(t37,t36);}
else{
t37=(C_word)C_eqp(t4,lf[377]);
t38=t6;
f_9427(t38,(C_truep(t37)?t37:(C_word)C_eqp(t4,lf[378])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k9425 in a9416 in ##compiler#estimate-foreign-result-location-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_9427(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9427,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[403]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[404]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(2));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub270(C_SCHEME_UNDEFINED,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
C_trace("support.scm: 1063 ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[371]),((C_word*)t0)[2]);}
else{
t5=t4;
f_9445(2,t5,C_SCHEME_FALSE);}}}}

/* k9443 in k9425 in a9416 in ##compiler#estimate-foreign-result-location-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9445,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(0));
C_trace("support.scm: 1065 next");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}
else{
t2=t1;
C_trace("support.scm: 1065 next");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_9479(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t5)){
t6=t4;
f_9479(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t6)){
t7=t4;
f_9479(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t7)){
t8=t4;
f_9479(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[355]);
t9=t4;
f_9479(t9,(C_truep(t8)?t8:(C_word)C_eqp(t2,lf[370])));}}}}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
C_trace("support.scm: 1049 quit");
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t2,lf[424],t3);}}}

/* k9477 in k9443 in k9425 in a9416 in ##compiler#estimate-foreign-result-location-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_9479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
C_trace("support.scm: 1049 quit");
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t2,lf[424],t3);}}

/* ##compiler#estimate-foreign-result-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9080(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9080,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9086,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9399,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1020 follow-without-loop");
((C_proc5)C_retrieve_proc(*((C_word*)lf[76]+1)))(5,*((C_word*)lf[76]+1),t1,t2,t3,t4);}

/* a9398 in ##compiler#estimate-foreign-result-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9399,2,t0,t1);}
C_trace("support.scm: 1045 quit");
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t1,lf[422],((C_word*)t0)[2]);}

/* a9085 in ##compiler#estimate-foreign-result-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9086,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,lf[334]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9096,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9096(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[338]);
if(C_truep(t7)){
t8=t6;
f_9096(t8,t7);}
else{
t8=(C_word)C_eqp(t4,lf[406]);
if(C_truep(t8)){
t9=t6;
f_9096(t9,t8);}
else{
t9=(C_word)C_eqp(t4,lf[419]);
if(C_truep(t9)){
t10=t6;
f_9096(t10,t9);}
else{
t10=(C_word)C_eqp(t4,lf[420]);
if(C_truep(t10)){
t11=t6;
f_9096(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[407]);
if(C_truep(t11)){
t12=t6;
f_9096(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[421]);
if(C_truep(t12)){
t13=t6;
f_9096(t13,t12);}
else{
t13=(C_word)C_eqp(t4,lf[335]);
if(C_truep(t13)){
t14=t6;
f_9096(t14,t13);}
else{
t14=(C_word)C_eqp(t4,lf[405]);
if(C_truep(t14)){
t15=t6;
f_9096(t15,t14);}
else{
t15=(C_word)C_eqp(t4,lf[408]);
if(C_truep(t15)){
t16=t6;
f_9096(t16,t15);}
else{
t16=(C_word)C_eqp(t4,lf[409]);
if(C_truep(t16)){
t17=t6;
f_9096(t17,t16);}
else{
t17=(C_word)C_eqp(t4,lf[410]);
t18=t6;
f_9096(t18,(C_truep(t17)?t17:(C_word)C_eqp(t4,lf[411])));}}}}}}}}}}}}

/* k9094 in a9085 in ##compiler#estimate-foreign-result-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_9096(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9096,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[356]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9105(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t4)){
t5=t3;
f_9105(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[353]);
if(C_truep(t5)){
t6=t3;
f_9105(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[355]);
if(C_truep(t6)){
t7=t3;
f_9105(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[360]);
if(C_truep(t7)){
t8=t3;
f_9105(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[374]);
if(C_truep(t8)){
t9=t3;
f_9105(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t9)){
t10=t3;
f_9105(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t10)){
t11=t3;
f_9105(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[376]);
if(C_truep(t11)){
t12=t3;
f_9105(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t12)){
t13=t3;
f_9105(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[377]);
t14=t3;
f_9105(t14,(C_truep(t13)?t13:(C_word)C_eqp(((C_word*)t0)[4],lf[378])));}}}}}}}}}}}}

/* k9103 in k9094 in a9085 in ##compiler#estimate-foreign-result-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_9105(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9105,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[351]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9117(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
if(C_truep(t4)){
t5=t3;
f_9117(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
if(C_truep(t5)){
t6=t3;
f_9117(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t6)){
t7=t3;
f_9117(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[382]);
t8=t3;
f_9117(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[379])));}}}}}}

/* k9115 in k9103 in k9094 in a9085 in ##compiler#estimate-foreign-result-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_9117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9117,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[340]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_9129(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[403]);
if(C_truep(t4)){
t5=t3;
f_9129(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[404]);
t6=t3;
f_9129(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[418])));}}}}

/* k9127 in k9115 in k9103 in k9094 in a9085 in ##compiler#estimate-foreign-result-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_9129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9129,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
C_trace("support.scm: 1036 ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t2,C_retrieve(lf[371]),((C_word*)t0)[2]);}
else{
t3=t2;
f_9135(2,t3,C_SCHEME_FALSE);}}}

/* k9133 in k9127 in k9115 in k9103 in k9094 in a9085 in ##compiler#estimate-foreign-result-size in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a;
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(0));
C_trace("support.scm: 1038 next");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}
else{
t2=t1;
C_trace("support.scm: 1038 next");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[362]);
if(C_truep(t3)){
if(C_truep(t3)){
t4=((C_word*)t0)[3];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub270(C_SCHEME_UNDEFINED,t5));}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}}
else{
t4=(C_word)C_eqp(t2,lf[344]);
if(C_truep(t4)){
if(C_truep(t4)){
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub270(C_SCHEME_UNDEFINED,t6));}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(0));}}
else{
t5=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t5)){
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t8=t6;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub270(C_SCHEME_UNDEFINED,t7));}
else{
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_fix(0));}}
else{
t6=(C_word)C_eqp(t2,lf[353]);
if(C_truep(t6)){
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t9=t7;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub270(C_SCHEME_UNDEFINED,t8));}
else{
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_fix(0));}}
else{
t7=(C_word)C_eqp(t2,lf[355]);
if(C_truep(t7)){
if(C_truep(t7)){
t8=((C_word*)t0)[3];
t9=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t10=t8;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)stub270(C_SCHEME_UNDEFINED,t9));}
else{
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}}
else{
t8=(C_word)C_eqp(t2,lf[370]);
if(C_truep(t8)){
if(C_truep(t8)){
t9=((C_word*)t0)[3];
t10=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t11=t9;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)stub270(C_SCHEME_UNDEFINED,t10));}
else{
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_fix(0));}}
else{
t9=(C_word)C_eqp(t2,lf[363]);
if(C_truep(t9)){
if(C_truep(t9)){
t10=((C_word*)t0)[3];
t11=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t12=t10;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub270(C_SCHEME_UNDEFINED,t11));}
else{
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_fix(0));}}
else{
t10=(C_word)C_eqp(t2,lf[364]);
if(C_truep(t10)){
if(C_truep(t10)){
t11=((C_word*)t0)[3];
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t13=t11;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)stub270(C_SCHEME_UNDEFINED,t12));}
else{
t11=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_fix(0));}}
else{
t11=(C_word)C_eqp(t2,lf[367]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
t13=(C_word)C_i_foreign_fixnum_argumentp(C_fix(3));
t14=t12;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)stub270(C_SCHEME_UNDEFINED,t13));}
else{
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_fix(0));}}}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* ##compiler#final-foreign-type in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9040,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9046,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9074,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 1007 follow-without-loop");
((C_proc5)C_retrieve_proc(*((C_word*)lf[76]+1)))(5,*((C_word*)lf[76]+1),t1,t2,t3,t4);}

/* a9073 in ##compiler#final-foreign-type in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9074,2,t0,t1);}
C_trace("support.scm: 1014 quit");
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t1,lf[416],((C_word*)t0)[2]);}

/* a9045 in ##compiler#final-foreign-type in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9046,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9050,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
C_trace("support.scm: 1010 ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[371]),t2);}
else{
t5=t4;
f_9050(2,t5,C_SCHEME_FALSE);}}

/* k9048 in a9045 in ##compiler#final-foreign-type in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(0));
C_trace("support.scm: 1012 next");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}
else{
t2=t1;
C_trace("support.scm: 1012 next");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#foreign-type-convert-argument in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9009,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9022,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 1001 ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[371]),t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k9020 in ##compiler#foreign-type-convert-argument in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_9022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9022,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#foreign-type-convert-result in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_8978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8978,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8991,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 994  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[371]),t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k8989 in ##compiler#foreign-type-convert-result in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_8991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8991,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(2));
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7925,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7931,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8972,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 895  follow-without-loop");
((C_proc5)C_retrieve_proc(*((C_word*)lf[76]+1)))(5,*((C_word*)lf[76]+1),t1,t3,t4,t5);}

/* a8971 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_8972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8972,2,t0,t1);}
C_trace("support.scm: 987  quit");
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),t1,lf[412],((C_word*)t0)[2]);}

/* a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7931,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7937,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7937(t7,t1,t2);}

/* repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7937(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7937,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[334]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[335]));
if(C_truep(t5)){
if(C_truep(C_retrieve(lf[336]))){
t6=((C_word*)t0)[4];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[337],t6));}}
else{
t6=(C_word)C_eqp(t3,lf[338]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7966(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[405]);
if(C_truep(t8)){
t9=t7;
f_7966(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[406]);
if(C_truep(t9)){
t10=t7;
f_7966(t10,t9);}
else{
t10=(C_word)C_eqp(t3,lf[407]);
if(C_truep(t10)){
t11=t7;
f_7966(t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[408]);
if(C_truep(t11)){
t12=t7;
f_7966(t12,t11);}
else{
t12=(C_word)C_eqp(t3,lf[409]);
if(C_truep(t12)){
t13=t7;
f_7966(t13,t12);}
else{
t13=(C_word)C_eqp(t3,lf[410]);
t14=t7;
f_7966(t14,(C_truep(t13)?t13:(C_word)C_eqp(t3,lf[411])));}}}}}}}}

/* k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7966(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7966,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[339],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[340]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7985(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[403]);
t5=t3;
f_7985(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[404])));}}}

/* k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7985,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[341],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8004(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[400]);
if(C_truep(t4)){
t5=t3;
f_8004(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[401]);
t6=t3;
f_8004(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[402])));}}}}

/* k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8004(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8004,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8007,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 905  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8074(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[397]);
if(C_truep(t4)){
t5=t3;
f_8074(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[398]);
t6=t3;
f_8074(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[399])));}}}}

/* k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8074(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8074,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[343],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[345]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8093(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t4)){
t5=t3;
f_8093(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t5)){
t6=t3;
f_8093(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[392]);
if(C_truep(t6)){
t7=t3;
f_8093(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[393]);
if(C_truep(t7)){
t8=t3;
f_8093(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[394]);
if(C_truep(t8)){
t9=t3;
f_8093(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[395]);
t10=t3;
f_8093(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[396])));}}}}}}}}

/* k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8093(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8093,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8096,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 917  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[347]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8175(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t4)){
t5=t3;
f_8175(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t5)){
t6=t3;
f_8175(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[385]);
if(C_truep(t6)){
t7=t3;
f_8175(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[386]);
if(C_truep(t7)){
t8=t3;
f_8175(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[387]);
if(C_truep(t8)){
t9=t3;
f_8175(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[388]);
t10=t3;
f_8175(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[389])));}}}}}}}}

/* k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8175(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8175,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[5],lf[348]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[81],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[346],t7));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[349]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8214(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[381]);
t5=t3;
f_8214(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[4],lf[382])));}}}

/* k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8214(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8214,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[350],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[351]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8233(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[379]);
t5=t3;
f_8233(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[380])));}}}

/* k8231 in k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8233(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8233,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[352],t2));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[353]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8252(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[377]);
t5=t3;
f_8252(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[378])));}}}

/* k8250 in k8231 in k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8252(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8252,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8255,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 937  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[355]);
if(C_truep(t2)){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[354],t3));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[356]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_8332(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[374]);
if(C_truep(t5)){
t6=t4;
f_8332(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[375]);
t7=t4;
f_8332(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[376])));}}}}}

/* k8330 in k8250 in k8231 in k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8332(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8332,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8335,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 945  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[359]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8417(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[372]);
t5=t3;
f_8417(t5,(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[373])));}}}

/* k8415 in k8330 in k8250 in k8231 in k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8417(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8417,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve(lf[336]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[357],t2));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[358],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[357],t4));}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[360]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[336]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[361],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[357],t5));}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[361],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[358],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[357],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
C_trace("support.scm: 961  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t3,C_retrieve(lf[371]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8492(2,t4,C_SCHEME_FALSE);}}}}

/* k8490 in k8415 in k8330 in k8250 in k8231 in k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_8492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8492,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(0));
C_trace("support.scm: 963  next");
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[5],t2);}
else{
t2=t1;
C_trace("support.scm: 963  next");
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[5],t2);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[362]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_8526(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[342]);
if(C_truep(t5)){
t6=t4;
f_8526(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[370]);
t7=t4;
f_8526(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[353])));}}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k8524 in k8490 in k8415 in k8330 in k8250 in k8231 in k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8526,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8529,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 967  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[363]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[364]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8596,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 973  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[367]);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[81],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[366],t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[368]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("support.scm: 980  repeat");
t7=((C_word*)((C_word*)t0)[2])[1];
f_7937(t7,((C_word*)t0)[5],t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[369]);
if(C_truep(t6)){
if(C_truep(C_retrieve(lf[336]))){
t7=((C_word*)t0)[6];
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[350],t7));}}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[344]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[355]));
if(C_truep(t8)){
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[354],t9));}
else{
t9=((C_word*)t0)[6];
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}}}}}}

/* k8594 in k8524 in k8490 in k8415 in k8330 in k8250 in k8231 in k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_8596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8596,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[365],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[81],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[366],t8);
t10=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,lf[81],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t9,t12);
t14=(C_word)C_a_i_cons(&a,2,t1,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[215],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_cons(&a,2,lf[91],t17));}

/* k8527 in k8524 in k8490 in k8415 in k8330 in k8250 in k8231 in k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_8529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8529,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[354],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[81],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[215],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[91],t14));}

/* k8333 in k8330 in k8250 in k8231 in k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_8335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8335,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8366,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8366(t7,(C_word)C_a_i_cons(&a,2,lf[357],t6));}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[358],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_8366(t9,(C_word)C_a_i_cons(&a,2,lf[357],t8));}}

/* k8364 in k8333 in k8330 in k8250 in k8231 in k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8366,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[215],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[91],t9));}

/* k8253 in k8250 in k8231 in k8212 in k8173 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_8255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8255,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[354],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[81],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t6,t9);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[215],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[91],t14));}

/* k8094 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_8096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8096,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8127,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=t5;
f_8127(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[81],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_8127(t10,(C_word)C_a_i_cons(&a,2,lf[346],t9));}}

/* k8125 in k8094 in k8091 in k8072 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8127,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[215],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[91],t9));}

/* k8005 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_8007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8007,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8038,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[336]))){
t6=t5;
f_8038(t6,t1);}
else{
t6=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_8038(t7,(C_word)C_a_i_cons(&a,2,lf[343],t6));}}

/* k8036 in k8005 in k8002 in k7983 in k7964 in repeat in a7930 in ##compiler#foreign-type-check in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_8038(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8038,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[81],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[215],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,lf[91],t9));}

/* ##compiler#pprint-expressions-to-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7873,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7877,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
C_trace("support.scm: 876  open-output-file");
((C_proc3)C_retrieve_proc(*((C_word*)lf[331]+1)))(3,*((C_word*)lf[331]+1),t4,t3);}
else{
C_trace("support.scm: 876  current-output-port");
((C_proc2)C_retrieve_proc(*((C_word*)lf[332]+1)))(2,*((C_word*)lf[332]+1),t4);}}

/* k7875 in ##compiler#pprint-expressions-to-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7880,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7888,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 877  with-output-to-port");
((C_proc4)C_retrieve_symbol_proc(lf[330]))(4,*((C_word*)lf[330]+1),t2,t1,t3);}

/* a7887 in k7875 in ##compiler#pprint-expressions-to-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7888,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7894,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7894(t5,t1,((C_word*)t0)[2]);}

/* loop1672 in a7887 in k7875 in ##compiler#pprint-expressions-to-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7894(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7894,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7907,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 881  pretty-print");
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7905 in loop1672 in a7887 in k7875 in ##compiler#pprint-expressions-to-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 882  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),t2);}

/* k7908 in k7905 in loop1672 in a7887 in k7875 in ##compiler#pprint-expressions-to-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7894(t3,((C_word*)t0)[2],t2);}

/* k7878 in k7875 in ##compiler#pprint-expressions-to-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
C_trace("support.scm: 884  close-output-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[328]+1)))(3,*((C_word*)lf[328]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7792,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7798,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7804,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t3,t4);}

/* a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7804,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7811,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("support.scm: 864  debugging");
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t9,lf[325],lf[326]);}

/* k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7811,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[324],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[323],((C_word*)t0)[3]);}

/* k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7826,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7826,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7829,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[322],t2);}

/* k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7835,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7838,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[321],t2);}

/* k7836 in k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7839 in k7836 in k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7844,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k7842 in k7839 in k7836 in k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7844,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7847,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[320],t2);}

/* k7845 in k7842 in k7839 in k7836 in k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7850,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7853,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k7851 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7853,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7856,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[319],t2);}

/* k7854 in k7851 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7857 in k7854 in k7851 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7862,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k7860 in k7857 in k7854 in k7851 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7862,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7865,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[318],t2);}

/* k7863 in k7860 in k7857 in k7854 in k7851 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7866 in k7863 in k7860 in k7857 in k7854 in k7851 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7830 in k7827 in k7824 in k7821 in k7818 in k7815 in k7812 in k7809 in a7803 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* a7797 in ##compiler#print-program-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7798,2,t0,t1);}
C_trace("support.scm: 863  compute-database-statistics");
((C_proc3)C_retrieve_symbol_proc(lf[314]))(3,*((C_word*)lf[314]+1),t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7696,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7700,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7705,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 839  ##sys#hash-table-for-each");
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t13,t14,t2);}

/* a7704 in ##compiler#compute-database-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7705,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_7711(t4,t3));}

/* loop1599 in a7704 in ##compiler#compute-database-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static C_word C_fcall f_7711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[179]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=(C_word)C_slot(t1,C_fix(1));
t29=t9;
t1=t29;
goto loop;}
else{
t7=(C_word)C_eqp(t5,lf[161]);
if(C_truep(t7)){
t8=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[223],t11);
if(C_truep(t12)){
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t14=C_mutate(((C_word *)((C_word*)t0)[3])+1,t13);
t15=(C_word)C_slot(t1,C_fix(1));
t29=t15;
t1=t29;
goto loop;}
else{
t13=(C_word)C_slot(t1,C_fix(1));
t29=t13;
t1=t29;
goto loop;}}
else{
t8=(C_word)C_eqp(t5,lf[167]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t10);
t12=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t13=(C_word)C_slot(t1,C_fix(1));
t29=t13;
t1=t29;
goto loop;}
else{
t9=(C_word)C_slot(t1,C_fix(1));
t29=t9;
t1=t29;
goto loop;}}}}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* k7698 in ##compiler#compute-database-statistics in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 853  values");
C_values(9,0,((C_word*)t0)[7],C_retrieve(lf[315]),C_retrieve(lf[316]),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7675,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7685,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 816  debugging");
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),t7,lf[246],lf[313],t2);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k7683 in ##sys#toplevel-definition-hook in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 817  hide-variable");
((C_proc3)C_retrieve_symbol_proc(lf[312]))(3,*((C_word*)lf[312]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#dump-global-refs in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7626(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7626,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7632,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 802  ##sys#hash-table-for-each");
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t3,t2);}

/* a7631 in ##compiler#dump-global-refs in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7632,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7673,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 804  keyword?");
((C_proc3)C_retrieve_symbol_proc(lf[308]))(3,*((C_word*)lf[308]+1),t4,t2);}

/* k7671 in a7631 in ##compiler#dump-global-refs in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7673,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_FALSE:(C_word)C_i_assq(lf[179],((C_word*)t0)[4]));
if(C_truep(t2)){
t3=(C_word)C_i_assq(lf[166],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7645,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_i_length(t5);
t7=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t6);
C_trace("support.scm: 806  write");
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t7);}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],C_fix(0));
C_trace("support.scm: 806  write");
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t5);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7643 in k7671 in a7631 in ##compiler#dump-global-refs in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 807  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#dump-defined-globals in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7589,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7595,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 792  ##sys#hash-table-for-each");
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t3,t2);}

/* a7594 in ##compiler#dump-defined-globals in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7595,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7602,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7624,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 794  keyword?");
((C_proc3)C_retrieve_symbol_proc(lf[308]))(3,*((C_word*)lf[308]+1),t5,t2);}

/* k7622 in a7594 in ##compiler#dump-defined-globals in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_7602(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_assq(lf[179],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_7602(t3,(C_truep(t2)?(C_word)C_i_assq(lf[177],((C_word*)t0)[2]):C_SCHEME_FALSE));}}

/* k7600 in a7594 in ##compiler#dump-defined-globals in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7602(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7602,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7605,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 797  write");
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7603 in k7600 in a7594 in ##compiler#dump-defined-globals in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 798  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#dump-undefined-globals in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7548,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7554,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 782  ##sys#hash-table-for-each");
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t3,t2);}

/* a7553 in ##compiler#dump-undefined-globals in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7554,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7561,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7587,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 784  keyword?");
((C_proc3)C_retrieve_symbol_proc(lf[308]))(3,*((C_word*)lf[308]+1),t5,t2);}

/* k7585 in a7553 in ##compiler#dump-undefined-globals in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_7561(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_assq(lf[179],((C_word*)t0)[2]))){
t2=(C_word)C_i_assq(lf[177],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_7561(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[3];
f_7561(t2,C_SCHEME_FALSE);}}}

/* k7559 in a7553 in ##compiler#dump-undefined-globals in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7561,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7564,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 787  write");
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7562 in k7559 in a7553 in ##compiler#dump-undefined-globals in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 788  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7456,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_pairp(t5);
t7=(C_truep(t6)?(C_word)C_i_car(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
if(C_truep((C_word)C_i_cadr(t4))){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7480,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_7480(3,t11,t1,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rec in ##compiler#simple-lambda-node? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7480,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,lf[235]);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(lf[210],t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t8,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(C_word)C_eqp(((C_word*)t0)[3],t12);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t7);
C_trace("support.scm: 774  every");
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)((C_word*)t0)[2])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t4,lf[226]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
C_trace("support.scm: 776  every");
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* ##compiler#expression-has-side-effects? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7370(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7370,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7376,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7376(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7376,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_eqp(t6,lf[210]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7392,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_7392(t9,t7);}
else{
t9=(C_word)C_eqp(t6,lf[81]);
if(C_truep(t9)){
t10=t8;
f_7392(t10,t9);}
else{
t10=(C_word)C_eqp(t6,lf[216]);
if(C_truep(t10)){
t11=t8;
f_7392(t11,t10);}
else{
t11=(C_word)C_eqp(t6,lf[227]);
t12=t8;
f_7392(t12,(C_truep(t11)?t11:(C_word)C_eqp(t6,lf[214])));}}}}

/* k7390 in walk in ##compiler#expression-has-side-effects? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7392,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[223]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7406,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 757  find");
((C_proc4)C_retrieve_symbol_proc(lf[304]))(4,*((C_word*)lf[304]+1),((C_word*)t0)[6],t6,C_retrieve(lf[305]));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[215]);
if(C_truep(t3)){
if(C_truep(t3)){
C_trace("support.scm: 758  any");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[91]);
if(C_truep(t4)){
C_trace("support.scm: 758  any");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}}

/* a7405 in k7390 in walk in ##compiler#expression-has-side-effects? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7406,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7414,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 757  foreign-callback-stub-id");
((C_proc3)C_retrieve_symbol_proc(lf[303]))(3,*((C_word*)lf[303]+1),t3,t2);}

/* k7412 in a7405 in k7390 in walk in ##compiler#expression-has-side-effects? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7175,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7178,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7207,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7250,a[2]=t9,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7354,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 741  matchn");
t15=((C_word*)t12)[1];
f_7250(t15,t14,t2,t3);}

/* k7352 in ##compiler#match-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7354,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7360,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=((C_word*)t0)[3];
t6=(C_word)C_slot(t5,C_fix(2));
C_trace("support.scm: 744  debugging");
((C_proc7)C_retrieve_proc(*((C_word*)lf[10]+1)))(7,*((C_word*)lf[10]+1),t2,lf[300],lf[301],t4,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7358 in k7352 in ##compiler#match-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* matchn in ##compiler#match-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7250(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7250,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
C_trace("support.scm: 730  resolve");
t4=((C_word*)t0)[4];
f_7178(t4,t1,t3,t2);}
else{
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_i_car(t3);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7272,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(2));
t11=(C_word)C_i_cadr(t3);
C_trace("support.scm: 732  match1");
t12=((C_word*)((C_word*)t0)[2])[1];
f_7207(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* k7270 in matchn in ##compiler#match-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7272,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7285,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7285(t8,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k7270 in matchn in ##compiler#match-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7285(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7285,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t2));}
else{
if(C_truep((C_word)C_i_not_pair_p(t3))){
C_trace("support.scm: 736  resolve");
t4=((C_word*)t0)[4];
f_7178(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7316,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
C_trace("support.scm: 738  matchn");
t7=((C_word*)((C_word*)t0)[2])[1];
f_7250(t7,t4,t5,t6);}}}}

/* k7314 in loop in k7270 in matchn in ##compiler#match-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 739  loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_7285(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7207(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7207,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t3))){
C_trace("support.scm: 723  resolve");
t4=((C_word*)t0)[3];
f_7178(t4,t1,t3,t2);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7229,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
C_trace("support.scm: 725  match1");
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k7227 in match1 in ##compiler#match-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 725  match1");
t4=((C_word*)((C_word*)t0)[3])[1];
f_7207(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7178(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7178,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t3,t5));}
else{
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7202,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 718  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}

/* k7200 in resolve in ##compiler#match-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* ##compiler#load-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7106,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7112,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 698  with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[298]))(4,*((C_word*)lf[298]+1),t1,t2,t3);}

/* a7111 in ##compiler#load-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7112,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7118,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7118(t5,t1);}

/* loop in a7111 in ##compiler#load-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7118,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7122,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 701  read");
((C_proc2)C_retrieve_proc(*((C_word*)lf[100]+1)))(2,*((C_word*)lf[100]+1),t2);}

/* k7120 in loop in a7111 in ##compiler#load-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7122,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7158,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7169,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(t1);
C_trace("support.scm: 706  sexpr->node");
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t4,t5);}}

/* k7167 in k7120 in loop in a7111 in ##compiler#load-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7169,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[290],C_SCHEME_TRUE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_car(t2);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[290],t5);}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k7131 in k7167 in k7120 in loop in a7111 in ##compiler#load-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[290],t1);}

/* k7156 in k7120 in loop in a7111 in ##compiler#load-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 707  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_7118(t2,((C_word*)t0)[2]);}

/* ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6920,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6924,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6967,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 667  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[296]))(4,*((C_word*)lf[296]+1),t6,t2,t7);}

/* a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7104,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 669  chicken-version");
((C_proc2)C_retrieve_symbol_proc(lf[295]))(2,*((C_word*)lf[295]+1),t3);}

/* k7102 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 669  print");
((C_proc7)C_retrieve_proc(*((C_word*)lf[280]+1)))(7,*((C_word*)lf[280]+1),((C_word*)t0)[2],lf[292],t1,lf[293],C_retrieve(lf[237]),lf[294]);}

/* k6969 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6974,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 671  ##sys#hash-table-for-each");
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t2,t3,((C_word*)t0)[2]);}

/* a6978 in k6969 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6979,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 673  variable-visible?");
((C_proc3)C_retrieve_symbol_proc(lf[291]))(3,*((C_word*)lf[291]+1),t4,t2);}

/* k6984 in a6978 in k6969 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6986,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[163],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t4,t3,lf[290]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7095 in k6984 in a6978 in k6969 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7097,2,t0,t1);}
if(C_truep((C_word)C_i_structurep(t1,lf[200]))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_assq(lf[161],((C_word*)t0)[6]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_7010(t5,t3);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(lf[157],t5);
t7=t4;
f_7010(t7,(C_word)C_i_not(t6));}}}

/* k7008 in k7095 in k6984 in a6978 in k6969 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7010,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_assq(lf[189],((C_word*)t0)[7]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_slot(t2,C_fix(2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7082,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 682  get");
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t4,((C_word*)t0)[2],((C_word*)t0)[4],lf[196]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7080 in k7008 in k7095 in k6984 in a6978 in k6969 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7082,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t3,t2,lf[289]);}}

/* k7035 in k7080 in k7008 in k7095 in k6984 in a6978 in k6969 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7040,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(t1,lf[286]);
if(C_truep(t3)){
t4=t2;
f_7040(t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(t1,lf[287]);
if(C_truep(t4)){
t5=t2;
f_7040(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t6=C_retrieve(lf[288]);
t7=t2;
f_7040(t7,(C_word)C_fixnum_lessp(t5,t6));}}}

/* k7038 in k7035 in k7080 in k7008 in k7095 in k6984 in a6978 in k6969 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_7040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7040,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7047,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7058,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("support.scm: 689  node->sexpr");
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7056 in k7038 in k7035 in k7080 in k7008 in k7095 in k6984 in a6978 in k6969 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7058,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
C_trace("support.scm: 689  pp");
((C_proc3)C_retrieve_symbol_proc(lf[285]))(3,*((C_word*)lf[285]+1),((C_word*)t0)[2],t2);}

/* k7045 in k7038 in k7035 in k7080 in k7008 in k7095 in k6984 in a6978 in k6969 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_7047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 690  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* k6972 in k6969 in a6966 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 692  print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[280]+1)))(3,*((C_word*)lf[280]+1),((C_word*)t0)[2],lf[284]);}

/* k6922 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
C_trace("support.scm: 694  debugging");
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t2,lf[282],lf[283]);}
else{
t3=t2;
f_6930(2,t3,C_SCHEME_FALSE);}}

/* k6928 in k6922 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6930,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6937,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 695  sort-symbols");
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6935 in k6928 in k6922 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6937,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6939,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6939(t5,((C_word*)t0)[2],t1);}

/* loop1376 in k6935 in k6928 in k6922 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_6939(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6939,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6952,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("print");
((C_proc4)C_retrieve_proc(*((C_word*)lf[280]+1)))(4,*((C_word*)lf[280]+1),t4,lf[281],t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6950 in loop1376 in k6935 in k6928 in k6922 in ##compiler#emit-global-inline-file in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6939(t3,((C_word*)t0)[2],t2);}

/* ##compiler#sexpr->node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6895,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6901,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6901(3,t6,t1,t2);}

/* walk in ##compiler#sexpr->node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6901,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6911,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cddr(t2);
C_trace("map");
t7=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k6909 in walk in ##compiler#sexpr->node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6911,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* ##compiler#node->sexpr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6859,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6865,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6865(3,t6,t1,t2);}

/* walk in ##compiler#node->sexpr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6865,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6885,a[2]=t4,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6889,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(3));
C_trace("map");
t11=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,((C_word*)((C_word*)t0)[2])[1],t10);}

/* k6887 in walk in ##compiler#node->sexpr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6883 in walk in ##compiler#node->sexpr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6885,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* ##compiler#copy-node! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6835,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6839,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t3;
t8=(C_word)C_i_check_structure(t7,lf[200]);
C_trace("##sys#block-set!");
t9=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t4,t7,C_fix(1),t6);}

/* k6837 in ##compiler#copy-node! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_slot(t3,C_fix(2));
t5=((C_word*)t0)[3];
t6=(C_word)C_i_check_structure(t5,lf[200]);
C_trace("##sys#block-set!");
t7=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(2),t4);}

/* k6840 in k6837 in ##compiler#copy-node! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_slot(t3,C_fix(3));
t5=((C_word*)t0)[3];
t6=(C_word)C_i_check_structure(t5,lf[200]);
C_trace("##sys#block-set!");
t7=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(3),t4);}

/* k6843 in k6840 in k6837 in ##compiler#copy-node! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#tree-copy in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6801,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6807,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6807(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_6807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6807,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6821,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
C_trace("support.scm: 646  rec");
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6819 in rec in ##compiler#tree-copy in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6825,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 646  rec");
t4=((C_word*)((C_word*)t0)[2])[1];
f_6807(t4,t2,t3);}

/* k6823 in k6819 in rec in ##compiler#tree-copy in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6825,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6599,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6603,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 604  map");
((C_proc5)C_retrieve_proc(*((C_word*)lf[251]+1)))(5,*((C_word*)lf[251]+1),t6,*((C_word*)lf[273]+1),t3,t4);}

/* k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6603,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6611,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
C_trace("support.scm: 641  walk");
t5=((C_word*)t3)[1];
f_6611(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_6611(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6611,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[210]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6634,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_car(t7);
t13=t3;
C_trace("support.scm: 605  alist-ref");
((C_proc6)C_retrieve_symbol_proc(lf[270]))(6,*((C_word*)lf[270]+1),t11,t12,t13,*((C_word*)lf[271]+1),t12);}
else{
t11=(C_word)C_eqp(t9,lf[228]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6665,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_car(t7);
t14=t3;
C_trace("support.scm: 605  alist-ref");
((C_proc6)C_retrieve_symbol_proc(lf[270]))(6,*((C_word*)lf[270]+1),t12,t13,t14,*((C_word*)lf[271]+1),t13);}
else{
t12=(C_word)C_eqp(t9,lf[91]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6681,a[2]=t3,a[3]=t13,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t15=(C_word)C_i_car(t5);
C_trace("support.scm: 618  walk");
t27=t14;
t28=t15;
t29=t3;
t1=t27;
t2=t28;
t3=t29;
goto loop;}
else{
t13=(C_word)C_eqp(t9,lf[223]);
if(C_truep(t13)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6723,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 625  decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6784,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 640  tree-copy");
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t14,t7);}}}}}

/* k6782 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6787,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6791 in k6782 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6792,3,t0,t1,t2);}
C_trace("walk1242");
t3=((C_word*)((C_word*)t0)[3])[1];
f_6611(t3,t1,t2,((C_word*)t0)[2]);}

/* k6785 in k6782 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6787,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6723,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6727,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t7=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a6773 in a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6774,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6778,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 629  gensym");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t3,t2);}

/* k6776 in a6773 in a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6781,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 630  put!");
((C_proc6)C_retrieve_symbol_proc(lf[137]))(6,*((C_word*)lf[137]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[274],C_SCHEME_TRUE);}

/* k6779 in k6776 in a6773 in a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6725 in a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6730,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6772,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 633  map");
((C_proc5)C_retrieve_proc(*((C_word*)lf[251]+1)))(5,*((C_word*)lf[251]+1),t3,*((C_word*)lf[273]+1),((C_word*)t0)[2],t1);}

/* k6770 in k6725 in a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 633  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6728 in k6725 in a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("support.scm: 636  gensym");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t2,lf[272]);}

/* k6747 in k6728 in k6725 in a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6749,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6757,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[6];
C_trace("support.scm: 605  alist-ref");
((C_proc6)C_retrieve_symbol_proc(lf[270]))(6,*((C_word*)lf[270]+1),t4,t5,t6,*((C_word*)lf[271]+1),t5);}
else{
C_trace("support.scm: 637  build-lambda-list");
((C_proc5)C_retrieve_proc(*((C_word*)lf[47]+1)))(5,*((C_word*)lf[47]+1),t3,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* k6763 in k6747 in k6728 in k6725 in a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 637  build-lambda-list");
((C_proc5)C_retrieve_proc(*((C_word*)lf[47]+1)))(5,*((C_word*)lf[47]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6755 in k6747 in k6728 in k6725 in a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6757,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6736,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6741,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a6740 in k6755 in k6747 in k6728 in k6725 in a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6741(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6741,3,t0,t1,t2);}
C_trace("walk1242");
t3=((C_word*)((C_word*)t0)[3])[1];
f_6611(t3,t1,t2,((C_word*)t0)[2]);}

/* k6734 in k6755 in k6747 in k6728 in k6725 in a6722 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6736,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[223],((C_word*)t0)[2],t1));}

/* k6679 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("support.scm: 619  gensym");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t2,((C_word*)t0)[3]);}

/* k6682 in k6679 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6687,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 620  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6685 in k6682 in k6679 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6687,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6700,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("support.scm: 623  walk");
t5=((C_word*)((C_word*)t0)[2])[1];
f_6611(t5,t3,t4,t1);}

/* k6698 in k6685 in k6682 in k6679 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6700,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[200],lf[91],((C_word*)t0)[2],t2));}

/* k6663 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6665,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6657,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("support.scm: 615  walk");
t5=((C_word*)((C_word*)t0)[3])[1];
f_6611(t5,t3,t4,((C_word*)t0)[2]);}

/* k6655 in k6663 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6657,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[200],lf[228],((C_word*)t0)[2],t2));}

/* k6632 in walk in k6601 in ##compiler#copy-node-tree-and-rename in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6634,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[200],lf[210],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#inline-lambda-bindings in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_6506,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6512,a[2]=t6,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 582  decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t1,t2,t7);}

/* a6511 in ##compiler#inline-lambda-bindings in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6512,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6518,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6524,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t5,t6);}

/* a6523 in a6511 in ##compiler#inline-lambda-bindings in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6524,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
C_trace("map");
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[92]),((C_word*)t0)[3]);}
else{
t5=t4;
f_6528(2,t5,((C_word*)t0)[3]);}}

/* k6526 in a6523 in a6511 in ##compiler#inline-lambda-bindings in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6531,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
C_trace("support.scm: 588  copy-node-tree-and-rename");
((C_proc6)C_retrieve_symbol_proc(lf[269]))(6,*((C_word*)lf[269]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t3=t2;
f_6531(2,t3,((C_word*)t0)[4]);}}

/* k6529 in k6526 in a6523 in a6511 in ##compiler#inline-lambda-bindings in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6536,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6550,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6591,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 594  last");
((C_proc3)C_retrieve_symbol_proc(lf[250]))(3,*((C_word*)lf[250]+1),t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_6550(t4,t1);}}

/* k6589 in k6529 in k6526 in a6523 in a6511 in ##compiler#inline-lambda-bindings in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6591,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t3=(C_word)C_a_i_list(&a,1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_record(&a,4,lf[200],lf[81],t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
f_6550(t6,(C_word)C_a_i_record(&a,4,lf[200],lf[91],t2,t5));}
else{
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_fixnum_times(C_fix(3),t3);
t5=(C_word)C_a_i_list(&a,2,lf[268],t4);
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_record(&a,4,lf[200],lf[233],t5,t6);
t8=(C_word)C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
f_6550(t9,(C_word)C_a_i_record(&a,4,lf[200],lf[91],t2,t8));}}

/* k6548 in k6529 in k6526 in a6523 in a6511 in ##compiler#inline-lambda-bindings in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_6550(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6550,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6554,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 600  take");
((C_proc4)C_retrieve_symbol_proc(lf[267]))(4,*((C_word*)lf[267]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6552 in k6548 in k6529 in k6526 in a6523 in a6511 in ##compiler#inline-lambda-bindings in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 590  fold-right");
((C_proc6)C_retrieve_symbol_proc(lf[266]))(6,*((C_word*)lf[266]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6535 in k6529 in k6526 in a6523 in a6511 in ##compiler#inline-lambda-bindings in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6536,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t2);
t6=(C_word)C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[200],lf[91],t5,t6));}

/* a6517 in a6511 in ##compiler#inline-lambda-bindings in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6518,2,t0,t1);}
C_trace("support.scm: 585  split-at");
((C_proc4)C_retrieve_symbol_proc(lf[265]))(4,*((C_word*)lf[265]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6458,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6464,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6464(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_6464(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6464,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6484,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t2);
C_trace("support.scm: 578  proc");
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}}

/* k6482 in fold in ##compiler#fold-boolean in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6488,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 579  fold");
t4=((C_word*)((C_word*)t0)[2])[1];
f_6464(t4,t2,t3);}

/* k6486 in k6482 in fold in ##compiler#fold-boolean in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6488,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[200],lf[225],lf[263],t2));}

/* ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6140,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6146,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6146(3,t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6146(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6146,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[215]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6165,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_6165(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[260]);
t12=t10;
f_6165(t12,(C_truep(t11)?t11:(C_word)C_eqp(t8,lf[261])));}}

/* k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_6165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6165,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6172,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[249]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6189,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6193,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[210]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[214]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_car(((C_word*)t0)[2]));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[81]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[81],t7));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[91]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6239,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6255,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6259,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 552  butlast");
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[223]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[116]:lf[223]);
t10=(C_word)C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6280,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("support.scm: 559  walk");
t13=((C_word*)((C_word*)t0)[4])[1];
f_6146(3,t13,t11,t12);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[235]);
if(C_truep(t8)){
C_trace("map");
t9=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[226]);
if(C_truep(t9)){
t10=(C_word)C_i_car(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6313,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t12=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[216]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[255]);
if(C_truep(t11)){
t12=(C_word)C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6337,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6337(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[256]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_6399(t14,t12);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[257]);
if(C_truep(t14)){
t15=t13;
f_6399(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[258]);
t16=t13;
f_6399(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[259])));}}}}}}}}}}}}}

/* k6397 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_6399(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6399,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("support.scm: 569  walk");
t4=((C_word*)((C_word*)t0)[2])[1];
f_6146(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6425,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6429,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k6427 in k6397 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 570  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6423 in k6397 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6425,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6404 in k6397 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6410,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("map");
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k6408 in k6404 in k6397 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 569  cons*");
((C_proc6)C_retrieve_symbol_proc(lf[254]))(6,*((C_word*)lf[254]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_6337(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6337,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6355,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 566  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),t6,t4);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6386,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_car(t3);
C_trace("support.scm: 567  walk");
t10=((C_word*)((C_word*)t0)[3])[1];
f_6146(3,t10,t8,t9);}}

/* k6384 in loop in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6386,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
C_trace("support.scm: 567  loop");
t3=((C_word*)((C_word*)t0)[5])[1];
f_6337(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6353 in loop in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("support.scm: 566  walk");
t4=((C_word*)((C_word*)t0)[2])[1];
f_6146(3,t4,t2,t3);}

/* k6361 in k6353 in loop in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[255],t3));}

/* k6311 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 561  cons*");
((C_proc5)C_retrieve_symbol_proc(lf[254]))(5,*((C_word*)lf[254]+1),((C_word*)t0)[3],lf[226],((C_word*)t0)[2],t1);}

/* k6278 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6280,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6257 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k6253 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 552  map");
((C_proc5)C_retrieve_proc(*((C_word*)lf[251]+1)))(5,*((C_word*)lf[251]+1),((C_word*)t0)[3],*((C_word*)lf[252]+1),((C_word*)t0)[2],t1);}

/* k6237 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6247,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6251,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 553  last");
((C_proc3)C_retrieve_symbol_proc(lf[250]))(3,*((C_word*)lf[250]+1),t3,((C_word*)t0)[2]);}

/* k6249 in k6237 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 553  walk");
t2=((C_word*)((C_word*)t0)[3])[1];
f_6146(3,t2,((C_word*)t0)[2],t1);}

/* k6245 in k6237 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6247,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[91],t3));}

/* k6191 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6187 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6189,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[249],t2));}

/* k6170 in k6163 in walk in ##compiler#build-expression-tree in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6172,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5626,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5629,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6135,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 536  walk");
t9=((C_word*)t6)[1];
f_5629(3,t9,t8,t2);}

/* k6133 in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6138,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 537  debugging");
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),t2,lf[246],lf[247],((C_word*)((C_word*)t0)[2])[1]);}

/* k6136 in k6133 in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word *a;
loop:
a=C_alloc(11);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_5629,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
t4=t2;
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[200],lf[210],t5,C_SCHEME_END_OF_LIST));}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
C_trace("support.scm: 471  bomb");
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t1,lf[213],t2);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[214]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[200],lf[214],t7,C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_eqp(t4,lf[215]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[216]));
if(C_truep(t7)){
t8=(C_word)C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5688,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cdr(t2);
C_trace("map");
t11=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[3])[1],t10);}
else{
t8=(C_word)C_eqp(t4,lf[81]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5714,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_numberp(t9))){
t11=(C_word)C_eqp(lf[220],C_retrieve(lf[221]));
if(C_truep(t11)){
t12=(C_word)C_i_integerp(t9);
t13=t10;
f_5714(t13,(C_word)C_i_not(t12));}
else{
t12=t10;
f_5714(t12,C_SCHEME_FALSE);}}
else{
t11=t10;
f_5714(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t4,lf[91]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("support.scm: 491  walk");
t69=t1;
t70=t11;
t1=t69;
t2=t70;
c=3;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5764,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 492  unzip1");
((C_proc3)C_retrieve_symbol_proc(lf[222]))(3,*((C_word*)lf[222]+1),t12,t10);}}
else{
t10=(C_word)C_eqp(t4,lf[116]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t4,lf[223]));
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5818,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_caddr(t2);
C_trace("support.scm: 496  walk");
t69=t14;
t70=t15;
t1=t69;
t2=t70;
c=3;
goto loop;}
else{
t12=(C_word)C_eqp(t4,lf[224]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5841,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t13))){
t16=(C_word)C_i_car(t13);
t17=(C_word)C_eqp(lf[81],t16);
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t13);
t19=t15;
f_5841(t19,(C_word)C_a_i_list(&a,1,t18));}
else{
t18=t15;
f_5841(t18,(C_word)C_a_i_list(&a,1,t13));}}
else{
t16=t15;
f_5841(t16,(C_word)C_a_i_list(&a,1,t13));}}
else{
t13=(C_word)C_eqp(t4,lf[225]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t4,lf[226]));
if(C_truep(t14)){
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5889,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t19=(C_word)C_i_cddr(t2);
C_trace("map");
t20=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,((C_word*)((C_word*)t0)[3])[1],t19);}
else{
t15=(C_word)C_eqp(t4,lf[227]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t2);
t17=(C_word)C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_record(&a,4,lf[200],lf[227],t17,C_SCHEME_END_OF_LIST));}
else{
t16=(C_word)C_eqp(t4,lf[228]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t4,lf[229]));
if(C_truep(t17)){
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,1,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5931,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(C_word)C_i_cddr(t2);
C_trace("map");
t22=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,((C_word*)((C_word*)t0)[3])[1],t21);}
else{
t18=(C_word)C_eqp(t4,lf[230]);
if(C_truep(t18)){
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_cadr(t19);
t21=(C_word)C_i_caddr(t2);
t22=(C_word)C_i_cadr(t21);
t23=(C_word)C_i_cadddr(t2);
t24=(C_word)C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5984,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
C_trace("support.scm: 515  fifth");
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),t25,t2);}
else{
t19=(C_word)C_eqp(t4,lf[233]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6005,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6005(t21,t19);}
else{
t21=(C_word)C_eqp(t4,lf[241]);
if(C_truep(t21)){
t22=t20;
f_6005(t22,t21);}
else{
t22=(C_word)C_eqp(t4,lf[242]);
if(C_truep(t22)){
t23=t20;
f_6005(t23,t22);}
else{
t23=(C_word)C_eqp(t4,lf[243]);
t24=t20;
f_6005(t24,(C_truep(t23)?t23:(C_word)C_eqp(t4,lf[244])));}}}}}}}}}}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6125,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t2);}}}}

/* k6123 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6125,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[235],lf[245],t1));}

/* k6003 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_6005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6005,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6014,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
C_trace("map");
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[234]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6030,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
C_trace("map");
t5=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6042,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6047 in k6003 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6048,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6062,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=t2;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6085,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),t6,t5,lf[240]);}

/* k6083 in a6047 in k6003 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6062(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6062(t2,C_SCHEME_FALSE);}}

/* k6060 in a6047 in k6003 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_6062(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6062,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6066,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 531  real-name");
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,((C_word*)t0)[2]);}
else{
C_trace("support.scm: 533  ##sys#symbol->qualified-string");
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),t2,((C_word*)t0)[2]);}}

/* k6067 in k6060 in a6047 in k6003 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t1;
t4=((C_word*)t0)[4];
f_6066(2,t4,(C_word)C_a_i_list(&a,3,C_retrieve(lf[237]),((C_word*)t0)[3],t3));}
else{
C_trace("support.scm: 532  ##sys#symbol->qualified-string");
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),t2,((C_word*)t0)[2]);}}

/* k6074 in k6067 in k6060 in a6047 in k6003 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6076,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6066(2,t2,(C_word)C_a_i_list(&a,3,C_retrieve(lf[237]),((C_word*)t0)[2],t1));}

/* k6064 in k6060 in a6047 in k6003 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6066,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6055,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k6053 in k6064 in k6060 in a6047 in k6003 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6055,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[235],((C_word*)t0)[2],t1));}

/* a6041 in k6003 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6042,2,t0,t1);}
C_trace("support.scm: 523  get-line-2");
((C_proc3)C_retrieve_symbol_proc(lf[144]))(3,*((C_word*)lf[144]+1),t1,((C_word*)t0)[2]);}

/* k6028 in k6003 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6030,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[235],lf[236],t1));}

/* k6012 in k6003 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6014,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5982 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5984,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5964,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5968,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 516  sixth");
((C_proc3)C_retrieve_symbol_proc(lf[231]))(3,*((C_word*)lf[231]+1),t5,((C_word*)t0)[2]);}

/* k5966 in k5982 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 516  walk");
t2=((C_word*)((C_word*)t0)[3])[1];
f_5629(3,t2,((C_word*)t0)[2],t1);}

/* k5962 in k5982 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5964,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[200],lf[230],((C_word*)t0)[2],t2));}

/* k5929 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5931,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[228],((C_word*)t0)[2],t1));}

/* k5887 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5889,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5839 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_5841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5841,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5844,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
C_trace("map");
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)((C_word*)t0)[2])[1],t3);}

/* k5842 in k5839 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5844,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5816 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5818,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[200],lf[116],((C_word*)t0)[2],t2));}

/* k5762 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5767,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5784,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("map");
t6=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5783 in k5762 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5784,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
C_trace("support.scm: 493  walk");
t4=((C_word*)((C_word*)t0)[2])[1];
f_5629(3,t4,t1,t3);}

/* k5772 in k5762 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5782,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 494  walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_5629(3,t3,t2,((C_word*)t0)[2]);}

/* k5780 in k5772 in k5762 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5782,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("support.scm: 493  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5765 in k5762 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5767,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],lf[91],((C_word*)t0)[2],t1));}

/* k5712 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_5714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5714,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 482  compiler-warning");
((C_proc5)C_retrieve_proc(*((C_word*)lf[19]+1)))(5,*((C_word*)lf[19]+1),t2,lf[218],lf[219],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[200],lf[81],t3,C_SCHEME_END_OF_LIST));}}

/* k5715 in k5712 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5724,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 485  truncate");
((C_proc3)C_retrieve_proc(*((C_word*)lf[217]+1)))(3,*((C_word*)lf[217]+1),t2,((C_word*)t0)[2]);}

/* k5722 in k5715 in k5712 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5724,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_list(&a,1,t2);
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[200],lf[81],t4,C_SCHEME_END_OF_LIST));}

/* k5686 in walk in ##compiler#build-node-graph in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5688,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[200],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1));}

/* ##compiler#qnode in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5617,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[200],lf[81],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#varnode in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5608,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[200],lf[210],t3,C_SCHEME_END_OF_LIST));}

/* make-node in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5602,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[200],t2,t3,t4));}

/* node-subexpressions in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5593,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[200]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(3)));}

/* node-subexpressions-set! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5584,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[200]);
C_trace("##sys#block-set!");
t5=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-parameters in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5575,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[200]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(2)));}

/* node-parameters-set! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5566,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[200]);
C_trace("##sys#block-set!");
t5=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-class in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5557,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[200]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* node-class-set! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5548,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[200]);
C_trace("##sys#block-set!");
t5=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node? in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5542,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[200]));}

/* f_5536 in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5536,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[200],t2,t3,t4));}

/* ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5061,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5065,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5065(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5534,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 401  append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t4,C_retrieve(lf[197]),C_retrieve(lf[198]),C_retrieve(lf[126]));}}

/* k5532 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5065(t3,t2);}

/* k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_5065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5065,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5070,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 404  ##sys#hash-table-for-each");
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5070,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=C_SCHEME_UNDEFINED;
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5080,a[2]=t3,a[3]=t9,a[4]=t7,a[5]=t5,a[6]=t13,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
C_trace("support.scm: 412  write");
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t14,t2);}}

/* k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5083,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5213,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5213(t6,t2,((C_word*)t0)[2]);}

/* loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_5213(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5213,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
C_trace("support.scm: 416  caar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[160]+1)))(3,*((C_word*)lf[160]+1),t3,t2);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5226,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[158]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_5239(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[177]);
if(C_truep(t5)){
t6=t4;
f_5239(t6,t5);}
else{
t6=(C_word)C_eqp(t1,lf[178]);
if(C_truep(t6)){
t7=t4;
f_5239(t7,t6);}
else{
t7=(C_word)C_eqp(t1,lf[179]);
if(C_truep(t7)){
t8=t4;
f_5239(t8,t7);}
else{
t8=(C_word)C_eqp(t1,lf[180]);
if(C_truep(t8)){
t9=t4;
f_5239(t9,t8);}
else{
t9=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t9)){
t10=t4;
f_5239(t10,t9);}
else{
t10=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t10)){
t11=t4;
f_5239(t11,t10);}
else{
t11=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t11)){
t12=t4;
f_5239(t12,t11);}
else{
t12=(C_word)C_eqp(t1,lf[184]);
if(C_truep(t12)){
t13=t4;
f_5239(t13,t12);}
else{
t13=(C_word)C_eqp(t1,lf[185]);
if(C_truep(t13)){
t14=t4;
f_5239(t14,t13);}
else{
t14=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t14)){
t15=t4;
f_5239(t15,t14);}
else{
t15=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t15)){
t16=t4;
f_5239(t16,t15);}
else{
t16=(C_word)C_eqp(t1,lf[188]);
if(C_truep(t16)){
t17=t4;
f_5239(t17,t16);}
else{
t17=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t17)){
t18=t4;
f_5239(t18,t17);}
else{
t18=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t18)){
t19=t4;
f_5239(t19,t18);}
else{
t19=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t19)){
t20=t4;
f_5239(t20,t19);}
else{
t20=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t20)){
t21=t4;
f_5239(t21,t20);}
else{
t21=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t21)){
t22=t4;
f_5239(t22,t21);}
else{
t22=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t22)){
t23=t4;
f_5239(t23,t22);}
else{
t23=(C_word)C_eqp(t1,lf[195]);
t24=t4;
f_5239(t24,(C_truep(t23)?t23:(C_word)C_eqp(t1,lf[196])));}}}}}}}}}}}}}}}}}}}}

/* k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_5239(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5239,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t4=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(9),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[157]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,lf[157]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
C_trace("support.scm: 437  loop");
t5=((C_word*)((C_word*)t0)[7])[1];
f_5213(t5,((C_word*)t0)[6],t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[161]);
if(C_truep(t3)){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[8])[1],lf[157]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[10]);
C_trace("support.scm: 437  loop");
t6=((C_word*)((C_word*)t0)[7])[1];
f_5213(t6,((C_word*)t0)[6],t5);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5280,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 424  cdar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t5,((C_word*)t0)[10]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[163]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[8])[1],lf[157]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(((C_word*)t0)[10]);
C_trace("support.scm: 437  loop");
t7=((C_word*)((C_word*)t0)[7])[1];
f_5213(t7,((C_word*)t0)[6],t6);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5296,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 426  cdar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t6,((C_word*)t0)[10]);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[164]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5306,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 428  cdar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t6,((C_word*)t0)[10]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[165]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t6)){
t8=t7;
f_5315(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[169]);
if(C_truep(t8)){
t9=t7;
f_5315(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[170]);
if(C_truep(t9)){
t10=t7;
f_5315(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[146]);
if(C_truep(t10)){
t11=t7;
f_5315(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[9],lf[171]);
if(C_truep(t11)){
t12=t7;
f_5315(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[9],lf[172]);
if(C_truep(t12)){
t13=t7;
f_5315(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[9],lf[173]);
if(C_truep(t13)){
t14=t7;
f_5315(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[9],lf[174]);
if(C_truep(t14)){
t15=t7;
f_5315(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[9],lf[175]);
t16=t7;
f_5315(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[9],lf[176])));}}}}}}}}}}}}}}

/* k5313 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_5315(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5315,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5318,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t4=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(9),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[166]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 433  cdar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[167]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("support.scm: 435  cdar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[7]);
C_trace("support.scm: 436  bomb");
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),((C_word*)t0)[8],lf[168],t4);}}}}

/* k5353 in k5313 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 437  loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_5213(t4,((C_word*)t0)[2],t3);}

/* k5343 in k5313 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 437  loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_5213(t4,((C_word*)t0)[2],t3);}

/* k5316 in k5313 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5335,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 431  caar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[160]+1)))(3,*((C_word*)lf[160]+1),t3,((C_word*)t0)[2]);}

/* k5333 in k5316 in k5313 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5319 in k5316 in k5313 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(61),((C_word*)t0)[3]);}

/* k5322 in k5319 in k5316 in k5313 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 431  cdar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t2,((C_word*)t0)[2]);}

/* k5329 in k5322 in k5319 in k5316 in k5313 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5304 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 437  loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_5213(t4,((C_word*)t0)[2],t3);}

/* k5294 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 437  loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_5213(t4,((C_word*)t0)[2],t3);}

/* k5278 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 437  loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_5213(t4,((C_word*)t0)[2],t3);}

/* k5240 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5257,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 420  caar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[160]+1)))(3,*((C_word*)lf[160]+1),t2,((C_word*)t0)[2]);}

/* k5255 in k5240 in k5237 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(t1,lf[159]);
t3=(C_word)C_i_cdr(t2);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5224 in k5221 in loop in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 437  loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_5213(t3,((C_word*)t0)[2],t2);}

/* k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5086,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[157]);
t5=t3;
f_5124(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5124(t4,C_SCHEME_FALSE);}}

/* k5122 in k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_5124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5124,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5127,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[154],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[157]);
t4=t2;
f_5148(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5148(t3,C_SCHEME_FALSE);}}}

/* k5146 in k5122 in k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_5148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5148,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5151,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[155],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5172,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[157]);
t4=t2;
f_5172(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_5172(t3,C_SCHEME_FALSE);}}}

/* k5170 in k5146 in k5122 in k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_5172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5172,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5175,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t3,lf[156],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_5086(2,t3,t2);}}

/* k5173 in k5170 in k5146 in k5122 in k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5175,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k5149 in k5146 in k5122 in k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5151,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k5125 in k5122 in k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5127,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_word)C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k5084 in k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5114,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t4,lf[153],t3);}
else{
t3=t2;
f_5089(2,t3,C_SCHEME_UNDEFINED);}}

/* k5112 in k5084 in k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[4])[1]);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5087 in k5084 in k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5092,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5101,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t4,lf[152],t3);}
else{
C_trace("support.scm: 446  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[3]);}}

/* k5099 in k5087 in k5084 in k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[4])[1]);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5090 in k5087 in k5084 in k5081 in k5078 in a5069 in k5063 in ##compiler#display-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 446  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5039,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 382  ##sys#hash-table-for-each");
((C_proc4)C_retrieve_symbol_proc(lf[150]))(4,*((C_word*)lf[150]+1),t1,t2,C_retrieve(lf[143]));}

/* a5038 in ##compiler#display-line-number-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5039,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5046,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t5,t2,t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5044 in a5038 in ##compiler#display-line-number-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k5047 in k5044 in a5038 in ##compiler#display-line-number-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5059,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[148]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[149]+1),((C_word*)t0)[2]);}

/* k5057 in k5047 in k5044 in a5038 in ##compiler#display-line-number-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5050 in k5047 in k5044 in a5038 in ##compiler#display-line-number-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##compiler#find-lambda-container in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5009,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5015,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5015(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_5015(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5015,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5025,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 378  get");
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t4,((C_word*)t0)[2],t2,lf[146]);}}

/* k5023 in loop in ##compiler#find-lambda-container in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_5025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 379  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_5015(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4973,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4980,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 370  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t4,C_retrieve(lf[143]),t3);}

/* k4978 in ##compiler#get-line-2 in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_cdr(t1);
t4=t2;
f_4983(t4,(C_word)C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_4983(t3,C_SCHEME_FALSE);}}

/* k4981 in k4978 in ##compiler#get-line-2 in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_4983(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(t1);
C_trace("support.scm: 372  values");
C_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
C_trace("support.scm: 373  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* ##compiler#get-line in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4963,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
C_trace("support.scm: 366  get");
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t1,C_retrieve(lf[143]),t3,t2);}

/* ##compiler#get-list in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4954,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4958,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 359  get");
((C_proc5)C_retrieve_symbol_proc(lf[133]))(5,*((C_word*)lf[133]+1),t5,t2,t3,t4);}

/* k4956 in ##compiler#get-list in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* ##compiler#count! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_4897r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4897r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4897r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4901,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 350  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k4899 in ##compiler#count! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4901,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_fixnum_plus(t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4931,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t1,C_fix(1));
C_trace("support.scm: 355  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("support.scm: 356  ##sys#hash-table-set!");
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k4929 in k4899 in ##compiler#count! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4845,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4849,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 342  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k4847 in ##compiler#collect! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4849,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4876,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=(C_word)C_slot(t1,C_fix(1));
C_trace("support.scm: 346  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
C_trace("support.scm: 347  ##sys#hash-table-set!");
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k4874 in k4847 in ##compiler#collect! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4799,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4803,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 334  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t6,t2,t3);}

/* k4801 in ##compiler#put! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4825,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t1,C_fix(1));
C_trace("support.scm: 338  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
C_trace("support.scm: 339  ##sys#hash-table-set!");
((C_proc5)C_retrieve_symbol_proc(lf[138]))(5,*((C_word*)lf[138]+1),((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k4823 in k4801 in ##compiler#put! in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4781r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4781r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4781r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4785,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 328  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,t2,t3);}

/* k4783 in ##compiler#get-all in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4785,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4793,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 330  filter-map");
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a4792 in k4783 in ##compiler#get-all in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4793,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4763,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4767,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 322  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t5,t2,t3);}

/* k4765 in ##compiler#get in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4532,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4536,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4678,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4678(t7,t3,C_retrieve(lf[132]));}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop494 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_4678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4678,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4718,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_list(&a,1,lf[131]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4693,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t4,t3,lf[124],C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_car(t5);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t4,t3,lf[124],t8);}
else{
C_trace("##sys#error");
t8=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4691 in loop494 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[124],t1);}

/* k4716 in loop494 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[127])))){
t3=(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t2,((C_word*)t0)[2],lf[128],C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t2,((C_word*)t0)[2],lf[128],t6);}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_4678(t4,((C_word*)t0)[3],t3);}}

/* k4734 in k4716 in loop494 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[128],t1);}

/* k4719 in k4716 in loop494 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4678(t3,((C_word*)t0)[2],t2);}

/* k4534 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4593,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4593(t6,t2,C_retrieve(lf[130]));}

/* loop538 in k4534 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_4593(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4593,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4633,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_list(&a,1,lf[129]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4608,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t4,t3,lf[124],C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_car(t5);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t4,t3,lf[124],t8);}
else{
C_trace("##sys#error");
t8=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4606 in loop538 in k4534 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[124],t1);}

/* k4631 in loop538 in k4534 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[127])))){
t3=(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4651,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t2,((C_word*)t0)[2],lf[128],C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t2,((C_word*)t0)[2],lf[128],t6);}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_4593(t4,((C_word*)t0)[3],t3);}}

/* k4649 in k4631 in loop538 in k4534 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[128],t1);}

/* k4634 in k4631 in loop538 in k4534 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4593(t3,((C_word*)t0)[2],t2);}

/* k4537 in k4534 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4539,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4544,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4544(t5,((C_word*)t0)[2],C_retrieve(lf[126]));}

/* loop581 in k4537 in k4534 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_4544(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4544,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4584,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,lf[122]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4559,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t4,t3,lf[124],C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_car(t5);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t4,t3,lf[124],t8);}
else{
C_trace("##sys#error");
t8=*((C_word*)lf[125]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4557 in loop581 in k4537 in k4534 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[124],t1);}

/* k4582 in loop581 in k4537 in k4534 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4544(t3,((C_word*)t0)[2],t2);}

/* k4530 in ##compiler#initialize-analysis-database in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#expand-profile-lambda in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4387,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[112]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4391,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 282  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[92]))(2,*((C_word*)lf[92]+1),t6);}

/* k4389 in ##compiler#expand-profile-lambda in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("support.scm: 283  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,((C_word*)t0)[6],((C_word*)t0)[2],C_retrieve(lf[113]));}

/* k4393 in k4389 in ##compiler#expand-profile-lambda in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4395,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! profile-lambda-list ...) */,t1);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
t4=C_mutate((C_word*)lf[112]+1 /* (set! profile-lambda-index ...) */,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[81],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[115],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[116],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[116],t14);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t15,t16);
t18=(C_word)C_a_i_cons(&a,2,lf[117],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=(C_word)C_a_i_cons(&a,2,lf[116],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[81],t22);
t24=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[114]),C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,t23,t24);
t26=(C_word)C_a_i_cons(&a,2,lf[118],t25);
t27=(C_word)C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[116],t28);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t21,t30);
t32=(C_word)C_a_i_cons(&a,2,t12,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[119],t32);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,(C_word)C_a_i_cons(&a,2,lf[116],t35));}

/* ##compiler#llist-length in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4384,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_length(t2));}

/* ##compiler#process-lambda-documentation in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4381,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4274,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4281,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[106]+1)))(3,*((C_word*)lf[106]+1),t3,t4);}

/* a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4283,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4289,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4314,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("with-exception-handler");
((C_proc4)C_retrieve_symbol_proc(lf[105]))(4,*((C_word*)lf[105]+1),t1,t3,t4);}

/* a4313 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4368,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a4367 in a4313 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4368r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4368r(t0,t1,t2);}}

static void C_ccall f_4368r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4374,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("k453456");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4373 in a4367 in a4313 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4374,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4319 in a4313 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4324,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4352,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 264  with-input-from-string");
((C_proc4)C_retrieve_symbol_proc(lf[104]))(4,*((C_word*)lf[104]+1),t2,((C_word*)t0)[2],t3);}

/* a4351 in a4319 in a4313 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4358,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4366,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 264  read");
((C_proc2)C_retrieve_proc(*((C_word*)lf[100]+1)))(2,*((C_word*)lf[100]+1),t3);}

/* k4364 in a4351 in a4319 in a4313 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 264  unfold");
((C_proc6)C_retrieve_symbol_proc(lf[101]))(6,*((C_word*)lf[101]+1),((C_word*)t0)[3],*((C_word*)lf[102]+1),*((C_word*)lf[103]+1),((C_word*)t0)[2],t1);}

/* a4357 in a4351 in a4319 in a4313 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4358,3,t0,t1,t2);}
C_trace("support.scm: 264  read");
((C_proc2)C_retrieve_proc(*((C_word*)lf[100]+1)))(2,*((C_word*)lf[100]+1),t1);}

/* k4322 in a4319 in a4313 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4324,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[97]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k4344 in k4322 in a4319 in a4313 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4346,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[98],t1));}

/* a4288 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4289,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4295,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("k453456");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4294 in a4288 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 261  exn?");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4304 in a4294 in a4288 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 262  exn-msg");
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("support.scm: 263  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4301 in a4294 in a4288 in a4282 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 259  quit");
((C_proc5)C_retrieve_proc(*((C_word*)lf[24]+1)))(5,*((C_word*)lf[24]+1),((C_word*)t0)[3],lf[96],((C_word*)t0)[2],t1);}

/* k4279 in ##compiler#string->expr in k4271 in k4268 in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4173,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4179,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4179(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_4179(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4179,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[89]);}
else{
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_car(t2));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_equalp(t4,lf[90]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4207,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4207(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4256,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 248  constant?");
((C_proc3)C_retrieve_proc(*((C_word*)lf[80]+1)))(3,*((C_word*)lf[80]+1),t7,t4);}}}}

/* k4254 in loop in ##compiler#canonicalize-begin-body in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_4207(t3,t2);}
else{
t2=((C_word*)t0)[3];
f_4207(t2,(C_word)C_i_equalp(((C_word*)t0)[2],lf[94]));}}

/* k4205 in loop in ##compiler#canonicalize-begin-body in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_4207(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4207,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 250  loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_4179(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 251  gensym");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t2,lf[93]);}}

/* k4243 in k4205 in loop in ##compiler#canonicalize-begin-body in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4233,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("support.scm: 252  loop");
t8=((C_word*)((C_word*)t0)[2])[1];
f_4179(t8,t6,t7);}

/* k4231 in k4243 in k4205 in loop in ##compiler#canonicalize-begin-body in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4233,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[91],t3));}

/* ##compiler#basic-literal? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4113,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4129,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 233  constant?");
((C_proc3)C_retrieve_proc(*((C_word*)lf[80]+1)))(3,*((C_word*)lf[80]+1),t5,t2);}}}

/* k4127 in ##compiler#basic-literal? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4129,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4171,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 234  vector->list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[87]+1)))(3,*((C_word*)lf[87]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4135(2,t3,C_SCHEME_FALSE);}}}

/* k4169 in k4127 in ##compiler#basic-literal? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 234  every");
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),((C_word*)t0)[2],*((C_word*)lf[85]+1),t1);}

/* k4133 in k4127 in ##compiler#basic-literal? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4135,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("support.scm: 236  basic-literal?");
((C_proc3)C_retrieve_proc(*((C_word*)lf[85]+1)))(3,*((C_word*)lf[85]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4148 in k4133 in k4127 in ##compiler#basic-literal? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 237  basic-literal?");
((C_proc3)C_retrieve_proc(*((C_word*)lf[85]+1)))(3,*((C_word*)lf[85]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4067,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4071,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4111,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 223  big-fixnum?");
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t4,t2);}
else{
t4=t3;
f_4071(t4,C_SCHEME_FALSE);}}

/* k4109 in ##compiler#immediate? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4071(t2,(C_word)C_i_not(t1));}

/* k4069 in ##compiler#immediate? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_4071(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:(C_word)C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4037,3,t0,t1,t2);}
t3=(C_word)C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3991,3,t0,t1,t2);}
t3=(C_word)C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(lf[81],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#sort-symbols in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3971,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3977,tmp=(C_word)a,a+=2,tmp);
C_trace("support.scm: 202  sort");
((C_proc4)C_retrieve_symbol_proc(lf[79]))(4,*((C_word*)lf[79]+1),t1,t2,t3);}

/* a3976 in ##compiler#sort-symbols in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3977,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3985,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 202  symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t4,t2);}

/* k3983 in a3976 in ##compiler#sort-symbols in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3989,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 202  symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t2,((C_word*)t0)[2]);}

/* k3987 in k3983 in a3976 in ##compiler#sort-symbols in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 202  string<?");
((C_proc4)C_retrieve_proc(*((C_word*)lf[78]+1)))(4,*((C_word*)lf[78]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#follow-without-loop in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3940,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3946,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3946(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3946(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3946,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_member(t2,t3))){
C_trace("support.scm: 198  abort");
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 199  proc");
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}}

/* a3960 in loop in ##compiler#follow-without-loop in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3961,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
C_trace("support.scm: 199  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_3946(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3877,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3891,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 188  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[75]+1)))(3,*((C_word*)lf[75]+1),t5,t3);}}

/* k3889 in ##compiler#fold-inner in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3891,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3893,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3893(t5,((C_word*)t0)[2],t1);}

/* fold in k3889 in ##compiler#fold-inner in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3893(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3893,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,t4,t5);
C_apply(4,0,t1,((C_word*)t0)[3],t6);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3922,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(t2);
C_trace("support.scm: 193  fold");
t10=t4;
t11=t5;
t1=t10;
t2=t11;
goto loop;}}

/* k3920 in fold in k3889 in ##compiler#fold-inner in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3922,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* ##compiler#close-checked-input-file in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3865,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_string_equal_p(t3,lf[72]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
C_trace("support.scm: 183  close-input-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t1,t2);}}

/* ##compiler#check-and-open-input-file in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3818r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3818r(t0,t1,t2,t3);}}

static void C_ccall f_3818r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_string_equal_p(t2,lf[65]))){
C_trace("support.scm: 177  current-input-port");
((C_proc2)C_retrieve_proc(*((C_word*)lf[66]+1)))(2,*((C_word*)lf[66]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3834,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 178  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),t4,t2);}}

/* k3832 in ##compiler#check-and-open-input-file in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3834,2,t0,t1);}
if(C_truep(t1)){
C_trace("support.scm: 178  open-input-file");
((C_proc3)C_retrieve_proc(*((C_word*)lf[67]+1)))(3,*((C_word*)lf[67]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_3846(t4,t2);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_3846(t5,(C_word)C_i_not(t4));}}}

/* k3844 in k3832 in ##compiler#check-and-open-input-file in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("support.scm: 179  quit");
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),((C_word*)t0)[4],lf[68],((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
C_trace("support.scm: 180  quit");
((C_proc5)C_retrieve_proc(*((C_word*)lf[24]+1)))(5,*((C_word*)lf[24]+1),((C_word*)t0)[4],lf[69],((C_word*)t0)[3],t2);}}

/* ##compiler#words->bytes in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3811,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub270(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3804,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub266(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3748,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3752,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3802,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 158  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),t4,t2);}

/* k3800 in ##compiler#valid-c-identifier? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string->list");
t2=C_retrieve(lf[55]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3750 in ##compiler#valid-c-identifier? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3752,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3775,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_cdr(t1);
C_trace("support.scm: 162  any");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3774 in k3750 in ##compiler#valid-c-identifier? in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3775,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3654,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3666,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("string->list");
t5=C_retrieve(lf[55]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3668 in ##compiler#c-ify-string in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3672,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3672(t5,((C_word*)t0)[2],t1);}

/* loop in k3668 in ##compiler#c-ify-string in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3672,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[52]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3694,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3694(t7,t5);}
else{
t7=(C_word)C_fixnum_greater_or_equal_p(t4,C_fix(127));
t8=t6;
f_3694(t8,(C_truep(t7)?t7:(C_word)C_i_memq(t3,lf[58])));}}}

/* k3692 in loop in k3668 in ##compiler#c-ify-string in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3694(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3694,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3701,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_3701(t3,lf[56]);}
else{
t3=(C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_3701(t4,(C_truep(t3)?lf[57]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("support.scm: 155  loop");
t4=((C_word*)((C_word*)t0)[4])[1];
f_3672(t4,t2,t3);}}

/* k3731 in k3692 in loop in k3668 in ##compiler#c-ify-string in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3733,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3699 in k3692 in loop in k3668 in ##compiler#c-ify-string in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3701,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3717,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 153  number->string");
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k3715 in k3699 in k3692 in loop in k3668 in ##compiler#c-ify-string in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string->list");
t2=C_retrieve(lf[55]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3703 in k3699 in k3692 in loop in k3668 in ##compiler#c-ify-string in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3709,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 154  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_3672(t4,t2,t3);}

/* k3707 in k3703 in k3699 in k3692 in loop in k3668 in ##compiler#c-ify-string in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 149  append");
((C_proc6)C_retrieve_proc(*((C_word*)lf[53]+1)))(6,*((C_word*)lf[53]+1),((C_word*)t0)[4],lf[54],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3664 in ##compiler#c-ify-string in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3666,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(34),t1);
C_trace("list->string");
t3=C_retrieve(lf[51]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3610,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3616,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3616(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3616(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3616,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=(C_word)C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3640,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_decrease(t3);
C_trace("support.scm: 135  loop");
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k3638 in loop in ##compiler#build-lambda-list in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3579,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
C_trace("support.scm: 129  string->symbol");
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3602,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[44]))(2,*((C_word*)lf[44]+1),t3);}}}

/* k3600 in ##compiler#symbolify in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3605,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],t1);}

/* k3603 in k3600 in ##compiler#symbolify in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3608,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k3606 in k3603 in k3600 in ##compiler#symbolify in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 130  string->symbol");
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3552,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
C_trace("support.scm: 124  symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[42]+1)))(3,*((C_word*)lf[42]+1),t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3571,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[44]))(2,*((C_word*)lf[44]+1),t3);}}}

/* k3569 in ##compiler#stringify in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3574,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],t1);}

/* k3572 in k3569 in ##compiler#stringify in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#posq in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3516,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3522,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3522(t4,t3,C_fix(0)));}

/* loop in ##compiler#posq in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static C_word C_fcall f_3522(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t2;
return(t5);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_fixnum_increase(t2);
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}

/* ##compiler#check-signature in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3448,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3451,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3472,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3472(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3472,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
if(C_truep((C_word)C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
C_trace("support.scm: 108  err");
t4=((C_word*)t0)[3];
f_3451(t4,t1);}}
else{
t4=(C_word)C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("support.scm: 110  err");
t5=((C_word*)t0)[3];
f_3451(t5,t1);}
else{
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
C_trace("support.scm: 111  loop");
t9=t1;
t10=t5;
t11=t6;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}}

/* err in ##compiler#check-signature in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3451,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 105  real-name");
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k3457 in err in ##compiler#check-signature in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3463,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("support.scm: 106  map-llist");
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,C_retrieve(lf[39]),t3);}

/* k3461 in k3457 in err in ##compiler#check-signature in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 104  quit");
((C_proc5)C_retrieve_proc(*((C_word*)lf[24]+1)))(5,*((C_word*)lf[24]+1),((C_word*)t0)[3],lf[38],((C_word*)t0)[2],t1);}

/* map-llist in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3405,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3411,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3411(t7,t1,t3);}

/* loop in map-llist in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3411,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
C_trace("support.scm: 99   proc");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3434,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
C_trace("support.scm: 100  proc");
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}}

/* k3432 in loop in map-llist in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3438,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("support.scm: 100  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_3411(t4,t2,t3);}

/* k3436 in k3432 in loop in map-llist in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3438,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3402,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_emit_syntax_trace_info(t2,t3,C_retrieve(lf[29])));}

/* ##sys#syntax-error-hook in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3341r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3341r(t0,t1,t2,t3);}}

static void C_ccall f_3341r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3345,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 78   current-error-port");
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t6);}

/* k3343 in ##sys#syntax-error-hook in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t2;
f_3348(t8,t3);}
else{
t3=t2;
f_3348(t3,C_SCHEME_FALSE);}}

/* k3346 in k3343 in ##sys#syntax-error-hook in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3348,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
C_trace("support.scm: 85   fprintf");
((C_proc6)C_retrieve_symbol_proc(lf[20]))(6,*((C_word*)lf[20]+1),t2,((C_word*)t0)[4],lf[32],t1,((C_word*)((C_word*)t0)[2])[1]);}
else{
C_trace("support.scm: 86   fprintf");
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t2,((C_word*)t0)[4],lf[33],((C_word*)((C_word*)t0)[2])[1]);}}

/* k3349 in k3346 in k3343 in ##sys#syntax-error-hook in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3354,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3362(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop93 in k3349 in k3346 in k3343 in ##sys#syntax-error-hook in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3362(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3362,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3375,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("fprintf");
((C_proc5)C_retrieve_symbol_proc(lf[20]))(5,*((C_word*)lf[20]+1),t4,((C_word*)t0)[2],lf[31],t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3373 in loop93 in k3349 in k3346 in k3343 in ##sys#syntax-error-hook in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3362(t3,((C_word*)t0)[2],t2);}

/* k3352 in k3349 in k3346 in k3343 in ##sys#syntax-error-hook in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3357,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 88   print-call-chain");
((C_proc6)C_retrieve_symbol_proc(lf[28]))(6,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2],C_fix(0),C_retrieve(lf[29]),lf[30]);}

/* k3355 in k3352 in k3349 in k3346 in k3343 in ##sys#syntax-error-hook in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 89   exit");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],C_fix(70));}

/* quit in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3322r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3322r(t0,t1,t2,t3);}}

static void C_ccall f_3322r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3326,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 71   current-error-port");
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t4);}

/* k3324 in quit in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3329,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 72   string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[26],((C_word*)t0)[2]);}

/* k3337 in k3324 in quit in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[20]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3327 in k3324 in quit in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 73   newline");
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t2,((C_word*)t0)[2]);}

/* k3330 in k3327 in k3324 in quit in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 74   exit");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],C_fix(1));}

/* ##compiler#compiler-warning in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3293r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3293r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3293r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3300,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[23]))){
t6=(C_word)C_i_memq(t2,*((C_word*)lf[4]+1));
t7=t5;
f_3300(t7,(C_word)C_i_not(t6));}
else{
t6=t5;
f_3300(t6,C_SCHEME_FALSE);}}

/* k3298 in ##compiler#compiler-warning in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3300(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3300,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 66   current-error-port");
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3301 in k3298 in ##compiler#compiler-warning in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3306,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("support.scm: 67   string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[21],((C_word*)t0)[2]);}

/* k3311 in k3301 in k3298 in ##compiler#compiler-warning in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],C_retrieve(lf[20]),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3304 in k3301 in k3298 in ##compiler#compiler-warning in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("support.scm: 68   newline");
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#debugging in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3234r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3234r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3234r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_memq(t2,*((C_word*)lf[3]+1)))){
t5=*((C_word*)lf[11]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3244,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t6,t3,t5);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k3242 in ##compiler#debugging in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3247,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 58   display");
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),t3,lf[18]);}
else{
t3=t2;
f_3247(2,t3,C_SCHEME_UNDEFINED);}}

/* k3257 in k3242 in ##compiler#debugging in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3259,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3264,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3264(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop49 in k3257 in k3242 in ##compiler#debugging in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_fcall f_3264(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3264,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3277,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3291,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("support.scm: 59   force");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t6,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3289 in loop49 in k3257 in k3242 in ##compiler#debugging in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3275 in loop49 in k3257 in k3242 in ##compiler#debugging in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k3278 in k3275 in loop49 in k3257 in k3242 in ##compiler#debugging in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3264(t3,((C_word*)t0)[2],t2);}

/* k3245 in k3242 in ##compiler#debugging in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3250,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 60   newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[13]+1)))(2,*((C_word*)lf[13]+1),t2);}

/* k3248 in k3245 in k3242 in ##compiler#debugging in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("support.scm: 61   flush-output");
((C_proc2)C_retrieve_proc(*((C_word*)lf[12]+1)))(2,*((C_word*)lf[12]+1),t2);}

/* k3251 in k3248 in k3245 in k3242 in ##compiler#debugging in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3207r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3207r(t0,t1,t2);}}

static void C_ccall f_3207r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3221,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
C_trace("support.scm: 49   string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),t3,lf[8],t4);}
else{
C_trace("support.scm: 50   error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t1,lf[9]);}}

/* k3219 in ##compiler#bomb in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[6]+1),t1,t2);}

/* ##compiler#compiler-cleanup-hook in k3196 in k3193 in k3190 in k3187 in k3184 in k3181 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3202,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[612] = {
{"toplevel:support_scm",(void*)C_support_toplevel},
{"f_3183:support_scm",(void*)f_3183},
{"f_3186:support_scm",(void*)f_3186},
{"f_3189:support_scm",(void*)f_3189},
{"f_3192:support_scm",(void*)f_3192},
{"f_3195:support_scm",(void*)f_3195},
{"f_3198:support_scm",(void*)f_3198},
{"f_4270:support_scm",(void*)f_4270},
{"f_4273:support_scm",(void*)f_4273},
{"f_11112:support_scm",(void*)f_11112},
{"f_11116:support_scm",(void*)f_11116},
{"f_11200:support_scm",(void*)f_11200},
{"f_11122:support_scm",(void*)f_11122},
{"f_11187:support_scm",(void*)f_11187},
{"f_11190:support_scm",(void*)f_11190},
{"f_11193:support_scm",(void*)f_11193},
{"f_11128:support_scm",(void*)f_11128},
{"f_11135:support_scm",(void*)f_11135},
{"f_11137:support_scm",(void*)f_11137},
{"f_11169:support_scm",(void*)f_11169},
{"f_11165:support_scm",(void*)f_11165},
{"f_11150:support_scm",(void*)f_11150},
{"f_11106:support_scm",(void*)f_11106},
{"f_11100:support_scm",(void*)f_11100},
{"f_11094:support_scm",(void*)f_11094},
{"f_11066:support_scm",(void*)f_11066},
{"f_11070:support_scm",(void*)f_11070},
{"f_11045:support_scm",(void*)f_11045},
{"f_11049:support_scm",(void*)f_11049},
{"f_11012:support_scm",(void*)f_11012},
{"f_11018:support_scm",(void*)f_11018},
{"f_10979:support_scm",(void*)f_10979},
{"f_10985:support_scm",(void*)f_10985},
{"f_10955:support_scm",(void*)f_10955},
{"f_10886:support_scm",(void*)f_10886},
{"f_10890:support_scm",(void*)f_10890},
{"f_10895:support_scm",(void*)f_10895},
{"f_10899:support_scm",(void*)f_10899},
{"f_10950:support_scm",(void*)f_10950},
{"f_10929:support_scm",(void*)f_10929},
{"f_10941:support_scm",(void*)f_10941},
{"f_10944:support_scm",(void*)f_10944},
{"f_10917:support_scm",(void*)f_10917},
{"f_10853:support_scm",(void*)f_10853},
{"f_10863:support_scm",(void*)f_10863},
{"f_10866:support_scm",(void*)f_10866},
{"f_10729:support_scm",(void*)f_10729},
{"f_10738:support_scm",(void*)f_10738},
{"f_10751:support_scm",(void*)f_10751},
{"f_10757:support_scm",(void*)f_10757},
{"f_10760:support_scm",(void*)f_10760},
{"f_10763:support_scm",(void*)f_10763},
{"f_10766:support_scm",(void*)f_10766},
{"f_10769:support_scm",(void*)f_10769},
{"f_10772:support_scm",(void*)f_10772},
{"f_10831:support_scm",(void*)f_10831},
{"f_10844:support_scm",(void*)f_10844},
{"f_10775:support_scm",(void*)f_10775},
{"f_10790:support_scm",(void*)f_10790},
{"f_10793:support_scm",(void*)f_10793},
{"f_10801:support_scm",(void*)f_10801},
{"f_10811:support_scm",(void*)f_10811},
{"f_10814:support_scm",(void*)f_10814},
{"f_10796:support_scm",(void*)f_10796},
{"f_10781:support_scm",(void*)f_10781},
{"f_10733:support_scm",(void*)f_10733},
{"f_10726:support_scm",(void*)f_10726},
{"f_10708:support_scm",(void*)f_10708},
{"f_10662:support_scm",(void*)f_10662},
{"f_10681:support_scm",(void*)f_10681},
{"f_10692:support_scm",(void*)f_10692},
{"f_10688:support_scm",(void*)f_10688},
{"f_10641:support_scm",(void*)f_10641},
{"f_10647:support_scm",(void*)f_10647},
{"f_10651:support_scm",(void*)f_10651},
{"f_10654:support_scm",(void*)f_10654},
{"f_10657:support_scm",(void*)f_10657},
{"f_10629:support_scm",(void*)f_10629},
{"f_10633:support_scm",(void*)f_10633},
{"f_10538:support_scm",(void*)f_10538},
{"f_10557:support_scm",(void*)f_10557},
{"f_10582:support_scm",(void*)f_10582},
{"f_10586:support_scm",(void*)f_10586},
{"f_10588:support_scm",(void*)f_10588},
{"f_10595:support_scm",(void*)f_10595},
{"f_10608:support_scm",(void*)f_10608},
{"f_10611:support_scm",(void*)f_10611},
{"f_10614:support_scm",(void*)f_10614},
{"f_10617:support_scm",(void*)f_10617},
{"f_10620:support_scm",(void*)f_10620},
{"f_10624:support_scm",(void*)f_10624},
{"f_10541:support_scm",(void*)f_10541},
{"f_10545:support_scm",(void*)f_10545},
{"f_10551:support_scm",(void*)f_10551},
{"f_10532:support_scm",(void*)f_10532},
{"f_10473:support_scm",(void*)f_10473},
{"f_10481:support_scm",(void*)f_10481},
{"f_10508:support_scm",(void*)f_10508},
{"f_10484:support_scm",(void*)f_10484},
{"f_10487:support_scm",(void*)f_10487},
{"f_10504:support_scm",(void*)f_10504},
{"f_10490:support_scm",(void*)f_10490},
{"f_10500:support_scm",(void*)f_10500},
{"f_10493:support_scm",(void*)f_10493},
{"f_10496:support_scm",(void*)f_10496},
{"f_10464:support_scm",(void*)f_10464},
{"f_10458:support_scm",(void*)f_10458},
{"f_10452:support_scm",(void*)f_10452},
{"f_10440:support_scm",(void*)f_10440},
{"f_10444:support_scm",(void*)f_10444},
{"f_10447:support_scm",(void*)f_10447},
{"f_10402:support_scm",(void*)f_10402},
{"f_10406:support_scm",(void*)f_10406},
{"f13068:support_scm",(void*)f13068},
{"f_10409:support_scm",(void*)f_10409},
{"f_10416:support_scm",(void*)f_10416},
{"f_10360:support_scm",(void*)f_10360},
{"f_10369:support_scm",(void*)f_10369},
{"f_10331:support_scm",(void*)f_10331},
{"f_10341:support_scm",(void*)f_10341},
{"f_10143:support_scm",(void*)f_10143},
{"f_10326:support_scm",(void*)f_10326},
{"f_10297:support_scm",(void*)f_10297},
{"f_10303:support_scm",(void*)f_10303},
{"f_10316:support_scm",(void*)f_10316},
{"f_10146:support_scm",(void*)f_10146},
{"f_10165:support_scm",(void*)f_10165},
{"f_10259:support_scm",(void*)f_10259},
{"f_10271:support_scm",(void*)f_10271},
{"f_10229:support_scm",(void*)f_10229},
{"f_10240:support_scm",(void*)f_10240},
{"f_10220:support_scm",(void*)f_10220},
{"f_10184:support_scm",(void*)f_10184},
{"f_10190:support_scm",(void*)f_10190},
{"f_10194:support_scm",(void*)f_10194},
{"f_10019:support_scm",(void*)f_10019},
{"f_10025:support_scm",(void*)f_10025},
{"f_10103:support_scm",(void*)f_10103},
{"f_10108:support_scm",(void*)f_10108},
{"f_10118:support_scm",(void*)f_10118},
{"f_10076:support_scm",(void*)f_10076},
{"f_10047:support_scm",(void*)f_10047},
{"f_10052:support_scm",(void*)f_10052},
{"f_10062:support_scm",(void*)f_10062},
{"f_10023:support_scm",(void*)f_10023},
{"f_9721:support_scm",(void*)f_9721},
{"f_9920:support_scm",(void*)f_9920},
{"f_9941:support_scm",(void*)f_9941},
{"f_9405:support_scm",(void*)f_9405},
{"f_9715:support_scm",(void*)f_9715},
{"f_9417:support_scm",(void*)f_9417},
{"f_9427:support_scm",(void*)f_9427},
{"f_9445:support_scm",(void*)f_9445},
{"f_9479:support_scm",(void*)f_9479},
{"f_9080:support_scm",(void*)f_9080},
{"f_9399:support_scm",(void*)f_9399},
{"f_9086:support_scm",(void*)f_9086},
{"f_9096:support_scm",(void*)f_9096},
{"f_9105:support_scm",(void*)f_9105},
{"f_9117:support_scm",(void*)f_9117},
{"f_9129:support_scm",(void*)f_9129},
{"f_9135:support_scm",(void*)f_9135},
{"f_9040:support_scm",(void*)f_9040},
{"f_9074:support_scm",(void*)f_9074},
{"f_9046:support_scm",(void*)f_9046},
{"f_9050:support_scm",(void*)f_9050},
{"f_9009:support_scm",(void*)f_9009},
{"f_9022:support_scm",(void*)f_9022},
{"f_8978:support_scm",(void*)f_8978},
{"f_8991:support_scm",(void*)f_8991},
{"f_7925:support_scm",(void*)f_7925},
{"f_8972:support_scm",(void*)f_8972},
{"f_7931:support_scm",(void*)f_7931},
{"f_7937:support_scm",(void*)f_7937},
{"f_7966:support_scm",(void*)f_7966},
{"f_7985:support_scm",(void*)f_7985},
{"f_8004:support_scm",(void*)f_8004},
{"f_8074:support_scm",(void*)f_8074},
{"f_8093:support_scm",(void*)f_8093},
{"f_8175:support_scm",(void*)f_8175},
{"f_8214:support_scm",(void*)f_8214},
{"f_8233:support_scm",(void*)f_8233},
{"f_8252:support_scm",(void*)f_8252},
{"f_8332:support_scm",(void*)f_8332},
{"f_8417:support_scm",(void*)f_8417},
{"f_8492:support_scm",(void*)f_8492},
{"f_8526:support_scm",(void*)f_8526},
{"f_8596:support_scm",(void*)f_8596},
{"f_8529:support_scm",(void*)f_8529},
{"f_8335:support_scm",(void*)f_8335},
{"f_8366:support_scm",(void*)f_8366},
{"f_8255:support_scm",(void*)f_8255},
{"f_8096:support_scm",(void*)f_8096},
{"f_8127:support_scm",(void*)f_8127},
{"f_8007:support_scm",(void*)f_8007},
{"f_8038:support_scm",(void*)f_8038},
{"f_7873:support_scm",(void*)f_7873},
{"f_7877:support_scm",(void*)f_7877},
{"f_7888:support_scm",(void*)f_7888},
{"f_7894:support_scm",(void*)f_7894},
{"f_7907:support_scm",(void*)f_7907},
{"f_7910:support_scm",(void*)f_7910},
{"f_7880:support_scm",(void*)f_7880},
{"f_7792:support_scm",(void*)f_7792},
{"f_7804:support_scm",(void*)f_7804},
{"f_7811:support_scm",(void*)f_7811},
{"f_7814:support_scm",(void*)f_7814},
{"f_7817:support_scm",(void*)f_7817},
{"f_7820:support_scm",(void*)f_7820},
{"f_7823:support_scm",(void*)f_7823},
{"f_7826:support_scm",(void*)f_7826},
{"f_7829:support_scm",(void*)f_7829},
{"f_7832:support_scm",(void*)f_7832},
{"f_7835:support_scm",(void*)f_7835},
{"f_7838:support_scm",(void*)f_7838},
{"f_7841:support_scm",(void*)f_7841},
{"f_7844:support_scm",(void*)f_7844},
{"f_7847:support_scm",(void*)f_7847},
{"f_7850:support_scm",(void*)f_7850},
{"f_7853:support_scm",(void*)f_7853},
{"f_7856:support_scm",(void*)f_7856},
{"f_7859:support_scm",(void*)f_7859},
{"f_7862:support_scm",(void*)f_7862},
{"f_7865:support_scm",(void*)f_7865},
{"f_7868:support_scm",(void*)f_7868},
{"f_7798:support_scm",(void*)f_7798},
{"f_7696:support_scm",(void*)f_7696},
{"f_7705:support_scm",(void*)f_7705},
{"f_7711:support_scm",(void*)f_7711},
{"f_7700:support_scm",(void*)f_7700},
{"f_7675:support_scm",(void*)f_7675},
{"f_7685:support_scm",(void*)f_7685},
{"f_7626:support_scm",(void*)f_7626},
{"f_7632:support_scm",(void*)f_7632},
{"f_7673:support_scm",(void*)f_7673},
{"f_7645:support_scm",(void*)f_7645},
{"f_7589:support_scm",(void*)f_7589},
{"f_7595:support_scm",(void*)f_7595},
{"f_7624:support_scm",(void*)f_7624},
{"f_7602:support_scm",(void*)f_7602},
{"f_7605:support_scm",(void*)f_7605},
{"f_7548:support_scm",(void*)f_7548},
{"f_7554:support_scm",(void*)f_7554},
{"f_7587:support_scm",(void*)f_7587},
{"f_7561:support_scm",(void*)f_7561},
{"f_7564:support_scm",(void*)f_7564},
{"f_7456:support_scm",(void*)f_7456},
{"f_7480:support_scm",(void*)f_7480},
{"f_7370:support_scm",(void*)f_7370},
{"f_7376:support_scm",(void*)f_7376},
{"f_7392:support_scm",(void*)f_7392},
{"f_7406:support_scm",(void*)f_7406},
{"f_7414:support_scm",(void*)f_7414},
{"f_7175:support_scm",(void*)f_7175},
{"f_7354:support_scm",(void*)f_7354},
{"f_7360:support_scm",(void*)f_7360},
{"f_7250:support_scm",(void*)f_7250},
{"f_7272:support_scm",(void*)f_7272},
{"f_7285:support_scm",(void*)f_7285},
{"f_7316:support_scm",(void*)f_7316},
{"f_7207:support_scm",(void*)f_7207},
{"f_7229:support_scm",(void*)f_7229},
{"f_7178:support_scm",(void*)f_7178},
{"f_7202:support_scm",(void*)f_7202},
{"f_7106:support_scm",(void*)f_7106},
{"f_7112:support_scm",(void*)f_7112},
{"f_7118:support_scm",(void*)f_7118},
{"f_7122:support_scm",(void*)f_7122},
{"f_7169:support_scm",(void*)f_7169},
{"f_7133:support_scm",(void*)f_7133},
{"f_7158:support_scm",(void*)f_7158},
{"f_6920:support_scm",(void*)f_6920},
{"f_6967:support_scm",(void*)f_6967},
{"f_7104:support_scm",(void*)f_7104},
{"f_6971:support_scm",(void*)f_6971},
{"f_6979:support_scm",(void*)f_6979},
{"f_6986:support_scm",(void*)f_6986},
{"f_7097:support_scm",(void*)f_7097},
{"f_7010:support_scm",(void*)f_7010},
{"f_7082:support_scm",(void*)f_7082},
{"f_7037:support_scm",(void*)f_7037},
{"f_7040:support_scm",(void*)f_7040},
{"f_7058:support_scm",(void*)f_7058},
{"f_7047:support_scm",(void*)f_7047},
{"f_6974:support_scm",(void*)f_6974},
{"f_6924:support_scm",(void*)f_6924},
{"f_6930:support_scm",(void*)f_6930},
{"f_6937:support_scm",(void*)f_6937},
{"f_6939:support_scm",(void*)f_6939},
{"f_6952:support_scm",(void*)f_6952},
{"f_6895:support_scm",(void*)f_6895},
{"f_6901:support_scm",(void*)f_6901},
{"f_6911:support_scm",(void*)f_6911},
{"f_6859:support_scm",(void*)f_6859},
{"f_6865:support_scm",(void*)f_6865},
{"f_6889:support_scm",(void*)f_6889},
{"f_6885:support_scm",(void*)f_6885},
{"f_6835:support_scm",(void*)f_6835},
{"f_6839:support_scm",(void*)f_6839},
{"f_6842:support_scm",(void*)f_6842},
{"f_6845:support_scm",(void*)f_6845},
{"f_6801:support_scm",(void*)f_6801},
{"f_6807:support_scm",(void*)f_6807},
{"f_6821:support_scm",(void*)f_6821},
{"f_6825:support_scm",(void*)f_6825},
{"f_6599:support_scm",(void*)f_6599},
{"f_6603:support_scm",(void*)f_6603},
{"f_6611:support_scm",(void*)f_6611},
{"f_6784:support_scm",(void*)f_6784},
{"f_6792:support_scm",(void*)f_6792},
{"f_6787:support_scm",(void*)f_6787},
{"f_6723:support_scm",(void*)f_6723},
{"f_6774:support_scm",(void*)f_6774},
{"f_6778:support_scm",(void*)f_6778},
{"f_6781:support_scm",(void*)f_6781},
{"f_6727:support_scm",(void*)f_6727},
{"f_6772:support_scm",(void*)f_6772},
{"f_6730:support_scm",(void*)f_6730},
{"f_6749:support_scm",(void*)f_6749},
{"f_6765:support_scm",(void*)f_6765},
{"f_6757:support_scm",(void*)f_6757},
{"f_6741:support_scm",(void*)f_6741},
{"f_6736:support_scm",(void*)f_6736},
{"f_6681:support_scm",(void*)f_6681},
{"f_6684:support_scm",(void*)f_6684},
{"f_6687:support_scm",(void*)f_6687},
{"f_6700:support_scm",(void*)f_6700},
{"f_6665:support_scm",(void*)f_6665},
{"f_6657:support_scm",(void*)f_6657},
{"f_6634:support_scm",(void*)f_6634},
{"f_6506:support_scm",(void*)f_6506},
{"f_6512:support_scm",(void*)f_6512},
{"f_6524:support_scm",(void*)f_6524},
{"f_6528:support_scm",(void*)f_6528},
{"f_6531:support_scm",(void*)f_6531},
{"f_6591:support_scm",(void*)f_6591},
{"f_6550:support_scm",(void*)f_6550},
{"f_6554:support_scm",(void*)f_6554},
{"f_6536:support_scm",(void*)f_6536},
{"f_6518:support_scm",(void*)f_6518},
{"f_6458:support_scm",(void*)f_6458},
{"f_6464:support_scm",(void*)f_6464},
{"f_6484:support_scm",(void*)f_6484},
{"f_6488:support_scm",(void*)f_6488},
{"f_6140:support_scm",(void*)f_6140},
{"f_6146:support_scm",(void*)f_6146},
{"f_6165:support_scm",(void*)f_6165},
{"f_6399:support_scm",(void*)f_6399},
{"f_6429:support_scm",(void*)f_6429},
{"f_6425:support_scm",(void*)f_6425},
{"f_6406:support_scm",(void*)f_6406},
{"f_6410:support_scm",(void*)f_6410},
{"f_6337:support_scm",(void*)f_6337},
{"f_6386:support_scm",(void*)f_6386},
{"f_6355:support_scm",(void*)f_6355},
{"f_6363:support_scm",(void*)f_6363},
{"f_6313:support_scm",(void*)f_6313},
{"f_6280:support_scm",(void*)f_6280},
{"f_6259:support_scm",(void*)f_6259},
{"f_6255:support_scm",(void*)f_6255},
{"f_6239:support_scm",(void*)f_6239},
{"f_6251:support_scm",(void*)f_6251},
{"f_6247:support_scm",(void*)f_6247},
{"f_6193:support_scm",(void*)f_6193},
{"f_6189:support_scm",(void*)f_6189},
{"f_6172:support_scm",(void*)f_6172},
{"f_5626:support_scm",(void*)f_5626},
{"f_6135:support_scm",(void*)f_6135},
{"f_6138:support_scm",(void*)f_6138},
{"f_5629:support_scm",(void*)f_5629},
{"f_6125:support_scm",(void*)f_6125},
{"f_6005:support_scm",(void*)f_6005},
{"f_6048:support_scm",(void*)f_6048},
{"f_6085:support_scm",(void*)f_6085},
{"f_6062:support_scm",(void*)f_6062},
{"f_6069:support_scm",(void*)f_6069},
{"f_6076:support_scm",(void*)f_6076},
{"f_6066:support_scm",(void*)f_6066},
{"f_6055:support_scm",(void*)f_6055},
{"f_6042:support_scm",(void*)f_6042},
{"f_6030:support_scm",(void*)f_6030},
{"f_6014:support_scm",(void*)f_6014},
{"f_5984:support_scm",(void*)f_5984},
{"f_5968:support_scm",(void*)f_5968},
{"f_5964:support_scm",(void*)f_5964},
{"f_5931:support_scm",(void*)f_5931},
{"f_5889:support_scm",(void*)f_5889},
{"f_5841:support_scm",(void*)f_5841},
{"f_5844:support_scm",(void*)f_5844},
{"f_5818:support_scm",(void*)f_5818},
{"f_5764:support_scm",(void*)f_5764},
{"f_5784:support_scm",(void*)f_5784},
{"f_5774:support_scm",(void*)f_5774},
{"f_5782:support_scm",(void*)f_5782},
{"f_5767:support_scm",(void*)f_5767},
{"f_5714:support_scm",(void*)f_5714},
{"f_5717:support_scm",(void*)f_5717},
{"f_5724:support_scm",(void*)f_5724},
{"f_5688:support_scm",(void*)f_5688},
{"f_5617:support_scm",(void*)f_5617},
{"f_5608:support_scm",(void*)f_5608},
{"f_5602:support_scm",(void*)f_5602},
{"f_5593:support_scm",(void*)f_5593},
{"f_5584:support_scm",(void*)f_5584},
{"f_5575:support_scm",(void*)f_5575},
{"f_5566:support_scm",(void*)f_5566},
{"f_5557:support_scm",(void*)f_5557},
{"f_5548:support_scm",(void*)f_5548},
{"f_5542:support_scm",(void*)f_5542},
{"f_5536:support_scm",(void*)f_5536},
{"f_5061:support_scm",(void*)f_5061},
{"f_5534:support_scm",(void*)f_5534},
{"f_5065:support_scm",(void*)f_5065},
{"f_5070:support_scm",(void*)f_5070},
{"f_5080:support_scm",(void*)f_5080},
{"f_5213:support_scm",(void*)f_5213},
{"f_5223:support_scm",(void*)f_5223},
{"f_5239:support_scm",(void*)f_5239},
{"f_5315:support_scm",(void*)f_5315},
{"f_5355:support_scm",(void*)f_5355},
{"f_5345:support_scm",(void*)f_5345},
{"f_5318:support_scm",(void*)f_5318},
{"f_5335:support_scm",(void*)f_5335},
{"f_5321:support_scm",(void*)f_5321},
{"f_5324:support_scm",(void*)f_5324},
{"f_5331:support_scm",(void*)f_5331},
{"f_5306:support_scm",(void*)f_5306},
{"f_5296:support_scm",(void*)f_5296},
{"f_5280:support_scm",(void*)f_5280},
{"f_5242:support_scm",(void*)f_5242},
{"f_5257:support_scm",(void*)f_5257},
{"f_5226:support_scm",(void*)f_5226},
{"f_5083:support_scm",(void*)f_5083},
{"f_5124:support_scm",(void*)f_5124},
{"f_5148:support_scm",(void*)f_5148},
{"f_5172:support_scm",(void*)f_5172},
{"f_5175:support_scm",(void*)f_5175},
{"f_5151:support_scm",(void*)f_5151},
{"f_5127:support_scm",(void*)f_5127},
{"f_5086:support_scm",(void*)f_5086},
{"f_5114:support_scm",(void*)f_5114},
{"f_5089:support_scm",(void*)f_5089},
{"f_5101:support_scm",(void*)f_5101},
{"f_5092:support_scm",(void*)f_5092},
{"f_5033:support_scm",(void*)f_5033},
{"f_5039:support_scm",(void*)f_5039},
{"f_5046:support_scm",(void*)f_5046},
{"f_5049:support_scm",(void*)f_5049},
{"f_5059:support_scm",(void*)f_5059},
{"f_5052:support_scm",(void*)f_5052},
{"f_5009:support_scm",(void*)f_5009},
{"f_5015:support_scm",(void*)f_5015},
{"f_5025:support_scm",(void*)f_5025},
{"f_4973:support_scm",(void*)f_4973},
{"f_4980:support_scm",(void*)f_4980},
{"f_4983:support_scm",(void*)f_4983},
{"f_4963:support_scm",(void*)f_4963},
{"f_4954:support_scm",(void*)f_4954},
{"f_4958:support_scm",(void*)f_4958},
{"f_4897:support_scm",(void*)f_4897},
{"f_4901:support_scm",(void*)f_4901},
{"f_4931:support_scm",(void*)f_4931},
{"f_4845:support_scm",(void*)f_4845},
{"f_4849:support_scm",(void*)f_4849},
{"f_4876:support_scm",(void*)f_4876},
{"f_4799:support_scm",(void*)f_4799},
{"f_4803:support_scm",(void*)f_4803},
{"f_4825:support_scm",(void*)f_4825},
{"f_4781:support_scm",(void*)f_4781},
{"f_4785:support_scm",(void*)f_4785},
{"f_4793:support_scm",(void*)f_4793},
{"f_4763:support_scm",(void*)f_4763},
{"f_4767:support_scm",(void*)f_4767},
{"f_4528:support_scm",(void*)f_4528},
{"f_4678:support_scm",(void*)f_4678},
{"f_4693:support_scm",(void*)f_4693},
{"f_4718:support_scm",(void*)f_4718},
{"f_4736:support_scm",(void*)f_4736},
{"f_4721:support_scm",(void*)f_4721},
{"f_4536:support_scm",(void*)f_4536},
{"f_4593:support_scm",(void*)f_4593},
{"f_4608:support_scm",(void*)f_4608},
{"f_4633:support_scm",(void*)f_4633},
{"f_4651:support_scm",(void*)f_4651},
{"f_4636:support_scm",(void*)f_4636},
{"f_4539:support_scm",(void*)f_4539},
{"f_4544:support_scm",(void*)f_4544},
{"f_4559:support_scm",(void*)f_4559},
{"f_4584:support_scm",(void*)f_4584},
{"f_4532:support_scm",(void*)f_4532},
{"f_4387:support_scm",(void*)f_4387},
{"f_4391:support_scm",(void*)f_4391},
{"f_4395:support_scm",(void*)f_4395},
{"f_4384:support_scm",(void*)f_4384},
{"f_4381:support_scm",(void*)f_4381},
{"f_4274:support_scm",(void*)f_4274},
{"f_4283:support_scm",(void*)f_4283},
{"f_4314:support_scm",(void*)f_4314},
{"f_4368:support_scm",(void*)f_4368},
{"f_4374:support_scm",(void*)f_4374},
{"f_4320:support_scm",(void*)f_4320},
{"f_4352:support_scm",(void*)f_4352},
{"f_4366:support_scm",(void*)f_4366},
{"f_4358:support_scm",(void*)f_4358},
{"f_4324:support_scm",(void*)f_4324},
{"f_4346:support_scm",(void*)f_4346},
{"f_4289:support_scm",(void*)f_4289},
{"f_4295:support_scm",(void*)f_4295},
{"f_4306:support_scm",(void*)f_4306},
{"f_4303:support_scm",(void*)f_4303},
{"f_4281:support_scm",(void*)f_4281},
{"f_4173:support_scm",(void*)f_4173},
{"f_4179:support_scm",(void*)f_4179},
{"f_4256:support_scm",(void*)f_4256},
{"f_4207:support_scm",(void*)f_4207},
{"f_4245:support_scm",(void*)f_4245},
{"f_4233:support_scm",(void*)f_4233},
{"f_4113:support_scm",(void*)f_4113},
{"f_4129:support_scm",(void*)f_4129},
{"f_4171:support_scm",(void*)f_4171},
{"f_4135:support_scm",(void*)f_4135},
{"f_4150:support_scm",(void*)f_4150},
{"f_4067:support_scm",(void*)f_4067},
{"f_4111:support_scm",(void*)f_4111},
{"f_4071:support_scm",(void*)f_4071},
{"f_4037:support_scm",(void*)f_4037},
{"f_3991:support_scm",(void*)f_3991},
{"f_3971:support_scm",(void*)f_3971},
{"f_3977:support_scm",(void*)f_3977},
{"f_3985:support_scm",(void*)f_3985},
{"f_3989:support_scm",(void*)f_3989},
{"f_3940:support_scm",(void*)f_3940},
{"f_3946:support_scm",(void*)f_3946},
{"f_3961:support_scm",(void*)f_3961},
{"f_3877:support_scm",(void*)f_3877},
{"f_3891:support_scm",(void*)f_3891},
{"f_3893:support_scm",(void*)f_3893},
{"f_3922:support_scm",(void*)f_3922},
{"f_3865:support_scm",(void*)f_3865},
{"f_3818:support_scm",(void*)f_3818},
{"f_3834:support_scm",(void*)f_3834},
{"f_3846:support_scm",(void*)f_3846},
{"f_3811:support_scm",(void*)f_3811},
{"f_3804:support_scm",(void*)f_3804},
{"f_3748:support_scm",(void*)f_3748},
{"f_3802:support_scm",(void*)f_3802},
{"f_3752:support_scm",(void*)f_3752},
{"f_3775:support_scm",(void*)f_3775},
{"f_3654:support_scm",(void*)f_3654},
{"f_3670:support_scm",(void*)f_3670},
{"f_3672:support_scm",(void*)f_3672},
{"f_3694:support_scm",(void*)f_3694},
{"f_3733:support_scm",(void*)f_3733},
{"f_3701:support_scm",(void*)f_3701},
{"f_3717:support_scm",(void*)f_3717},
{"f_3705:support_scm",(void*)f_3705},
{"f_3709:support_scm",(void*)f_3709},
{"f_3666:support_scm",(void*)f_3666},
{"f_3610:support_scm",(void*)f_3610},
{"f_3616:support_scm",(void*)f_3616},
{"f_3640:support_scm",(void*)f_3640},
{"f_3579:support_scm",(void*)f_3579},
{"f_3602:support_scm",(void*)f_3602},
{"f_3605:support_scm",(void*)f_3605},
{"f_3608:support_scm",(void*)f_3608},
{"f_3552:support_scm",(void*)f_3552},
{"f_3571:support_scm",(void*)f_3571},
{"f_3574:support_scm",(void*)f_3574},
{"f_3516:support_scm",(void*)f_3516},
{"f_3522:support_scm",(void*)f_3522},
{"f_3448:support_scm",(void*)f_3448},
{"f_3472:support_scm",(void*)f_3472},
{"f_3451:support_scm",(void*)f_3451},
{"f_3459:support_scm",(void*)f_3459},
{"f_3463:support_scm",(void*)f_3463},
{"f_3405:support_scm",(void*)f_3405},
{"f_3411:support_scm",(void*)f_3411},
{"f_3434:support_scm",(void*)f_3434},
{"f_3438:support_scm",(void*)f_3438},
{"f_3402:support_scm",(void*)f_3402},
{"f_3341:support_scm",(void*)f_3341},
{"f_3345:support_scm",(void*)f_3345},
{"f_3348:support_scm",(void*)f_3348},
{"f_3351:support_scm",(void*)f_3351},
{"f_3362:support_scm",(void*)f_3362},
{"f_3375:support_scm",(void*)f_3375},
{"f_3354:support_scm",(void*)f_3354},
{"f_3357:support_scm",(void*)f_3357},
{"f_3322:support_scm",(void*)f_3322},
{"f_3326:support_scm",(void*)f_3326},
{"f_3339:support_scm",(void*)f_3339},
{"f_3329:support_scm",(void*)f_3329},
{"f_3332:support_scm",(void*)f_3332},
{"f_3293:support_scm",(void*)f_3293},
{"f_3300:support_scm",(void*)f_3300},
{"f_3303:support_scm",(void*)f_3303},
{"f_3313:support_scm",(void*)f_3313},
{"f_3306:support_scm",(void*)f_3306},
{"f_3234:support_scm",(void*)f_3234},
{"f_3244:support_scm",(void*)f_3244},
{"f_3259:support_scm",(void*)f_3259},
{"f_3264:support_scm",(void*)f_3264},
{"f_3291:support_scm",(void*)f_3291},
{"f_3277:support_scm",(void*)f_3277},
{"f_3280:support_scm",(void*)f_3280},
{"f_3247:support_scm",(void*)f_3247},
{"f_3250:support_scm",(void*)f_3250},
{"f_3253:support_scm",(void*)f_3253},
{"f_3207:support_scm",(void*)f_3207},
{"f_3221:support_scm",(void*)f_3221},
{"f_3202:support_scm",(void*)f_3202},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
