/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-28 22:55
   Version 4.1.4 - SVN rev. 15427
   linux-unix-gnu-x86 [ ptables applyhook ]
   compiled 2009-08-13 on x (Linux)
   command line: chicken.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature debugbuild -scrutinize -types ./types.db -no-lambda-info -local -extend private-namespace.scm -output-file chicken.c
   used units: library eval data_structures ports extras srfi_69 chicken_syntax srfi_1 srfi_4 utils files support compiler optimizer compiler_syntax scrutinizer driver platform backend srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_syntax_toplevel)
C_externimport void C_ccall C_compiler_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scrutinizer_toplevel)
C_externimport void C_ccall C_scrutinizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[95];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_270)
static void C_ccall f_270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_273)
static void C_ccall f_273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_276)
static void C_ccall f_276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_279)
static void C_ccall f_279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_282)
static void C_ccall f_282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_285)
static void C_ccall f_285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_288)
static void C_ccall f_288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_291)
static void C_ccall f_291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_294)
static void C_ccall f_294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_297)
static void C_ccall f_297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_300)
static void C_ccall f_300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_303)
static void C_ccall f_303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_306)
static void C_ccall f_306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_309)
static void C_ccall f_309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_312)
static void C_ccall f_312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_315)
static void C_ccall f_315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_318)
static void C_ccall f_318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_321)
static void C_ccall f_321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_324)
static void C_ccall f_324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_327)
static void C_ccall f_327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_331)
static void C_ccall f_331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1211)
static void C_ccall f_1211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_fcall f_1221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_fcall f_1224(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1414)
static void C_ccall f_1414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1240)
static void C_ccall f_1240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_334)
static void C_ccall f_334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1096)
static void C_ccall f_1096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1116)
static void C_ccall f_1116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_337)
static void C_ccall f_337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_924)
static void C_ccall f_924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_933)
static void C_ccall f_933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1056)
static void C_ccall f_1056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_936)
static void C_ccall f_936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_947)
static void C_ccall f_947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_834)
static void C_ccall f_834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_838)
static void C_ccall f_838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_841)
static void C_ccall f_841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_872)
static void C_ccall f_872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_888)
static void C_ccall f_888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_891)
static void C_ccall f_891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_910)
static void C_ccall f_910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_900)
static void C_ccall f_900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_906)
static void C_ccall f_906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_343)
static void C_ccall f_343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_760)
static void C_ccall f_760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_793)
static void C_ccall f_793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_809)
static void C_fcall f_809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_758)
static void C_ccall f_758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_346)
static void C_ccall f_346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_735)
static void C_ccall f_735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_729)
static void C_ccall f_729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_349)
static void C_ccall f_349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_352)
static void C_ccall f_352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_718)
static void C_ccall f_718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_710)
static void C_ccall f_710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_700)
static void C_ccall f_700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_708)
static void C_ccall f_708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_485)
static void C_ccall f_485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_497)
static void C_fcall f_497(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_683)
static void C_ccall f_683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_646)
static void C_ccall f_646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_609)
static void C_ccall f_609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_595)
static void C_ccall f_595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_519)
static void C_ccall f_519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_572)
static void C_ccall f_572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_562)
static void C_ccall f_562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_552)
static void C_ccall f_552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_522)
static void C_ccall f_522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_489)
static void C_ccall f_489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_492)
static void C_ccall f_492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_473)
static void C_ccall f_473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_480)
static void C_ccall f_480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_471)
static void C_ccall f_471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_468)
static void C_ccall f_468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_358)
static void C_ccall f_358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_364)
static void C_fcall f_364(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_399)
static void C_fcall f_399(C_word t0,C_word t1) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_421)
static void C_ccall f_421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_378)
static void C_ccall f_378(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1221)
static void C_fcall trf_1221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1221(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1221(t0,t1);}

C_noret_decl(trf_1224)
static void C_fcall trf_1224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1224(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1224(t0,t1);}

C_noret_decl(trf_809)
static void C_fcall trf_809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_809(t0,t1);}

C_noret_decl(trf_497)
static void C_fcall trf_497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_497(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_497(t0,t1,t2);}

C_noret_decl(trf_364)
static void C_fcall trf_364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_364(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_364(t0,t1,t2,t3,t4);}

C_noret_decl(trf_399)
static void C_fcall trf_399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_399(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_399(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1128)){
C_save(t1);
C_rereclaim2(1128*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,95);
lf[0]=C_h_intern(&lf[0],33,"\003syschicken-ffi-macro-environment");
lf[1]=C_h_intern(&lf[1],27,"\010compilercompiler-arguments");
lf[2]=C_h_intern(&lf[2],29,"\010compilerprocess-command-line");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],14,"string->symbol");
lf[5]=C_h_intern(&lf[5],9,"substring");
lf[6]=C_h_intern(&lf[6],25,"\003sysimplicit-exit-handler");
lf[7]=C_h_intern(&lf[7],17,"user-options-pass");
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],19,"compile-source-file");
lf[10]=C_h_intern(&lf[10],14,"optimize-level");
lf[11]=C_h_intern(&lf[11],22,"optimize-leaf-routines");
lf[12]=C_h_intern(&lf[12],5,"cons*");
lf[13]=C_h_intern(&lf[13],6,"inline");
lf[14]=C_h_intern(&lf[14],5,"local");
lf[15]=C_h_intern(&lf[15],6,"unsafe");
lf[16]=C_h_intern(&lf[16],25,"\010compilercompiler-warning");
lf[17]=C_h_intern(&lf[17],5,"usage");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\047invalid optimization level ~S - ignored");
lf[19]=C_h_intern(&lf[19],11,"debug-level");
lf[20]=C_h_intern(&lf[20],14,"no-lambda-info");
lf[21]=C_h_intern(&lf[21],8,"no-trace");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000 invalid debug level ~S - ignored");
lf[23]=C_h_intern(&lf[23],14,"benchmark-mode");
lf[24]=C_h_intern(&lf[24],17,"fixnum-arithmetic");
lf[25]=C_h_intern(&lf[25],18,"disable-interrupts");
lf[26]=C_h_intern(&lf[26],5,"block");
lf[27]=C_h_intern(&lf[27],11,"lambda-lift");
lf[28]=C_h_intern(&lf[28],31,"\010compilervalid-compiler-options");
lf[29]=C_h_intern(&lf[29],45,"\010compilervalid-compiler-options-with-argument");
lf[30]=C_h_intern(&lf[30],4,"quit");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000&invalid compiler option `~a\047 - ignored");
lf[33]=C_h_intern(&lf[33],4,"conc");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[35]=C_h_intern(&lf[35],6,"append");
lf[36]=C_h_intern(&lf[36],4,"argv");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_h_intern(&lf[38],6,"remove");
lf[39]=C_h_intern(&lf[39],12,"string-split");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[41]=C_h_intern(&lf[41],24,"get-environment-variable");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
lf[43]=C_h_intern(&lf[43],16,"\003sysmacro-subset");
lf[44]=C_h_intern(&lf[44],28,"\003sysextend-macro-environment");
lf[45]=C_h_intern(&lf[45],15,"foreign-declare");
lf[46]=C_h_intern(&lf[46],12,"\004coredeclare");
lf[47]=C_h_intern(&lf[47],10,"\003sysappend");
lf[48]=C_h_intern(&lf[48],16,"\003syscheck-syntax");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[50]=C_h_intern(&lf[50],18,"\003syser-transformer");
lf[51]=C_h_intern(&lf[51],13,"foreign-value");
lf[52]=C_h_intern(&lf[52],14,"symbol->string");
lf[53]=C_h_intern(&lf[53],12,"syntax-error");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a string or symbol");
lf[55]=C_h_intern(&lf[55],23,"define-foreign-variable");
lf[56]=C_h_intern(&lf[56],5,"begin");
lf[57]=C_h_intern(&lf[57],6,"gensym");
lf[58]=C_h_intern(&lf[58],5,"code_");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[60]=C_h_intern(&lf[60],12,"foreign-code");
lf[61]=C_h_intern(&lf[61],11,"\004coreinline");
lf[62]=C_h_intern(&lf[62],17,"get-output-string");
lf[63]=C_h_intern(&lf[63],7,"display");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000 \012; return C_SCHEME_UNDEFINED; }\012");
lf[65]=C_h_intern(&lf[65],18,"string-intersperse");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\005() { ");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\016static C_word ");
lf[69]=C_h_intern(&lf[69],18,"open-output-string");
lf[70]=C_h_intern(&lf[70],7,"declare");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[72]=C_h_intern(&lf[72],12,"let-location");
lf[73]=C_h_intern(&lf[73],17,"\004corelet-location");
lf[74]=C_h_intern(&lf[74],10,"fold-right");
lf[75]=C_h_intern(&lf[75],10,"append-map");
lf[76]=C_h_intern(&lf[76],7,"\003sysmap");
lf[77]=C_h_intern(&lf[77],3,"let");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\000\376\001\000\000\001_");
lf[79]=C_h_intern(&lf[79],15,"define-location");
lf[80]=C_h_intern(&lf[80],9,"\004coreset!");
lf[81]=C_h_intern(&lf[81],24,"define-external-variable");
lf[82]=C_h_intern(&lf[82],9,"\003syserror");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[85]=C_h_intern(&lf[85],15,"define-external");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[87]=C_h_intern(&lf[87],5,"quote");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[89]=C_h_intern(&lf[89],29,"\004coreforeign-callback-wrapper");
lf[90]=C_h_intern(&lf[90],6,"lambda");
lf[91]=C_h_intern(&lf[91],6,"define");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[94]=C_h_intern(&lf[94],21,"\003sysmacro-environment");
C_register_lf2(lf,95,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_270,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k268 */
static void C_ccall f_270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_273,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k271 in k268 */
static void C_ccall f_273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_276,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k274 in k271 in k268 */
static void C_ccall f_276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_279,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k277 in k274 in k271 in k268 */
static void C_ccall f_279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_282,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_285,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scrutinizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#macro-environment");
((C_proc2)C_retrieve_symbol_proc(lf[94]))(2,*((C_word*)lf[94]+1),t2);}

/* k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_334,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1209,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1211,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1211,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1218,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("r37");
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[87]);}

/* k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_1221(t4,(C_word)C_i_stringp(t3));}
else{
t3=t2;
f_1221(t3,C_SCHEME_FALSE);}}

/* k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_fcall f_1221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1221,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1224,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_1224(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_1224(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t2;
f_1224(t4,C_SCHEME_FALSE);}}}

/* k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_fcall f_1224(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1224,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[85],((C_word*)t0)[5],lf[86]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("##sys#check-syntax");
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[85],((C_word*)t0)[5],lf[92]);}
else{
C_trace("##sys#check-syntax");
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t2,lf[85],((C_word*)t0)[5],lf[93]);}}}

/* k1327 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1329,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_i_cadr(((C_word*)t0)[4]):(C_word)C_i_car(((C_word*)t0)[4]));
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1342,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("r37");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[91]);}

/* k1340 in k1327 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1342,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[87],t4);
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_car(((C_word*)t0)[5]):lf[88]);
t7=(C_truep(((C_word*)t0)[6])?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[87],t8);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t5,a[10]=t6,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1440,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t12=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[3]);}

/* a1439 in k1340 in k1327 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1440,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k1436 in k1340 in k1327 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1438,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[87],t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1402,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
C_trace("r37");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[90]);}

/* k1400 in k1436 in k1340 in k1327 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1426,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t4=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1425 in k1400 in k1436 in k1340 in k1327 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1426,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k1408 in k1400 in k1436 in k1340 in k1327 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1414,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_i_cdddr(((C_word*)t0)[2]):(C_word)C_i_cddr(((C_word*)t0)[2]));
C_trace("##sys#append");
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k1412 in k1408 in k1400 in k1436 in k1340 in k1327 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1414,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[89],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t10);
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t11));}

/* k1228 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("r37");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[56]);}

/* k1238 in k1228 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("r37");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[55]);}

/* k1312 in k1238 in k1228 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1314,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,t1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("r37");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[81]);}

/* k1292 in k1312 in k1238 in k1228 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_caddr(((C_word*)t0)[6]);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t10);
t12=(C_word)C_a_i_cons(&a,2,lf[80],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t14=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t7,t13,C_SCHEME_END_OF_LIST);}
else{
C_trace("##sys#append");
t9=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k1258 in k1292 in k1312 in k1238 in k1228 in k1222 in k1219 in k1216 in a1210 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1260,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1207 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[85],C_SCHEME_END_OF_LIST,t1);}

/* k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1068,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1070,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a1069 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1070,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1074,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[79],t2,lf[84]);}

/* k1072 in a1069 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1086(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1086(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[83],t4);}}}

/* k1084 in k1072 in a1069 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1089,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1186,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
((C_proc2)C_retrieve_symbol_proc(lf[57]))(2,*((C_word*)lf[57]+1),t3);}

/* k1184 in k1084 in k1072 in a1069 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r77");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1087 in k1084 in k1072 in a1069 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("r77");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k1094 in k1087 in k1084 in k1072 in a1069 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("r77");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[55]);}

/* k1164 in k1094 in k1087 in k1084 in k1072 in a1069 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[52]+1)))(3,*((C_word*)lf[52]+1),t2,((C_word*)t0)[6]);}

/* k1180 in k1164 in k1094 in k1087 in k1084 in k1072 in a1069 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1182,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
C_trace("r77");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[81]);}

/* k1144 in k1180 in k1164 in k1094 in k1087 in k1084 in k1072 in a1069 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1146,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1116,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t8=(C_word)C_i_car(((C_word*)t0)[2]);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[80],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t13=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t7,t12,C_SCHEME_END_OF_LIST);}
else{
C_trace("##sys#append");
t8=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k1114 in k1144 in k1180 in k1164 in k1094 in k1087 in k1084 in k1072 in a1069 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1116,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k1066 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[79],C_SCHEME_END_OF_LIST,t1);}

/* k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_918,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_920,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a919 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_920,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_924,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[72],t2,lf[78]);}

/* k922 in a919 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_924,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_933,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("r98");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[77]);}

/* k931 in k922 in a919 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1056,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t4=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a1055 in k931 in k922 in a919 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1056,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1064,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("gensym");
((C_proc2)C_retrieve_symbol_proc(lf[57]))(2,*((C_word*)lf[57]+1),t3);}

/* k1062 in a1055 in k931 in k922 in a919 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("r98");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k934 in k931 in k922 in a919 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_947,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1032,tmp=(C_word)a,a+=2,tmp);
C_trace("append-map");
((C_proc5)C_retrieve_symbol_proc(lf[75]))(5,*((C_word*)lf[75]+1),t2,t3,((C_word*)t0)[3],t1);}

/* a1031 in k934 in k931 in k922 in a919 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1032,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k945 in k934 in k931 in k922 in a919 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_955,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_957,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#append");
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1028 in k945 in k934 in k931 in k922 in a919 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1030,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
C_trace("fold-right");
((C_proc6)C_retrieve_symbol_proc(lf[74]))(6,*((C_word*)lf[74]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a956 in k945 in k934 in k931 in k922 in a919 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_957,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t3,t9);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[73],t12));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=(C_word)C_a_i_cons(&a,2,t7,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[73],t11));}}

/* k953 in k945 in k934 in k931 in k922 in a919 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_955,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k916 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[72],C_SCHEME_END_OF_LIST,t1);}

/* k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_832,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_834,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_834,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_838,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[60],t2,lf[71]);}

/* k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("gensym");
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t2,lf[58]);}

/* k839 in k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("r129");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k846 in k839 in k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_872,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("r129");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[70]);}

/* k870 in k846 in k839 in k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t2);}

/* k886 in k870 in k846 in k839 in k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_891,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[68],t1);}

/* k889 in k886 in k870 in k846 in k839 in k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[6],((C_word*)t0)[3]);}

/* k892 in k889 in k886 in k870 in k846 in k839 in k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[67],((C_word*)t0)[3]);}

/* k895 in k892 in k889 in k886 in k870 in k846 in k839 in k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_910,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t3,t4,lf[66]);}

/* k908 in k895 in k892 in k889 in k886 in k870 in k846 in k839 in k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k898 in k895 in k892 in k889 in k886 in k870 in k846 in k839 in k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[64],((C_word*)t0)[2]);}

/* k901 in k898 in k895 in k892 in k889 in k886 in k870 in k846 in k839 in k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_906,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t2,((C_word*)t0)[2]);}

/* k904 in k901 in k898 in k895 in k892 in k889 in k886 in k870 in k846 in k839 in k836 in a833 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_906,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[45],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[61],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* k830 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[60],C_SCHEME_END_OF_LIST,t1);}

/* k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_758,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_760,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a759 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_760,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_764,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#check-syntax");
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[51],t2,lf[59]);}

/* k762 in a759 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("gensym");
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t2,lf[58]);}

/* k765 in k762 in a759 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_767,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_777,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("r148");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[56]);}

/* k775 in k765 in k762 in a759 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_793,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("r148");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[55]);}

/* k791 in k775 in k765 in k762 in a759 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_793,2,t0,t1);}
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_813,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
t5=t3;
f_809(t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
C_trace("symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[52]+1)))(3,*((C_word*)lf[52]+1),t4,((C_word*)t0)[2]);}
else{
C_trace("syntax-error");
((C_proc5)C_retrieve_symbol_proc(lf[53]))(5,*((C_word*)lf[53]+1),t4,lf[51],lf[54],((C_word*)t0)[2]);}}}

/* k811 in k791 in k775 in k765 in k762 in a759 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_813,2,t0,t1);}
t2=((C_word*)t0)[2];
f_809(t2,(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k807 in k791 in k775 in k765 in k762 in a759 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_fcall f_809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_809,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k756 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[51],C_SCHEME_END_OF_LIST,t1);}

/* k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_729,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_731,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#er-transformer");
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t3,t4);}

/* a730 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_731,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_735,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#check-syntax");
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t5,lf[45],t2,lf[49]);}

/* k733 in a730 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_750,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("##sys#append");
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k748 in k733 in a730 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_750,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[45],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[46],t3));}

/* k727 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[45],C_SCHEME_END_OF_LIST,t1);}

/* k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_352,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#macro-subset");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}

/* k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_352,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! chicken-ffi-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_356,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_700,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_710,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_718,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_722,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken.scm: 48   get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t7,lf[42]);}

/* k720 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
C_trace("chicken.scm: 48   string-split");
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t2);}
else{
C_trace("chicken.scm: 48   string-split");
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],lf[40]);}}

/* k716 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 46   remove");
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a709 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_710,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,lf[37]));}

/* k698 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_708,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("chicken.scm: 49   argv");
((C_proc2)C_retrieve_symbol_proc(lf[36]))(2,*((C_word*)lf[36]+1),t2);}

/* k706 in k698 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(t1);
C_trace("chicken.scm: 45   append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_356,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! compiler-arguments ...) */,t1);
t3=C_mutate((C_word*)lf[2]+1 /* (set! process-command-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_358,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_465,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_473,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_485,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t4,t5,t6);}

/* a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_485,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_489,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_497,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_497(t9,t5,((C_word*)t4)[1]);}

/* loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_fcall f_497(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_497,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(lf[10],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_519,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
C_trace("chicken.scm: 82   string->number");
C_string_to_number(3,0,t6,t7);}
else{
t6=(C_word)C_eqp(lf[19],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_592,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_car(t4);
C_trace("chicken.scm: 99   string->number");
C_string_to_number(3,0,t7,t8);}
else{
t7=(C_word)C_eqp(lf[23],t3);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_646,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("chicken.scm: 108  cons*");
((C_proc12)C_retrieve_symbol_proc(lf[12]))(12,*((C_word*)lf[12]+1),t8,lf[24],lf[25],lf[21],lf[15],lf[11],lf[26],lf[27],lf[20],lf[13],((C_word*)((C_word*)t0)[2])[1]);}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[28])))){
C_trace("chicken.scm: 113  loop");
t18=t1;
t19=t4;
t1=t18;
t2=t19;
goto loop;}
else{
if(C_truep((C_word)C_i_memq(t3,C_retrieve(lf[29])))){
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_i_cdr(t4);
C_trace("chicken.scm: 116  loop");
t18=t1;
t19=t8;
t1=t18;
t2=t19;
goto loop;}
else{
C_trace("chicken.scm: 117  quit");
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t1,lf[31],t3);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_683,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_690,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
C_trace("chicken.scm: 119  compiler-warning");
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),t8,lf[17],lf[32],t3);}
else{
C_trace("chicken.scm: 121  conc");
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t9,lf[34],t3);}}}}}}}}

/* k688 in loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 119  compiler-warning");
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),((C_word*)t0)[2],lf[17],lf[32],t1);}

/* k681 in loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 122  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_497(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k644 in loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
C_trace("chicken.scm: 112  loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_497(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k590 in loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_595,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("chicken.scm: 101  cons*");
((C_proc5)C_retrieve_symbol_proc(lf[12]))(5,*((C_word*)lf[12]+1),t3,lf[20],lf[21],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[21],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("chicken.scm: 105  loop");
t6=((C_word*)((C_word*)t0)[4])[1];
f_497(t6,((C_word*)t0)[3],t5);
case C_fix(2):
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("chicken.scm: 105  loop");
t4=((C_word*)((C_word*)t0)[4])[1];
f_497(t4,((C_word*)t0)[3],t3);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("chicken.scm: 104  compiler-warning");
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),t2,lf[17],lf[22],t3);}}

/* k607 in k590 in loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("chicken.scm: 105  loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_497(t4,((C_word*)t0)[2],t3);}

/* k593 in k590 in loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("chicken.scm: 105  loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_497(t3,((C_word*)t0)[2],t2);}

/* k517 in loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_522,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
switch(t1){
case C_fix(0):
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("chicken.scm: 97   loop");
t4=((C_word*)((C_word*)t0)[4])[1];
f_497(t4,((C_word*)t0)[3],t3);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,lf[11],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("chicken.scm: 97   loop");
t6=((C_word*)((C_word*)t0)[4])[1];
f_497(t6,((C_word*)t0)[3],t5);
case C_fix(2):
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("chicken.scm: 89   cons*");
((C_proc5)C_retrieve_symbol_proc(lf[12]))(5,*((C_word*)lf[12]+1),t3,lf[11],lf[13],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(3):
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("chicken.scm: 92   cons*");
((C_proc6)C_retrieve_symbol_proc(lf[12]))(6,*((C_word*)lf[12]+1),t3,lf[11],lf[13],lf[14],((C_word*)((C_word*)t0)[2])[1]);
case C_fix(4):
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_572,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("chicken.scm: 95   cons*");
((C_proc7)C_retrieve_symbol_proc(lf[12]))(7,*((C_word*)lf[12]+1),t3,lf[11],lf[13],lf[14],lf[15],((C_word*)((C_word*)t0)[2])[1]);
default:
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("chicken.scm: 96   compiler-warning");
((C_proc5)C_retrieve_symbol_proc(lf[16]))(5,*((C_word*)lf[16]+1),t2,lf[17],lf[18],t3);}}

/* k570 in k517 in loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("chicken.scm: 97   loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_497(t4,((C_word*)t0)[2],t3);}

/* k560 in k517 in loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("chicken.scm: 97   loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_497(t4,((C_word*)t0)[2],t3);}

/* k550 in k517 in loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("chicken.scm: 97   loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_497(t4,((C_word*)t0)[2],t3);}

/* k520 in k517 in loop in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("chicken.scm: 97   loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_497(t3,((C_word*)t0)[2],t2);}

/* k487 in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_492,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,C_retrieve(lf[9]),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k490 in k487 in a484 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 124  exit");
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* a472 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_480,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken.scm: 76   user-options-pass");
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k478 in a472 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[1]));}
else{
t2=C_retrieve(lf[2]);
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_retrieve(lf[1]));}}

/* k463 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_471,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#implicit-exit-handler");
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t3);}

/* k469 in k463 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k466 in k463 in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_358,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_364,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_364(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_fcall f_364(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_364,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_378,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken.scm: 61   reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_string_length(t5);
t7=(C_word)C_i_string_ref(t5,C_fix(0));
t8=(C_word)C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?(C_word)C_fixnum_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_399,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t6,C_fix(1)))){
t11=(C_word)C_i_string_ref(t5,C_fix(1));
t12=t10;
f_399(t12,(C_word)C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_399(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=(C_word)C_i_cdr(t2);
t11=(C_word)C_a_i_cons(&a,2,t5,t3);
C_trace("chicken.scm: 70   loop");
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=(C_word)C_i_cdr(t2);
C_trace("chicken.scm: 71   loop");
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k397 in loop in ##compiler#process-command-line in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_fcall f_399(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_399,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
C_trace("chicken.scm: 67   loop");
t3=((C_word*)((C_word*)t0)[7])[1];
f_364(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_421,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_425,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken.scm: 68   substring");
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k423 in k397 in loop in ##compiler#process-command-line in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 68   string->symbol");
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),((C_word*)t0)[2],t1);}

/* k419 in k397 in loop in ##compiler#process-command-line in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_421,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
C_trace("chicken.scm: 68   loop");
t3=((C_word*)((C_word*)t0)[5])[1];
f_364(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k376 in loop in ##compiler#process-command-line in k354 in k350 in k347 in k344 in k341 in k338 in k335 in k332 in k329 in k325 in k322 in k319 in k316 in k313 in k310 in k307 in k304 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 in k277 in k274 in k271 in k268 */
static void C_ccall f_378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken.scm: 61   values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[129] = {
{"toplevel:chicken_scm",(void*)C_toplevel},
{"f_270:chicken_scm",(void*)f_270},
{"f_273:chicken_scm",(void*)f_273},
{"f_276:chicken_scm",(void*)f_276},
{"f_279:chicken_scm",(void*)f_279},
{"f_282:chicken_scm",(void*)f_282},
{"f_285:chicken_scm",(void*)f_285},
{"f_288:chicken_scm",(void*)f_288},
{"f_291:chicken_scm",(void*)f_291},
{"f_294:chicken_scm",(void*)f_294},
{"f_297:chicken_scm",(void*)f_297},
{"f_300:chicken_scm",(void*)f_300},
{"f_303:chicken_scm",(void*)f_303},
{"f_306:chicken_scm",(void*)f_306},
{"f_309:chicken_scm",(void*)f_309},
{"f_312:chicken_scm",(void*)f_312},
{"f_315:chicken_scm",(void*)f_315},
{"f_318:chicken_scm",(void*)f_318},
{"f_321:chicken_scm",(void*)f_321},
{"f_324:chicken_scm",(void*)f_324},
{"f_327:chicken_scm",(void*)f_327},
{"f_331:chicken_scm",(void*)f_331},
{"f_1211:chicken_scm",(void*)f_1211},
{"f_1218:chicken_scm",(void*)f_1218},
{"f_1221:chicken_scm",(void*)f_1221},
{"f_1224:chicken_scm",(void*)f_1224},
{"f_1329:chicken_scm",(void*)f_1329},
{"f_1342:chicken_scm",(void*)f_1342},
{"f_1440:chicken_scm",(void*)f_1440},
{"f_1438:chicken_scm",(void*)f_1438},
{"f_1402:chicken_scm",(void*)f_1402},
{"f_1426:chicken_scm",(void*)f_1426},
{"f_1410:chicken_scm",(void*)f_1410},
{"f_1414:chicken_scm",(void*)f_1414},
{"f_1230:chicken_scm",(void*)f_1230},
{"f_1240:chicken_scm",(void*)f_1240},
{"f_1314:chicken_scm",(void*)f_1314},
{"f_1294:chicken_scm",(void*)f_1294},
{"f_1260:chicken_scm",(void*)f_1260},
{"f_1209:chicken_scm",(void*)f_1209},
{"f_334:chicken_scm",(void*)f_334},
{"f_1070:chicken_scm",(void*)f_1070},
{"f_1074:chicken_scm",(void*)f_1074},
{"f_1086:chicken_scm",(void*)f_1086},
{"f_1186:chicken_scm",(void*)f_1186},
{"f_1089:chicken_scm",(void*)f_1089},
{"f_1096:chicken_scm",(void*)f_1096},
{"f_1166:chicken_scm",(void*)f_1166},
{"f_1182:chicken_scm",(void*)f_1182},
{"f_1146:chicken_scm",(void*)f_1146},
{"f_1116:chicken_scm",(void*)f_1116},
{"f_1068:chicken_scm",(void*)f_1068},
{"f_337:chicken_scm",(void*)f_337},
{"f_920:chicken_scm",(void*)f_920},
{"f_924:chicken_scm",(void*)f_924},
{"f_933:chicken_scm",(void*)f_933},
{"f_1056:chicken_scm",(void*)f_1056},
{"f_1064:chicken_scm",(void*)f_1064},
{"f_936:chicken_scm",(void*)f_936},
{"f_1032:chicken_scm",(void*)f_1032},
{"f_947:chicken_scm",(void*)f_947},
{"f_1030:chicken_scm",(void*)f_1030},
{"f_957:chicken_scm",(void*)f_957},
{"f_955:chicken_scm",(void*)f_955},
{"f_918:chicken_scm",(void*)f_918},
{"f_340:chicken_scm",(void*)f_340},
{"f_834:chicken_scm",(void*)f_834},
{"f_838:chicken_scm",(void*)f_838},
{"f_841:chicken_scm",(void*)f_841},
{"f_848:chicken_scm",(void*)f_848},
{"f_872:chicken_scm",(void*)f_872},
{"f_888:chicken_scm",(void*)f_888},
{"f_891:chicken_scm",(void*)f_891},
{"f_894:chicken_scm",(void*)f_894},
{"f_897:chicken_scm",(void*)f_897},
{"f_910:chicken_scm",(void*)f_910},
{"f_900:chicken_scm",(void*)f_900},
{"f_903:chicken_scm",(void*)f_903},
{"f_906:chicken_scm",(void*)f_906},
{"f_832:chicken_scm",(void*)f_832},
{"f_343:chicken_scm",(void*)f_343},
{"f_760:chicken_scm",(void*)f_760},
{"f_764:chicken_scm",(void*)f_764},
{"f_767:chicken_scm",(void*)f_767},
{"f_777:chicken_scm",(void*)f_777},
{"f_793:chicken_scm",(void*)f_793},
{"f_813:chicken_scm",(void*)f_813},
{"f_809:chicken_scm",(void*)f_809},
{"f_758:chicken_scm",(void*)f_758},
{"f_346:chicken_scm",(void*)f_346},
{"f_731:chicken_scm",(void*)f_731},
{"f_735:chicken_scm",(void*)f_735},
{"f_750:chicken_scm",(void*)f_750},
{"f_729:chicken_scm",(void*)f_729},
{"f_349:chicken_scm",(void*)f_349},
{"f_352:chicken_scm",(void*)f_352},
{"f_722:chicken_scm",(void*)f_722},
{"f_718:chicken_scm",(void*)f_718},
{"f_710:chicken_scm",(void*)f_710},
{"f_700:chicken_scm",(void*)f_700},
{"f_708:chicken_scm",(void*)f_708},
{"f_356:chicken_scm",(void*)f_356},
{"f_485:chicken_scm",(void*)f_485},
{"f_497:chicken_scm",(void*)f_497},
{"f_690:chicken_scm",(void*)f_690},
{"f_683:chicken_scm",(void*)f_683},
{"f_646:chicken_scm",(void*)f_646},
{"f_592:chicken_scm",(void*)f_592},
{"f_609:chicken_scm",(void*)f_609},
{"f_595:chicken_scm",(void*)f_595},
{"f_519:chicken_scm",(void*)f_519},
{"f_572:chicken_scm",(void*)f_572},
{"f_562:chicken_scm",(void*)f_562},
{"f_552:chicken_scm",(void*)f_552},
{"f_522:chicken_scm",(void*)f_522},
{"f_489:chicken_scm",(void*)f_489},
{"f_492:chicken_scm",(void*)f_492},
{"f_473:chicken_scm",(void*)f_473},
{"f_480:chicken_scm",(void*)f_480},
{"f_465:chicken_scm",(void*)f_465},
{"f_471:chicken_scm",(void*)f_471},
{"f_468:chicken_scm",(void*)f_468},
{"f_358:chicken_scm",(void*)f_358},
{"f_364:chicken_scm",(void*)f_364},
{"f_399:chicken_scm",(void*)f_399},
{"f_425:chicken_scm",(void*)f_425},
{"f_421:chicken_scm",(void*)f_421},
{"f_378:chicken_scm",(void*)f_378},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
