/* Generated from scheduler.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-28 22:53
   Version 4.1.4 - SVN rev. 15427
   linux-unix-gnu-x86 [ ptables applyhook ]
   compiled 2009-08-13 on x (Linux)
   command line: scheduler.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature debugbuild -scrutinize -types ./types.db -explicit-use -no-trace -output-file scheduler.c
   unit: scheduler
*/

#include "chicken.h"

#ifdef HAVE_ERRNO_H
# include <errno.h>
# define C_signal_interrupted_p     C_mk_bool(errno == EINTR)
#else
# define C_signal_interrupted_p     C_SCHEME_FALSE
#endif

#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define C_msleep(n)     (Sleep(C_unfix(n)), C_SCHEME_TRUE)
#else
# include <unistd.h>
# include <sys/types.h>
# include <sys/time.h>
# include <time.h>
static C_word C_msleep(C_word ms);
C_word C_msleep(C_word ms) {
#ifdef __CYGWIN__
  if(usleep(C_unfix(ms) * 1000) == -1) return C_SCHEME_FALSE;
#else
  struct timespec ts;
  unsigned long mss = C_unfix(ms);
  ts.tv_sec = mss / 1000;
  ts.tv_nsec = (mss % 1000) * 1000000;
  
  if(nanosleep(&ts, NULL) == -1) return C_SCHEME_FALSE;
#endif
  return C_SCHEME_TRUE;
}
#endif
static fd_set C_fdset_input, C_fdset_output, C_fdset_input_2, C_fdset_output_2;
#define C_fd_test_input(fd)  C_mk_bool(FD_ISSET(C_unfix(fd), &C_fdset_input))
#define C_fd_test_output(fd)  C_mk_bool(FD_ISSET(C_unfix(fd), &C_fdset_output))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[72];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,7),40,108,111,111,112,50,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,50,32,116,104,114,101,97,100,115,51,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,110,51,49,50,32,108,115,116,51,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,51,53,49,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,53,56,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,7),40,108,111,111,112,49,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,16),40,35,35,115,121,115,35,115,99,104,101,100,117,108,101,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,114,101,97,100,121,45,113,117,101,117,101,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,97,100,100,45,116,111,45,114,101,97,100,121,45,113,117,101,117,101,32,116,104,114,101,97,100,49,48,50,41,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,6),40,97,56,55,52,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,49,51,56,32,115,116,97,116,101,49,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,112,114,101,118,49,52,57,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,114,101,109,111,118,101,45,102,114,111,109,45,116,105,109,101,111,117,116,45,108,105,115,116,32,116,49,52,54,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,116,108,49,53,55,32,112,114,101,118,49,53,56,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,116,105,109,101,111,117,116,33,32,116,49,53,52,32,116,109,49,53,53,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,116,101,114,109,105,110,97,116,105,111,110,33,32,116,49,54,57,32,116,50,49,55,48,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,49,57,48,32,108,115,116,49,57,49,49,57,52,41,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,116,104,114,101,97,100,45,107,105,108,108,33,32,116,49,56,51,32,115,49,56,52,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,97,115,105,99,45,117,110,98,108,111,99,107,33,32,116,50,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,49,49,50,55,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,100,101,102,97,117,108,116,45,101,120,99,101,112,116,105,111,110,45,104,97,110,100,108,101,114,32,97,114,103,50,49,54,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,50,54,55,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,47),40,35,35,115,121,115,35,116,104,114,101,97,100,45,98,108,111,99,107,45,102,111,114,45,105,47,111,33,32,116,50,54,51,32,102,100,50,54,52,32,105,47,111,50,54,53,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,108,51,57,56,41,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,52,48,49,32,105,52,48,50,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,51,57,52,32,105,51,57,53,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,51,57,49,32,105,51,57,50,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,24),40,98,111,100,121,51,55,57,32,99,110,115,51,56,56,32,105,110,105,116,51,56,57,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,24),40,100,101,102,45,105,110,105,116,51,56,50,32,37,99,110,115,51,55,55,52,48,55,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,38),40,97,49,54,54,53,32,113,117,101,117,101,52,48,57,32,97,114,103,52,49,48,32,118,97,108,52,49,49,32,105,110,105,116,52,49,50,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,99,110,115,51,56,49,41,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,97,108,108,45,116,104,114,101,97,100,115,32,46,32,116,109,112,51,55,50,51,55,51,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,101,116,99,104,45,97,110,100,45,99,108,101,97,114,45,116,104,114,101,97,100,115,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,114,101,115,116,111,114,101,45,116,104,114,101,97,100,115,32,118,101,99,52,50,53,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,100,108,52,51,52,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,116,104,114,101,97,100,45,117,110,98,108,111,99,107,33,32,116,52,51,48,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,49,56,54,53,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,49,56,53,54,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,14),40,97,49,56,56,57,32,46,32,95,52,53,51,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,12),40,97,49,56,49,57,32,107,52,53,48,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,98,114,101,97,107,45,101,110,116,114,121,32,110,97,109,101,52,52,49,32,97,114,103,115,52,52,50,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,97,49,57,52,54,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,27),40,35,35,115,121,115,35,98,114,101,97,107,45,114,101,115,117,109,101,32,101,120,110,52,54,57,41,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from ##sys#fdset-clear */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub259(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub259(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_CLR(fd, &C_fdset_input_2);FD_CLR(fd, &C_fdset_output_2);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-output-set */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub255(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub255(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_SET(fd, &C_fdset_output);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-input-set */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub251(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub251(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
FD_SET(fd, &C_fdset_input);
C_ret:
#undef return

return C_r;}

/* from f_520 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub248(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub248(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
FD_ZERO(&C_fdset_input);FD_ZERO(&C_fdset_output);
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-restore */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub246(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub246(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_fdset_input = C_fdset_input_2;C_fdset_output = C_fdset_output_2;
C_ret:
#undef return

return C_r;}

/* from ##sys#fdset-select-timeout */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub242(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub242(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int to=(int )C_truep(C_a0);
unsigned long tm=(unsigned long )C_num_to_unsigned_long(C_a1);
struct timeval timeout;timeout.tv_sec = tm / 1000;timeout.tv_usec = (tm % 1000) * 1000;C_fdset_input_2 = C_fdset_input;C_fdset_output_2 = C_fdset_output;return(select(FD_SETSIZE, &C_fdset_input, &C_fdset_output, NULL, to ? &timeout : NULL));
C_ret:
#undef return

return C_r;}

C_noret_decl(C_scheduler_toplevel)
C_externexport void C_ccall C_scheduler_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1824)
static void C_fcall f_1824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1762)
static void C_fcall f_1762(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1660)
static void C_fcall f_1660(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1655)
static void C_fcall f_1655(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1541)
static void C_fcall f_1541(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1547)
static void C_fcall f_1547(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1574)
static void C_fcall f_1574(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1628)
static void C_fcall f_1628(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_fcall f_1601(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1239)
static void C_fcall f_1239(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_fcall f_1185(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1141)
static void C_ccall f_1141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1108)
static void C_ccall f_1108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_fcall f_1060(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_938)
static void C_fcall f_938(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_948)
static void C_fcall f_948(C_word t0,C_word t1) C_noret;
C_noret_decl(f_927)
static void C_ccall f_927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_882)
static void C_ccall f_882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_888)
static C_word C_fcall f_888(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_875)
static void C_ccall f_875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_861)
static void C_ccall f_861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_756)
static void C_ccall f_756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_753)
static void C_ccall f_753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_524)
static void C_ccall f_524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_554)
static void C_ccall f_554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_559)
static void C_fcall f_559(C_word t0,C_word t1) C_noret;
C_noret_decl(f_638)
static void C_fcall f_638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_690)
static void C_fcall f_690(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_fcall f_1474(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_673)
static void C_fcall f_673(C_word t0,C_word t1) C_noret;
C_noret_decl(f_676)
static void C_ccall f_676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_fcall f_1297(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_fcall f_1321(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1422)
static void C_ccall f_1422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_fcall f_1352(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1392)
static void C_fcall f_1392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_566)
static void C_ccall f_566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_571)
static void C_fcall f_571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_575)
static void C_fcall f_575(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1824)
static void C_fcall trf_1824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1824(t0,t1);}

C_noret_decl(trf_1762)
static void C_fcall trf_1762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1762(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1762(t0,t1,t2);}

C_noret_decl(trf_1660)
static void C_fcall trf_1660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1660(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1660(t0,t1);}

C_noret_decl(trf_1655)
static void C_fcall trf_1655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1655(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1655(t0,t1,t2);}

C_noret_decl(trf_1541)
static void C_fcall trf_1541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1541(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1541(t0,t1,t2);}

C_noret_decl(trf_1547)
static void C_fcall trf_1547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1547(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1547(t0,t1,t2,t3);}

C_noret_decl(trf_1574)
static void C_fcall trf_1574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1574(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1574(t0,t1,t2,t3);}

C_noret_decl(trf_1628)
static void C_fcall trf_1628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1628(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1628(t0,t1,t2,t3);}

C_noret_decl(trf_1601)
static void C_fcall trf_1601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1601(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1601(t0,t1,t2);}

C_noret_decl(trf_1239)
static void C_fcall trf_1239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1239(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1239(t0,t1,t2);}

C_noret_decl(trf_1185)
static void C_fcall trf_1185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1185(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1185(t0,t1);}

C_noret_decl(trf_1060)
static void C_fcall trf_1060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1060(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1060(t0,t1,t2);}

C_noret_decl(trf_938)
static void C_fcall trf_938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_938(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_938(t0,t1,t2,t3);}

C_noret_decl(trf_948)
static void C_fcall trf_948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_948(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_948(t0,t1);}

C_noret_decl(trf_559)
static void C_fcall trf_559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_559(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_559(t0,t1);}

C_noret_decl(trf_638)
static void C_fcall trf_638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_638(t0,t1,t2);}

C_noret_decl(trf_690)
static void C_fcall trf_690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_690(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_690(t0,t1);}

C_noret_decl(trf_1474)
static void C_fcall trf_1474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1474(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1474(t0,t1,t2);}

C_noret_decl(trf_673)
static void C_fcall trf_673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_673(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_673(t0,t1);}

C_noret_decl(trf_1297)
static void C_fcall trf_1297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1297(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1297(t0,t1);}

C_noret_decl(trf_1321)
static void C_fcall trf_1321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1321(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1321(t0,t1,t2,t3);}

C_noret_decl(trf_1352)
static void C_fcall trf_1352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1352(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1352(t0,t1,t2);}

C_noret_decl(trf_1392)
static void C_fcall trf_1392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1392(t0,t1);}

C_noret_decl(trf_571)
static void C_fcall trf_571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_571(t0,t1);}

C_noret_decl(trf_575)
static void C_fcall trf_575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_575(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_scheduler_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("scheduler_toplevel"));
C_check_nursery_minimum(57);
if(!C_demand(57)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(763)){
C_save(t1);
C_rereclaim2(763*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(57);
C_initialize_lf(lf,72);
lf[0]=C_h_intern(&lf[0],12,"\003sysschedule");
lf[1]=C_h_intern(&lf[1],18,"\003syscurrent-thread");
lf[2]=C_h_intern(&lf[2],17,"\003sysdynamic-winds");
lf[3]=C_h_intern(&lf[3],18,"\003sysstandard-input");
lf[4]=C_h_intern(&lf[4],19,"\003sysstandard-output");
lf[5]=C_h_intern(&lf[5],18,"\003sysstandard-error");
lf[6]=C_h_intern(&lf[6],29,"\003syscurrent-exception-handler");
lf[7]=C_h_intern(&lf[7],28,"\003syscurrent-parameter-vector");
lf[8]=C_h_intern(&lf[8],5,"ready");
lf[9]=C_h_intern(&lf[9],7,"running");
lf[11]=C_h_intern(&lf[11],11,"\003sysfd-list");
lf[12]=C_h_intern(&lf[12],15,"\003syssignal-hook");
lf[13]=C_h_intern(&lf[13],14,"\000runtime-error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\010deadlock");
lf[17]=C_h_intern(&lf[17],19,"\003systhread-unblock!");
lf[18]=C_h_intern(&lf[18],21,"\003sysprimordial-thread");
lf[19]=C_h_intern(&lf[19],25,"\003systhread-basic-unblock!");
lf[20]=C_h_intern(&lf[20],8,"\003sysdelq");
lf[21]=C_h_intern(&lf[21],22,"\003sysadd-to-ready-queue");
lf[22]=C_h_intern(&lf[22],15,"\003sysready-queue");
lf[23]=C_h_intern(&lf[23],18,"\003sysinterrupt-hook");
lf[24]=C_h_intern(&lf[24],28,"\003sysremove-from-timeout-list");
lf[25]=C_h_intern(&lf[25],29,"\003systhread-block-for-timeout!");
lf[26]=C_h_intern(&lf[26],7,"blocked");
lf[27]=C_h_intern(&lf[27],33,"\003systhread-block-for-termination!");
lf[28]=C_h_intern(&lf[28],4,"dead");
lf[29]=C_h_intern(&lf[29],10,"terminated");
lf[30]=C_h_intern(&lf[30],16,"\003systhread-kill!");
lf[31]=C_h_intern(&lf[31],19,"\003sysabandon-mutexes");
lf[32]=C_h_intern(&lf[32],19,"print-error-message");
lf[33]=C_h_intern(&lf[33],7,"display");
lf[34]=C_h_intern(&lf[34],16,"print-call-chain");
lf[35]=C_h_intern(&lf[35],18,"open-output-string");
lf[36]=C_h_intern(&lf[36],17,"get-output-string");
lf[37]=C_h_intern(&lf[37],29,"\003sysdefault-exception-handler");
lf[38]=C_h_intern(&lf[38],10,"\003syssignal");
lf[39]=C_h_intern(&lf[39],20,"\003syswarnings-enabled");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\003): ");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\011Warning (");
lf[42]=C_h_intern(&lf[42],25,"\003systhread-block-for-i/o!");
lf[43]=C_h_intern(&lf[43],6,"\000input");
lf[44]=C_h_intern(&lf[44],7,"\000output");
lf[45]=C_h_intern(&lf[45],4,"\000all");
lf[46]=C_h_intern(&lf[46],15,"\003sysall-threads");
lf[47]=C_h_intern(&lf[47],3,"i/o");
lf[48]=C_h_intern(&lf[48],7,"timeout");
lf[49]=C_h_intern(&lf[49],27,"\003sysfetch-and-clear-threads");
lf[50]=C_h_intern(&lf[50],19,"\003sysrestore-threads");
lf[51]=C_h_intern(&lf[51],15,"\003sysbreak-entry");
lf[52]=C_h_intern(&lf[52],19,"\003sysbreak-in-thread");
lf[53]=C_h_intern(&lf[53],9,"condition");
lf[54]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\003\000\000\002\376\001\000\000\012breakpoint\376\377\016");
lf[55]=C_h_intern(&lf[55],19,"\003syslast-breakpoint");
lf[56]=C_h_intern(&lf[56],9,"suspended");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\022*** breakpoint ***");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\011arguments");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\010location");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\014continuation");
lf[62]=C_h_intern(&lf[62],6,"append");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\006thread");
lf[64]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\027primordial-continuation");
lf[65]=C_h_intern(&lf[65],16,"\003sysbreak-resume");
lf[66]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\014continuation");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\006thread");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\027primordial-continuation");
lf[69]=C_h_intern(&lf[69],11,"\000type-error");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\035condition has no continuation");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\035condition has no continuation");
C_register_lf2(lf,72,create_ptable());
t2=C_mutate((C_word*)lf[0]+1 /* (set! schedule ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_524,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t3=lf[15] /* ready-queue-head */ =C_SCHEME_END_OF_LIST;;
t4=lf[16] /* ready-queue-tail */ =C_SCHEME_END_OF_LIST;;
t5=C_mutate((C_word*)lf[22]+1 /* (set! ready-queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_753,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[21]+1 /* (set! add-to-ready-queue ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_756,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[23]+1);
t8=C_mutate((C_word*)lf[23]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_857,a[2]=t7,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t9=lf[10] /* timeout-list */ =C_SCHEME_END_OF_LIST;;
t10=C_mutate((C_word*)lf[24]+1 /* (set! remove-from-timeout-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_882,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[25]+1 /* (set! thread-block-for-timeout! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_923,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[27]+1 /* (set! thread-block-for-termination! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_986,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[30]+1 /* (set! thread-kill! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[19]+1 /* (set! thread-basic-unblock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1092,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[32]+1);
t16=*((C_word*)lf[33]+1);
t17=*((C_word*)lf[34]+1);
t18=*((C_word*)lf[35]+1);
t19=*((C_word*)lf[36]+1);
t20=C_mutate((C_word*)lf[37]+1 /* (set! default-exception-handler ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1104,a[2]=t18,a[3]=t16,a[4]=t19,a[5]=t15,a[6]=t17,a[7]=((C_word)li20),tmp=(C_word)a,a+=8,tmp));
t21=C_set_block_item(lf[11] /* fd-list */,0,C_SCHEME_END_OF_LIST);
t22=(C_word)stub248(C_SCHEME_UNDEFINED);
t23=C_mutate((C_word*)lf[42]+1 /* (set! thread-block-for-i/o! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1178,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[46]+1 /* (set! all-threads ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1539,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[49]+1 /* (set! fetch-and-clear-threads ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[50]+1 /* (set! restore-threads ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1721,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[17]+1 /* (set! thread-unblock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[51]+1 /* (set! break-entry ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[65]+1 /* (set! break-resume ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1902,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t30=t1;
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,C_SCHEME_UNDEFINED);}

/* ##sys#break-resume */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1902,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_member(lf[66],t3);
t5=(C_word)C_i_member(lf[67],t3);
t6=(C_word)C_i_member(lf[68],t3);
t7=(C_truep(t6)?t6:t4);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1921,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t9=(C_word)C_u_i_cadr(t5);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1939,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1947,a[2]=t4,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_setslot(t9,C_fix(1),t11);
/* scheduler.scm: 530  ##sys#add-to-ready-queue */
t13=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t8,t9);}
else{
/* scheduler.scm: 529  ##sys#signal-hook */
t11=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t10,lf[69],lf[71],t2);}}
else{
t9=t8;
f_1921(2,t9,C_SCHEME_UNDEFINED);}}

/* a1946 in ##sys#break-resume */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1947,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,C_SCHEME_UNDEFINED);}

/* k1937 in ##sys#break-resume */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 530  ##sys#add-to-ready-queue */
t2=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1919 in ##sys#break-resume */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],C_SCHEME_UNDEFINED);}
else{
/* scheduler.scm: 533  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[69],lf[70],((C_word*)t0)[2]);}}

/* ##sys#break-entry */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1805,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not(*((C_word*)lf[52]+1));
t5=(C_truep(t4)?t4:(C_word)C_eqp(*((C_word*)lf[52]+1),*((C_word*)lf[1]+1)));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1820,a[2]=t3,a[3]=t2,a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 488  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* a1819 in ##sys#break-entry */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1820,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(*((C_word*)lf[1]+1),*((C_word*)lf[18]+1));
if(C_truep(t4)){
t5=t3;
f_1824(t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1890,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
t6=t3;
f_1824(t6,(C_word)C_a_i_list(&a,4,lf[63],*((C_word*)lf[1]+1),lf[64],t5));}}

/* a1889 in a1819 in ##sys#break-entry */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=(C_word)C_slot(*((C_word*)lf[18]+1),C_fix(1));
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k1822 in a1819 in ##sys#break-entry */
static void C_fcall f_1824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1824,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1874,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,8,lf[57],lf[58],lf[59],t3,lf[60],((C_word*)t0)[3],lf[61],((C_word*)t0)[4]);
/* scheduler.scm: 498  append */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,t1);}

/* k1872 in k1822 in a1819 in ##sys#break-entry */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1874,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,3,lf[53],lf[54],t1);
t3=C_mutate((C_word*)lf[55]+1 /* (set! last-breakpoint ...) */,t2);
t4=(C_word)C_eqp(*((C_word*)lf[1]+1),*((C_word*)lf[18]+1));
if(C_truep(t4)){
/* scheduler.scm: 506  ##sys#signal */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[3],t2);}
else{
t5=(C_word)C_i_setslot(*((C_word*)lf[1]+1),C_fix(3),lf[56]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[2],a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_setslot(*((C_word*)lf[1]+1),C_fix(1),t6);
t8=(C_word)C_slot(*((C_word*)lf[18]+1),C_fix(1));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1857,a[2]=t2,a[3]=t8,a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_setslot(*((C_word*)lf[18]+1),C_fix(1),t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* scheduler.scm: 516  ##sys#thread-unblock! */
t12=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,*((C_word*)lf[18]+1));}}

/* k1850 in k1872 in k1822 in a1819 in ##sys#break-entry */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 517  ##sys#schedule */
t2=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1856 in k1872 in k1822 in a1819 in ##sys#break-entry */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1861,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 514  ##sys#signal */
t3=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1859 in a1856 in k1872 in k1822 in a1819 in ##sys#break-entry */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 515  old */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1865 in k1872 in k1822 in a1819 in ##sys#break-entry */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
/* scheduler.scm: 509  k */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##sys#thread-unblock! */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1740,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_eqp(lf[26],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1750,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 470  ##sys#remove-from-timeout-list */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k1748 in ##sys#thread-unblock! */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1762,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word)li34),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1762(t6,t2,*((C_word*)lf[11]+1));}

/* loop in k1748 in ##sys#thread-unblock! */
static void C_fcall f_1762(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1762,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 478  ##sys#delq */
t7=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}}

/* k1793 in loop in k1748 in ##sys#thread-unblock! */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1783,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* scheduler.scm: 479  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1762(t5,t3,t4);}

/* k1781 in k1793 in loop in k1748 in ##sys#thread-unblock! */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1783,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1752 in k1748 in ##sys#thread-unblock! */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1 /* (set! fd-list ...) */,t1);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(12),C_SCHEME_END_OF_LIST);
/* scheduler.scm: 481  ##sys#thread-basic-unblock! */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* ##sys#restore-threads */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1721,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=C_mutate(&lf[15] /* (set! ready-queue-head ...) */,t3);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_mutate(&lf[16] /* (set! ready-queue-tail ...) */,t5);
t7=(C_word)C_slot(t2,C_fix(2));
t8=C_mutate((C_word*)lf[11]+1 /* (set! fd-list ...) */,t7);
t9=(C_word)C_slot(t2,C_fix(3));
t10=C_mutate(&lf[10] /* (set! timeout-list ...) */,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}

/* ##sys#fetch-and-clear-threads */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,lf[15],lf[16],*((C_word*)lf[11]+1),lf[10]);
t3=lf[15] /* ready-queue-head */ =C_SCHEME_END_OF_LIST;;
t4=lf[16] /* ready-queue-tail */ =C_SCHEME_END_OF_LIST;;
t5=C_set_block_item(lf[11] /* fd-list */,0,C_SCHEME_END_OF_LIST);
t6=lf[10] /* timeout-list */ =C_SCHEME_END_OF_LIST;;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}

/* ##sys#all-threads */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_1539r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1539r(t0,t1,t2);}}

static void C_ccall f_1539r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1541,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1655,a[2]=t3,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1660,a[2]=t4,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-cns381408 */
t6=t5;
f_1660(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-init382406 */
t8=t4;
f_1655(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body379387 */
f_1541(t1,t6,t8);}}}

/* def-cns381 in ##sys#all-threads */
static void C_fcall f_1660(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1660,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1666,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
/* def-init382406 */
t3=((C_word*)t0)[2];
f_1655(t3,t1,t2);}

/* a1665 in def-cns381 in ##sys#all-threads */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1666,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t4,t5));}

/* def-init382 in ##sys#all-threads */
static void C_fcall f_1655(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1655,NULL,3,t0,t1,t2);}
/* body379387 */
f_1541(t1,t2,C_SCHEME_END_OF_LIST);}

/* body379 in ##sys#all-threads */
static void C_fcall f_1541(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1541,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1547,a[2]=t2,a[3]=t5,a[4]=((C_word)li26),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1547(t7,t1,lf[15],t3);}

/* loop in body379 in ##sys#all-threads */
static void C_fcall f_1547(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1547,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1565,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* scheduler.scm: 432  cns */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,lf[8],C_SCHEME_FALSE,t6,t3);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1574(t7,t1,*((C_word*)lf[11]+1),t3);}}

/* loop in loop in body379 in ##sys#all-threads */
static void C_fcall f_1574(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1574,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_caar(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1595,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_cdar(t2);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1601,a[2]=t9,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word)li23),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_1601(t11,t6,t7);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li24),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1628(t7,t1,lf[10],t3);}}

/* loop in loop in loop in body379 in ##sys#all-threads */
static void C_fcall f_1628(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1628,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1646,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_caar(t2);
t7=(C_word)C_u_i_cdar(t2);
/* scheduler.scm: 442  cns */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,lf[48],t6,t7,t3);}
else{
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1644 in loop in loop in loop in body379 in ##sys#all-threads */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 442  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1628(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in loop in loop in body379 in ##sys#all-threads */
static void C_fcall f_1601(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1601,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[5];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1619,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 439  loop */
t8=t4;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}

/* k1617 in loop in loop in loop in body379 in ##sys#all-threads */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 439  cns */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[47],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1593 in loop in loop in body379 in ##sys#all-threads */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 435  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1574(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1563 in loop in body379 in ##sys#all-threads */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 432  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1547(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#thread-block-for-i/o! */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1178,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1182,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1239,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=((C_word)li21),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_1239(t9,t5,*((C_word*)lf[11]+1));}

/* loop in ##sys#thread-block-for-i/o! */
static void C_fcall f_1239(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1239,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,*((C_word*)lf[11]+1));
t5=C_mutate((C_word*)lf[11]+1 /* (set! fd-list ...) */,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t3,C_fix(1),t7));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 346  loop */
t13=t1;
t14=t6;
t1=t13;
t2=t14;
goto loop;}}}

/* k1180 in ##sys#thread-block-for-i/o! */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1182,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,C_SCHEME_TRUE);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t2,lf[43]));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t3;
f_1185(t7,(C_word)stub251(C_SCHEME_UNDEFINED,t6));}
else{
t6=(C_word)C_eqp(t2,C_SCHEME_FALSE);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[44]));
if(C_truep(t7)){
t8=((C_word*)t0)[3];
t9=t3;
f_1185(t9,(C_word)stub255(C_SCHEME_UNDEFINED,t8));}
else{
t8=(C_word)C_eqp(t2,lf[45]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
t10=(C_word)stub251(C_SCHEME_UNDEFINED,t9);
t11=((C_word*)t0)[3];
t12=t3;
f_1185(t12,(C_word)stub255(C_SCHEME_UNDEFINED,t11));}
else{
t9=C_SCHEME_UNDEFINED;
t10=t3;
f_1185(t10,t9);}}}}

/* k1183 in k1180 in ##sys#thread-block-for-i/o! */
static void C_fcall f_1185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1185,NULL,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(3),lf[26]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(13),C_SCHEME_FALSE);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(11),t4));}

/* ##sys#default-exception-handler */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1104,3,t0,t1,t2);}
t3=*((C_word*)lf[1]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1108,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_mk_bool(C_abort_on_thread_exceptions))){
t5=*((C_word*)lf[18]+1);
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1128,a[2]=t2,a[3]=t6,a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
/* scheduler.scm: 290  ##sys#thread-unblock! */
t9=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t4,t5);}
else{
if(C_truep(*((C_word*)lf[39]+1))){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1141,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scheduler.scm: 292  open-output-string */
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t4;
f_1108(2,t6,t5);}}}

/* k1139 in ##sys#default-exception-handler */
static void C_ccall f_1141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1144,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* scheduler.scm: 293  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[41],t1);}

/* k1142 in k1139 in ##sys#default-exception-handler */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* scheduler.scm: 294  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[3]);}

/* k1145 in k1142 in k1139 in ##sys#default-exception-handler */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* scheduler.scm: 295  display */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[40],((C_word*)t0)[3]);}

/* k1148 in k1145 in k1142 in k1139 in ##sys#default-exception-handler */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1153,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1160,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 296  get-output-string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1158 in k1148 in k1145 in k1142 in k1139 in ##sys#default-exception-handler */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 296  print-error-message */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[5]+1),t1);}

/* k1151 in k1148 in k1145 in k1142 in k1139 in ##sys#default-exception-handler */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 297  print-call-chain */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[5]+1),C_fix(0),((C_word*)t0)[2]);}

/* a1127 in ##sys#default-exception-handler */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1132,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 288  ##sys#signal */
t3=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1130 in a1127 in ##sys#default-exception-handler */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 289  ptx */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1106 in ##sys#default-exception-handler */
static void C_ccall f_1108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1108,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* scheduler.scm: 299  ##sys#thread-kill! */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[29]);}

/* k1112 in k1106 in ##sys#default-exception-handler */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 300  ##sys#schedule */
t2=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#thread-basic-unblock! */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1092,3,t0,t1,t2);}
t3=(C_word)C_i_set_i_slot(t2,C_fix(11),C_SCHEME_FALSE);
t4=(C_word)C_i_set_i_slot(t2,C_fix(4),C_SCHEME_FALSE);
/* scheduler.scm: 271  ##sys#add-to-ready-queue */
t5=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}

/* ##sys#thread-kill! */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1024,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1028,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 251  ##sys#abandon-mutexes */
t5=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1026 in ##sys#thread-kill! */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),((C_word*)t0)[3]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(4),C_SCHEME_FALSE);
t4=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(11),C_SCHEME_FALSE);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(8),C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* scheduler.scm: 256  ##sys#remove-from-timeout-list */
t7=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[4]);}

/* k1041 in k1026 in ##sys#thread-kill! */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1043,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(12));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(12),C_SCHEME_END_OF_LIST));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1060,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1060(t7,t3,t2);}}

/* loop190 in k1041 in k1026 in ##sys#thread-kill! */
static void C_fcall f_1060(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1060,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1073,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(11));
t6=(C_word)C_eqp(t5,((C_word*)t0)[2]);
if(C_truep(t6)){
/* scheduler.scm: 263  ##sys#thread-basic-unblock! */
t7=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t4,t3);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1071 in loop190 in k1041 in k1026 in ##sys#thread-kill! */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1060(t3,((C_word*)t0)[2],t2);}

/* k1047 in k1041 in k1026 in ##sys#thread-kill! */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(12),C_SCHEME_END_OF_LIST));}

/* ##sys#thread-block-for-termination! */
static void C_ccall f_986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_986,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_eqp(t4,lf[28]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,lf[29]));
if(C_truep(t6)){
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_slot(t3,C_fix(12));
t8=(C_word)C_a_i_cons(&a,2,t2,t7);
t9=(C_word)C_i_setslot(t3,C_fix(12),t8);
t10=(C_word)C_i_setslot(t2,C_fix(3),lf[26]);
t11=(C_word)C_i_set_i_slot(t2,C_fix(13),C_SCHEME_FALSE);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_i_setslot(t2,C_fix(11),t3));}}

/* ##sys#thread-block-for-timeout! */
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_923,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_927,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_938,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=((C_word)li13),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_938(t8,t4,lf[10],C_SCHEME_FALSE);}

/* loop in ##sys#thread-block-for-timeout! */
static void C_fcall f_938(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_938,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_948(t6,t4);}
else{
t6=(C_word)C_u_i_caar(t2);
t7=((C_word*)t0)[4];
t8=t5;
f_948(t8,(C_word)C_fixnum_lessp(t7,t6));}}

/* k946 in loop in ##sys#thread-block-for-timeout! */
static void C_fcall f_948(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_948,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[7],C_fix(1),t3));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=C_mutate(&lf[10] /* (set! timeout-list ...) */,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 235  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_938(t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}}

/* k925 in ##sys#thread-block-for-timeout! */
static void C_ccall f_927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[26]);
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(13),C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(4),((C_word*)t0)[2]));}

/* ##sys#remove-from-timeout-list */
static void C_ccall f_882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_882,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_888,a[2]=t2,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_888(t3,lf[10],C_SCHEME_FALSE));}

/* loop in ##sys#remove-from-timeout-list */
static C_word C_fcall f_888(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
t3=t1;
return(t3);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_eqp(t5,((C_word*)t0)[2]);
if(C_truep(t6)){
if(C_truep(t2)){
return((C_word)C_i_setslot(t2,C_fix(1),t4));}
else{
t7=C_mutate(&lf[10] /* (set! timeout-list ...) */,t4);
return(t7);}}
else{
t10=t4;
t11=t1;
t1=t10;
t2=t11;
goto loop;}}}

/* ##sys#interrupt-hook */
static void C_ccall f_857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_857,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_861,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(t2,C_fix(255));
if(C_truep(t5)){
t6=*((C_word*)lf[1]+1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_875,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word)li9),tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_setslot(t6,C_fix(1),t7);
/* scheduler.scm: 210  ##sys#schedule */
t9=*((C_word*)lf[0]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t4);}
else{
/* scheduler.scm: 211  oldhook */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}}

/* a874 in ##sys#interrupt-hook */
static void C_ccall f_875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_875,2,t0,t1);}
/* scheduler.scm: 209  oldhook */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k859 in ##sys#interrupt-hook */
static void C_ccall f_861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scheduler.scm: 211  oldhook */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#add-to-ready-queue */
static void C_ccall f_756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_756,3,t0,t1,t2);}
t3=(C_word)C_i_setslot(t2,C_fix(3),lf[8]);
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=(C_word)C_eqp(C_SCHEME_END_OF_LIST,lf[15]);
if(C_truep(t5)){
t6=C_mutate(&lf[15] /* (set! ready-queue-head ...) */,t4);
t7=C_mutate(&lf[16] /* (set! ready-queue-tail ...) */,t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t6=(C_word)C_i_setslot(lf[16],C_fix(1),t4);
t7=C_mutate(&lf[16] /* (set! ready-queue-tail ...) */,t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* ##sys#ready-queue */
static void C_ccall f_753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_753,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}

/* ##sys#schedule */
static void C_ccall f_524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_524,2,t0,t1);}
t2=*((C_word*)lf[1]+1);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_slot(t2,C_fix(5));
t7=(C_word)C_i_setslot(t6,C_fix(0),*((C_word*)lf[2]+1));
t8=(C_word)C_i_setslot(t6,C_fix(1),*((C_word*)lf[3]+1));
t9=(C_word)C_i_setslot(t6,C_fix(2),*((C_word*)lf[4]+1));
t10=(C_word)C_i_setslot(t6,C_fix(3),*((C_word*)lf[5]+1));
t11=(C_word)C_i_setslot(t6,C_fix(4),*((C_word*)lf[6]+1));
t12=(C_word)C_i_setslot(t6,C_fix(5),*((C_word*)lf[7]+1));
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_554,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_eqp(t5,lf[9]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[8]));
if(C_truep(t15)){
t16=(C_word)C_i_set_i_slot(t2,C_fix(13),C_SCHEME_FALSE);
/* scheduler.scm: 111  ##sys#add-to-ready-queue */
t17=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t13,t2);}
else{
t16=t13;
f_554(2,t16,C_SCHEME_UNDEFINED);}}

/* k552 in ##sys#schedule */
static void C_ccall f_554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_554,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_559,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_559(t5,((C_word*)t0)[2]);}

/* loop1 in k552 in ##sys#schedule */
static void C_fcall f_559(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_559,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_563,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(lf[10]))){
t3=t2;
f_563(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_fudge(C_fix(16));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_638,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=((C_word)li4),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_638(t7,t2,lf[10]);}}

/* loop in loop1 in k552 in ##sys#schedule */
static void C_fcall f_638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
loop:
a=C_alloc(17);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_638,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=lf[10] /* timeout-list */ =C_SCHEME_END_OF_LIST;;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_u_i_caar(t2);
t4=(C_word)C_u_i_cdar(t2);
t5=(C_word)C_slot(t4,C_fix(4));
t6=(C_word)C_eqp(t3,t5);
if(C_truep(t6)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[4],t3))){
t7=(C_word)C_i_set_i_slot(t4,C_fix(13),C_SCHEME_TRUE);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_673,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t4,C_fix(11));
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_slot(t4,C_fix(11));
t11=(C_word)C_slot(t10,C_fix(0));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1472,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1474,a[2]=t14,a[3]=t4,a[4]=t11,a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_1474(t16,t12,*((C_word*)lf[11]+1));}
else{
t10=C_SCHEME_UNDEFINED;
t11=t8;
f_673(t11,t10);}}
else{
t7=C_mutate(&lf[10] /* (set! timeout-list ...) */,t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_690,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(lf[15]))){
t9=(C_word)C_i_nullp(*((C_word*)lf[11]+1));
t10=t8;
f_690(t10,(C_truep(t9)?(C_word)C_i_pairp(lf[10]):C_SCHEME_FALSE));}
else{
t9=t8;
f_690(t9,C_SCHEME_FALSE);}}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 144  loop */
t23=t1;
t24=t7;
t1=t23;
t2=t24;
goto loop;}}}

/* k688 in loop in loop1 in k552 in ##sys#schedule */
static void C_fcall f_690(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_caar(lf[10]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_fixnum_max(C_fix(0),t3);
if(C_truep((C_word)C_msleep(t4))){
t5=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_mk_bool(C_signal_interrupted_p);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop in loop in loop1 in k552 in ##sys#schedule */
static void C_fcall f_1474(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1474,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[4],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1496,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 410  ##sys#delq */
t8=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[3],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1525,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* scheduler.scm: 419  loop */
t11=t6;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* k1523 in loop in loop in loop1 in k552 in ##sys#schedule */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1525,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1494 in loop in loop in loop1 in k552 in ##sys#schedule */
static void C_ccall f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)stub259(C_SCHEME_UNDEFINED,((C_word*)t0)[5]);
t3=(C_word)stub246(C_SCHEME_UNDEFINED);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[3],C_fix(1)));}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1470 in loop in loop1 in k552 in ##sys#schedule */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1 /* (set! fd-list ...) */,t1);
t3=((C_word*)t0)[2];
f_673(t3,t2);}

/* k671 in loop in loop1 in k552 in ##sys#schedule */
static void C_fcall f_673(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_673,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_676,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scheduler.scm: 130  ##sys#thread-basic-unblock! */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k674 in k671 in loop in loop1 in k552 in ##sys#schedule */
static void C_ccall f_676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 131  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_638(t3,((C_word*)t0)[2],t2);}

/* k561 in loop1 in k552 in ##sys#schedule */
static void C_ccall f_563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* scheduler.scm: 163  ##sys#thread-unblock! */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[18]+1));}
else{
if(C_truep((C_word)C_i_nullp(*((C_word*)lf[11]+1)))){
t3=C_SCHEME_UNDEFINED;
t4=t2;
f_566(2,t4,t3);}
else{
t3=(C_word)C_i_pairp(lf[10]);
t4=(C_word)C_i_pairp(lf[15]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(t4)?t4:t3);
t7=(C_truep(t3)?(C_word)C_i_not(t4):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_u_i_caar(lf[10]);
t9=(C_word)C_fudge(C_fix(16));
t10=(C_word)C_u_fixnum_difference(t8,t9);
t11=(C_word)C_i_fixnum_max(C_fix(0),t10);
t12=t5;
f_1297(t12,(C_word)stub242(C_SCHEME_UNDEFINED,t6,t11));}
else{
t8=t5;
f_1297(t8,(C_word)stub242(C_SCHEME_UNDEFINED,t6,C_fix(0)));}}}}

/* k1295 in k561 in loop1 in k552 in ##sys#schedule */
static void C_fcall f_1297(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1297,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t3)){
/* scheduler.scm: 163  ##sys#thread-unblock! */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,*((C_word*)lf[18]+1));}
else{
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1321,a[2]=t6,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1321(t8,t4,t1,*((C_word*)lf[11]+1));}
else{
t4=((C_word*)t0)[2];
f_566(2,t4,(C_word)stub246(C_SCHEME_UNDEFINED));}}}

/* loop in k1295 in k561 in loop1 in k552 in ##sys#schedule */
static void C_fcall f_1321(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1321,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_u_i_car(t6);
t8=(C_word)C_fd_test_input(t7);
t9=(C_word)C_fd_test_output(t7);
t10=(C_truep(t8)?t8:t9);
if(C_truep(t10)){
t11=(C_word)C_slot(t6,C_fix(1));
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1352,a[2]=t13,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t7,a[7]=((C_word)li1),tmp=(C_word)a,a+=8,tmp));
t15=((C_word*)t13)[1];
f_1352(t15,t1,t11);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1422,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_slot(t3,C_fix(1));
/* scheduler.scm: 394  loop */
t19=t11;
t20=t2;
t21=t12;
t1=t19;
t2=t20;
t3=t21;
goto loop;}}}

/* k1420 in loop in k1295 in k561 in loop1 in k552 in ##sys#schedule */
static void C_ccall f_1422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1422,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k1295 in k561 in loop1 in k552 in ##sys#schedule */
static void C_fcall f_1352(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1352,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)stub259(C_SCHEME_UNDEFINED,((C_word*)t0)[6]);
t4=(C_word)C_u_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 386  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1321(t6,t1,t4,t5);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t3,C_fix(11));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1382,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1392,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_u_i_car(t4);
t8=(C_word)C_eqp(((C_word*)t0)[6],t7);
if(C_truep(t8)){
t9=(C_word)C_slot(t3,C_fix(13));
t10=t6;
f_1392(t10,(C_word)C_i_not(t9));}
else{
t9=t6;
f_1392(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_1392(t7,C_SCHEME_FALSE);}}}

/* k1390 in loop2 in loop in k1295 in k561 in loop1 in k552 in ##sys#schedule */
static void C_fcall f_1392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* scheduler.scm: 392  ##sys#thread-basic-unblock! */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 393  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1352(t3,((C_word*)t0)[2],t2);}}

/* k1380 in loop2 in loop in k1295 in k561 in loop1 in k552 in ##sys#schedule */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* scheduler.scm: 393  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1352(t3,((C_word*)t0)[2],t2);}

/* k1317 in k1295 in k561 in loop1 in k552 in ##sys#schedule */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[11]+1 /* (set! fd-list ...) */,t1);
t3=((C_word*)t0)[2];
f_566(2,t3,(C_word)stub246(C_SCHEME_UNDEFINED));}

/* k1298 in k1295 in k561 in loop1 in k552 in ##sys#schedule */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_566(2,t2,(C_word)stub246(C_SCHEME_UNDEFINED));}

/* k564 in k561 in loop1 in k552 in ##sys#schedule */
static void C_ccall f_566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_566,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_571,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_571(t5,((C_word*)t0)[2]);}

/* loop2 in k564 in k561 in loop1 in k552 in ##sys#schedule */
static void C_fcall f_571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_571,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=lf[15];
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_575(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(1));
t5=C_mutate(&lf[15] /* (set! ready-queue-head ...) */,t4);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
t7=lf[16] /* ready-queue-tail */ =C_SCHEME_END_OF_LIST;;
t8=t2;
f_575(t8,(C_word)C_u_i_car(t3));}
else{
t7=t2;
f_575(t7,(C_word)C_u_i_car(t3));}}}

/* k573 in loop2 in k564 in k561 in loop1 in k552 in ##sys#schedule */
static void C_fcall f_575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_slot(t1,C_fix(3));
t4=(C_word)C_eqp(t3,lf[8]);
if(C_truep(t4)){
t5=((C_word*)t0)[4];
t6=t1;
t7=C_mutate((C_word*)lf[1]+1 /* (set! current-thread ...) */,t6);
t8=(C_word)C_i_setslot(t6,C_fix(3),lf[9]);
t9=(C_word)C_slot(t6,C_fix(5));
t10=(C_word)C_slot(t9,C_fix(0));
t11=C_mutate((C_word*)lf[2]+1 /* (set! dynamic-winds ...) */,t10);
t12=(C_word)C_slot(t9,C_fix(1));
t13=C_mutate((C_word*)lf[3]+1 /* (set! standard-input ...) */,t12);
t14=(C_word)C_slot(t9,C_fix(2));
t15=C_mutate((C_word*)lf[4]+1 /* (set! standard-output ...) */,t14);
t16=(C_word)C_slot(t9,C_fix(3));
t17=C_mutate((C_word*)lf[5]+1 /* (set! standard-error ...) */,t16);
t18=(C_word)C_slot(t9,C_fix(4));
t19=C_mutate((C_word*)lf[6]+1 /* (set! current-exception-handler ...) */,t18);
t20=(C_word)C_slot(t9,C_fix(5));
t21=C_mutate((C_word*)lf[7]+1 /* (set! current-parameter-vector ...) */,t20);
t22=(C_word)C_slot(t6,C_fix(9));
t23=(C_word)C_set_initial_timer_interrupt_period(t22);
t24=(C_word)C_slot(t6,C_fix(1));
t25=t24;
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,t5);}
else{
/* scheduler.scm: 159  loop2 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_571(t5,((C_word*)t0)[4]);}}
else{
if(C_truep((C_word)C_i_nullp(lf[10]))){
if(C_truep((C_word)C_i_nullp(*((C_word*)lf[11]+1)))){
/* scheduler.scm: 156  ##sys#signal-hook */
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],lf[13],lf[14]);}
else{
/* scheduler.scm: 157  loop1 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_559(t3,((C_word*)t0)[4]);}}
else{
/* scheduler.scm: 157  loop1 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_559(t3,((C_word*)t0)[4]);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[93] = {
{"toplevel:scheduler_scm",(void*)C_scheduler_toplevel},
{"f_1902:scheduler_scm",(void*)f_1902},
{"f_1947:scheduler_scm",(void*)f_1947},
{"f_1939:scheduler_scm",(void*)f_1939},
{"f_1921:scheduler_scm",(void*)f_1921},
{"f_1805:scheduler_scm",(void*)f_1805},
{"f_1820:scheduler_scm",(void*)f_1820},
{"f_1890:scheduler_scm",(void*)f_1890},
{"f_1824:scheduler_scm",(void*)f_1824},
{"f_1874:scheduler_scm",(void*)f_1874},
{"f_1852:scheduler_scm",(void*)f_1852},
{"f_1857:scheduler_scm",(void*)f_1857},
{"f_1861:scheduler_scm",(void*)f_1861},
{"f_1866:scheduler_scm",(void*)f_1866},
{"f_1740:scheduler_scm",(void*)f_1740},
{"f_1750:scheduler_scm",(void*)f_1750},
{"f_1762:scheduler_scm",(void*)f_1762},
{"f_1795:scheduler_scm",(void*)f_1795},
{"f_1783:scheduler_scm",(void*)f_1783},
{"f_1754:scheduler_scm",(void*)f_1754},
{"f_1721:scheduler_scm",(void*)f_1721},
{"f_1711:scheduler_scm",(void*)f_1711},
{"f_1539:scheduler_scm",(void*)f_1539},
{"f_1660:scheduler_scm",(void*)f_1660},
{"f_1666:scheduler_scm",(void*)f_1666},
{"f_1655:scheduler_scm",(void*)f_1655},
{"f_1541:scheduler_scm",(void*)f_1541},
{"f_1547:scheduler_scm",(void*)f_1547},
{"f_1574:scheduler_scm",(void*)f_1574},
{"f_1628:scheduler_scm",(void*)f_1628},
{"f_1646:scheduler_scm",(void*)f_1646},
{"f_1601:scheduler_scm",(void*)f_1601},
{"f_1619:scheduler_scm",(void*)f_1619},
{"f_1595:scheduler_scm",(void*)f_1595},
{"f_1565:scheduler_scm",(void*)f_1565},
{"f_1178:scheduler_scm",(void*)f_1178},
{"f_1239:scheduler_scm",(void*)f_1239},
{"f_1182:scheduler_scm",(void*)f_1182},
{"f_1185:scheduler_scm",(void*)f_1185},
{"f_1104:scheduler_scm",(void*)f_1104},
{"f_1141:scheduler_scm",(void*)f_1141},
{"f_1144:scheduler_scm",(void*)f_1144},
{"f_1147:scheduler_scm",(void*)f_1147},
{"f_1150:scheduler_scm",(void*)f_1150},
{"f_1160:scheduler_scm",(void*)f_1160},
{"f_1153:scheduler_scm",(void*)f_1153},
{"f_1128:scheduler_scm",(void*)f_1128},
{"f_1132:scheduler_scm",(void*)f_1132},
{"f_1108:scheduler_scm",(void*)f_1108},
{"f_1114:scheduler_scm",(void*)f_1114},
{"f_1092:scheduler_scm",(void*)f_1092},
{"f_1024:scheduler_scm",(void*)f_1024},
{"f_1028:scheduler_scm",(void*)f_1028},
{"f_1043:scheduler_scm",(void*)f_1043},
{"f_1060:scheduler_scm",(void*)f_1060},
{"f_1073:scheduler_scm",(void*)f_1073},
{"f_1049:scheduler_scm",(void*)f_1049},
{"f_986:scheduler_scm",(void*)f_986},
{"f_923:scheduler_scm",(void*)f_923},
{"f_938:scheduler_scm",(void*)f_938},
{"f_948:scheduler_scm",(void*)f_948},
{"f_927:scheduler_scm",(void*)f_927},
{"f_882:scheduler_scm",(void*)f_882},
{"f_888:scheduler_scm",(void*)f_888},
{"f_857:scheduler_scm",(void*)f_857},
{"f_875:scheduler_scm",(void*)f_875},
{"f_861:scheduler_scm",(void*)f_861},
{"f_756:scheduler_scm",(void*)f_756},
{"f_753:scheduler_scm",(void*)f_753},
{"f_524:scheduler_scm",(void*)f_524},
{"f_554:scheduler_scm",(void*)f_554},
{"f_559:scheduler_scm",(void*)f_559},
{"f_638:scheduler_scm",(void*)f_638},
{"f_690:scheduler_scm",(void*)f_690},
{"f_1474:scheduler_scm",(void*)f_1474},
{"f_1525:scheduler_scm",(void*)f_1525},
{"f_1496:scheduler_scm",(void*)f_1496},
{"f_1472:scheduler_scm",(void*)f_1472},
{"f_673:scheduler_scm",(void*)f_673},
{"f_676:scheduler_scm",(void*)f_676},
{"f_563:scheduler_scm",(void*)f_563},
{"f_1297:scheduler_scm",(void*)f_1297},
{"f_1321:scheduler_scm",(void*)f_1321},
{"f_1422:scheduler_scm",(void*)f_1422},
{"f_1352:scheduler_scm",(void*)f_1352},
{"f_1392:scheduler_scm",(void*)f_1392},
{"f_1382:scheduler_scm",(void*)f_1382},
{"f_1319:scheduler_scm",(void*)f_1319},
{"f_1300:scheduler_scm",(void*)f_1300},
{"f_566:scheduler_scm",(void*)f_566},
{"f_571:scheduler_scm",(void*)f_571},
{"f_575:scheduler_scm",(void*)f_575},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
