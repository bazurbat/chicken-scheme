/* Generated from compiler-syntax.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-28 22:55
   Version 4.1.4 - SVN rev. 15427
   linux-unix-gnu-x86 [ ptables applyhook ]
   compiled 2009-08-13 on x (Linux)
   command line: compiler-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature debugbuild -scrutinize -types ./types.db -no-lambda-info -local -extend private-namespace.scm -output-file compiler-syntax.c
   unit: compiler_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[66];
static double C_possibly_force_alignment;


C_noret_decl(C_compiler_syntax_toplevel)
C_externexport void C_ccall C_compiler_syntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_374)
static void C_ccall f_374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_383)
static void C_ccall f_383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1556)
static void C_ccall f_1556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_fcall f_1565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_ccall f_474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1346)
static void C_ccall f_1346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_480)
static void C_ccall f_480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_483)
static void C_ccall f_483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_486)
static void C_ccall f_486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_494)
static void C_ccall f_494(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_516)
static void C_fcall f_516(C_word t0,C_word t1) C_noret;
C_noret_decl(f_519)
static void C_ccall f_519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_559)
static void C_ccall f_559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_562)
static void C_ccall f_562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_565)
static void C_ccall f_565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_568)
static void C_ccall f_568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_571)
static void C_ccall f_571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_574)
static void C_ccall f_574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_577)
static void C_ccall f_577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_671)
static void C_fcall f_671(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_732)
static void C_ccall f_732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static C_word C_fcall f_1036(C_word t0,C_word t1);
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_953)
static void C_ccall f_953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_920)
static void C_ccall f_920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_883)
static void C_ccall f_883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_809)
static void C_ccall f_809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_784)
static void C_ccall f_784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_759)
static void C_ccall f_759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_738)
static void C_ccall f_738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_681)
static void C_ccall f_681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_684)
static void C_ccall f_684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_608)
static void C_fcall f_608(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_651)
static void C_ccall f_651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_661)
static C_word C_fcall f_661(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_589)
static void C_fcall f_589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_579)
static C_word C_fcall f_579(C_word t0);
C_noret_decl(f_524)
static void C_fcall f_524(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_528)
static void C_ccall f_528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_544)
static void C_ccall f_544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_547)
static void C_ccall f_547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_550)
static void C_ccall f_550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_541)
static void C_ccall f_541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_531)
static void C_ccall f_531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_452)
static void C_ccall f_452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_422)
static void C_fcall f_422(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_435)
static void C_ccall f_435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_396)
static void C_ccall f_396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1565)
static void C_fcall trf_1565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1565(t0,t1);}

C_noret_decl(trf_516)
static void C_fcall trf_516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_516(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_516(t0,t1);}

C_noret_decl(trf_671)
static void C_fcall trf_671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_671(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_671(t0,t1,t2);}

C_noret_decl(trf_608)
static void C_fcall trf_608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_608(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_608(t0,t1,t2);}

C_noret_decl(trf_589)
static void C_fcall trf_589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_589(t0,t1);}

C_noret_decl(trf_524)
static void C_fcall trf_524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_524(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_524(t0,t1,t2,t3,t4);}

C_noret_decl(trf_422)
static void C_fcall trf_422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_422(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_422(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_compiler_syntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_compiler_syntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("compiler_syntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(725)){
C_save(t1);
C_rereclaim2(725*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,66);
lf[0]=C_h_intern(&lf[0],35,"\010compilercompiler-syntax-statistics");
lf[1]=C_h_intern(&lf[1],24,"\003syscompiler-syntax-hook");
lf[2]=C_h_intern(&lf[2],13,"alist-update!");
lf[3]=C_h_intern(&lf[3],9,"alist-ref");
lf[4]=C_h_intern(&lf[4],3,"eq\077");
lf[5]=C_h_intern(&lf[5],14,"\010compilerr-c-s");
lf[6]=C_h_intern(&lf[6],8,"\003sysput!");
lf[7]=C_h_intern(&lf[7],24,"\010compilercompiler-syntax");
lf[8]=C_h_intern(&lf[8],18,"\003syser-transformer");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[11]=C_h_intern(&lf[11],30,"\010compilercompile-format-string");
lf[12]=C_h_intern(&lf[12],17,"extended-bindings");
lf[13]=C_h_intern(&lf[13],25,"\010compilercompiler-warning");
lf[14]=C_h_intern(&lf[14],6,"syntax");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\036(~a) in format string ~s~a, ~\077");
lf[16]=C_h_intern(&lf[16],17,"get-output-string");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\011 in line ");
lf[19]=C_h_intern(&lf[19],18,"open-output-string");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[21]=C_h_intern(&lf[21],17,"\010compilerget-line");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[23]=C_h_intern(&lf[23],20,"reverse-list->string");
lf[24]=C_h_intern(&lf[24],10,"\003sysappend");
lf[25]=C_h_intern(&lf[25],7,"reverse");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\0000too many arguments to formatted output procedure");
lf[27]=C_h_intern(&lf[27],16,"\003sysflush-output");
lf[28]=C_h_intern(&lf[28],9,"\003sysapply");
lf[29]=C_h_intern(&lf[29],10,"write-char");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000$illegal format-string character `~c\047");
lf[31]=C_h_intern(&lf[31],14,"number->string");
lf[32]=C_h_intern(&lf[32],3,"let");
lf[33]=C_h_intern(&lf[33],7,"fprintf");
lf[34]=C_h_intern(&lf[34],3,"out");
lf[35]=C_h_intern(&lf[35],5,"write");
lf[36]=C_h_intern(&lf[36],5,"cadar");
lf[37]=C_h_intern(&lf[37],4,"caar");
lf[38]=C_h_intern(&lf[38],5,"quote");
lf[39]=C_h_intern(&lf[39],7,"call/cc");
lf[40]=C_h_intern(&lf[40],6,"printf");
lf[41]=C_h_intern(&lf[41],19,"\003sysstandard-output");
lf[42]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006printf\376\003\000\000\002\376\001\000\000\010#%printf\376\377\016");
lf[43]=C_h_intern(&lf[43],19,"\003sysprimitive-alias");
lf[44]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007fprintf\376\003\000\000\002\376\001\000\000\011#%fprintf\376\377\016");
lf[45]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\377\016");
lf[46]=C_h_intern(&lf[46],7,"sprintf");
lf[47]=C_h_intern(&lf[47],6,"format");
lf[48]=C_h_intern(&lf[48],6,"gensym");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\003\000\000\002\376\001\000\000\006format\376\003\000\000\002\376\001\000\000\010#%format\376\377\016");
lf[50]=C_h_intern(&lf[50],1,"o");
lf[51]=C_h_intern(&lf[51],10,"fold-right");
lf[52]=C_h_intern(&lf[52],4,"list");
lf[53]=C_h_intern(&lf[53],6,"lambda");
lf[54]=C_h_intern(&lf[54],3,"tmp");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\003#%o\376\377\016");
lf[56]=C_h_intern(&lf[56],8,"\003sysslot");
lf[57]=C_h_intern(&lf[57],8,"\004coreapp");
lf[58]=C_h_intern(&lf[58],8,"for-each");
lf[59]=C_h_intern(&lf[59],17,"standard-bindings");
lf[60]=C_h_intern(&lf[60],5,"pair\077");
lf[61]=C_h_intern(&lf[61],5,"begin");
lf[62]=C_h_intern(&lf[62],3,"lst");
lf[63]=C_h_intern(&lf[63],4,"loop");
lf[64]=C_h_intern(&lf[64],2,"if");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\014\003sysfor-each\376\003\000\000\002\376\001\000\000\012#%for-each\376\377\016");
C_register_lf2(lf,66,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_374,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k372 */
static void C_ccall f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k375 in k372 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k378 in k375 in k372 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k381 in k378 in k375 in k372 */
static void C_ccall f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=C_set_block_item(lf[0] /* compiler-syntax-statistics */,0,C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[1]+1 /* (set! compiler-syntax-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_392,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! r-c-s ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_406,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1540,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1698,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t7,lf[60]);}

/* k1696 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1698,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[60],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
C_trace("##compiler#r-c-s");
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[65],((C_word*)t0)[2],t3);}

/* a1539 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1540,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1544,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("compiler-syntax.scm: 61   r");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[32]);}

/* k1542 in a1539 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1547,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("compiler-syntax.scm: 62   r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[64]);}

/* k1545 in k1542 in a1539 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("compiler-syntax.scm: 63   r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[63]);}

/* k1548 in k1545 in k1542 in a1539 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("compiler-syntax.scm: 64   r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[62]);}

/* k1551 in k1548 in k1545 in k1542 in a1539 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("compiler-syntax.scm: 65   r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[61]);}

/* k1554 in k1551 in k1548 in k1545 in k1542 in a1539 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("compiler-syntax.scm: 66   r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[60]);}

/* k1557 in k1554 in k1551 in k1548 in k1545 in k1542 in a1539 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_memq(lf[58],C_retrieve(lf[59])))){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=t2;
f_1565(t4,(C_word)C_eqp(C_fix(3),t3));}
else{
t3=t2;
f_1565(t3,C_SCHEME_FALSE);}}

/* k1563 in k1557 in k1554 in k1551 in k1548 in k1545 in k1542 in a1539 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_1565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[78],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1565,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_i_cadr(((C_word*)t0)[9]);
t9=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[56],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t8,t12);
t14=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[56],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t17);
t19=(C_word)C_a_i_cons(&a,2,lf[57],t18);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t13,t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t21);
t23=(C_word)C_a_i_cons(&a,2,t22,C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,t7,t23);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t5,t26);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t27);
t29=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t28));}
else{
t2=((C_word*)t0)[9];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_477,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1491,tmp=(C_word)a,a+=2,tmp);
C_trace("##compiler#r-c-s");
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),t2,lf[55],t3,C_SCHEME_END_OF_LIST);}

/* a1490 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1491,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_memq(lf[50],C_retrieve(lf[12])):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1501,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("compiler-syntax.scm: 79   r");
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[54]);}
else{
t8=t2;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* k1499 in a1490 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("compiler-syntax.scm: 80   r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k1506 in k1499 in a1490 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1524,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("compiler-syntax.scm: 80   fold-right");
((C_proc5)C_retrieve_symbol_proc(lf[51]))(5,*((C_word*)lf[51]+1),t3,*((C_word*)lf[52]+1),((C_word*)t0)[4],t4);}

/* k1522 in k1506 in k1499 in a1490 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_480,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1329,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1489,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t4,lf[17]);}

/* k1487 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[17],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[35]);}

/* k1483 in k1487 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1485,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[35],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[33]);}

/* k1479 in k1483 in k1487 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1481,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[31]);}

/* k1475 in k1479 in k1483 in k1487 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1477,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[29]);}

/* k1471 in k1475 in k1479 in k1483 in k1487 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1473,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[19]);}

/* k1467 in k1471 in k1475 in k1479 in k1483 in k1487 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1469,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[16]);}

/* k1463 in k1467 in k1471 in k1475 in k1479 in k1483 in k1487 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[16],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
C_trace("##compiler#r-c-s");
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[49],((C_word*)t0)[2],t9);}

/* a1328 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1329,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1333,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("compiler-syntax.scm: 85   gensym");
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t5,lf[34]);}

/* k1331 in a1328 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_memq(t3,lf[45]);
t5=(C_truep(t4)?lf[46]:lf[47]);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("compiler-syntax.scm: 86   compile-format-string");
((C_proc8)C_retrieve_symbol_proc(lf[11]))(8,*((C_word*)lf[11]+1),t2,t5,t1,((C_word*)t0)[3],t6,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1334 in k1331 in a1328 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("compiler-syntax.scm: 95   r");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[32]);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1344 in k1334 in k1331 in a1328 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1390,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("compiler-syntax.scm: 95   r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[19]);}

/* k1388 in k1344 in k1334 in k1331 in a1328 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1390,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("compiler-syntax.scm: 97   r");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[16]);}

/* k1368 in k1388 in k1344 in k1334 in k1331 in a1328 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1370,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_483,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1218,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1327,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t4,lf[17]);}

/* k1325 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1327,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[17],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[35]);}

/* k1321 in k1325 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[35],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[33]);}

/* k1317 in k1321 in k1325 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1319,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[31]);}

/* k1313 in k1317 in k1321 in k1325 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[29]);}

/* k1309 in k1313 in k1317 in k1321 in k1325 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[19]);}

/* k1305 in k1309 in k1313 in k1317 in k1321 in k1325 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[16]);}

/* k1301 in k1305 in k1309 in k1313 in k1317 in k1321 in k1325 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[16],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
C_trace("##compiler#r-c-s");
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[44],((C_word*)t0)[2],t9);}

/* a1217 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1218,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1228,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
t8=(C_word)C_i_cddr(t2);
C_trace("compiler-syntax.scm: 103  compile-format-string");
((C_proc8)C_retrieve_symbol_proc(lf[11]))(8,*((C_word*)lf[11]+1),t6,lf[33],t7,t2,t8,t3,t4);}
else{
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k1226 in a1217 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_486,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1121,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1216,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t4,lf[17]);}

/* k1214 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1216,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[17],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[35]);}

/* k1210 in k1214 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[35],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[33]);}

/* k1206 in k1210 in k1214 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1208,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[33],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[31]);}

/* k1202 in k1206 in k1210 in k1214 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1204,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[31],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[29]);}

/* k1198 in k1202 in k1206 in k1210 in k1214 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1200,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[19]);}

/* k1194 in k1198 in k1202 in k1206 in k1210 in k1214 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[19],t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
C_trace("##sys#primitive-alias");
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t3,lf[16]);}

/* k1190 in k1194 in k1198 in k1202 in k1206 in k1210 in k1214 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1192,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[16],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
C_trace("##compiler#r-c-s");
((C_proc5)C_retrieve_proc(*((C_word*)lf[5]+1)))(5,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[42],((C_word*)t0)[2],t9);}

/* a1120 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1121,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1125,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
C_trace("compiler-syntax.scm: 112  compile-format-string");
((C_proc8)C_retrieve_symbol_proc(lf[11]))(8,*((C_word*)lf[11]+1),t5,lf[40],lf[41],t2,t6,t3,t4);}

/* k1123 in a1120 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_486,2,t0,t1);}
t2=C_mutate((C_word*)lf[11]+1 /* (set! compile-format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_488,tmp=(C_word)a,a+=2,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=8) C_bad_argc_2(c,8,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_488,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_494,a[2]=t7,a[3]=t6,a[4]=t3,a[5]=t4,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
C_trace("compiler-syntax.scm: 119  call/cc");
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t1,t8);}

/* a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_494(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_494,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)t0)[7]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(1)))){
if(C_truep((C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[12])))){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_stringp(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_516,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_516(t7,t5);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1092,a[2]=((C_word*)t0)[7],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1103,a[2]=((C_word*)t0)[7],a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("compiler-syntax.scm: 125  r");
t10=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[38]);}
else{
t8=t6;
f_516(t8,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1101 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1107,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("compiler-syntax.scm: 125  caar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[37]+1)))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}

/* k1105 in k1101 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("compiler-syntax.scm: 125  c");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1090 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1092,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1099,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("compiler-syntax.scm: 126  cadar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_516(t2,C_SCHEME_FALSE);}}

/* k1097 in k1090 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_516(t2,(C_word)C_i_stringp(t1));}

/* k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_516(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_516,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_stringp(t3))){
t4=t2;
f_519(2,t4,(C_word)C_i_car(((C_word*)t0)[8]));}
else{
C_trace("compiler-syntax.scm: 127  cadar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[8]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_519,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_524,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_i_string_length(t1);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t10,a[6]=t7,a[7]=t5,a[8]=t4,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
C_trace("compiler-syntax.scm: 141  r");
t12=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,lf[17]);}

/* k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("compiler-syntax.scm: 142  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[35]);}

/* k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("compiler-syntax.scm: 143  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[29]);}

/* k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("compiler-syntax.scm: 144  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[34]);}

/* k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
C_trace("compiler-syntax.scm: 145  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[33]);}

/* k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
C_trace("compiler-syntax.scm: 146  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[32]);}

/* k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_577,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
C_trace("compiler-syntax.scm: 147  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[31]);}

/* k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_579,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_589,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_661,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_608,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_671,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=t2,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t5,a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[5],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[6],a[18]=((C_word*)t0)[7],a[19]=((C_word*)t0)[14],tmp=(C_word)a,a+=20,tmp));
t9=((C_word*)t7)[1];
f_671(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_671(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_671,NULL,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[19])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[18]))){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_681,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t1,a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[12])[1]))){
t5=t4;
f_681(2,t5,C_SCHEME_UNDEFINED);}
else{
C_trace("compiler-syntax.scm: 169  fail");
t5=((C_word*)t0)[11];
f_524(t5,t4,C_SCHEME_FALSE,lf[26],C_SCHEME_END_OF_LIST);}}
else{
t4=f_579(((C_word*)t0)[10]);
t5=(C_word)C_eqp(t4,C_make_character(126));
if(C_truep(t5)){
t6=f_579(((C_word*)t0)[10]);
t7=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_732,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[16],a[13]=t1,a[14]=((C_word*)t0)[9],a[15]=t6,tmp=(C_word)a,a+=16,tmp);
C_trace("compiler-syntax.scm: 177  endchunk");
t8=((C_word*)t0)[13];
f_608(t8,t7,t2);}
else{
t6=(C_word)C_a_i_cons(&a,2,t4,t2);
C_trace("compiler-syntax.scm: 200  loop");
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k730 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_732,2,t0,t1);}
t2=(C_word)C_u_i_char_upcase(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_738,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
switch(t2){
case C_make_character(83):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_759,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
C_trace("compiler-syntax.scm: 179  next");
t5=((C_word*)t0)[9];
f_589(t5,t4);
case C_make_character(65):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_784,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
C_trace("compiler-syntax.scm: 180  next");
t5=((C_word*)t0)[9];
f_589(t5,t4);
case C_make_character(67):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_809,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
C_trace("compiler-syntax.scm: 181  next");
t5=((C_word*)t0)[9];
f_589(t5,t4);
case C_make_character(66):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_846,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("compiler-syntax.scm: 182  next");
t5=((C_word*)t0)[9];
f_589(t5,t4);
case C_make_character(79):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_883,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("compiler-syntax.scm: 183  next");
t5=((C_word*)t0)[9];
f_589(t5,t4);
case C_make_character(88):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_920,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("compiler-syntax.scm: 184  next");
t5=((C_word*)t0)[9];
f_589(t5,t4);
case C_make_character(33):
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[27],t4);
t6=f_661(C_a_i(&a,3),((C_word*)t0)[10],t5);
C_trace("compiler-syntax.scm: 199  loop");
t7=((C_word*)((C_word*)t0)[14])[1];
f_671(t7,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
case C_make_character(63):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_950,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
C_trace("compiler-syntax.scm: 187  next");
t5=((C_word*)t0)[9];
f_589(t5,t4);
case C_make_character(126):
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_make_character(126),t4);
t6=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[29]+1),t5);
t7=f_661(C_a_i(&a,3),((C_word*)t0)[10],t6);
C_trace("compiler-syntax.scm: 199  loop");
t8=((C_word*)((C_word*)t0)[14])[1];
f_671(t8,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
default:
t4=(C_word)C_eqp(t2,C_make_character(37));
t5=(C_truep(t4)?t4:(C_word)C_eqp(t2,C_make_character(78)));
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_make_character(10),t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=f_661(C_a_i(&a,3),((C_word*)t0)[10],t8);
C_trace("compiler-syntax.scm: 199  loop");
t10=((C_word*)((C_word*)t0)[14])[1];
f_671(t10,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(((C_word*)t0)[15]))){
t6=f_579(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=f_1036(t7,t6);
C_trace("compiler-syntax.scm: 199  loop");
t9=((C_word*)((C_word*)t0)[14])[1];
f_671(t9,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);}
else{
C_trace("compiler-syntax.scm: 198  fail");
t6=((C_word*)t0)[2];
f_524(t6,t3,C_SCHEME_TRUE,lf[30],(C_word)C_a_i_list(&a,1,((C_word*)t0)[15]));}}}}

/* skip in k730 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static C_word C_fcall f_1036(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_579(((C_word*)t0)[3]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k948 in k730 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("compiler-syntax.scm: 188  next");
t3=((C_word*)t0)[2];
f_589(t3,t2);}

/* k951 in k948 in k730 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_953,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[28],t5);
t7=f_661(C_a_i(&a,3),((C_word*)t0)[4],t6);
C_trace("compiler-syntax.scm: 199  loop");
t8=((C_word*)((C_word*)t0)[3])[1];
f_671(t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k918 in k730 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_920,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(16),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=f_661(C_a_i(&a,3),((C_word*)t0)[4],t7);
C_trace("compiler-syntax.scm: 199  loop");
t9=((C_word*)((C_word*)t0)[3])[1];
f_671(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k881 in k730 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_883,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(8),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=f_661(C_a_i(&a,3),((C_word*)t0)[4],t7);
C_trace("compiler-syntax.scm: 199  loop");
t9=((C_word*)((C_word*)t0)[3])[1];
f_671(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k844 in k730 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_846,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(2),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=f_661(C_a_i(&a,3),((C_word*)t0)[4],t7);
C_trace("compiler-syntax.scm: 199  loop");
t9=((C_word*)((C_word*)t0)[3])[1];
f_671(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k807 in k730 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_809,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=f_661(C_a_i(&a,3),((C_word*)t0)[4],t4);
C_trace("compiler-syntax.scm: 199  loop");
t6=((C_word*)((C_word*)t0)[3])[1];
f_671(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k782 in k730 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_784,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=f_661(C_a_i(&a,3),((C_word*)t0)[4],t4);
C_trace("compiler-syntax.scm: 199  loop");
t6=((C_word*)((C_word*)t0)[3])[1];
f_671(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k757 in k730 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_759,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=f_661(C_a_i(&a,3),((C_word*)t0)[4],t4);
C_trace("compiler-syntax.scm: 199  loop");
t6=((C_word*)((C_word*)t0)[3])[1];
f_671(t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k736 in k730 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("compiler-syntax.scm: 199  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_671(t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k679 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_684,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
C_trace("compiler-syntax.scm: 170  endchunk");
t3=((C_word*)t0)[3];
f_608(t3,t2,((C_word*)t0)[2]);}

/* k682 in k679 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_684,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_699,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_703,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("compiler-syntax.scm: 172  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),t6,((C_word*)((C_word*)t0)[2])[1]);}

/* k701 in k682 in k679 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k697 in k682 in k679 in loop in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_699,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* endchunk in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_608(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_608,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
C_trace("compiler-syntax.scm: 160  push");
t9=t1;
((C_proc2)C_retrieve_proc(t9))(2,t9,f_661(C_a_i(&a,3),((C_word*)t0)[3],t8));}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_651,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("compiler-syntax.scm: 163  reverse-list->string");
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t5,t2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k649 in endchunk in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_651,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
C_trace("compiler-syntax.scm: 160  push");
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,f_661(C_a_i(&a,3),((C_word*)t0)[2],t4));}

/* push in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static C_word C_fcall f_661(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}

/* next in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_589,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
C_trace("compiler-syntax.scm: 154  fail");
t2=((C_word*)t0)[2];
f_524(t2,t1,C_SCHEME_TRUE,lf[22],C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in k575 in k572 in k569 in k566 in k563 in k560 in k557 in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static C_word C_fcall f_579(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=(C_word)C_i_string_ref(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* fail in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_524(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_524,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_528,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
C_trace("compiler-syntax.scm: 130  get-line");
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t5,((C_word*)t0)[2]);}

/* k526 in fail in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_531,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_544,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[19]))(2,*((C_word*)lf[19]+1),t4);}
else{
C_trace("compiler-syntax.scm: 131  compiler-warning");
((C_proc9)C_retrieve_symbol_proc(lf[13]))(9,*((C_word*)lf[13]+1),t2,lf[14],lf[15],((C_word*)t0)[5],((C_word*)t0)[4],lf[20],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k542 in k526 in fail in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_547,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,lf[18],t1);}

/* k545 in k542 in k526 in fail in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k548 in k545 in k542 in k526 in fail in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k539 in k526 in fail in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("compiler-syntax.scm: 131  compiler-warning");
((C_proc9)C_retrieve_symbol_proc(lf[13]))(9,*((C_word*)lf[13]+1),((C_word*)t0)[6],lf[14],lf[15],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k529 in k526 in fail in k517 in k514 in a493 in ##compiler#compile-format-string in k484 in k481 in k478 in k475 in k472 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
C_trace("compiler-syntax.scm: 137  return");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#r-c-s in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_406r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_406r(t0,t1,t2,t3,t4);}}

static void C_ccall f_406r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_410,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_410(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_410(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[10],t4);}}}

/* k408 in ##compiler#r-c-s in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("compiler-syntax.scm: 46   ##sys#er-transformer");
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t2,((C_word*)t0)[2]);}

/* k450 in k408 in ##compiler#r-c-s in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_452,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_i_symbolp(((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]):((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_422,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_422(t8,((C_word*)t0)[2],t4);}

/* loop52 in k450 in k408 in ##compiler#r-c-s in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_422(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_422,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_435,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("compiler-syntax.scm: 49   ##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t4,t3,lf[7],((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k433 in loop52 in k450 in k408 in ##compiler#r-c-s in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_422(t3,((C_word*)t0)[2],t2);}

/* ##sys#compiler-syntax-hook in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_392,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_396,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("compiler-syntax.scm: 41   alist-ref");
((C_proc6)C_retrieve_symbol_proc(lf[3]))(6,*((C_word*)lf[3]+1),t4,t2,*((C_word*)lf[0]+1),*((C_word*)lf[4]+1),C_fix(0));}

/* k394 in ##sys#compiler-syntax-hook in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_400,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_fixnum_increase(t1);
C_trace("compiler-syntax.scm: 43   alist-update!");
((C_proc5)C_retrieve_symbol_proc(lf[2]))(5,*((C_word*)lf[2]+1),t2,((C_word*)t0)[2],t3,*((C_word*)lf[0]+1));}

/* k398 in k394 in ##sys#compiler-syntax-hook in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[0]+1 /* (set! compiler-syntax-statistics ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[108] = {
{"toplevel:compiler_syntax_scm",(void*)C_compiler_syntax_toplevel},
{"f_374:compiler_syntax_scm",(void*)f_374},
{"f_377:compiler_syntax_scm",(void*)f_377},
{"f_380:compiler_syntax_scm",(void*)f_380},
{"f_383:compiler_syntax_scm",(void*)f_383},
{"f_386:compiler_syntax_scm",(void*)f_386},
{"f_389:compiler_syntax_scm",(void*)f_389},
{"f_1698:compiler_syntax_scm",(void*)f_1698},
{"f_1540:compiler_syntax_scm",(void*)f_1540},
{"f_1544:compiler_syntax_scm",(void*)f_1544},
{"f_1547:compiler_syntax_scm",(void*)f_1547},
{"f_1550:compiler_syntax_scm",(void*)f_1550},
{"f_1553:compiler_syntax_scm",(void*)f_1553},
{"f_1556:compiler_syntax_scm",(void*)f_1556},
{"f_1559:compiler_syntax_scm",(void*)f_1559},
{"f_1565:compiler_syntax_scm",(void*)f_1565},
{"f_474:compiler_syntax_scm",(void*)f_474},
{"f_1491:compiler_syntax_scm",(void*)f_1491},
{"f_1501:compiler_syntax_scm",(void*)f_1501},
{"f_1508:compiler_syntax_scm",(void*)f_1508},
{"f_1524:compiler_syntax_scm",(void*)f_1524},
{"f_477:compiler_syntax_scm",(void*)f_477},
{"f_1489:compiler_syntax_scm",(void*)f_1489},
{"f_1485:compiler_syntax_scm",(void*)f_1485},
{"f_1481:compiler_syntax_scm",(void*)f_1481},
{"f_1477:compiler_syntax_scm",(void*)f_1477},
{"f_1473:compiler_syntax_scm",(void*)f_1473},
{"f_1469:compiler_syntax_scm",(void*)f_1469},
{"f_1465:compiler_syntax_scm",(void*)f_1465},
{"f_1329:compiler_syntax_scm",(void*)f_1329},
{"f_1333:compiler_syntax_scm",(void*)f_1333},
{"f_1336:compiler_syntax_scm",(void*)f_1336},
{"f_1346:compiler_syntax_scm",(void*)f_1346},
{"f_1390:compiler_syntax_scm",(void*)f_1390},
{"f_1370:compiler_syntax_scm",(void*)f_1370},
{"f_480:compiler_syntax_scm",(void*)f_480},
{"f_1327:compiler_syntax_scm",(void*)f_1327},
{"f_1323:compiler_syntax_scm",(void*)f_1323},
{"f_1319:compiler_syntax_scm",(void*)f_1319},
{"f_1315:compiler_syntax_scm",(void*)f_1315},
{"f_1311:compiler_syntax_scm",(void*)f_1311},
{"f_1307:compiler_syntax_scm",(void*)f_1307},
{"f_1303:compiler_syntax_scm",(void*)f_1303},
{"f_1218:compiler_syntax_scm",(void*)f_1218},
{"f_1228:compiler_syntax_scm",(void*)f_1228},
{"f_483:compiler_syntax_scm",(void*)f_483},
{"f_1216:compiler_syntax_scm",(void*)f_1216},
{"f_1212:compiler_syntax_scm",(void*)f_1212},
{"f_1208:compiler_syntax_scm",(void*)f_1208},
{"f_1204:compiler_syntax_scm",(void*)f_1204},
{"f_1200:compiler_syntax_scm",(void*)f_1200},
{"f_1196:compiler_syntax_scm",(void*)f_1196},
{"f_1192:compiler_syntax_scm",(void*)f_1192},
{"f_1121:compiler_syntax_scm",(void*)f_1121},
{"f_1125:compiler_syntax_scm",(void*)f_1125},
{"f_486:compiler_syntax_scm",(void*)f_486},
{"f_488:compiler_syntax_scm",(void*)f_488},
{"f_494:compiler_syntax_scm",(void*)f_494},
{"f_1103:compiler_syntax_scm",(void*)f_1103},
{"f_1107:compiler_syntax_scm",(void*)f_1107},
{"f_1092:compiler_syntax_scm",(void*)f_1092},
{"f_1099:compiler_syntax_scm",(void*)f_1099},
{"f_516:compiler_syntax_scm",(void*)f_516},
{"f_519:compiler_syntax_scm",(void*)f_519},
{"f_559:compiler_syntax_scm",(void*)f_559},
{"f_562:compiler_syntax_scm",(void*)f_562},
{"f_565:compiler_syntax_scm",(void*)f_565},
{"f_568:compiler_syntax_scm",(void*)f_568},
{"f_571:compiler_syntax_scm",(void*)f_571},
{"f_574:compiler_syntax_scm",(void*)f_574},
{"f_577:compiler_syntax_scm",(void*)f_577},
{"f_671:compiler_syntax_scm",(void*)f_671},
{"f_732:compiler_syntax_scm",(void*)f_732},
{"f_1036:compiler_syntax_scm",(void*)f_1036},
{"f_950:compiler_syntax_scm",(void*)f_950},
{"f_953:compiler_syntax_scm",(void*)f_953},
{"f_920:compiler_syntax_scm",(void*)f_920},
{"f_883:compiler_syntax_scm",(void*)f_883},
{"f_846:compiler_syntax_scm",(void*)f_846},
{"f_809:compiler_syntax_scm",(void*)f_809},
{"f_784:compiler_syntax_scm",(void*)f_784},
{"f_759:compiler_syntax_scm",(void*)f_759},
{"f_738:compiler_syntax_scm",(void*)f_738},
{"f_681:compiler_syntax_scm",(void*)f_681},
{"f_684:compiler_syntax_scm",(void*)f_684},
{"f_703:compiler_syntax_scm",(void*)f_703},
{"f_699:compiler_syntax_scm",(void*)f_699},
{"f_608:compiler_syntax_scm",(void*)f_608},
{"f_651:compiler_syntax_scm",(void*)f_651},
{"f_661:compiler_syntax_scm",(void*)f_661},
{"f_589:compiler_syntax_scm",(void*)f_589},
{"f_579:compiler_syntax_scm",(void*)f_579},
{"f_524:compiler_syntax_scm",(void*)f_524},
{"f_528:compiler_syntax_scm",(void*)f_528},
{"f_544:compiler_syntax_scm",(void*)f_544},
{"f_547:compiler_syntax_scm",(void*)f_547},
{"f_550:compiler_syntax_scm",(void*)f_550},
{"f_541:compiler_syntax_scm",(void*)f_541},
{"f_531:compiler_syntax_scm",(void*)f_531},
{"f_406:compiler_syntax_scm",(void*)f_406},
{"f_410:compiler_syntax_scm",(void*)f_410},
{"f_452:compiler_syntax_scm",(void*)f_452},
{"f_422:compiler_syntax_scm",(void*)f_422},
{"f_435:compiler_syntax_scm",(void*)f_435},
{"f_392:compiler_syntax_scm",(void*)f_392},
{"f_396:compiler_syntax_scm",(void*)f_396},
{"f_400:compiler_syntax_scm",(void*)f_400},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
