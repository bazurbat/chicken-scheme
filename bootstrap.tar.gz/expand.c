/* Generated from expand.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-28 22:53
   Version 4.1.4 - SVN rev. 15427
   linux-unix-gnu-x86 [ ptables applyhook ]
   compiled 2009-08-13 on x (Linux)
   command line: expand.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature debugbuild -scrutinize -types ./types.db -explicit-use -no-trace -output-file expand.c
   unit: expand
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[354];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,20),40,108,111,111,107,117,112,32,105,100,49,48,48,32,115,101,49,48,49,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,26),40,109,97,99,114,111,45,97,108,105,97,115,32,118,97,114,49,49,54,32,115,101,49,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,50,48,52,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,11),40,119,97,108,107,32,120,49,55,52,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,24),40,98,111,100,121,49,54,49,32,115,101,49,55,48,32,97,108,105,97,115,49,55,49,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,24),40,100,101,102,45,97,108,105,97,115,49,54,52,32,37,115,101,49,53,57,50,49,52,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,11),40,100,101,102,45,115,101,49,54,51,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,115,116,114,105,112,45,115,121,110,116,97,120,32,101,120,112,49,53,52,32,46,32,116,109,112,49,53,51,49,53,53,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,115,121,110,116,97,99,116,105,99,45,101,110,118,105,114,111,110,109,101,110,116,63,32,111,98,106,50,50,50,41,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,50,56,54,32,108,115,116,50,56,55,50,57,48,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,52),40,35,35,115,121,115,35,115,121,110,116,97,99,116,105,99,45,101,110,118,105,114,111,110,109,101,110,116,45,115,121,109,98,111,108,115,32,101,110,118,50,54,55,32,112,114,101,100,50,54,56,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,101,120,116,101,110,100,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,110,97,109,101,51,48,57,32,115,101,51,49,48,32,104,97,110,100,108,101,114,51,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,99,111,112,121,45,109,97,99,114,111,32,111,108,100,51,50,52,32,110,101,119,51,50,53,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,109,97,99,114,111,63,32,115,121,109,51,51,52,32,46,32,116,109,112,51,51,51,51,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,109,101,51,53,52,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,109,97,99,114,111,32,110,97,109,101,51,53,50,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,117,110,100,101,102,105,110,101,45,109,97,99,114,111,33,32,110,97,109,101,51,54,52,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,112,115,51,56,54,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,7),40,97,51,56,54,52,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,13),40,97,51,56,53,56,32,101,120,51,56,50,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,17),40,102,95,52,48,48,51,32,105,110,112,117,116,52,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,52,48,48,56,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,52,48,49,51,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,7),40,97,52,48,49,57,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,51,57,55,49,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,7),40,97,52,48,51,51,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,20),40,97,52,48,50,55,32,46,32,97,114,103,115,51,55,57,52,49,53,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,51,57,54,53,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,15),40,97,51,56,53,50,32,107,51,55,56,51,56,49,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,52),40,99,97,108,108,45,104,97,110,100,108,101,114,32,110,97,109,101,51,55,49,32,104,97,110,100,108,101,114,51,55,50,32,101,120,112,51,55,51,32,115,101,51,55,52,32,99,115,51,55,53,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,31),40,101,120,112,97,110,100,32,104,101,97,100,52,49,56,32,101,120,112,52,49,57,32,109,100,101,102,52,50,48,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,12),40,97,52,50,48,50,32,98,52,54,53,41,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,52,51,48,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,101,120,112,97,110,100,45,48,32,101,120,112,51,54,54,32,100,115,101,51,54,55,32,99,115,63,51,54,56,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,109,111,100,117,108,101,45,114,101,110,97,109,101,32,115,121,109,52,57,53,32,112,114,101,102,105,120,52,57,54,41,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,16),40,109,114,101,110,97,109,101,32,115,121,109,53,48,56,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,97,108,105,97,115,45,103,108,111,98,97,108,45,104,111,111,107,32,115,121,109,52,57,56,32,97,115,115,105,103,110,52,57,57,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,52,52,53,51,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,32),40,97,52,52,53,57,32,101,120,112,50,53,54,57,53,55,48,53,55,51,32,109,53,55,49,53,55,50,53,55,52,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,53,54,54,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,53,53,52,32,115,101,53,54,51,32,99,115,63,53,54,52,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,99,115,63,53,53,55,32,37,115,101,53,53,50,53,55,57,41,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,11),40,100,101,102,45,115,101,53,53,54,41,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,101,120,112,97,110,100,32,101,120,112,53,52,55,32,46,32,116,109,112,53,52,54,53,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,63,32,108,108,105,115,116,53,56,54,41,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,12),40,101,114,114,32,109,115,103,54,49,53,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,12),40,97,52,55,57,50,32,107,54,52,50,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,109,111,100,101,54,50,54,32,114,101,113,54,50,55,32,111,112,116,54,50,56,32,107,101,121,54,50,57,32,108,108,105,115,116,54,51,48,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,67),40,35,35,115,121,115,35,101,120,112,97,110,100,45,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,32,108,108,105,115,116,48,54,48,57,32,98,111,100,121,54,49,48,32,101,114,114,104,54,49,49,32,115,101,54,49,50,41,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,98,111,100,121,50,55,54,57,32,101,120,112,115,55,55,48,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,17),40,97,53,51,52,51,32,118,56,49,52,32,116,56,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,18),40,97,53,51,48,54,32,118,115,56,48,55,32,120,56,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,17),40,97,53,51,55,51,32,118,56,48,49,32,120,56,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,12),40,97,53,51,57,49,32,118,56,48,48,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,48),40,102,105,110,105,32,118,97,114,115,55,54,49,32,118,97,108,115,55,54,50,32,109,118,97,114,115,55,54,51,32,109,118,97,108,115,55,54,52,32,98,111,100,121,55,54,53,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,30),40,108,111,111,112,32,98,111,100,121,56,50,56,32,100,101,102,115,56,50,57,32,100,111,110,101,56,51,48,41,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,55),40,102,105,110,105,47,115,121,110,116,97,120,32,118,97,114,115,56,50,50,32,118,97,108,115,56,50,51,32,109,118,97,114,115,56,50,52,32,109,118,97,108,115,56,50,53,32,98,111,100,121,56,50,54,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,50,32,120,56,56,56,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,48),40,108,111,111,112,32,98,111,100,121,56,54,48,32,118,97,114,115,56,54,49,32,118,97,108,115,56,54,50,32,109,118,97,114,115,56,54,51,32,109,118,97,108,115,56,54,52,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,98,111,100,121,56,53,56,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,55,52,55,32,115,101,55,53,54,32,99,115,63,55,53,55,41,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,99,115,63,55,53,48,32,37,115,101,55,52,53,57,49,57,41,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,11),40,100,101,102,45,115,101,55,52,57,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,99,97,110,111,110,105,99,97,108,105,122,101,45,98,111,100,121,32,98,111,100,121,55,52,48,32,46,32,116,109,112,55,51,57,55,52,49,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,17),40,109,119,97,108,107,32,120,57,51,50,32,112,57,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,40),40,109,97,116,99,104,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,57,50,53,32,112,97,116,57,50,54,32,118,97,114,115,57,50,55,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,104,101,97,100,57,53,57,32,98,111,100,121,57,54,48,41,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,51),40,35,35,115,121,115,35,101,120,112,97,110,100,45,99,117,114,114,105,101,100,45,100,101,102,105,110,101,32,104,101,97,100,57,53,52,32,98,111,100,121,57,53,53,32,115,101,57,53,54,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,45,104,111,111,107,32,46,32,97,114,103,115,57,55,51,41,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,115,121,110,116,97,120,45,114,117,108,101,115,45,109,105,115,109,97,116,99,104,32,105,110,112,117,116,57,55,53,41,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,25),40,103,101,116,45,108,105,110,101,45,110,117,109,98,101,114,32,115,101,120,112,57,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,13),40,101,114,114,32,109,115,103,49,48,51,56,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,29),40,116,101,115,116,32,120,49,48,51,51,32,112,114,101,100,49,48,51,52,32,109,115,103,49,48,51,53,41,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,49,48,52,57,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,20),40,108,97,109,98,100,97,45,108,105,115,116,63,32,120,49,48,52,50,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,20),40,112,114,111,112,101,114,45,108,105,115,116,63,32,120,49,48,54,53,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,49,48,48,32,120,49,49,48,52,32,110,49,49,48,53,41};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,97,54,52,55,51,32,121,49,49,49,57,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,48,56,49,32,112,49,48,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,49,48,49,54,32,99,117,108,112,114,105,116,49,48,50,53,32,115,101,49,48,50,54,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,101,49,48,49,57,32,37,99,117,108,112,114,105,116,49,48,49,52,49,49,51,49,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,99,117,108,112,114,105,116,49,48,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,99,104,101,99,107,45,115,121,110,116,97,120,32,105,100,49,48,48,55,32,101,120,112,49,48,48,56,32,112,97,116,49,48,48,57,32,46,32,116,109,112,49,48,48,54,49,48,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,28),40,101,114,45,109,97,99,114,111,45,116,114,97,110,115,102,111,114,109,101,114,32,120,49,49,51,56,41,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,16),40,114,101,110,97,109,101,32,115,121,109,49,49,52,55,41};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,23),40,99,111,109,112,97,114,101,32,115,49,49,49,55,55,32,115,50,49,49,55,56,41,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,32),40,102,95,54,54,48,54,32,102,111,114,109,49,49,52,48,32,115,101,49,49,52,49,32,100,115,101,49,49,52,50,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,101,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,49,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,17),40,114,101,115,111,108,118,101,32,115,121,109,49,50,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,13),40,116,111,115,116,114,32,120,49,50,55,49,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,10),40,115,119,97,112,49,50,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,7),40,97,54,57,51,50,41,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,110,97,109,101,32,115,112,101,99,49,50,55,56,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,105,100,115,49,51,53,57,32,118,49,51,54,48,32,115,49,51,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,115,49,51,56,54,32,115,49,51,56,55,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,118,49,51,55,55,32,118,49,51,55,56,41,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,49,52,49,57,32,108,115,116,49,52,50,48,49,52,50,51,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,105,109,112,118,49,51,57,56,32,105,109,112,115,49,51,57,57,32,118,49,52,48,48,32,115,49,52,48,49,32,105,100,115,49,52,48,50,41,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,13),40,114,101,110,32,105,109,112,49,52,51,54,41,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,115,112,101,99,32,115,112,101,99,49,51,51,52,41,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,49,52,55,53,32,108,115,116,49,52,55,54,49,52,55,57,41,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,49,52,53,57,32,108,115,116,49,52,54,48,49,52,54,51,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,49,52,52,52,32,108,115,116,49,52,52,53,49,52,52,56,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,86),40,35,35,115,121,115,35,101,120,112,97,110,100,45,105,109,112,111,114,116,32,120,49,50,53,48,32,114,49,50,53,49,32,99,49,50,53,50,32,105,109,112,111,114,116,45,101,110,118,49,50,53,51,32,109,97,99,114,111,45,101,110,118,49,50,53,52,32,109,101,116,97,63,49,50,53,53,32,108,111,99,49,50,53,54,41,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,14),40,102,95,55,56,48,52,32,120,50,48,51,48,41,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,18),40,102,95,55,56,49,48,32,114,117,108,101,115,50,48,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,13),40,97,55,57,52,57,32,120,50,48,52,55,41,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,17),40,102,95,55,57,48,48,32,114,117,108,101,50,48,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,30),40,102,95,55,57,56,52,32,105,110,112,117,116,50,48,52,56,32,112,97,116,116,101,114,110,50,48,52,57,41,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,30),40,102,95,56,50,48,53,32,105,110,112,117,116,50,48,57,52,32,112,97,116,116,101,114,110,50,48,57,53,41,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,49,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,30),40,102,95,56,51,50,55,32,105,110,112,117,116,50,49,48,57,32,112,97,116,116,101,114,110,50,49,49,48,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,13),40,97,56,54,53,51,32,120,50,49,54,48,41,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,49,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,39),40,102,95,56,54,49,53,32,112,97,116,116,101,114,110,50,49,53,49,32,112,97,116,104,50,49,53,50,32,109,97,112,105,116,50,49,53,51,41,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,50,50,50,55,32,100,50,50,51,49,32,103,101,110,50,50,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,37),40,102,95,56,56,50,50,32,116,101,109,112,108,97,116,101,50,49,57,53,32,100,105,109,50,49,57,54,32,101,110,118,50,49,57,55,41,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,37),40,102,95,57,48,55,54,32,112,97,116,116,101,114,110,50,50,53,52,32,100,105,109,50,50,53,53,32,118,97,114,115,50,50,53,54,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,46),40,102,95,57,49,52,57,32,116,101,109,112,108,97,116,101,50,50,54,51,32,100,105,109,50,50,54,52,32,101,110,118,50,50,54,53,32,102,114,101,101,50,50,54,54,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,20),40,102,95,57,50,52,50,32,112,97,116,116,101,114,110,50,50,55,56,41,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,20),40,102,95,57,50,54,52,32,112,97,116,116,101,114,110,50,50,56,54,41,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,20),40,102,95,57,50,57,48,32,112,97,116,116,101,114,110,50,50,57,49,41,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,97,116,116,101,114,110,50,50,57,52,41,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,49,48,32,112,97,116,116,101,114,110,50,50,57,50,41,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,79),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,115,121,110,116,97,120,45,114,117,108,101,115,32,101,108,108,105,112,115,105,115,49,57,55,50,32,114,117,108,101,115,49,57,55,51,32,115,117,98,107,101,121,119,111,114,100,115,49,57,55,52,32,114,49,57,55,53,32,99,49,57,55,54,41,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,50,51,54,56,41,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,109,97,99,114,111,45,115,117,98,115,101,116,32,109,101,48,50,51,53,57,32,46,32,116,109,112,50,51,53,56,50,51,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,50,51,57,50,32,108,115,116,50,51,57,51,50,51,57,54,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,52),40,35,35,115,121,115,35,102,105,120,117,112,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,115,101,50,51,56,50,32,46,32,116,109,112,50,51,56,49,50,51,56,51,41,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,23),40,109,111,100,117,108,101,45,110,97,109,101,32,120,50,52,48,56,50,52,50,52,41,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,48),40,115,101,116,45,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,52,48,56,50,52,53,49,32,121,50,52,48,57,50,52,53,50,41};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,32,120,50,52,48,56,50,52,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,109,111,100,117,108,101,45,101,120,112,111,114,116,115,32,109,50,53,48,57,41,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,102,105,110,100,45,109,111,100,117,108,101,32,110,97,109,101,50,53,50,50,32,46,32,116,109,112,50,53,50,49,50,53,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,64),40,35,35,115,121,115,35,116,111,112,108,101,118,101,108,45,100,101,102,105,110,105,116,105,111,110,45,104,111,111,107,32,115,121,109,50,53,51,56,32,109,111,100,50,53,51,57,32,101,120,112,50,53,52,48,32,118,97,108,50,53,52,49,41};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,50,53,52,51,41};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,42),40,99,104,101,99,107,45,102,111,114,45,114,101,100,101,102,32,115,121,109,50,53,52,57,32,101,110,118,50,53,53,48,32,115,101,110,118,50,53,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,101,120,112,111,114,116,32,115,121,109,50,53,54,50,32,109,111,100,50,53,54,51,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,115,121,110,116,97,120,45,101,120,112,111,114,116,32,115,121,109,50,53,56,52,32,109,111,100,50,53,56,53,32,118,97,108,50,53,56,54,41,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,117,110,100,101,102,105,110,101,100,32,115,121,109,50,54,48,55,32,109,111,100,50,54,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,50,54,50,57,32,115,101,120,112,111,114,116,115,50,54,51,57,41,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,18),40,100,101,102,45,115,101,120,112,111,114,116,115,50,54,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,58),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,32,110,97,109,101,50,54,50,49,32,101,120,112,108,105,115,116,50,54,50,50,32,46,32,116,109,112,50,54,50,48,50,54,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,50,54,53,51,32,108,115,116,50,54,53,52,50,54,53,55,41,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,109,97,114,107,45,105,109,112,111,114,116,101,100,45,115,121,109,98,111,108,115,32,115,101,50,54,53,48,41,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,21),40,119,97,114,110,32,109,115,103,50,54,56,55,32,105,100,50,54,56,56,41,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,50,32,105,101,120,112,111,114,116,115,50,54,57,56,41,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,101,120,112,111,114,116,115,50,54,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,105,110,100,105,114,101,99,116,45,101,120,112,111,114,116,115,32,109,111,100,50,54,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,101,50,55,51,52,41,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,18),40,109,101,114,103,101,45,115,101,32,115,101,115,50,55,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,100,50,55,57,52,41,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,20),40,97,49,48,54,54,57,32,115,101,120,112,111,114,116,50,55,55,51,41,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,52,49,32,105,101,50,55,54,52,41,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,45,114,101,103,105,115,116,114,97,116,105,111,110,32,109,111,100,50,55,52,54,41,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,10),40,108,111,111,112,50,56,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,10),40,108,111,111,112,50,56,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,10),40,108,111,111,112,50,56,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,15),40,97,49,49,48,51,57,32,110,101,50,56,51,53,41,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,15),40,97,49,49,48,53,55,32,105,101,50,56,51,51,41,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,15),40,97,49,49,48,56,57,32,115,101,50,56,51,49,41,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,94),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,32,110,97,109,101,50,56,49,52,32,105,101,120,112,111,114,116,115,50,56,49,53,32,118,101,120,112,111,114,116,115,50,56,49,54,32,115,101,120,112,111,114,116,115,50,56,49,55,32,46,32,116,109,112,50,56,49,51,50,56,49,56,41,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,112,114,105,109,105,116,105,118,101,45,97,108,105,97,115,32,115,121,109,50,56,55,55,41,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,15),40,97,49,49,49,56,48,32,115,101,50,56,57,57,41,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,15),40,97,49,49,49,57,56,32,118,101,50,56,57,56,41,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,69),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,105,109,105,116,105,118,101,45,109,111,100,117,108,101,32,110,97,109,101,50,56,56,55,32,118,101,120,112,111,114,116,115,50,56,56,56,32,46,32,116,109,112,50,56,56,54,50,56,56,57,41,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,50,57,49,50,41,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,102,105,110,100,45,101,120,112,111,114,116,32,115,121,109,50,57,48,55,32,109,111,100,50,57,48,56,32,105,110,100,105,114,101,99,116,50,57,48,57,41};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,51,48,50,48,32,108,115,116,51,48,50,49,51,48,50,52,41,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,16),40,97,49,49,52,49,51,32,101,120,112,51,48,48,53,41};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,50,57,57,53,41,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,50,57,56,50,32,108,115,116,50,57,56,51,50,57,56,54,41,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,50,57,53,57,41,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,50,57,52,57,41,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,16),40,97,49,49,55,51,49,32,115,121,109,50,57,52,54,41};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,110,97,108,105,122,101,45,109,111,100,117,108,101,32,109,111,100,50,57,51,56,41,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,28),40,97,49,49,55,54,50,32,101,120,112,49,57,53,56,32,114,49,57,53,57,32,99,49,57,54,48,41,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,49,57,51,51,32,108,115,116,49,57,51,52,49,57,51,55,41,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,57,57,32,120,49,57,50,52,32,114,49,57,50,53,32,99,49,57,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,26),40,97,49,49,57,49,56,32,120,49,57,49,49,32,114,49,57,49,50,32,99,49,57,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,26),40,97,49,49,57,54,50,32,120,49,57,48,51,32,114,49,57,48,52,32,99,49,57,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,26),40,97,49,50,48,49,51,32,120,49,56,57,53,32,114,49,56,57,54,32,99,49,56,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,26),40,97,49,50,48,51,52,32,120,49,56,56,55,32,114,49,56,56,56,32,99,49,56,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,11),40,101,114,114,32,120,49,56,49,57,41,0,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,13),40,116,101,115,116,32,102,120,49,56,50,48,41,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,14),40,97,49,50,50,52,57,32,120,49,56,54,53,41,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,99,108,115,49,56,53,56,41};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,29),40,97,49,50,48,53,53,32,102,111,114,109,49,56,48,57,32,114,49,56,49,48,32,99,49,56,49,49,41,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,29),40,97,49,50,51,51,54,32,102,111,114,109,49,56,48,49,32,114,49,56,48,50,32,99,49,56,48,51,41,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,55,49,52,32,110,49,55,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,19),40,119,97,108,107,49,32,120,49,55,49,54,32,110,49,55,49,55,41,0,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,16),40,115,105,109,112,108,105,102,121,32,120,49,55,55,52,41};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,29),40,97,49,50,51,54,57,32,102,111,114,109,49,55,48,52,32,114,49,55,48,53,32,99,49,55,48,54,41,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,14),40,97,49,50,56,54,54,32,98,49,55,48,50,41,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,14),40,97,49,50,57,50,49,32,98,49,54,57,50,41,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,29),40,97,49,50,55,54,52,32,102,111,114,109,49,54,55,57,32,114,49,54,56,48,32,99,49,54,56,49,41,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,15),40,101,120,112,97,110,100,32,98,115,49,54,54,56,41,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,29),40,97,49,50,57,52,51,32,102,111,114,109,49,54,54,49,32,114,49,54,54,50,32,99,49,54,54,51,41,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,14),40,97,49,51,49,51,51,32,120,49,54,53,51,41,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,54,52,50,41,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,29),40,97,49,51,48,49,50,32,102,111,114,109,49,54,50,56,32,114,49,54,50,57,32,99,49,54,51,48,41,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,53,57,49,41,0,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,29),40,97,49,51,49,55,57,32,102,111,114,109,49,53,56,48,32,114,49,53,56,49,32,99,49,53,56,50,41,0,0,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,29),40,97,49,51,53,48,57,32,102,111,114,109,49,53,54,57,32,114,49,53,55,48,32,99,49,53,55,49,41,0,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,29),40,97,49,51,53,57,57,32,102,111,114,109,49,53,53,57,32,114,49,53,54,48,32,99,49,53,54,49,41,0,0,0};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,102,111,114,109,49,53,51,51,41,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,29),40,97,49,51,54,53,56,32,102,111,114,109,49,53,50,57,32,114,49,53,51,48,32,99,49,53,51,49,41,0,0,0};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,50),40,97,49,51,56,48,48,32,103,49,53,50,48,49,53,50,49,49,53,50,54,32,103,49,53,50,50,49,53,50,51,49,53,50,55,32,103,49,53,50,52,49,53,50,53,49,53,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,50),40,97,49,51,56,49,48,32,103,49,53,48,55,49,53,48,56,49,53,49,51,32,103,49,53,48,57,49,53,49,48,49,53,49,52,32,103,49,53,49,49,49,53,49,50,49,53,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_expand_toplevel)
C_externexport void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13811)
static void C_ccall f_13811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13809)
static void C_ccall f_13809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7651)
static void C_ccall f_7651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13801)
static void C_ccall f_13801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13799)
static void C_ccall f_13799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7654)
static void C_ccall f_7654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7658)
static void C_ccall f_7658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13659)
static void C_ccall f_13659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13669)
static void C_fcall f_13669(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13685)
static void C_ccall f_13685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13688)
static void C_ccall f_13688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13716)
static void C_ccall f_13716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13691)
static void C_ccall f_13691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13738)
static void C_ccall f_13738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13741)
static void C_ccall f_13741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13787)
static void C_ccall f_13787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13744)
static void C_ccall f_13744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13767)
static void C_ccall f_13767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13779)
static void C_ccall f_13779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13725)
static void C_ccall f_13725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13728)
static void C_ccall f_13728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13735)
static void C_ccall f_13735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13657)
static void C_ccall f_13657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7661)
static void C_ccall f_7661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13600)
static void C_ccall f_13600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13629)
static void C_ccall f_13629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13649)
static void C_ccall f_13649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13653)
static void C_ccall f_13653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13598)
static void C_ccall f_13598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7664)
static void C_ccall f_7664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13510)
static void C_ccall f_13510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13535)
static void C_ccall f_13535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13542)
static void C_ccall f_13542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13562)
static void C_ccall f_13562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13582)
static void C_ccall f_13582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13586)
static void C_ccall f_13586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13508)
static void C_ccall f_13508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7667)
static void C_ccall f_7667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13180)
static void C_ccall f_13180(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13187)
static void C_ccall f_13187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13190)
static void C_ccall f_13190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13193)
static void C_ccall f_13193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13196)
static void C_ccall f_13196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13199)
static void C_ccall f_13199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13202)
static void C_ccall f_13202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13207)
static void C_fcall f_13207(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13223)
static void C_ccall f_13223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13229)
static void C_ccall f_13229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13271)
static void C_ccall f_13271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13339)
static void C_ccall f_13339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13464)
static void C_ccall f_13464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13460)
static void C_ccall f_13460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13342)
static void C_ccall f_13342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13397)
static void C_ccall f_13397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13274)
static void C_ccall f_13274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13313)
static void C_ccall f_13313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13265)
static void C_ccall f_13265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13236)
static void C_ccall f_13236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13178)
static void C_ccall f_13178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7670)
static void C_ccall f_7670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13013)
static void C_ccall f_13013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13017)
static void C_ccall f_13017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13026)
static void C_ccall f_13026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13029)
static void C_ccall f_13029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13032)
static void C_ccall f_13032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13035)
static void C_ccall f_13035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13056)
static void C_fcall f_13056(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13072)
static void C_ccall f_13072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13078)
static void C_ccall f_13078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13134)
static void C_ccall f_13134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13132)
static void C_ccall f_13132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13128)
static void C_ccall f_13128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13120)
static void C_ccall f_13120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13116)
static void C_ccall f_13116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13085)
static void C_ccall f_13085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13054)
static void C_ccall f_13054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13011)
static void C_ccall f_13011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7673)
static void C_ccall f_7673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12944)
static void C_ccall f_12944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12948)
static void C_ccall f_12948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12957)
static void C_ccall f_12957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12962)
static void C_fcall f_12962(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12999)
static void C_ccall f_12999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12980)
static void C_ccall f_12980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12942)
static void C_ccall f_12942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7676)
static void C_ccall f_7676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12765)
static void C_ccall f_12765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12769)
static void C_ccall f_12769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12781)
static void C_ccall f_12781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12784)
static void C_ccall f_12784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12787)
static void C_ccall f_12787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12922)
static void C_ccall f_12922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12802)
static void C_ccall f_12802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12920)
static void C_ccall f_12920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12829)
static void C_fcall f_12829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12910)
static void C_ccall f_12910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12845)
static void C_fcall f_12845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12867)
static void C_ccall f_12867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12865)
static void C_ccall f_12865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12861)
static void C_ccall f_12861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12763)
static void C_ccall f_12763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12370)
static void C_ccall f_12370(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12374)
static void C_ccall f_12374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12377)
static void C_ccall f_12377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12380)
static void C_ccall f_12380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12383)
static void C_ccall f_12383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12752)
static void C_ccall f_12752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12664)
static void C_fcall f_12664(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12668)
static void C_ccall f_12668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12693)
static void C_ccall f_12693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12739)
static void C_ccall f_12739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12724)
static void C_ccall f_12724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12395)
static void C_fcall f_12395(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12442)
static void C_ccall f_12442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12489)
static void C_ccall f_12489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12650)
static void C_ccall f_12650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12658)
static void C_ccall f_12658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12636)
static void C_ccall f_12636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12625)
static void C_ccall f_12625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12633)
static void C_ccall f_12633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12610)
static void C_ccall f_12610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12598)
static void C_ccall f_12598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12579)
static void C_ccall f_12579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12537)
static void C_ccall f_12537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12514)
static void C_ccall f_12514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12468)
static void C_ccall f_12468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12417)
static void C_ccall f_12417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12413)
static void C_ccall f_12413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12385)
static void C_fcall f_12385(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12393)
static void C_ccall f_12393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12368)
static void C_ccall f_12368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7682)
static void C_ccall f_7682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12337)
static void C_ccall f_12337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12341)
static void C_ccall f_12341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12335)
static void C_ccall f_12335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7685)
static void C_ccall f_7685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12056)
static void C_ccall f_12056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12063)
static void C_ccall f_12063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12066)
static void C_ccall f_12066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12069)
static void C_ccall f_12069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12072)
static void C_ccall f_12072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12234)
static void C_fcall f_12234(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12287)
static void C_ccall f_12287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12309)
static void C_ccall f_12309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12316)
static void C_ccall f_12316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12303)
static void C_ccall f_12303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12250)
static void C_ccall f_12250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12248)
static void C_ccall f_12248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12084)
static void C_fcall f_12084(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12115)
static void C_ccall f_12115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12161)
static void C_ccall f_12161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12211)
static void C_ccall f_12211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12218)
static void C_ccall f_12218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12176)
static void C_ccall f_12176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12190)
static void C_ccall f_12190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12133)
static void C_ccall f_12133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12144)
static void C_ccall f_12144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12074)
static void C_fcall f_12074(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12054)
static void C_ccall f_12054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7688)
static void C_ccall f_7688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12035)
static void C_ccall f_12035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12033)
static void C_ccall f_12033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7691)
static void C_ccall f_7691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12014)
static void C_ccall f_12014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12012)
static void C_ccall f_12012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7694)
static void C_ccall f_7694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11963)
static void C_ccall f_11963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11967)
static void C_ccall f_11967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12004)
static void C_ccall f_12004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11990)
static void C_ccall f_11990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11961)
static void C_ccall f_11961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7697)
static void C_ccall f_7697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11919)
static void C_ccall f_11919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11923)
static void C_ccall f_11923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11953)
static void C_ccall f_11953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11926)
static void C_ccall f_11926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11941)
static void C_ccall f_11941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11917)
static void C_ccall f_11917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7700)
static void C_ccall f_7700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11800)
static void C_ccall f_11800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11807)
static void C_ccall f_11807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11810)
static void C_ccall f_11810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11830)
static void C_fcall f_11830(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11868)
static C_word C_fcall f_11868(C_word t0);
C_noret_decl(f_11853)
static void C_fcall f_11853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11843)
static void C_ccall f_11843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11813)
static void C_ccall f_11813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11828)
static void C_ccall f_11828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11820)
static void C_ccall f_11820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11816)
static void C_ccall f_11816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11798)
static void C_ccall f_11798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11763)
static void C_ccall f_11763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11767)
static void C_ccall f_11767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11785)
static void C_ccall f_11785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11761)
static void C_ccall f_11761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7706)
static void C_ccall f_7706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11757)
static void C_ccall f_11757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9504)
static void C_ccall f_9504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11753)
static void C_ccall f_11753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9508)
static void C_ccall f_9508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11319)
static void C_ccall f_11319(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11732)
static void C_ccall f_11732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11744)
static void C_ccall f_11744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11335)
static void C_ccall f_11335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11689)
static void C_ccall f_11689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11691)
static void C_fcall f_11691(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11730)
static void C_ccall f_11730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11704)
static void C_ccall f_11704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11715)
static void C_ccall f_11715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11338)
static void C_ccall f_11338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11562)
static void C_fcall f_11562(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11613)
static void C_fcall f_11613(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11663)
static void C_ccall f_11663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11625)
static void C_fcall f_11625(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11649)
static void C_ccall f_11649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11645)
static void C_ccall f_11645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11641)
static void C_ccall f_11641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11610)
static void C_ccall f_11610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11595)
static void C_fcall f_11595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11599)
static void C_ccall f_11599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11341)
static void C_ccall f_11341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11457)
static void C_ccall f_11457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11459)
static void C_fcall f_11459(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11486)
static void C_ccall f_11486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11489)
static void C_ccall f_11489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11526)
static void C_fcall f_11526(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11552)
static void C_ccall f_11552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11540)
static void C_ccall f_11540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11544)
static void C_ccall f_11544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11524)
static void C_ccall f_11524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11520)
static void C_ccall f_11520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11513)
static void C_ccall f_11513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11509)
static void C_ccall f_11509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11505)
static void C_ccall f_11505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11472)
static void C_ccall f_11472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11344)
static void C_ccall f_11344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11347)
static void C_ccall f_11347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11450)
static void C_ccall f_11450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11414)
static void C_ccall f_11414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11442)
static void C_ccall f_11442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11350)
static void C_ccall f_11350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11408)
static void C_ccall f_11408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11412)
static void C_ccall f_11412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11353)
static void C_ccall f_11353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11356)
static void C_ccall f_11356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11370)
static void C_fcall f_11370(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11383)
static void C_ccall f_11383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11359)
static void C_ccall f_11359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11365)
static void C_ccall f_11365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11234)
static void C_ccall f_11234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11245)
static void C_ccall f_11245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11247)
static void C_fcall f_11247(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11296)
static void C_ccall f_11296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11292)
static void C_ccall f_11292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11275)
static void C_fcall f_11275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11153)
static void C_ccall f_11153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11153)
static void C_ccall f_11153r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11157)
static void C_ccall f_11157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11160)
static void C_ccall f_11160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11199)
static void C_ccall f_11199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11213)
static void C_ccall f_11213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11175)
static void C_ccall f_11175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11181)
static void C_ccall f_11181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11179)
static void C_ccall f_11179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11136)
static void C_ccall f_11136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11147)
static void C_ccall f_11147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11140)
static void C_ccall f_11140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11143)
static void C_ccall f_11143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10877)
static void C_ccall f_10877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_10877)
static void C_ccall f_10877r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_10881)
static void C_ccall f_10881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11090)
static void C_ccall f_11090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11111)
static void C_ccall f_11111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10907)
static void C_ccall f_10907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10910)
static void C_ccall f_10910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11058)
static void C_ccall f_11058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11080)
static void C_ccall f_11080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10913)
static void C_ccall f_10913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11040)
static void C_ccall f_11040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11052)
static void C_ccall f_11052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10916)
static void C_ccall f_10916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11034)
static void C_ccall f_11034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11038)
static void C_ccall f_11038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10922)
static void C_ccall f_10922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10925)
static void C_ccall f_10925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10944)
static C_word C_fcall f_10944(C_word t0,C_word t1);
C_noret_decl(f_10970)
static C_word C_fcall f_10970(C_word t0,C_word t1);
C_noret_decl(f_11006)
static C_word C_fcall f_11006(C_word t0,C_word t1);
C_noret_decl(f_10483)
static void C_ccall f_10483(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10875)
static void C_ccall f_10875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10506)
static void C_fcall f_10506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10845)
static void C_ccall f_10845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10514)
static void C_fcall f_10514(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10827)
static void C_ccall f_10827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10522)
static void C_ccall f_10522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10815)
static void C_ccall f_10815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10742)
static void C_ccall f_10742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10740)
static void C_ccall f_10740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10736)
static void C_ccall f_10736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10670)
static void C_ccall f_10670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10702)
static void C_ccall f_10702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10668)
static void C_ccall f_10668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10664)
static void C_ccall f_10664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10590)
static void C_fcall f_10590(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10660)
static void C_ccall f_10660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10613)
static void C_ccall f_10613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10656)
static void C_ccall f_10656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10648)
static void C_ccall f_10648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10644)
static void C_ccall f_10644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10624)
static void C_ccall f_10624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10578)
static void C_ccall f_10578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10574)
static void C_ccall f_10574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10518)
static void C_ccall f_10518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10510)
static void C_ccall f_10510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10423)
static void C_fcall f_10423(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10427)
static void C_ccall f_10427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10438)
static void C_fcall f_10438(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10477)
static void C_ccall f_10477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10469)
static void C_ccall f_10469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10433)
static void C_ccall f_10433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10147)
static void C_fcall f_10147(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10228)
static void C_fcall f_10228(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10255)
static void C_ccall f_10255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10257)
static void C_fcall f_10257(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10417)
static void C_ccall f_10417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10405)
static void C_ccall f_10405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10386)
static void C_ccall f_10386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10353)
static void C_ccall f_10353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10323)
static void C_ccall f_10323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10304)
static void C_fcall f_10304(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10308)
static void C_ccall f_10308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10280)
static void C_ccall f_10280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10205)
static void C_fcall f_10205(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10217)
static void C_ccall f_10217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10213)
static void C_ccall f_10213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10084)
static void C_ccall f_10084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10090)
static void C_fcall f_10090(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10113)
static void C_fcall f_10113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10103)
static void C_ccall f_10103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10016)
static void C_ccall f_10016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10016)
static void C_ccall f_10016r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10036)
static C_word C_fcall f_10036(C_word *a,C_word t0);
C_noret_decl(f_10031)
static C_word C_fcall f_10031(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_10018)
static C_word C_fcall f_10018(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9994)
static void C_ccall f_9994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10001)
static void C_ccall f_10001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9913)
static void C_ccall f_9913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9923)
static void C_ccall f_9923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9926)
static void C_ccall f_9926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9932)
static void C_ccall f_9932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9975)
static void C_ccall f_9975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9979)
static void C_ccall f_9979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9935)
static void C_ccall f_9935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9941)
static void C_ccall f_9941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9824)
static void C_ccall f_9824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9834)
static void C_ccall f_9834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9837)
static void C_ccall f_9837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9900)
static void C_ccall f_9900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9840)
static void C_ccall f_9840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9843)
static void C_ccall f_9843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9882)
static void C_ccall f_9882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9886)
static void C_ccall f_9886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9846)
static void C_ccall f_9846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9849)
static void C_ccall f_9849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9803)
static void C_fcall f_9803(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9810)
static void C_ccall f_9810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9783)
static void C_ccall f_9783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9787)
static void C_ccall f_9787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9780)
static void C_ccall f_9780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9740)
static void C_ccall f_9740(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9740)
static void C_ccall f_9740r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9744)
static void C_ccall f_9744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9716)
static void C_ccall f_9716(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9616)
static void C_ccall f_9616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9607)
static void C_ccall f_9607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9526)
static void C_ccall f_9526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9414)
static void C_ccall f_9414(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9414)
static void C_ccall f_9414r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9418)
static void C_ccall f_9418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9421)
static void C_ccall f_9421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9426)
static void C_fcall f_9426(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9460)
static void C_ccall f_9460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9424)
static void C_ccall f_9424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9349)
static void C_ccall f_9349(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9349)
static void C_ccall f_9349r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9353)
static void C_ccall f_9353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9363)
static void C_ccall f_9363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9365)
static void C_fcall f_9365(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9386)
static void C_ccall f_9386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9356)
static void C_ccall f_9356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7708)
static void C_ccall f_7708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7715)
static void C_ccall f_7715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7729)
static void C_ccall f_7729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7733)
static void C_ccall f_7733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7737)
static void C_ccall f_7737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7742)
static void C_ccall f_7742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7748)
static void C_ccall f_7748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7756)
static void C_ccall f_7756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7760)
static void C_ccall f_7760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7764)
static void C_ccall f_7764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7769)
static void C_ccall f_7769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7773)
static void C_ccall f_7773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7785)
static void C_ccall f_7785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7789)
static void C_ccall f_7789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7793)
static void C_ccall f_7793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7797)
static void C_ccall f_7797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9310)
static void C_ccall f_9310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9320)
static void C_fcall f_9320(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9327)
static void C_ccall f_9327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9290)
static void C_ccall f_9290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9297)
static void C_ccall f_9297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9304)
static void C_ccall f_9304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9264)
static void C_ccall f_9264(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9242)
static void C_ccall f_9242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9249)
static void C_ccall f_9249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9149)
static void C_ccall f_9149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9191)
static void C_ccall f_9191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9240)
static void C_ccall f_9240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9223)
static void C_ccall f_9223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9202)
static void C_ccall f_9202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9076)
static void C_ccall f_9076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9102)
static void C_ccall f_9102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9147)
static void C_ccall f_9147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9130)
static void C_ccall f_9130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8822)
static void C_ccall f_8822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8869)
static void C_ccall f_8869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9067)
static void C_ccall f_9067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9063)
static void C_ccall f_9063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9030)
static void C_ccall f_9030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8872)
static void C_ccall f_8872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8878)
static void C_ccall f_8878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8890)
static void C_ccall f_8890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8956)
static void C_fcall f_8956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8971)
static void C_ccall f_8971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8893)
static void C_fcall f_8893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8927)
static void C_fcall f_8927(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8896)
static void C_ccall f_8896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8925)
static void C_ccall f_8925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8921)
static void C_ccall f_8921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8917)
static void C_ccall f_8917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8615)
static void C_ccall f_8615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8645)
static void C_ccall f_8645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8745)
static void C_ccall f_8745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8768)
static void C_fcall f_8768(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8782)
static void C_ccall f_8782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8786)
static void C_ccall f_8786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8755)
static void C_ccall f_8755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8705)
static void C_ccall f_8705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8709)
static void C_ccall f_8709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8654)
static void C_ccall f_8654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8639)
static void C_ccall f_8639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8334)
static void C_ccall f_8334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8373)
static void C_fcall f_8373(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8383)
static void C_fcall f_8383(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8514)
static void C_ccall f_8514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8518)
static void C_ccall f_8518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8447)
static void C_ccall f_8447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8443)
static void C_ccall f_8443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8381)
static void C_ccall f_8381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8377)
static void C_ccall f_8377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8281)
static void C_ccall f_8281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8034)
static void C_ccall f_8034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8148)
static void C_fcall f_8148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8094)
static void C_ccall f_8094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7900)
static void C_ccall f_7900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7907)
static void C_fcall f_7907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7959)
static void C_ccall f_7959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7955)
static void C_ccall f_7955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7936)
static void C_ccall f_7936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7944)
static void C_ccall f_7944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7810)
static void C_ccall f_7810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7804)
static void C_ccall f_7804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6796)
static void C_ccall f_6796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6806)
static void C_ccall f_6806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7424)
static void C_ccall f_7424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7427)
static void C_ccall f_7427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7640)
static void C_ccall f_7640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7625)
static void C_ccall f_7625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7430)
static void C_ccall f_7430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7439)
static void C_fcall f_7439(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7452)
static void C_ccall f_7452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_ccall f_7470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7565)
static void C_fcall f_7565(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7615)
static void C_ccall f_7615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7473)
static void C_ccall f_7473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7507)
static void C_fcall f_7507(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7501)
static void C_ccall f_7501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7482)
static void C_ccall f_7482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7433)
static void C_ccall f_7433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6950)
static void C_fcall f_6950(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6969)
static void C_fcall f_6969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6978)
static void C_ccall f_6978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7177)
static void C_ccall f_7177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7343)
static void C_ccall f_7343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7346)
static void C_ccall f_7346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7379)
static void C_ccall f_7379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7383)
static void C_ccall f_7383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7348)
static void C_ccall f_7348(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7356)
static void C_ccall f_7356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7180)
static void C_ccall f_7180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7189)
static void C_fcall f_7189(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7334)
static void C_ccall f_7334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7315)
static void C_ccall f_7315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7303)
static void C_ccall f_7303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7263)
static void C_ccall f_7263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7251)
static void C_ccall f_7251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7210)
static void C_fcall f_7210(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7073)
static void C_ccall f_7073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7076)
static void C_ccall f_7076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7081)
static void C_fcall f_7081(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7167)
static void C_ccall f_7167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7093)
static void C_fcall f_7093(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7135)
static void C_ccall f_7135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6996)
static void C_ccall f_6996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7001)
static void C_fcall f_7001(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6863)
static void C_fcall f_6863(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6948)
static void C_ccall f_6948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6944)
static void C_ccall f_6944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6885)
static void C_ccall f_6885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6891)
static void C_ccall f_6891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6894)
static void C_ccall f_6894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6902)
static void C_ccall f_6902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6909)
static void C_ccall f_6909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6916)
static void C_ccall f_6916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6920)
static void C_ccall f_6920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6923)
static void C_ccall f_6923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6873)
static void C_ccall f_6873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6820)
static void C_fcall f_6820(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6833)
static void C_ccall f_6833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6840)
static void C_ccall f_6840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6811)
static void C_ccall f_6811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6815)
static void C_ccall f_6815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6606)
static void C_ccall f_6606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6680)
static void C_ccall f_6680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f15795)
static void C_ccall f15795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6683)
static void C_fcall f_6683(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f15788)
static void C_ccall f15788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6689)
static void C_fcall f_6689(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6735)
static void C_ccall f_6735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6708)
static void C_ccall f_6708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6609)
static void C_ccall f_6609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6654)
static void C_ccall f_6654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6640)
static void C_ccall f_6640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6553)
static void C_fcall f_6553(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6544)
static void C_fcall f_6544(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6141)
static void C_fcall f_6141(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6272)
static void C_fcall f_6272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6277)
static void C_fcall f_6277(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6296)
static void C_fcall f_6296(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_fcall f_6301(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6320)
static void C_ccall f_6320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6243)
static void C_ccall f_6243(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6249)
static C_word C_fcall f_6249(C_word t0);
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6191)
static void C_ccall f_6191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6219)
static void C_ccall f_6219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6144)
static void C_fcall f_6144(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6151)
static void C_ccall f_6151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6156)
static void C_fcall f_6156(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6160)
static void C_ccall f_6160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6097)
static void C_ccall f_6097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6016)
static void C_ccall f_6016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6079)
static void C_ccall f_6079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6019)
static void C_fcall f_6019(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6072)
static void C_ccall f_6072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6045)
static void C_ccall f_6045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_fcall f_5933(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5936)
static void C_fcall f_5936(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5985)
static void C_ccall f_5985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5881)
static void C_fcall f_5881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_fcall f_5876(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5165)
static void C_fcall f_5165(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5589)
static void C_fcall f_5589(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5595)
static void C_fcall f_5595(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_fcall f_5617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5635)
static void C_ccall f_5635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_fcall f_5640(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5709)
static void C_ccall f_5709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5687)
static void C_ccall f_5687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_fcall f_5412(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5422)
static void C_fcall f_5422(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5468)
static void C_fcall f_5468(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5168)
static void C_fcall f_5168(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5374)
static void C_ccall f_5374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5342)
static void C_ccall f_5342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_fcall f_5180(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_fcall f_5244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_fcall f_5199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5218)
static void C_ccall f_5218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_fcall f_4606(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5090)
static void C_fcall f_5090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_fcall f_5009(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_fcall f_4963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_fcall f_4966(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4929)
static void C_fcall f_4929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_ccall f_4824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_fcall f_4624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_fcall f_4636(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_fcall f_4572(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4532)
static C_word C_fcall f_4532(C_word t0);
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4473)
static void C_fcall f_4473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_fcall f_4468(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4442)
static void C_fcall f_4442(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4448)
static void C_fcall f_4448(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_fcall f_4357(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4086)
static void C_fcall f_4086(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_fcall f_4114(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_fcall f_4216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4123)
static void C_ccall f_4123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_fcall f_4040(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3838)
static void C_fcall f_3838(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_fcall f_3876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_fcall f_3893(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3912)
static void C_fcall f_3912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_fcall f_3792(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3819)
static void C_ccall f_3819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3634)
static void C_fcall f_3634(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_fcall f_3667(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3596)
static void C_fcall f_3596(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3421)
static void C_fcall f_3421(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_fcall f_3416(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3265)
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3271)
static void C_fcall f_3271(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3390)
static C_word C_fcall f_3390(C_word t0,C_word t1);
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_fcall f_3302(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_fcall f_3188(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_fcall f_3198(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3170)
static void C_fcall f_3170(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_13669)
static void C_fcall trf_13669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13669(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13669(t0,t1,t2);}

C_noret_decl(trf_13207)
static void C_fcall trf_13207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13207(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13207(t0,t1,t2);}

C_noret_decl(trf_13056)
static void C_fcall trf_13056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13056(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13056(t0,t1,t2);}

C_noret_decl(trf_12962)
static void C_fcall trf_12962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12962(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12962(t0,t1,t2);}

C_noret_decl(trf_12829)
static void C_fcall trf_12829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12829(t0,t1);}

C_noret_decl(trf_12845)
static void C_fcall trf_12845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12845(t0,t1);}

C_noret_decl(trf_12664)
static void C_fcall trf_12664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12664(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12664(t0,t1,t2);}

C_noret_decl(trf_12395)
static void C_fcall trf_12395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12395(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12395(t0,t1,t2,t3);}

C_noret_decl(trf_12385)
static void C_fcall trf_12385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12385(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12385(t0,t1,t2,t3);}

C_noret_decl(trf_12234)
static void C_fcall trf_12234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12234(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12234(t0,t1,t2);}

C_noret_decl(trf_12084)
static void C_fcall trf_12084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12084(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12084(t0,t1,t2);}

C_noret_decl(trf_12074)
static void C_fcall trf_12074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12074(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12074(t0,t1,t2);}

C_noret_decl(trf_11830)
static void C_fcall trf_11830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11830(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11830(t0,t1,t2);}

C_noret_decl(trf_11853)
static void C_fcall trf_11853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11853(t0,t1);}

C_noret_decl(trf_11691)
static void C_fcall trf_11691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11691(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11691(t0,t1,t2);}

C_noret_decl(trf_11562)
static void C_fcall trf_11562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11562(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11562(t0,t1,t2);}

C_noret_decl(trf_11613)
static void C_fcall trf_11613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11613(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11613(t0,t1);}

C_noret_decl(trf_11625)
static void C_fcall trf_11625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11625(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11625(t0,t1);}

C_noret_decl(trf_11595)
static void C_fcall trf_11595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11595(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11595(t0,t1);}

C_noret_decl(trf_11459)
static void C_fcall trf_11459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11459(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11459(t0,t1,t2);}

C_noret_decl(trf_11526)
static void C_fcall trf_11526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11526(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11526(t0,t1,t2);}

C_noret_decl(trf_11370)
static void C_fcall trf_11370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11370(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11370(t0,t1,t2);}

C_noret_decl(trf_11247)
static void C_fcall trf_11247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11247(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11247(t0,t1,t2);}

C_noret_decl(trf_11275)
static void C_fcall trf_11275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11275(t0,t1);}

C_noret_decl(trf_10506)
static void C_fcall trf_10506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10506(t0,t1);}

C_noret_decl(trf_10514)
static void C_fcall trf_10514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10514(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10514(t0,t1);}

C_noret_decl(trf_10590)
static void C_fcall trf_10590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10590(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10590(t0,t1,t2);}

C_noret_decl(trf_10423)
static void C_fcall trf_10423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10423(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10423(t0,t1);}

C_noret_decl(trf_10438)
static void C_fcall trf_10438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10438(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10438(t0,t1,t2);}

C_noret_decl(trf_10147)
static void C_fcall trf_10147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10147(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10147(t0,t1);}

C_noret_decl(trf_10228)
static void C_fcall trf_10228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10228(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10228(t0,t1,t2);}

C_noret_decl(trf_10257)
static void C_fcall trf_10257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10257(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10257(t0,t1,t2);}

C_noret_decl(trf_10304)
static void C_fcall trf_10304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10304(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10304(t0,t1);}

C_noret_decl(trf_10205)
static void C_fcall trf_10205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10205(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10205(t0,t1,t2,t3);}

C_noret_decl(trf_10090)
static void C_fcall trf_10090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10090(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10090(t0,t1,t2);}

C_noret_decl(trf_10113)
static void C_fcall trf_10113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10113(t0,t1);}

C_noret_decl(trf_9803)
static void C_fcall trf_9803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9803(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9803(t0,t1,t2,t3);}

C_noret_decl(trf_9426)
static void C_fcall trf_9426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9426(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9426(t0,t1,t2);}

C_noret_decl(trf_9365)
static void C_fcall trf_9365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9365(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9365(t0,t1,t2);}

C_noret_decl(trf_9320)
static void C_fcall trf_9320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9320(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9320(t0,t1,t2);}

C_noret_decl(trf_8956)
static void C_fcall trf_8956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8956(t0,t1);}

C_noret_decl(trf_8893)
static void C_fcall trf_8893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8893(t0,t1);}

C_noret_decl(trf_8927)
static void C_fcall trf_8927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8927(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8927(t0,t1,t2,t3);}

C_noret_decl(trf_8768)
static void C_fcall trf_8768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8768(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8768(t0,t1,t2);}

C_noret_decl(trf_8373)
static void C_fcall trf_8373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8373(t0,t1);}

C_noret_decl(trf_8383)
static void C_fcall trf_8383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8383(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8383(t0,t1,t2);}

C_noret_decl(trf_8148)
static void C_fcall trf_8148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8148(t0,t1);}

C_noret_decl(trf_7907)
static void C_fcall trf_7907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7907(t0,t1);}

C_noret_decl(trf_7439)
static void C_fcall trf_7439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7439(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7439(t0,t1,t2);}

C_noret_decl(trf_7565)
static void C_fcall trf_7565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7565(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7565(t0,t1,t2);}

C_noret_decl(trf_7507)
static void C_fcall trf_7507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7507(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7507(t0,t1,t2);}

C_noret_decl(trf_6950)
static void C_fcall trf_6950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6950(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6950(t0,t1,t2);}

C_noret_decl(trf_6969)
static void C_fcall trf_6969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6969(t0,t1);}

C_noret_decl(trf_7189)
static void C_fcall trf_7189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7189(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7189(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7210)
static void C_fcall trf_7210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7210(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7210(t0,t1,t2);}

C_noret_decl(trf_7081)
static void C_fcall trf_7081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7081(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7081(t0,t1,t2,t3);}

C_noret_decl(trf_7093)
static void C_fcall trf_7093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7093(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7093(t0,t1,t2,t3);}

C_noret_decl(trf_7001)
static void C_fcall trf_7001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7001(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7001(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6863)
static void C_fcall trf_6863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6863(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6863(t0,t1,t2);}

C_noret_decl(trf_6820)
static void C_fcall trf_6820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6820(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6820(t0,t1,t2);}

C_noret_decl(trf_6683)
static void C_fcall trf_6683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6683(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6683(t0,t1);}

C_noret_decl(trf_6689)
static void C_fcall trf_6689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6689(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6689(t0,t1);}

C_noret_decl(trf_6553)
static void C_fcall trf_6553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6553(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6553(t0,t1);}

C_noret_decl(trf_6544)
static void C_fcall trf_6544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6544(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6544(t0,t1,t2);}

C_noret_decl(trf_6141)
static void C_fcall trf_6141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6141(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6141(t0,t1,t2,t3);}

C_noret_decl(trf_6272)
static void C_fcall trf_6272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6272(t0,t1);}

C_noret_decl(trf_6277)
static void C_fcall trf_6277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6277(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6277(t0,t1,t2,t3);}

C_noret_decl(trf_6296)
static void C_fcall trf_6296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6296(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6296(t0,t1);}

C_noret_decl(trf_6301)
static void C_fcall trf_6301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6301(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6301(t0,t1,t2,t3);}

C_noret_decl(trf_6199)
static void C_fcall trf_6199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6199(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6199(t0,t1,t2);}

C_noret_decl(trf_6144)
static void C_fcall trf_6144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6144(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6144(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6156)
static void C_fcall trf_6156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6156(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6156(t0,t1,t2);}

C_noret_decl(trf_6019)
static void C_fcall trf_6019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6019(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6019(t0,t1,t2,t3);}

C_noret_decl(trf_5933)
static void C_fcall trf_5933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5933(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5933(t0,t1,t2,t3);}

C_noret_decl(trf_5936)
static void C_fcall trf_5936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5936(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5936(t0,t1,t2,t3);}

C_noret_decl(trf_5881)
static void C_fcall trf_5881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5881(t0,t1);}

C_noret_decl(trf_5876)
static void C_fcall trf_5876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5876(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5876(t0,t1,t2);}

C_noret_decl(trf_5165)
static void C_fcall trf_5165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5165(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5165(t0,t1,t2,t3);}

C_noret_decl(trf_5589)
static void C_fcall trf_5589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5589(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5589(t0,t1,t2);}

C_noret_decl(trf_5595)
static void C_fcall trf_5595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5595(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5595(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5617)
static void C_fcall trf_5617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5617(t0,t1);}

C_noret_decl(trf_5640)
static void C_fcall trf_5640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5640(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5640(t0,t1,t2);}

C_noret_decl(trf_5412)
static void C_fcall trf_5412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5412(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5412(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5422)
static void C_fcall trf_5422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5422(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5422(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5468)
static void C_fcall trf_5468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5468(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5468(t0,t1);}

C_noret_decl(trf_5168)
static void C_fcall trf_5168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5168(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5168(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5180)
static void C_fcall trf_5180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5180(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5180(t0,t1,t2,t3);}

C_noret_decl(trf_5244)
static void C_fcall trf_5244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5244(t0,t1);}

C_noret_decl(trf_5199)
static void C_fcall trf_5199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5199(t0,t1);}

C_noret_decl(trf_4606)
static void C_fcall trf_4606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4606(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4606(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5090)
static void C_fcall trf_5090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5090(t0,t1);}

C_noret_decl(trf_5009)
static void C_fcall trf_5009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5009(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5009(t0,t1);}

C_noret_decl(trf_4963)
static void C_fcall trf_4963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4963(t0,t1);}

C_noret_decl(trf_4966)
static void C_fcall trf_4966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4966(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4966(t0,t1);}

C_noret_decl(trf_4929)
static void C_fcall trf_4929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4929(t0,t1);}

C_noret_decl(trf_4624)
static void C_fcall trf_4624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4624(t0,t1);}

C_noret_decl(trf_4636)
static void C_fcall trf_4636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4636(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4636(t0,t1);}

C_noret_decl(trf_4572)
static void C_fcall trf_4572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4572(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4572(t0,t1,t2);}

C_noret_decl(trf_4473)
static void C_fcall trf_4473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4473(t0,t1);}

C_noret_decl(trf_4468)
static void C_fcall trf_4468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4468(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4468(t0,t1,t2);}

C_noret_decl(trf_4442)
static void C_fcall trf_4442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4442(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4442(t0,t1,t2,t3);}

C_noret_decl(trf_4448)
static void C_fcall trf_4448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4448(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4448(t0,t1,t2);}

C_noret_decl(trf_4357)
static void C_fcall trf_4357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4357(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4357(t0,t1,t2);}

C_noret_decl(trf_4086)
static void C_fcall trf_4086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4086(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4086(t0,t1,t2);}

C_noret_decl(trf_4114)
static void C_fcall trf_4114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4114(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4114(t0,t1);}

C_noret_decl(trf_4216)
static void C_fcall trf_4216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4216(t0,t1);}

C_noret_decl(trf_4040)
static void C_fcall trf_4040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4040(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4040(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3838)
static void C_fcall trf_3838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3838(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3838(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3876)
static void C_fcall trf_3876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3876(t0,t1);}

C_noret_decl(trf_3893)
static void C_fcall trf_3893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3893(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3893(t0,t1,t2);}

C_noret_decl(trf_3912)
static void C_fcall trf_3912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3912(t0,t1);}

C_noret_decl(trf_3792)
static void C_fcall trf_3792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3792(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3792(t0,t1,t2);}

C_noret_decl(trf_3634)
static void C_fcall trf_3634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3634(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3634(t0,t1,t2);}

C_noret_decl(trf_3667)
static void C_fcall trf_3667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3667(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3667(t0,t1);}

C_noret_decl(trf_3596)
static void C_fcall trf_3596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3596(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3596(t0,t1);}

C_noret_decl(trf_3421)
static void C_fcall trf_3421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3421(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3421(t0,t1);}

C_noret_decl(trf_3416)
static void C_fcall trf_3416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3416(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3416(t0,t1,t2);}

C_noret_decl(trf_3265)
static void C_fcall trf_3265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3265(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3265(t0,t1,t2,t3);}

C_noret_decl(trf_3271)
static void C_fcall trf_3271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3271(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3271(t0,t1,t2);}

C_noret_decl(trf_3302)
static void C_fcall trf_3302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3302(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3302(t0,t1);}

C_noret_decl(trf_3188)
static void C_fcall trf_3188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3188(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3188(t0,t1,t2);}

C_noret_decl(trf_3198)
static void C_fcall trf_3198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3198(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3198(t0,t1);}

C_noret_decl(trf_3170)
static void C_fcall trf_3170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3170(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3170(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_expand_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("expand_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3644)){
C_save(t1);
C_rereclaim2(3644*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,354);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],12,"\003sysfeatures");
lf[3]=C_h_intern(&lf[3],23,"\003syscurrent-environment");
lf[4]=C_h_intern(&lf[4],28,"\003syscurrent-meta-environment");
lf[6]=C_h_intern(&lf[6],7,"\003sysget");
lf[7]=C_h_intern(&lf[7],16,"\004coremacro-alias");
lf[9]=C_h_intern(&lf[9],19,"\003sysundefined-value");
lf[10]=C_h_intern(&lf[10],8,"\003sysput!");
lf[11]=C_h_intern(&lf[11],14,"\004corereal-name");
lf[12]=C_h_intern(&lf[12],6,"gensym");
lf[13]=C_h_intern(&lf[13],21,"\003sysqualified-symbol\077");
lf[14]=C_h_intern(&lf[14],16,"\003sysstrip-syntax");
lf[15]=C_h_intern(&lf[15],21,"\003sysalias-global-hook");
lf[16]=C_h_intern(&lf[16],3,"get");
lf[17]=C_h_intern(&lf[17],11,"make-vector");
lf[18]=C_h_intern(&lf[18],9,"\003syserror");
lf[19]=C_h_intern(&lf[19],12,"strip-syntax");
lf[20]=C_h_intern(&lf[20],21,"\003sysmacro-environment");
lf[21]=C_h_intern(&lf[21],29,"\003syschicken-macro-environment");
lf[22]=C_h_intern(&lf[22],33,"\003syschicken-ffi-macro-environment");
lf[23]=C_h_intern(&lf[23],26,"\003syssyntactic-environment\077");
lf[24]=C_h_intern(&lf[24],33,"\003syssyntactic-environment-symbols");
lf[25]=C_h_intern(&lf[25],28,"\003sysextend-macro-environment");
lf[26]=C_h_intern(&lf[26],14,"\003syscopy-macro");
lf[27]=C_h_intern(&lf[27],10,"\003sysmacro\077");
lf[28]=C_h_intern(&lf[28],20,"\003sysunregister-macro");
lf[29]=C_h_intern(&lf[29],4,"caar");
lf[30]=C_h_intern(&lf[30],19,"\003sysundefine-macro!");
lf[31]=C_h_intern(&lf[31],12,"\003sysexpand-0");
lf[32]=C_h_intern(&lf[32],9,"condition");
lf[33]=C_h_intern(&lf[33],9,"\003sysabort");
lf[34]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[35]=C_h_intern(&lf[35],13,"string-append");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[38]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[39]=C_h_intern(&lf[39],3,"exn");
lf[40]=C_h_intern(&lf[40],21,"\003syssyntax-error-hook");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\030syntax transformer for `");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000@\047 returns original form, which would result in endless expansion");
lf[43]=C_h_intern(&lf[43],14,"symbol->string");
lf[44]=C_h_intern(&lf[44],25,"\003syssyntax-rules-mismatch");
lf[45]=C_h_intern(&lf[45],16,"\003sysdynamic-wind");
lf[46]=C_h_intern(&lf[46],22,"with-exception-handler");
lf[47]=C_h_intern(&lf[47],30,"call-with-current-continuation");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[49]=C_h_intern(&lf[49],3,"let");
lf[50]=C_h_intern(&lf[50],8,"\004corelet");
lf[51]=C_h_intern(&lf[51],16,"\004coreloop-lambda");
lf[52]=C_h_intern(&lf[52],11,"\004coreletrec");
lf[53]=C_h_intern(&lf[53],8,"\004coreapp");
lf[54]=C_h_intern(&lf[54],10,"\003sysappend");
lf[55]=C_h_intern(&lf[55],7,"\003sysmap");
lf[56]=C_h_intern(&lf[56],4,"cadr");
lf[57]=C_h_intern(&lf[57],16,"\003syscheck-syntax");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[59]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[60]=C_h_intern(&lf[60],10,"\003syssetter");
lf[61]=C_h_intern(&lf[61],6,"append");
lf[62]=C_h_intern(&lf[62],4,"set!");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[64]=C_h_intern(&lf[64],24,"\003syscompiler-syntax-hook");
lf[65]=C_h_intern(&lf[65],24,"\010compilercompiler-syntax");
lf[66]=C_h_intern(&lf[66],9,"\004coreset!");
lf[67]=C_h_intern(&lf[67],25,"\003sysenable-runtime-macros");
lf[68]=C_h_intern(&lf[68],17,"\003sysmodule-rename");
lf[69]=C_h_intern(&lf[69],18,"\003sysstring->symbol");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[71]=C_h_intern(&lf[71],6,"module");
lf[72]=C_h_intern(&lf[72],22,"\003sysregister-undefined");
lf[73]=C_h_intern(&lf[73],18,"\003syscurrent-module");
lf[74]=C_h_intern(&lf[74],14,"\004coreprimitive");
lf[75]=C_h_intern(&lf[75],12,"\004corealiased");
lf[76]=C_h_intern(&lf[76],10,"\003sysexpand");
lf[77]=C_h_intern(&lf[77],6,"expand");
lf[78]=C_h_intern(&lf[78],25,"\003sysextended-lambda-list\077");
lf[79]=C_h_intern(&lf[79],6,"#!rest");
lf[80]=C_h_intern(&lf[80],10,"#!optional");
lf[81]=C_h_intern(&lf[81],5,"#!key");
lf[82]=C_h_intern(&lf[82],7,"reverse");
lf[83]=C_h_intern(&lf[83],31,"\003sysexpand-extended-lambda-list");
lf[84]=C_h_intern(&lf[84],5,"cadar");
lf[85]=C_h_intern(&lf[85],5,"quote");
lf[86]=C_h_intern(&lf[86],15,"\003sysget-keyword");
lf[87]=C_h_intern(&lf[87],11,"\004corelambda");
lf[88]=C_h_intern(&lf[88],15,"string->keyword");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[91]=C_h_intern(&lf[91],3,"tmp");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[100]=C_h_intern(&lf[100],14,"let-optionals*");
lf[101]=C_h_intern(&lf[101],13,"let-optionals");
lf[102]=C_h_intern(&lf[102],8,"optional");
lf[103]=C_h_intern(&lf[103],4,"let*");
lf[104]=C_h_intern(&lf[104],3,"map");
lf[105]=C_h_intern(&lf[105],21,"\003syscanonicalize-body");
lf[106]=C_h_intern(&lf[106],10,"\004corebegin");
lf[107]=C_h_intern(&lf[107],13,"define-values");
lf[108]=C_h_intern(&lf[108],6,"define");
lf[109]=C_h_intern(&lf[109],20,"\003syscall-with-values");
lf[110]=C_h_intern(&lf[110],14,"\004coreundefined");
lf[111]=C_h_intern(&lf[111],3,"cdr");
lf[112]=C_h_intern(&lf[112],13,"letrec-syntax");
lf[113]=C_h_intern(&lf[113],13,"define-syntax");
lf[114]=C_h_intern(&lf[114],5,"cdadr");
lf[115]=C_h_intern(&lf[115],6,"lambda");
lf[116]=C_h_intern(&lf[116],5,"caadr");
lf[117]=C_h_intern(&lf[117],25,"\003sysexpand-curried-define");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[119]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[120]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[122]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[123]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-syntax\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[124]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[125]=C_h_intern(&lf[125],5,"begin");
lf[126]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[128]=C_h_intern(&lf[128],24,"\003sysline-number-database");
lf[129]=C_h_intern(&lf[129],24,"\003syssyntax-error-culprit");
lf[130]=C_h_intern(&lf[130],15,"\003syssignal-hook");
lf[131]=C_h_intern(&lf[131],13,"\000syntax-error");
lf[132]=C_h_intern(&lf[132],12,"syntax-error");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[134]=C_h_intern(&lf[134],15,"get-line-number");
lf[135]=C_h_intern(&lf[135],18,"\003syshash-table-ref");
lf[136]=C_h_intern(&lf[136],8,"keyword\077");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[146]=C_h_intern(&lf[146],1,"_");
lf[147]=C_h_intern(&lf[147],4,"pair");
lf[148]=C_h_intern(&lf[148],5,"pair\077");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[150]=C_h_intern(&lf[150],8,"variable");
lf[151]=C_h_intern(&lf[151],7,"symbol\077");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[153]=C_h_intern(&lf[153],6,"symbol");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[155]=C_h_intern(&lf[155],4,"list");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[157]=C_h_intern(&lf[157],6,"number");
lf[158]=C_h_intern(&lf[158],7,"number\077");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[160]=C_h_intern(&lf[160],6,"string");
lf[161]=C_h_intern(&lf[161],7,"string\077");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[163]=C_h_intern(&lf[163],11,"lambda-list");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[168]=C_h_intern(&lf[168],20,"er-macro-transformer");
lf[169]=C_h_intern(&lf[169],18,"\003syser-transformer");
lf[170]=C_h_intern(&lf[170],17,"\003sysexpand-import");
lf[171]=C_h_intern(&lf[171],17,"\003sysstring-append");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[173]=C_h_intern(&lf[173],18,"\003syssymbol->string");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid prefix");
lf[175]=C_h_intern(&lf[175],15,"\003sysfind-module");
lf[176]=C_h_intern(&lf[176],8,"\003sysload");
lf[177]=C_h_intern(&lf[177],26,"\003sysmeta-macro-environment");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000#cannot import from undefined module");
lf[179]=C_h_intern(&lf[179],18,"\003sysfind-extension");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\007.import");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[182]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[183]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[184]=C_h_intern(&lf[184],8,"\003syswarn");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\037renamed identifier not imported");
lf[186]=C_h_intern(&lf[186],8,"\003sysdelq");
lf[187]=C_h_intern(&lf[187],4,"cdar");
lf[188]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[191]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000$re-importing already imported syntax");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000(re-importing already imported identifier");
lf[194]=C_h_intern(&lf[194],25,"\003sysmark-imported-symbols");
lf[195]=C_h_intern(&lf[195],14,"\003sysblock-set!");
lf[196]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[197]=C_h_intern(&lf[197],6,"prefix");
lf[198]=C_h_intern(&lf[198],6,"except");
lf[199]=C_h_intern(&lf[199],6,"rename");
lf[200]=C_h_intern(&lf[200],4,"only");
lf[201]=C_h_intern(&lf[201],29,"\003sysinitial-macro-environment");
lf[202]=C_h_intern(&lf[202],24,"\003sysprocess-syntax-rules");
lf[203]=C_h_intern(&lf[203],7,"\003syscar");
lf[204]=C_h_intern(&lf[204],7,"\003syscdr");
lf[205]=C_h_intern(&lf[205],11,"\003sysvector\077");
lf[206]=C_h_intern(&lf[206],17,"\003sysvector-length");
lf[207]=C_h_intern(&lf[207],14,"\003sysvector-ref");
lf[208]=C_h_intern(&lf[208],16,"\003sysvector->list");
lf[209]=C_h_intern(&lf[209],16,"\003syslist->vector");
lf[210]=C_h_intern(&lf[210],6,"\003sys>=");
lf[211]=C_h_intern(&lf[211],5,"\003sys=");
lf[212]=C_h_intern(&lf[212],5,"\003sys+");
lf[213]=C_h_intern(&lf[213],8,"\003syscons");
lf[214]=C_h_intern(&lf[214],7,"\003syseq\077");
lf[215]=C_h_intern(&lf[215],10,"\003sysequal\077");
lf[216]=C_h_intern(&lf[216],9,"\003syslist\077");
lf[217]=C_h_intern(&lf[217],9,"\003sysmap-n");
lf[218]=C_h_intern(&lf[218],9,"\003sysnull\077");
lf[219]=C_h_intern(&lf[219],9,"\003syspair\077");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\026ill-formed syntax rule");
lf[221]=C_h_intern(&lf[221],6,"syntax");
lf[222]=C_h_intern(&lf[222],12,"vector->list");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000,template dimension error (too few ellipses\077)");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\021too many ellipses");
lf[225]=C_h_intern(&lf[225],9,"\003sysapply");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000 segment matching not implemented");
lf[227]=C_h_intern(&lf[227],4,"temp");
lf[228]=C_h_intern(&lf[228],4,"tail");
lf[229]=C_h_intern(&lf[229],2,"or");
lf[230]=C_h_intern(&lf[230],4,"loop");
lf[231]=C_h_intern(&lf[231],1,"l");
lf[232]=C_h_intern(&lf[232],5,"input");
lf[233]=C_h_intern(&lf[233],4,"else");
lf[234]=C_h_intern(&lf[234],4,"cond");
lf[235]=C_h_intern(&lf[235],7,"compare");
lf[236]=C_h_intern(&lf[236],1,"i");
lf[237]=C_h_intern(&lf[237],3,"and");
lf[238]=C_h_intern(&lf[238],16,"\003sysmacro-subset");
lf[239]=C_h_intern(&lf[239],27,"\003sysfixup-macro-environment");
lf[240]=C_h_intern(&lf[240],29,"\003sysdefault-macro-environment");
lf[242]=C_h_intern(&lf[242],26,"set-module-undefined-list!");
lf[243]=C_h_intern(&lf[243],21,"module-undefined-list");
lf[244]=C_h_intern(&lf[244],15,"\003sysmodule-name");
lf[245]=C_h_intern(&lf[245],18,"\003sysmodule-exports");
lf[246]=C_h_intern(&lf[246],16,"\003sysmodule-table");
lf[247]=C_h_intern(&lf[247],5,"error");
lf[248]=C_h_intern(&lf[248],6,"import");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\020module not found");
lf[250]=C_h_intern(&lf[250],28,"\003systoplevel-definition-hook");
lf[251]=C_h_intern(&lf[251],28,"\003sysregister-meta-expression");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\047redefinition of imported syntax binding");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000&redefinition of imported value binding");
lf[255]=C_h_intern(&lf[255],19,"\003sysregister-export");
lf[256]=C_h_intern(&lf[256],15,"\003sysfind-export");
lf[257]=C_h_intern(&lf[257],26,"\003sysregister-syntax-export");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000!use of syntax precedes definition");
lf[259]=C_h_intern(&lf[259],19,"\003sysregister-module");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\014 in module `");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000!indirect export of syntax binding");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\033indirect reexport of syntax");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\042indirect export of unknown binding");
lf[267]=C_h_intern(&lf[267],32,"\003syscompiled-module-registration");
lf[268]=C_h_intern(&lf[268],28,"\003sysregister-compiled-module");
lf[269]=C_h_intern(&lf[269],4,"cons");
lf[270]=C_h_intern(&lf[270],4,"eval");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\0000cannot find implementation of re-exported syntax");
lf[272]=C_h_intern(&lf[272],19,"\003sysprimitive-alias");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\002#%");
lf[274]=C_h_intern(&lf[274],29,"\003sysregister-primitive-module");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\0001unknown macro referenced while registering module");
lf[276]=C_h_intern(&lf[276],18,"module-exists-list");
lf[277]=C_h_intern(&lf[277],19,"\003sysfinalize-module");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000$(internal) indirect export not found");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\021module unresolved");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\027  suggesting: `(import ");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\002)\047");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\025  suggesting one of:\012");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\026Warning:     `(import ");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\003)\047\012");
lf[286]=C_h_intern(&lf[286],7,"\004coredb");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000(reference to possibly unbound identifier");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000 exported identifier for module `");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\026\047 has not been defined");
lf[290]=C_h_intern(&lf[290],14,"make-parameter");
lf[291]=C_h_intern(&lf[291],12,"syntax-rules");
lf[292]=C_h_intern(&lf[292],3,"...");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[294]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[295]=C_h_intern(&lf[295],6,"export");
lf[296]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000!`export\047 used outside module body");
lf[299]=C_h_intern(&lf[299],16,"begin-for-syntax");
lf[300]=C_h_intern(&lf[300],24,"\004coreelaborationtimeonly");
lf[301]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[302]=C_h_intern(&lf[302],1,"*");
lf[303]=C_h_intern(&lf[303],11,"\004coremodule");
lf[304]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[305]=C_h_intern(&lf[305],17,"require-extension");
lf[306]=C_h_intern(&lf[306],22,"\004corerequire-extension");
lf[307]=C_h_intern(&lf[307],15,"require-library");
lf[308]=C_h_intern(&lf[308],11,"cond-expand");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[310]=C_h_intern(&lf[310],12,"\003sysfeature\077");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[312]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[313]=C_h_intern(&lf[313],3,"not");
lf[314]=C_h_intern(&lf[314],5,"delay");
lf[315]=C_h_intern(&lf[315],16,"\003sysmake-promise");
lf[316]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[317]=C_h_intern(&lf[317],10,"quasiquote");
lf[318]=C_h_intern(&lf[318],8,"\003syslist");
lf[319]=C_h_intern(&lf[319],17,"%unquote-splicing");
lf[320]=C_h_intern(&lf[320],1,"a");
lf[321]=C_h_intern(&lf[321],1,"b");
lf[322]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[323]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[324]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[325]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[326]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[327]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[328]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[329]=C_h_intern(&lf[329],16,"unquote-splicing");
lf[330]=C_h_intern(&lf[330],7,"unquote");
lf[331]=C_h_intern(&lf[331],2,"do");
lf[332]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[333]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[334]=C_h_intern(&lf[334],2,"if");
lf[335]=C_h_intern(&lf[335],6,"doloop");
lf[336]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001"
"\000\000\000\001");
lf[337]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[338]=C_h_intern(&lf[338],4,"case");
lf[339]=C_h_intern(&lf[339],8,"\003syseqv\077");
lf[340]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[341]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[342]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[343]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[344]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[345]=C_h_intern(&lf[345],2,"=>");
lf[346]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[347]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[348]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[351]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[352]=C_h_intern(&lf[352],17,"import-for-syntax");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\020\000hygienic-macros\376\003\000\000\002\376\001\000\000\015\000syntax-rules\376\377\016");
C_register_lf2(lf,354,create_ptable());
t2=C_mutate(&lf[0] /* (set! c220 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3136,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 41   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),t3,lf[353],*((C_word*)lf[2]+1));}

/* k3134 */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3136,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! features ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3164,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 68   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[290]))(3,*((C_word*)lf[290]+1),t3,C_SCHEME_END_OF_LIST);}

/* k3162 in k3134 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3164,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! current-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3168,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 69   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[290]))(3,*((C_word*)lf[290]+1),t3,C_SCHEME_END_OF_LIST);}

/* k3166 in k3162 in k3134 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3168,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! current-meta-environment ...) */,t1);
t3=C_mutate(&lf[5] /* (set! lookup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3170,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[8] /* (set! macro-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3188,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[14]+1 /* (set! strip-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3263,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[19]+1 /* (set! strip-syntax ...) */,C_retrieve(lf[14]));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 134  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[290]))(3,*((C_word*)lf[290]+1),t7,C_SCHEME_END_OF_LIST);}

/* k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word ab[85],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3472,2,t0,t1);}
t2=C_mutate((C_word*)lf[20]+1 /* (set! macro-environment ...) */,t1);
t3=C_set_block_item(lf[21] /* chicken-macro-environment */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[22] /* chicken-ffi-macro-environment */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[23]+1 /* (set! syntactic-environment? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3476,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[24]+1 /* (set! syntactic-environment-symbols ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3604,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[25]+1 /* (set! extend-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3682,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[26]+1 /* (set! copy-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3715,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[27]+1 /* (set! macro? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3728,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[28]+1 /* (set! unregister-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3778,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[30]+1 /* (set! undefine-macro! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3829,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[31]+1 /* (set! expand-0 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3835,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(lf[64] /* compiler-syntax-hook */,0,C_SCHEME_FALSE);
t14=C_set_block_item(lf[67] /* enable-runtime-macros */,0,C_SCHEME_FALSE);
t15=C_mutate((C_word*)lf[68]+1 /* (set! module-rename ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4336,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[15]+1 /* (set! alias-global-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4354,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[76]+1 /* (set! expand ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4440,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[77]+1 /* (set! expand ...) */,C_retrieve(lf[76]));
t19=C_mutate((C_word*)lf[78]+1 /* (set! extended-lambda-list? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4526,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t20=*((C_word*)lf[82]+1);
t21=C_retrieve(lf[12]);
t22=C_mutate((C_word*)lf[83]+1 /* (set! expand-extended-lambda-list ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4569,a[2]=t20,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp));
t23=*((C_word*)lf[82]+1);
t24=*((C_word*)lf[104]+1);
t25=C_mutate((C_word*)lf[105]+1 /* (set! canonicalize-body ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5163,a[2]=t24,a[3]=t23,a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp));
t26=C_mutate(&lf[127] /* (set! match-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5933,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[117]+1 /* (set! expand-curried-define ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6016,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t28=C_set_block_item(lf[128] /* line-number-database */,0,C_SCHEME_FALSE);
t29=C_set_block_item(lf[129] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
t30=C_mutate((C_word*)lf[40]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6086,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[132]+1 /* (set! syntax-error ...) */,C_retrieve(lf[40]));
t32=C_mutate((C_word*)lf[44]+1 /* (set! syntax-rules-mismatch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6097,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[134]+1 /* (set! get-line-number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6103,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t34=*((C_word*)lf[35]+1);
t35=C_retrieve(lf[136]);
t36=C_retrieve(lf[134]);
t37=*((C_word*)lf[43]+1);
t38=C_mutate((C_word*)lf[57]+1 /* (set! check-syntax ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6139,a[2]=t35,a[3]=t36,a[4]=t37,a[5]=t34,a[6]=((C_word)li84),tmp=(C_word)a,a+=7,tmp));
t39=C_mutate((C_word*)lf[168]+1 /* (set! er-macro-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6601,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[169]+1 /* (set! er-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6604,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[170]+1 /* (set! expand-import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6796,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7651,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t43=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13809,a[2]=t42,tmp=(C_word)a,a+=3,tmp);
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13811,a[2]=((C_word)li211),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 969  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t43,t44);}

/* a13810 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13811,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
((C_proc9)C_retrieve_symbol_proc(lf[170]))(9,*((C_word*)lf[170]+1),t1,t2,t3,t4,C_retrieve(lf[3]),C_retrieve(lf[20]),C_SCHEME_FALSE,lf[248]);}

/* k13807 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 967  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[248],C_SCHEME_END_OF_LIST,t1);}

/* k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7654,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13799,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13801,a[2]=((C_word)li210),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 975  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a13800 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13801(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13801,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
((C_proc9)C_retrieve_symbol_proc(lf[170]))(9,*((C_word*)lf[170]+1),t1,t2,t3,t4,C_retrieve(lf[4]),C_retrieve(lf[177]),C_SCHEME_TRUE,lf[352]);}

/* k13797 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 973  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[352],C_SCHEME_END_OF_LIST,t1);}

/* k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7658,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 979  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t2);}

/* k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7658,2,t0,t1);}
t2=C_mutate((C_word*)lf[201]+1 /* (set! initial-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13657,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13659,a[2]=((C_word)li209),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 984  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t4,t5);}

/* a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13659,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13669,a[2]=t3,a[3]=t7,a[4]=((C_word)li208),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_13669(t9,t1,t5);}

/* loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_13669(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13669,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13725,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 995  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t6,lf[108],t3,lf[347]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13738,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 999  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t6,lf[108],t3,lf[349]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13685,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 990  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t5,lf[108],t3,lf[153]);}}

/* k13683 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 991  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t2,lf[108],((C_word*)t0)[4],lf[351]);}

/* k13686 in k13683 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13716,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 992  ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[73]))(2,*((C_word*)lf[73]+1),t3);}

/* k13714 in k13686 in k13683 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 992  ##sys#register-export */
((C_proc4)C_retrieve_symbol_proc(lf[255]))(4,*((C_word*)lf[255]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13689 in k13686 in k13683 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13691,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[66],t4));}
else{
t2=(C_word)C_a_i_cons(&a,2,lf[350],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[66],t3));}}

/* k13736 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1000 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t2,lf[108],((C_word*)t0)[3],lf[348]);}

/* k13739 in k13736 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13787,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1001 ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[73]))(2,*((C_word*)lf[73]+1),t4);}

/* k13785 in k13739 in k13736 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1001 ##sys#register-export */
((C_proc4)C_retrieve_symbol_proc(lf[255]))(4,*((C_word*)lf[255]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13742 in k13739 in k13736 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13744,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1004 r */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[115]);}

/* k13765 in k13742 in k13739 in k13736 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13767,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13779,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13777 in k13765 in k13742 in k13739 in k13736 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13779,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[66],t5));}

/* k13723 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 996  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t2,lf[108],((C_word*)t0)[2],lf[346]);}

/* k13726 in k13723 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13735,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 997  ##sys#expand-curried-define */
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13733 in k13726 in k13723 in loop in a13658 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 997  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_13669(t2,((C_word*)t0)[2],t1);}

/* k13655 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 981  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[108],C_SCHEME_END_OF_LIST,t1);}

/* k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13598,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13600,a[2]=((C_word)li207),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1009 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a13599 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13600,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13629,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1018 r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[334]);}}}

/* k13627 in a13599 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13649,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1018 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}

/* k13647 in k13627 in a13599 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13651 in k13647 in k13627 in a13599 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13653,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k13596 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1006 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[237],C_SCHEME_END_OF_LIST,t1);}

/* k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13508,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13510,a[2]=((C_word)li206),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1023 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a13509 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13510,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13535,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1032 r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[91]);}}}

/* k13533 in a13509 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1033 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[49]);}

/* k13540 in k13533 in a13509 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13542,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1034 r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[334]);}

/* k13560 in k13540 in k13533 in a13509 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1034 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[229]);}

/* k13580 in k13560 in k13540 in k13533 in a13509 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13584 in k13580 in k13560 in k13540 in k13533 in a13509 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13586,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k13506 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1020 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[229],C_SCHEME_END_OF_LIST,t1);}

/* k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13178,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13180,a[2]=((C_word)li205),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1039 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13180(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13180,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13187,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1042 r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[49]);}

/* k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1043 r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[334]);}

/* k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1044 r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[345]);}

/* k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1045 r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[229]);}

/* k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 1046 r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[233]);}

/* k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1047 r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[115]);}

/* k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13202,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13207,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,a[10]=((C_word*)t0)[10],a[11]=((C_word)li204),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_13207(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_13207(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13207,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_13223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
/* expand.scm: 1053 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t5,lf[234],t3,lf[343]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[344]);}}

/* k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_13229,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* expand.scm: 1054 c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k13227 in k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13229,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13236,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
/* ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13265,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[12],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1055 expand */
t5=((C_word*)((C_word*)t0)[9])[1];
f_13207(t5,t4,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[11]);
/* expand.scm: 1056 c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}}

/* k13269 in k13227 in k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13271,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13274,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1057 r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[91]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13339,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[11]))){
t3=(C_word)C_i_length(((C_word*)t0)[11]);
t4=(C_word)C_eqp(t3,C_fix(4));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[11]);
/* expand.scm: 1063 c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,((C_word*)t0)[2],t5);}
else{
t5=t2;
f_13339(2,t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_13339(2,t3,C_SCHEME_FALSE);}}}

/* k13337 in k13269 in k13227 in k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13339,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13342,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1064 r */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[91]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13464,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* ##sys#append */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k13462 in k13337 in k13269 in k13227 in k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13464,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13460,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1073 expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_13207(t4,t3,((C_word*)t0)[2]);}

/* k13458 in k13462 in k13337 in k13269 in k13227 in k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13460,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k13340 in k13337 in k13269 in k13227 in k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13342,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[225],t8);
t10=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[225],t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13397,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t9,a[7]=t13,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1070 expand */
t15=((C_word*)((C_word*)t0)[3])[1];
f_13207(t15,t14,((C_word*)t0)[2]);}

/* k13395 in k13340 in k13337 in k13269 in k13227 in k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13397,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[334],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[109],t10));}

/* k13272 in k13269 in k13227 in k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13274,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13313,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1061 expand */
t10=((C_word*)((C_word*)t0)[3])[1];
f_13207(t10,t9,((C_word*)t0)[2]);}

/* k13311 in k13272 in k13269 in k13227 in k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13313,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k13263 in k13227 in k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13265,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k13234 in k13227 in k13221 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13185 in a13179 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13236,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[106],t1));}

/* k13176 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1036 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[234],C_SCHEME_END_OF_LIST,t1);}

/* k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7673,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13011,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13013,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1078 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13013,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13017,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1080 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t5,lf[338],t2,lf[342]);}

/* k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13017,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13026,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1083 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[91]);}

/* k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1084 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[334]);}

/* k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1085 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[229]);}

/* k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1086 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[233]);}

/* k13033 in k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13035,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13054,a[2]=((C_word*)t0)[6],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13056,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li202),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_13056(t9,t5,((C_word*)t0)[2]);}

/* expand in k13033 in k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_13056(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13056,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1093 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t5,lf[338],t3,lf[340]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[341]);}}

/* k13070 in expand in k13033 in k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13078,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 1094 c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k13076 in k13070 in expand in k13033 in k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13078,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13085,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13128,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13132,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13134,a[2]=((C_word*)t0)[2],a[3]=((C_word)li201),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1096 ##sys#map */
t6=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a13133 in k13076 in k13070 in expand in k13033 in k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13134,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[85],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[339],t6));}

/* k13130 in k13076 in k13070 in expand in k13033 in k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k13126 in k13076 in k13070 in expand in k13033 in k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13128,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k13118 in k13126 in k13076 in k13070 in expand in k13033 in k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13120,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13116,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1099 expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_13056(t4,t3,((C_word*)t0)[2]);}

/* k13114 in k13118 in k13126 in k13076 in k13070 in expand in k13033 in k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13116,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k13083 in k13076 in k13070 in expand in k13033 in k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13085,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[106],t1));}

/* k13052 in k13033 in k13030 in k13027 in k13024 in k13015 in a13012 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13054,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[49],t3));}

/* k13009 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_13011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1075 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[338],C_SCHEME_END_OF_LIST,t1);}

/* k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12942,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12944,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1104 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a12943 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12944,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12948,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1106 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t5,lf[103],t2,lf[337]);}

/* k12946 in a12943 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12948,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12957,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1109 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[49]);}

/* k12955 in k12946 in a12943 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12957,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12962,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li199),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_12962(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k12955 in k12946 in a12943 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_12962(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12962,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12980,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12999,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1113 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k12997 in expand in k12955 in k12946 in a12943 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12999,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k12978 in expand in k12955 in k12946 in a12943 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12980,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12940 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1101 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[103],C_SCHEME_END_OF_LIST,t1);}

/* k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12763,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12765,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1118 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12765,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12769,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1120 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t5,lf[331],t2,lf[336]);}

/* k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12769,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12781,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1124 r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[335]);}

/* k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1125 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[49]);}

/* k12782 in k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1126 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[334]);}

/* k12785 in k12782 in k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12922,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1127 ##sys#map */
t4=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a12921 in k12785 in k12782 in k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12922,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k12800 in k12785 in k12782 in k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12802,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t5=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_12829(t6,lf[333]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12920,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t7=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,C_SCHEME_END_OF_LIST);}}

/* k12918 in k12800 in k12785 in k12782 in k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12920,2,t0,t1);}
t2=((C_word*)t0)[2];
f_12829(t2,(C_word)C_a_i_cons(&a,2,lf[106],t1));}

/* k12827 in k12800 in k12785 in k12782 in k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_12829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12829,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_12845(t4,lf[332]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12910,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k12908 in k12827 in k12800 in k12785 in k12782 in k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12910,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_12845(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12843 in k12827 in k12800 in k12785 in k12782 in k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_12845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12845,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12865,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12867,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1138 ##sys#map */
t5=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a12866 in k12843 in k12827 in k12800 in k12785 in k12782 in k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12867,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_car(t2));}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t7));}}

/* k12863 in k12843 in k12827 in k12800 in k12785 in k12782 in k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k12859 in k12843 in k12827 in k12800 in k12785 in k12782 in k12779 in k12767 in a12764 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12861,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[53],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[106],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k12761 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1115 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[331],C_SCHEME_END_OF_LIST,t1);}

/* k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12368,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12370,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1147 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12370(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12370,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12374,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1149 r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[85]);}

/* k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1150 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[317]);}

/* k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1151 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[330]);}

/* k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1152 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[329]);}

/* k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12383,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12385,a[2]=t5,a[3]=t7,a[4]=((C_word)li192),tmp=(C_word)a,a+=5,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12395,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word)li193),tmp=(C_word)a,a+=9,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12664,a[2]=t7,a[3]=((C_word)li194),tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12752,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1202 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t11,lf[317],((C_word*)t0)[3],lf[328]);}

/* k12750 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1203 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12385(t3,((C_word*)t0)[2],t2,C_fix(0));}

/* simplify in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_12664(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12664,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12668,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1190 match-expression */
f_5933(t3,t2,lf[326],lf[327]);}

/* k12666 in simplify in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12668,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[320],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[318],t4);
/* expand.scm: 1191 simplify */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12664(t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1192 match-expression */
f_5933(t2,((C_word*)t0)[2],lf[324],lf[325]);}}

/* k12691 in k12666 in simplify in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12693,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[321],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_i_assq(lf[320],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* ##sys#append */
t8=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1199 match-expression */
f_5933(t2,((C_word*)t0)[2],lf[322],lf[323]);}}

/* k12737 in k12691 in k12666 in simplify in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[320],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k12722 in k12691 in k12666 in simplify in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12724,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[318],t2);
/* expand.scm: 1196 simplify */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12664(t4,((C_word*)t0)[2],t3);}

/* walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_12395(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12395,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12413,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12417,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1156 vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[222]+1)))(3,*((C_word*)lf[222]+1),t5,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=t3,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1161 c */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t4);}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4));}}}

/* k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12442,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12468,a[2]=t5,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
/* expand.scm: 1167 walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_12385(t8,t6,t2,t7);}}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2));}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1169 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k12487 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12489,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12514,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1172 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_12385(t7,t4,t5,t6);}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12537,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1174 walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_12385(t4,t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12636,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1178 c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12650,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1188 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_12385(t3,t2,((C_word*)t0)[4],((C_word*)t0)[6]);}}}

/* k12648 in k12487 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12658,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1188 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12385(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12656 in k12648 in k12487 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12658,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[213],t3));}

/* k12634 in k12487 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12636,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12579,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1182 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12385(t6,t5,((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12610,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1184 walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_12385(t7,t5,t3,t6);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12625,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1186 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_12385(t4,t3,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* k12623 in k12634 in k12487 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12633,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1186 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12385(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12631 in k12623 in k12634 in k12487 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12633,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[213],t3));}

/* k12608 in k12634 in k12487 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12610,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[319],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[318],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12598,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1185 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12385(t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12596 in k12608 in k12634 in k12487 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12598,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[213],t3));}

/* k12577 in k12634 in k12487 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12579,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[54],t3));}

/* k12535 in k12487 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12537,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[213],((C_word*)t0)[2],t1));}

/* k12512 in k12487 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12514,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[318],t3));}

/* k12466 in k12440 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12468,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[318],((C_word*)t0)[2],t1));}

/* k12415 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1156 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12385(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12411 in walk1 in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12413,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[209],t2));}

/* walk in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_12385(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12385,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12393,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1153 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12395(t5,t4,t2,t3);}

/* k12391 in walk in k12381 in k12378 in k12375 in k12372 in a12369 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1153 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12664(t2,((C_word*)t0)[2],t1);}

/* k12366 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1144 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[317],C_SCHEME_END_OF_LIST,t1);}

/* k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7685,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12335,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12337,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1208 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a12336 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12337,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12341,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1210 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t5,lf[314],t2,lf[316]);}

/* k12339 in a12336 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12341,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[115],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[315],t6));}

/* k12333 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1205 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[314],C_SCHEME_END_OF_LIST,t1);}

/* k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7688,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12054,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12056,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1216 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12056,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12063,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1219 r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[229]);}

/* k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1220 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[313]);}

/* k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1221 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[233]);}

/* k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12072,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1222 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}

/* k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12074,a[2]=((C_word*)t0)[7],a[3]=((C_word)li186),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12084,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t4,a[7]=t1,a[8]=((C_word)li187),tmp=(C_word)a,a+=9,tmp));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12234,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t7,a[7]=((C_word*)t0)[7],a[8]=((C_word)li189),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_12234(t9,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* expand in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_12234(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12234,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12248,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12250,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12287,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1259 c */
t8=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t6,((C_word*)t0)[3]);}
else{
/* expand.scm: 1257 err */
t6=((C_word*)t0)[2];
f_12074(t6,t1,t4);}}
else{
/* expand.scm: 1252 err */
t4=((C_word*)t0)[2];
f_12074(t4,t1,t2);}}}

/* k12285 in expand in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12287,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[312]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12303,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12309,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1264 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12084(t3,t2,((C_word*)t0)[2]);}}

/* k12307 in k12285 in expand in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12309,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12316,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
/* expand.scm: 1265 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12234(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k12314 in k12307 in k12285 in expand in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12316,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[106],t1));}

/* k12301 in k12285 in expand in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12303,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[106],t1));}

/* a12249 in expand in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12250,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k12246 in expand in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[18]+1),lf[311],t1);}

/* test in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_12084(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12084,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 1228 ##sys#feature? */
((C_proc3)C_retrieve_symbol_proc(lf[310]))(3,*((C_word*)lf[310]+1),t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12115,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1233 c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],t3);}
else{
/* expand.scm: 1229 err */
t3=((C_word*)t0)[5];
f_12074(t3,t1,t2);}}}

/* k12113 in test in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12115,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12133,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[11]);
/* expand.scm: 1236 test */
t5=((C_word*)((C_word*)t0)[8])[1];
f_12084(t5,t3,t4);}
else{
/* expand.scm: 1238 err */
t3=((C_word*)t0)[7];
f_12074(t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1239 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k12159 in k12113 in test in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12161,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12176,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 1242 test */
t5=((C_word*)((C_word*)t0)[7])[1];
f_12084(t5,t3,t4);}
else{
/* expand.scm: 1244 err */
t3=((C_word*)t0)[6];
f_12074(t3,((C_word*)t0)[9],((C_word*)t0)[5]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12211,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1245 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k12209 in k12159 in k12113 in test in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12211,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12218,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1245 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12084(t4,t2,t3);}
else{
/* expand.scm: 1246 err */
t2=((C_word*)t0)[2];
f_12074(t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k12216 in k12209 in k12159 in k12113 in test in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k12174 in k12159 in k12113 in test in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12176,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12190,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k12188 in k12174 in k12159 in k12113 in test in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12190,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1243 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12084(t3,((C_word*)t0)[2],t2);}

/* k12131 in k12113 in test in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12133,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12144,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12142 in k12131 in k12113 in test in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12144,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1237 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12084(t3,((C_word*)t0)[2],t2);}

/* err in k12070 in k12067 in k12064 in k12061 in a12055 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_12074(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12074,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[308],((C_word*)t0)[2]);
/* expand.scm: 1224 ##sys#error */
t4=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[309],t2,t3);}

/* k12052 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1213 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[308],C_SCHEME_END_OF_LIST,t1);}

/* k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7691,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12033,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12035,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1270 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a12034 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12035,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[306],t7));}

/* k12031 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1267 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[307],C_SCHEME_END_OF_LIST,t1);}

/* k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12012,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12014,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1278 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a12013 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12014,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[306],t7));}

/* k12010 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1275 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[305],C_SCHEME_END_OF_LIST,t1);}

/* k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11961,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11963,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1286 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a11962 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11963,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11967,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1288 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t5,lf[71],t2,lf[304]);}

/* k11965 in a11962 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11967,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12004,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* expand.scm: 1291 strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,t4);}

/* k12002 in k11965 in a11962 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_12004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12004,2,t0,t1);}
t2=(C_word)C_eqp(lf[302],t1);
t3=(C_truep(t2)?C_SCHEME_TRUE:(C_word)C_i_caddr(((C_word*)t0)[4]));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* ##sys#append */
t6=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k11988 in k12002 in k11965 in a11962 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11990,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[303],t3));}

/* k11959 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1283 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[71],C_SCHEME_END_OF_LIST,t1);}

/* k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11917,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11919,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1299 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a11918 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11919,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11923,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1301 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t5,lf[299],t2,lf[301]);}

/* k11921 in a11918 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11953,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k11951 in k11921 in a11918 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11953,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* expand.scm: 1302 ##sys#register-meta-expression */
((C_proc3)C_retrieve_symbol_proc(lf[251]))(3,*((C_word*)lf[251]+1),((C_word*)t0)[2],t2);}

/* k11924 in k11921 in a11918 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11941,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k11939 in k11924 in k11921 in a11918 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11941,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[300],t3));}

/* k11915 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1296 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[299],C_SCHEME_END_OF_LIST,t1);}

/* k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11798,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11800,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1308 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a11799 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11800,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11807,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1311 ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[73]))(2,*((C_word*)lf[73]+1),t6);}

/* k11805 in a11799 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11810,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_11810(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1313 syntax-error */
((C_proc4)C_retrieve_symbol_proc(lf[132]))(4,*((C_word*)lf[132]+1),t2,lf[295],lf[298]);}}

/* k11808 in k11805 in a11799 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11830,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word)li180),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11830(t6,t2,((C_word*)t0)[2]);}

/* loop1933 in k11808 in k11805 in a11799 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11830(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11830,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11843,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11853,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
t6=t5;
f_11853(t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11868,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
t7=t5;
f_11853(t7,f_11868(t3));}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop in loop1933 in k11808 in k11805 in a11799 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static C_word C_fcall f_11868(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_TRUE);}}
else{
return(C_SCHEME_TRUE);}}}

/* k11851 in loop1933 in k11808 in k11805 in a11799 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
t3=(C_word)C_i_check_structure(t2,lf[71]);
t4=(C_word)C_i_block_ref(t2,C_fix(1));
/* expand.scm: 1322 syntax-error */
((C_proc6)C_retrieve_symbol_proc(lf[132]))(6,*((C_word*)lf[132]+1),((C_word*)t0)[6],lf[295],lf[297],((C_word*)t0)[5],t4);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11830(t3,((C_word*)t0)[2],t2);}}

/* k11841 in loop1933 in k11808 in k11805 in a11799 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11830(t3,((C_word*)t0)[2],t2);}

/* k11811 in k11808 in k11805 in a11799 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11816,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11820,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=(C_word)C_i_check_structure(t4,lf[71]);
t6=(C_word)C_i_block_ref(t4,C_fix(2));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11828,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t8=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[14]),((C_word*)t0)[2]);}

/* k11826 in k11811 in k11808 in k11805 in a11799 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1326 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11818 in k11811 in k11808 in k11805 in a11799 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[71]);
/* ##sys#block-set! */
t4=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(2),t1);}

/* k11814 in k11811 in k11808 in k11805 in a11799 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[296]);}

/* k11796 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1305 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[295],C_SCHEME_END_OF_LIST,t1);}

/* k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7706,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11761,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11763,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t3,t4);}

/* a11762 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11763,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11767,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t5,lf[291],t2,lf[294]);}

/* k11765 in a11762 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11767,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[5]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=lf[292];
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t4)[1]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t7,a[6]=t4,a[7]=t9,tmp=(C_word)a,a+=8,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t10,lf[291],((C_word*)t0)[5],lf[293]);}
else{
/* ##sys#process-syntax-rules */
((C_proc7)C_retrieve_symbol_proc(lf[202]))(7,*((C_word*)lf[202]+1),((C_word*)t0)[4],((C_word*)t9)[1],((C_word*)t7)[1],((C_word*)t4)[1],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11783 in k11765 in a11762 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)((C_word*)t0)[6])[1]);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
/* ##sys#process-syntax-rules */
((C_proc7)C_retrieve_symbol_proc(lf[202]))(7,*((C_word*)lf[202]+1),((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11759 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[291],C_SCHEME_END_OF_LIST,t1);}

/* k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7706,2,t0,t1);}
t2=C_mutate((C_word*)lf[202]+1 /* (set! process-syntax-rules ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7708,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[238]+1 /* (set! macro-subset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9349,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[239]+1 /* (set! fixup-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9414,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9504,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11757,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1359 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t6);}

/* k11755 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1359 ##sys#fixup-macro-environment */
((C_proc3)C_retrieve_symbol_proc(lf[239]))(3,*((C_word*)lf[239]+1),((C_word*)t0)[2],t1);}

/* k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9504,2,t0,t1);}
t2=C_mutate((C_word*)lf[240]+1 /* (set! default-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9508,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11753,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1364 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t4);}

/* k11751 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1364 make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[290]))(3,*((C_word*)lf[290]+1),((C_word*)t0)[2],t1);}

/* k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9508,2,t0,t1);}
t2=C_mutate((C_word*)lf[177]+1 /* (set! meta-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9512,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1365 make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[290]))(3,*((C_word*)lf[290]+1),t3,C_SCHEME_FALSE);}

/* k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9512,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* (set! current-module ...) */,t1);
t3=C_mutate(&lf[241] /* (set! module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9526,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[242]+1 /* (set! set-module-undefined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9607,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[243]+1 /* (set! module-undefined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9616,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[244]+1 /* (set! module-name ...) */,C_retrieve2(lf[241],"module-name"));
t7=C_mutate((C_word*)lf[245]+1 /* (set! module-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9716,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[175]+1 /* (set! find-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9740,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[250]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9780,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[251]+1 /* (set! register-meta-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9783,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[252] /* (set! check-for-redef ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9803,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[255]+1 /* (set! register-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9824,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[257]+1 /* (set! register-syntax-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9913,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[72]+1 /* (set! register-undefined ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9994,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[259]+1 /* (set! register-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10016,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[194]+1 /* (set! mark-imported-symbols ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10084,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[260] /* (set! module-indirect-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10147,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate(&lf[266] /* (set! merge-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10423,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[267]+1 /* (set! compiled-module-registration ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10483,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[268]+1 /* (set! register-compiled-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10877,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[272]+1 /* (set! primitive-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11136,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[274]+1 /* (set! register-primitive-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11153,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[256]+1 /* (set! find-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11234,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[277]+1 /* (set! finalize-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11319,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(lf[246] /* module-table */,0,C_SCHEME_END_OF_LIST);
t26=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,C_SCHEME_UNDEFINED);}

/* ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11319(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11319,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_i_check_structure(t3,lf[71]);
t5=(C_word)C_i_block_ref(t3,C_fix(2));
t6=t2;
t7=(C_word)C_i_check_structure(t6,lf[71]);
t8=(C_word)C_i_block_ref(t6,C_fix(1));
t9=t2;
t10=(C_word)C_i_check_structure(t9,lf[71]);
t11=(C_word)C_i_block_ref(t9,C_fix(3));
t12=t2;
t13=(C_word)C_i_check_structure(t12,lf[71]);
t14=(C_word)C_i_block_ref(t12,C_fix(4));
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11335,a[2]=t11,a[3]=t5,a[4]=t14,a[5]=t8,a[6]=t16,a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11732,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
t19=t2;
t20=(C_word)C_i_check_structure(t19,lf[71]);
t21=(C_word)C_i_block_ref(t19,C_fix(5));
/* map */
t22=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t17,t18,t21);}

/* a11731 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11732,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11744,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1663 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t4);}

/* k11742 in a11731 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_11338(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11689,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1668 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t4);}}

/* k11687 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11689,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11691,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li175),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11691(t5,((C_word*)t0)[2],t1);}

/* loop in k11687 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11691(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11691,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11704,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11730,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1670 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t4,t2);}}

/* k11728 in loop in k11687 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1670 ##sys#find-export */
((C_proc5)C_retrieve_symbol_proc(lf[256]))(5,*((C_word*)lf[256]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11702 in loop in k11687 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11704,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11715,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1671 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11691(t5,t3,t4);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1672 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11691(t3,((C_word*)t0)[3],t2);}}

/* k11713 in k11702 in loop in k11687 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11715,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11341,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t4=(C_truep(t3)?((C_word*)t0)[4]:((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11562,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t1,a[7]=((C_word)li174),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_11562(t8,t2,t4);}

/* loop in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11562(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(17);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11562,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?t3:(C_word)C_i_car(t3));
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[6]))){
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1680 loop */
t13=t1;
t14=t6;
t1=t13;
t2=t14;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11595,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_assq(t5,((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11610,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t5,a[6]=t6,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t10=(C_word)C_i_cdr(t7);
t11=t9;
f_11613(t11,(C_word)C_i_symbolp(t10));}
else{
t10=t9;
f_11613(t10,C_SCHEME_FALSE);}}}}

/* k11611 in loop in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11613(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11613,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=((C_word*)t0)[6];
f_11595(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1687 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}}

/* k11661 in k11611 in loop in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11663,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_11625(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_11625(t4,C_SCHEME_FALSE);}}

/* k11623 in k11661 in k11611 in loop in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11625(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11625,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=((C_word*)t0)[7];
f_11595(t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3));}
else{
if(C_truep(((C_word*)t0)[5])){
/* expand.scm: 1700 ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[68]))(4,*((C_word*)lf[68]+1),((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3]);}
else{
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11641,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11645,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11649,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1696 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t5,((C_word*)t0)[3]);}}}

/* k11647 in k11623 in k11661 in k11611 in loop in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1694 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[35]+1)))(5,*((C_word*)lf[35]+1),((C_word*)t0)[2],lf[288],t1,lf[289]);}

/* k11643 in k11623 in k11661 in k11611 in loop in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1693 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11639 in k11623 in k11661 in k11611 in loop in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11641,2,t0,t1);}
t2=((C_word*)t0)[3];
f_11595(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_FALSE));}

/* k11608 in loop in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11610,2,t0,t1);}
t2=((C_word*)t0)[3];
f_11595(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11593 in loop in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11595,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11599,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1701 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_11562(t4,t2,t3);}

/* k11597 in k11593 in loop in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11599,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11344,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11457,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1722 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t3,((C_word*)t0)[7]);}

/* k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11457,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word)li173),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_11459(t5,((C_word*)t0)[2],t1);}

/* loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11459(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11459,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11472,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t5=(C_word)C_slot(t2,C_fix(1));
t10=t1;
t11=t5;
t1=t10;
t2=t11;
goto loop;}
else{
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11486,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1706 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t6,lf[287],t3);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11484 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11489,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1707 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,((C_word*)t0)[2],lf[286]);}

/* k11487 in k11484 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11489,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11505,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11509,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11513,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1711 cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t6,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11520,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11524,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11526,a[2]=t7,a[3]=((C_word)li172),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_11526(t9,t5,t1);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11459(t3,((C_word*)t0)[2],t2);}}

/* loop in k11487 in k11484 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11526(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11526,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[283]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11540,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11552,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1720 cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t4,t2);}}

/* k11550 in loop in k11487 in k11484 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1720 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),((C_word*)t0)[2],t1);}

/* k11538 in loop in k11487 in k11484 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11544,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1721 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_11526(t4,t2,t3);}

/* k11542 in k11538 in loop in k11487 in k11484 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1719 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[35]+1)))(6,*((C_word*)lf[35]+1),((C_word*)t0)[3],lf[284],((C_word*)t0)[2],lf[285],t1);}

/* k11522 in k11487 in k11484 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1714 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),((C_word*)t0)[2],lf[282],t1);}

/* k11518 in k11487 in k11484 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1713 ##sys#warn */
((C_proc3)C_retrieve_symbol_proc(lf[184]))(3,*((C_word*)lf[184]+1),((C_word*)t0)[2],t1);}

/* k11511 in k11487 in k11484 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1711 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),((C_word*)t0)[2],t1);}

/* k11507 in k11487 in k11484 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1710 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[35]+1)))(5,*((C_word*)lf[35]+1),((C_word*)t0)[2],lf[280],t1,lf[281]);}

/* k11503 in k11487 in k11484 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1709 ##sys#warn */
((C_proc3)C_retrieve_symbol_proc(lf[184]))(3,*((C_word*)lf[184]+1),((C_word*)t0)[2],t1);}

/* k11470 in loop2982 in k11455 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11459(t3,((C_word*)t0)[2],t2);}

/* k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11347,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
/* expand.scm: 1724 ##sys#error */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[279],((C_word*)t0)[2]);}
else{
t3=t2;
f_11347(2,t3,C_SCHEME_UNDEFINED);}}

/* k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11414,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11450,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1730 module-indirect-exports */
f_10147(t4,((C_word*)t0)[5]);}

/* k11448 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11413 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11414,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11442,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1728 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t5);}}

/* k11440 in a11413 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 1729 ##sys#error */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],lf[278],t3);}}

/* k11348 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11353,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11408,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1732 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t3);}

/* k11406 in k11348 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11412,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1733 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}

/* k11410 in k11406 in k11348 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11412,2,t0,t1);}
/* expand.scm: 1731 merge-se */
f_10423(((C_word*)t0)[4],(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k11351 in k11348 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11356,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1735 ##sys#mark-imported-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[194]))(3,*((C_word*)lf[194]+1),t2,((C_word*)t0)[2]);}

/* k11354 in k11351 in k11348 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11359,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11370,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word)li170),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_11370(t6,t2,((C_word*)t0)[2]);}

/* loop3020 in k11354 in k11351 in k11348 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11370(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11370,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11383,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cadr(t3);
/* expand.scm: 1738 merge-se */
f_10423(t4,(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[2]));}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11381 in loop3020 in k11354 in k11351 in k11348 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_retrieve(lf[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_i_set_car(t3,t1);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=((C_word*)((C_word*)t0)[3])[1];
f_11370(t6,((C_word*)t0)[2],t5);}

/* k11357 in k11354 in k11351 in k11348 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11359,2,t0,t1);}
t2=C_retrieve(lf[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11365,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[2];
t6=(C_word)C_i_check_structure(t4,lf[71]);
/* ##sys#block-set! */
t7=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,C_fix(10),t5);}

/* k11363 in k11357 in k11354 in k11351 in k11348 in k11345 in k11342 in k11339 in k11336 in k11333 in ##sys#finalize-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[71]);
/* ##sys#block-set! */
t6=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(11),t4);}

/* ##sys#find-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11234,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_i_check_structure(t5,lf[71]);
t7=(C_word)C_i_block_ref(t5,C_fix(2));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11245,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_eqp(C_SCHEME_TRUE,t7);
if(C_truep(t9)){
/* expand.scm: 1648 module-exists-list */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t8,t3);}
else{
t10=t8;
f_11245(2,t10,t7);}}

/* k11243 in ##sys#find-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11245,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11247,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li168),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_11247(t5,((C_word*)t0)[2],t1);}

/* loop in k11243 in ##sys#find-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11247(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11247,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1652 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t6,t2);}
else{
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1655 loop */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}}

/* k11294 in loop in k11243 in ##sys#find-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11296,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11292,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1653 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[187]+1)))(3,*((C_word*)lf[187]+1),t4,((C_word*)t0)[4]);}
else{
t4=t3;
f_11275(t4,C_SCHEME_FALSE);}}}

/* k11290 in k11294 in loop in k11243 in ##sys#find-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_11275(t2,(C_word)C_i_memq(((C_word*)t0)[2],t1));}

/* k11273 in k11294 in loop in k11243 in ##sys#find-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_11275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1654 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11247(t3,((C_word*)t0)[4],t2);}}

/* ##sys#register-primitive-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11153r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11153r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11153r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11157,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11157(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11157(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11155 in ##sys#register-primitive-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11160,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1629 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t2);}

/* k11158 in k11155 in ##sys#register-primitive-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11175,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11199,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11198 in k11158 in k11155 in ##sys#register-primitive-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11199,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11213,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1634 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[272]))(3,*((C_word*)lf[272]+1),t3,t2);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11211 in a11198 in k11158 in k11155 in ##sys#register-primitive-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11213,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11173 in k11158 in k11155 in ##sys#register-primitive-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11179,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11181,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word)li165),tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11180 in k11173 in k11158 in k11155 in ##sys#register-primitive-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11181,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* expand.scm: 1640 ##sys#error */
t4=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[275],t2,((C_word*)t0)[2]);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11177 in k11173 in k11158 in k11155 in ##sys#register-primitive-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11179,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_a_i_record(&a,12,lf[71],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,t1);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_retrieve(lf[246]));
t7=C_mutate((C_word*)lf[246]+1 /* (set! module-table ...) */,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t4);}

/* ##sys#primitive-alias in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11136,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11140,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11147,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 1624 ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),t4,lf[273],t5);}

/* k11145 in ##sys#primitive-alias in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1623 ##sys#string->symbol */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],t1);}

/* k11138 in ##sys#primitive-alias in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11143,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1625 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t2,t1,lf[74],((C_word*)t0)[2]);}

/* k11141 in k11138 in ##sys#primitive-alias in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_10877r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_10877r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_10877r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10881,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t7;
f_10881(2,t8,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_i_cdr(t6);
if(C_truep((C_word)C_i_nullp(t8))){
t9=t7;
f_10881(2,t9,(C_word)C_i_car(t6));}
else{
/* ##sys#error */
t9=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}

/* k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10910,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11090,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11089 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11090,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10907,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1577 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t5);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11111,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 1587 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t4,t5);}}

/* k11109 in a11089 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11111,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10905 in a11089 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* expand.scm: 1580 ##sys#error */
t4=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],lf[248],lf[271],((C_word*)t0)[3]);}}
else{
/* expand.scm: 1580 ##sys#error */
t3=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[248],lf[271],((C_word*)t0)[3]);}}

/* k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11058,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11057 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11058,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11080,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_caddr(t2);
/* expand.scm: 1592 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t6,t7);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k11078 in a11057 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11080,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10911 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10916,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11040,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11039 in k10911 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11040,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11052,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 1597 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t4,t5);}

/* k11050 in a11039 in k10911 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11052,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10914 in k10911 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10916,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=(C_word)C_a_i_record(&a,12,lf[71],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,t4);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10922,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11034,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1601 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t7);}

/* k11032 in k10914 in k10911 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1602 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}

/* k11036 in k11032 in k10914 in k10911 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_11038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11038,2,t0,t1);}
/* expand.scm: 1600 merge-se */
f_10423(((C_word*)t0)[7],(C_word)C_a_i_list(&a,6,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10920 in k10914 in k10911 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1604 ##sys#mark-imported-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[194]))(3,*((C_word*)lf[194]+1),t2,((C_word*)t0)[6]);}

/* k10923 in k10920 in k10914 in k10911 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11006,a[2]=((C_word*)t0)[8],a[3]=((C_word)li157),tmp=(C_word)a,a+=4,tmp);
t3=f_11006(t2,((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10970,a[2]=((C_word*)t0)[8],a[3]=((C_word)li158),tmp=(C_word)a,a+=4,tmp);
t5=f_10970(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10944,a[2]=((C_word*)t0)[8],a[3]=((C_word)li159),tmp=(C_word)a,a+=4,tmp);
t7=f_10944(t6,((C_word*)t0)[5]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=(C_word)C_a_i_cons(&a,2,t8,C_retrieve(lf[246]));
t10=C_mutate((C_word*)lf[246]+1 /* (set! module-table ...) */,t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,((C_word*)t0)[3]);}

/* loop2862 in k10923 in k10920 in k10914 in k10911 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static C_word C_fcall f_10944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_set_car(t3,((C_word*)t0)[2]);
t5=(C_word)C_slot(t1,C_fix(1));
t8=t5;
t1=t8;
goto loop;}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* loop2850 in k10923 in k10920 in k10914 in k10911 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static C_word C_fcall f_10970(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_set_car(t4,((C_word*)t0)[2]);
t6=(C_word)C_slot(t1,C_fix(1));
t10=t6;
t1=t10;
goto loop;}
else{
t4=(C_word)C_slot(t1,C_fix(1));
t10=t4;
t1=t10;
goto loop;}}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* loop2840 in k10923 in k10920 in k10914 in k10911 in k10908 in k10879 in ##sys#register-compiled-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static C_word C_fcall f_11006(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_set_car(t3,((C_word*)t0)[2]);
t5=(C_word)C_slot(t1,C_fix(1));
t8=t5;
t1=t8;
goto loop;}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10483(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10483,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_i_check_structure(t3,lf[71]);
t5=(C_word)C_i_block_ref(t3,C_fix(3));
t6=t2;
t7=(C_word)C_i_check_structure(t6,lf[71]);
t8=(C_word)C_i_block_ref(t6,C_fix(1));
t9=t2;
t10=(C_word)C_i_check_structure(t9,lf[71]);
t11=(C_word)C_i_block_ref(t9,C_fix(7));
t12=t2;
t13=(C_word)C_i_check_structure(t12,lf[71]);
t14=(C_word)C_i_block_ref(t12,C_fix(11));
t15=t2;
t16=(C_word)C_i_check_structure(t15,lf[71]);
t17=(C_word)C_i_block_ref(t15,C_fix(8));
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10506,a[2]=t17,a[3]=t5,a[4]=t14,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t11))){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10875,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t20=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t19,t11,C_SCHEME_END_OF_LIST);}
else{
t19=t18;
f_10506(t19,C_SCHEME_END_OF_LIST);}}

/* k10873 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10875,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[248],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[85],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[270],t5);
t7=((C_word*)t0)[2];
f_10506(t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10506,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10510,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10845,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_10514(t4,C_SCHEME_END_OF_LIST);}}

/* k10843 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10845,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[248],t1);
t3=((C_word*)t0)[2];
f_10514(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10514(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10514,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10518,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10827,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[4];
t6=(C_word)C_i_check_structure(t5,lf[71]);
t7=(C_word)C_i_block_ref(t5,C_fix(9));
/* map */
t8=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,C_retrieve(lf[14]),t7);}

/* k10825 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1543 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[82]+1)))(3,*((C_word*)lf[82]+1),((C_word*)t0)[2],t1);}

/* k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10522,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=(C_word)C_i_check_structure(t2,lf[71]);
t4=(C_word)C_i_block_ref(t2,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[85],t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10740,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10742,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10815,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1551 module-indirect-exports */
f_10147(t10,((C_word*)t0)[5]);}

/* k10813 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10741 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10742,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[85],t7));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[85],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[85],t7);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[155],t12));}}

/* k10738 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10736,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[155],t1);
t3=((C_word*)t0)[7];
t4=(C_word)C_i_check_structure(t3,lf[71]);
t5=(C_word)C_i_block_ref(t3,C_fix(10));
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[85],t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10664,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10668,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10670,a[2]=((C_word*)t0)[2],a[3]=((C_word)li154),tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,((C_word*)t0)[3]);}

/* a10669 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10670,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(t3,((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[85],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10702,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(t4);
/* expand.scm: 1558 ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t8,t9);}
else{
t5=C_retrieve(lf[9]);
t6=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[85],t6));}}

/* k10700 in a10669 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10702,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[269],t3));}

/* k10666 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10662 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10664,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[155],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10574,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10578,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
/* ##sys#append */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t5=((C_word*)t0)[2];
t6=(C_word)C_i_check_structure(t5,lf[71]);
t7=(C_word)C_i_block_ref(t5,C_fix(5));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10590,a[2]=t9,a[3]=((C_word*)t0)[3],a[4]=((C_word)li153),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_10590(t11,t4,t7);}}

/* loop in k10662 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10590(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10590,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10660,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1568 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t3,t2);}}

/* k10658 in loop in k10662 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10660,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,((C_word*)t0)[5]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1568 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10590(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10613,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1570 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t2,((C_word*)t0)[4]);}}

/* k10611 in k10658 in loop in k10662 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1571 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t2,((C_word*)t0)[3]);}

/* k10654 in k10611 in k10658 in loop in k10662 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10656,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[85],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10648,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1571 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[187]+1)))(3,*((C_word*)lf[187]+1),t5,((C_word*)t0)[3]);}

/* k10646 in k10654 in k10611 in k10658 in loop in k10662 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1571 ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],t1);}

/* k10642 in k10654 in k10611 in k10658 in loop in k10662 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10644,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[269],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10624,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1572 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_10590(t7,t5,t6);}

/* k10622 in k10642 in k10654 in k10611 in k10658 in loop in k10662 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10624,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10576 in k10662 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10572 in k10662 in k10734 in k10520 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10574,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[155],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[268],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t10=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,((C_word*)t0)[3],((C_word*)t0)[2],t9);}

/* k10516 in k10512 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10508 in k10504 in ##sys#compiled-module-registration in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* merge-se in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10423(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10423,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10427,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,*((C_word*)lf[61]+1),t2);}

/* k10425 in merge-se in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10427,2,t0,t1);}
t2=C_retrieve(lf[9]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10438,a[2]=t5,a[3]=((C_word)li151),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_10438(t7,t3,t1);}

/* loop in k10425 in merge-se in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10438(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10438,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10477,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1530 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t3,t2);}}

/* k10475 in loop in k10425 in merge-se in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10477,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(t1,t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1530 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10438(t4,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10469,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1531 loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10438(t6,t4,t5);}}

/* k10467 in k10475 in loop in k10425 in merge-se in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10469,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10431 in k10425 in merge-se in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[9]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10147(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10147,NULL,2,t1,t2);}
t3=t2;
t4=(C_word)C_i_check_structure(t3,lf[71]);
t5=(C_word)C_i_block_ref(t3,C_fix(2));
t6=t2;
t7=(C_word)C_i_check_structure(t6,lf[71]);
t8=(C_word)C_i_block_ref(t6,C_fix(1));
t9=t2;
t10=(C_word)C_i_check_structure(t9,lf[71]);
t11=(C_word)C_i_block_ref(t9,C_fix(3));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10205,a[2]=t8,a[3]=((C_word)li147),tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_eqp(C_SCHEME_TRUE,t5);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_END_OF_LIST);}
else{
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10228,a[2]=t8,a[3]=t11,a[4]=t12,a[5]=t15,a[6]=((C_word)li149),tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_10228(t17,t1,t5);}}

/* loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10228(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10228,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_cdr(t2);
/* expand.scm: 1499 loop */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10255,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1501 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[187]+1)))(3,*((C_word*)lf[187]+1),t4,t2);}}}

/* k10253 in loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10255,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10257,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li148),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_10257(t5,((C_word*)t0)[2],t1);}

/* loop2 in k10253 in loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10257(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10257,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 1502 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_10228(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1503 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t4);}}

/* k10415 in loop2 in k10253 in loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10417,2,t0,t1);}
if(C_truep((C_word)C_i_assq(((C_word*)t0)[8],t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10280,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1504 warn */
t4=((C_word*)t0)[4];
f_10205(t4,t2,lf[263],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10304,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10323,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t6)){
t8=t4;
f_10304(t8,(C_word)C_a_i_cons(&a,2,t5,t6));}
else{
t8=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1511 ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[68]))(4,*((C_word*)lf[68]+1),t7,t8,((C_word*)t0)[2]);}}
else{
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10405,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1513 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t5);}}}

/* k10403 in k10415 in loop2 in k10253 in loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10405,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10353,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 1516 loop2 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10257(t9,t7,t8);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10368,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1518 warn */
t6=((C_word*)t0)[2];
f_10205(t6,t4,lf[264],t5);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10386,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1521 warn */
t5=((C_word*)t0)[2];
f_10205(t5,t3,lf[265],t4);}}

/* k10384 in k10403 in k10415 in loop2 in k10253 in loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1522 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10257(t3,((C_word*)t0)[2],t2);}

/* k10366 in k10403 in k10415 in loop2 in k10253 in loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1519 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10257(t3,((C_word*)t0)[2],t2);}

/* k10351 in k10403 in k10415 in loop2 in k10253 in loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10353,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10321 in k10415 in loop2 in k10253 in loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10323,2,t0,t1);}
t2=((C_word*)t0)[3];
f_10304(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10302 in k10415 in loop2 in k10253 in loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10304(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10304,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10308,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1512 loop2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10257(t4,t2,t3);}

/* k10306 in k10302 in k10415 in loop2 in k10253 in loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10308,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10278 in k10415 in loop2 in k10253 in loop in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1505 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10257(t3,((C_word*)t0)[2],t2);}

/* warn in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10205(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10205,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10213,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10217,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1493 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t5,((C_word*)t0)[2]);}

/* k10215 in warn in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1493 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[35]+1)))(6,*((C_word*)lf[35]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[261],t1,lf[262]);}

/* k10211 in warn in module-indirect-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1492 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#mark-imported-symbols in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10084,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10090,a[2]=t4,a[3]=((C_word)li145),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10090(t6,t1,t2);}

/* loop2653 in ##sys#mark-imported-symbols in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10090(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10090,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10103,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10113,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
t9=(C_word)C_eqp(t7,t8);
t10=t5;
f_10113(t10,(C_word)C_i_not(t9));}
else{
t7=t5;
f_10113(t7,C_SCHEME_FALSE);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10111 in loop2653 in ##sys#mark-imported-symbols in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_10113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=C_retrieve(lf[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* expand.scm: 1478 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),((C_word*)t0)[5],t3,lf[75],C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10090(t3,((C_word*)t0)[2],t2);}}

/* k10101 in loop2653 in ##sys#mark-imported-symbols in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10090(t3,((C_word*)t0)[2],t2);}

/* ##sys#register-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+31)){
C_save_and_reclaim((void*)tr4r,(void*)f_10016r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10016r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10016r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(31);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10018,a[2]=t3,a[3]=t2,a[4]=((C_word)li142),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10031,a[2]=t5,a[3]=((C_word)li143),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10036,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-vexports26312644 */
t8=t1;
((C_proc2)C_retrieve_proc(t8))(2,t8,f_10036(C_a_i(&a,19),t7));}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-sexports26322642 */
t10=t1;
((C_proc2)C_retrieve_proc(t10))(2,t10,f_10031(C_a_i(&a,19),t6,t8));}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body26292637 */
t12=t1;
((C_proc2)C_retrieve_proc(t12))(2,t12,f_10018(C_a_i(&a,19),t5,t8,t10));}
else{
/* ##sys#error */
t12=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-vexports2631 in ##sys#register-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static C_word C_fcall f_10036(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return(f_10031(C_a_i(&a,19),((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* def-sexports2632 in ##sys#register-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static C_word C_fcall f_10031(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return(f_10018(C_a_i(&a,19),((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST));}

/* body2629 in ##sys#register-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static C_word C_fcall f_10018(C_word *a,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_check;
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_word)C_a_i_record(&a,12,lf[71],t3,t4,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t1,t2);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_retrieve(lf[246]));
t8=C_mutate((C_word*)lf[246]+1 /* (set! module-table ...) */,t7);
return(t5);}

/* ##sys#register-undefined in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9994,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10001,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1464 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t4,t3);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k9999 in ##sys#register-undefined in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_10001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10001,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1466 set-module-undefined-list! */
((C_proc4)C_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* ##sys#register-syntax-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9913,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t3;
t6=(C_word)C_i_check_structure(t5,lf[71]);
t7=(C_word)C_i_block_ref(t5,C_fix(2));
t8=(C_word)C_eqp(C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9923,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_9923(2,t10,t8);}
else{
/* expand.scm: 1446 ##sys#find-export */
((C_proc5)C_retrieve_symbol_proc(lf[256]))(5,*((C_word*)lf[256]+1),t9,t2,t3,C_SCHEME_TRUE);}}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k9921 in ##sys#register-syntax-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9926,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1447 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t2,((C_word*)t0)[5]);}

/* k9924 in k9921 in ##sys#register-syntax-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9926,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=(C_word)C_i_check_structure(t2,lf[71]);
t4=(C_word)C_i_block_ref(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],t1))){
/* expand.scm: 1450 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t5,lf[258],((C_word*)t0)[5]);}
else{
t6=t5;
f_9932(2,t6,C_SCHEME_UNDEFINED);}}

/* k9930 in k9924 in k9921 in ##sys#register-syntax-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9975,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1451 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t3);}

/* k9973 in k9930 in k9924 in k9921 in ##sys#register-syntax-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9979,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1451 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t2);}

/* k9977 in k9973 in k9930 in k9924 in k9921 in ##sys#register-syntax-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1451 check-for-redef */
f_9803(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9933 in k9930 in k9924 in k9921 in ##sys#register-syntax-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9935,2,t0,t1);}
t2=C_retrieve(lf[9]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9941,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t5=((C_word*)t0)[4];
t6=(C_word)C_i_check_structure(t5,lf[71]);
t7=(C_word)C_i_block_ref(t5,C_fix(3));
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=((C_word*)t0)[4];
t10=(C_word)C_i_check_structure(t9,lf[71]);
/* ##sys#block-set! */
t11=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t3,t9,C_fix(3),t8);}
else{
t4=t3;
f_9941(2,t4,C_SCHEME_UNDEFINED);}}

/* k9939 in k9933 in k9930 in k9924 in k9921 in ##sys#register-syntax-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9941,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
t4=(C_word)C_i_check_structure(t3,lf[71]);
t5=(C_word)C_i_block_ref(t3,C_fix(5));
t6=(C_word)C_a_i_cons(&a,2,t2,t5);
t7=((C_word*)t0)[2];
t8=((C_word*)t0)[3];
t9=(C_word)C_i_check_structure(t8,lf[71]);
/* ##sys#block-set! */
t10=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t8,C_fix(5),t6);}

/* ##sys#register-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9824,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t3;
t5=(C_word)C_i_check_structure(t4,lf[71]);
t6=(C_word)C_i_block_ref(t4,C_fix(2));
t7=(C_word)C_eqp(C_SCHEME_TRUE,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9834,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t9=t8;
f_9834(2,t9,t7);}
else{
/* expand.scm: 1427 ##sys#find-export */
((C_proc5)C_retrieve_symbol_proc(lf[256]))(5,*((C_word*)lf[256]+1),t8,t2,t3,C_SCHEME_TRUE);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k9832 in ##sys#register-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1428 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t2,((C_word*)t0)[3]);}

/* k9835 in k9832 in ##sys#register-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9840,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9900,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
t5=(C_word)C_i_check_structure(t4,lf[71]);
t6=(C_word)C_i_block_ref(t4,C_fix(1));
/* expand.scm: 1430 ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[68]))(4,*((C_word*)lf[68]+1),t3,((C_word*)t0)[4],t6);}

/* k9898 in k9835 in k9832 in ##sys#register-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1429 ##sys#toplevel-definition-hook */
((C_proc6)C_retrieve_symbol_proc(lf[250]))(6,*((C_word*)lf[250]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9838 in k9835 in k9832 in ##sys#register-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9843,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9896,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1433 ##sys#delq */
((C_proc4)C_retrieve_symbol_proc(lf[186]))(4,*((C_word*)lf[186]+1),t3,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_9843(2,t3,C_SCHEME_UNDEFINED);}}

/* k9894 in k9838 in k9835 in k9832 in ##sys#register-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1433 set-module-undefined-list! */
((C_proc4)C_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9841 in k9838 in k9835 in k9832 in ##sys#register-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9882,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1434 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t3);}

/* k9880 in k9841 in k9838 in k9835 in k9832 in ##sys#register-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9886,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1434 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t2);}

/* k9884 in k9880 in k9841 in k9838 in k9835 in k9832 in ##sys#register-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1434 check-for-redef */
f_9803(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9844 in k9841 in k9838 in k9835 in k9832 in ##sys#register-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_i_check_structure(t3,lf[71]);
t5=(C_word)C_i_block_ref(t3,C_fix(4));
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
t8=(C_word)C_i_check_structure(t7,lf[71]);
/* ##sys#block-set! */
t9=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t2,t7,C_fix(4),t6);}

/* k9847 in k9844 in k9841 in k9838 in k9835 in k9832 in ##sys#register-export in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9849,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=C_retrieve(lf[9]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
t5=(C_word)C_i_check_structure(t4,lf[71]);
t6=(C_word)C_i_block_ref(t4,C_fix(3));
t7=(C_word)C_a_i_cons(&a,2,t3,t6);
t8=((C_word*)t0)[2];
t9=((C_word*)t0)[3];
t10=(C_word)C_i_check_structure(t9,lf[71]);
/* ##sys#block-set! */
t11=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t8,t9,C_fix(3),t7);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* check-for-redef in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_9803(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9803,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(t2,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9810,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
/* expand.scm: 1420 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t6,lf[254],t2);}
else{
t7=t6;
f_9810(2,t7,C_SCHEME_FALSE);}}

/* k9808 in check-for-redef in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
/* expand.scm: 1422 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),((C_word*)t0)[2],lf[253],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#register-meta-expression in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9783,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9787,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1415 ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[73]))(2,*((C_word*)lf[73]+1),t3);}

/* k9785 in ##sys#register-meta-expression in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9787,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=(C_word)C_i_check_structure(t2,lf[71]);
t4=(C_word)C_i_block_ref(t2,C_fix(9));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
t7=t1;
t8=(C_word)C_i_check_structure(t7,lf[71]);
/* ##sys#block-set! */
t9=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t6,t7,C_fix(9),t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#toplevel-definition-hook in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9780,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}

/* ##sys#find-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9740(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_9740r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9740r(t0,t1,t2,t3);}}

static void C_ccall f_9740r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9744,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_9744(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_9744(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k9742 in ##sys#find-module in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[246]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
if(C_truep(t1)){
/* expand.scm: 1409 error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[247]+1)))(5,*((C_word*)lf[247]+1),((C_word*)t0)[2],lf[248],lf[249],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* ##sys#module-exports in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9716(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9716,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_i_check_structure(t3,lf[71]);
t5=(C_word)C_i_block_ref(t3,C_fix(2));
t6=t2;
t7=(C_word)C_i_check_structure(t6,lf[71]);
t8=(C_word)C_i_block_ref(t6,C_fix(10));
t9=t2;
t10=(C_word)C_i_check_structure(t9,lf[71]);
t11=(C_word)C_i_block_ref(t9,C_fix(11));
/* expand.scm: 1399 values */
C_values(5,0,t1,t5,t8,t11);}

/* module-undefined-list in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9616,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* set-module-undefined-list! in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9607,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[71]);
/* ##sys#block-set! */
t5=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* module-name in k9510 in k9506 in k9502 in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9526,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##sys#fixup-macro-environment in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9414(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_9414r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9414r(t0,t1,t2,t3);}}

static void C_ccall f_9414r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9418,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_9418(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_9418(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k9416 in ##sys#fixup-macro-environment in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
/* expand.scm: 1346 ##sys#append */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}
else{
t3=t2;
f_9421(2,t3,((C_word*)t0)[2]);}}

/* k9419 in k9416 in ##sys#fixup-macro-environment in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9426,a[2]=t1,a[3]=t4,a[4]=((C_word)li129),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_9426(t6,t2,((C_word*)t0)[2]);}

/* loop2392 in k9419 in k9416 in ##sys#fixup-macro-environment in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_9426(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9426,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cdr(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9460,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_cadr(t3);
if(C_truep((C_word)C_i_nullp(t7))){
t8=((C_word*)t0)[2];
t9=(C_word)C_i_set_car(t5,t8);
t10=(C_word)C_slot(t2,C_fix(1));
t15=t1;
t16=t10;
t1=t15;
t2=t16;
goto loop;}
else{
t8=(C_word)C_i_cadr(t3);
/* expand.scm: 1354 ##sys#append */
t9=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t8,((C_word*)t0)[2]);}}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t15=t1;
t16=t5;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9458 in loop2392 in k9419 in k9416 in ##sys#fixup-macro-environment in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_9426(t4,((C_word*)t0)[2],t3);}

/* k9422 in k9419 in k9416 in ##sys#fixup-macro-environment in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#macro-subset in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9349(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_9349r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9349r(t0,t1,t2,t3);}}

static void C_ccall f_9349r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9353,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_9353(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_9353(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k9351 in ##sys#macro-subset in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9356,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9363,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1339 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t3);}

/* k9361 in k9351 in ##sys#macro-subset in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9363,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9365,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li127),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_9365(t5,((C_word*)t0)[2],t1);}

/* loop in k9361 in k9351 in ##sys#macro-subset in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_9365(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9365,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,((C_word*)t0)[3]));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9386,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1342 loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* k9384 in loop in k9361 in k9351 in ##sys#macro-subset in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9386,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k9354 in k9351 in ##sys#macro-subset in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1343 ##sys#fixup-macro-environment */
((C_proc4)C_retrieve_symbol_proc(lf[239]))(4,*((C_word*)lf[239]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word ab[155],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7708,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_SCHEME_UNDEFINED;
t42=(*a=C_VECTOR_TYPE|1,a[1]=t41,tmp=(C_word)a,a+=2,tmp);
t43=C_SCHEME_UNDEFINED;
t44=(*a=C_VECTOR_TYPE|1,a[1]=t43,tmp=(C_word)a,a+=2,tmp);
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_SCHEME_UNDEFINED;
t56=(*a=C_VECTOR_TYPE|1,a[1]=t55,tmp=(C_word)a,a+=2,tmp);
t57=C_SCHEME_UNDEFINED;
t58=(*a=C_VECTOR_TYPE|1,a[1]=t57,tmp=(C_word)a,a+=2,tmp);
t59=C_SCHEME_UNDEFINED;
t60=(*a=C_VECTOR_TYPE|1,a[1]=t59,tmp=(C_word)a,a+=2,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_SCHEME_UNDEFINED;
t64=(*a=C_VECTOR_TYPE|1,a[1]=t63,tmp=(C_word)a,a+=2,tmp);
t65=C_SCHEME_UNDEFINED;
t66=(*a=C_VECTOR_TYPE|1,a[1]=t65,tmp=(C_word)a,a+=2,tmp);
t67=C_SCHEME_UNDEFINED;
t68=(*a=C_VECTOR_TYPE|1,a[1]=t67,tmp=(C_word)a,a+=2,tmp);
t69=C_SCHEME_UNDEFINED;
t70=(*a=C_VECTOR_TYPE|1,a[1]=t69,tmp=(C_word)a,a+=2,tmp);
t71=C_SCHEME_UNDEFINED;
t72=(*a=C_VECTOR_TYPE|1,a[1]=t71,tmp=(C_word)a,a+=2,tmp);
t73=C_SCHEME_UNDEFINED;
t74=(*a=C_VECTOR_TYPE|1,a[1]=t73,tmp=(C_word)a,a+=2,tmp);
t75=C_SCHEME_UNDEFINED;
t76=(*a=C_VECTOR_TYPE|1,a[1]=t75,tmp=(C_word)a,a+=2,tmp);
t77=C_SCHEME_UNDEFINED;
t78=(*a=C_VECTOR_TYPE|1,a[1]=t77,tmp=(C_word)a,a+=2,tmp);
t79=C_SCHEME_UNDEFINED;
t80=(*a=C_VECTOR_TYPE|1,a[1]=t79,tmp=(C_word)a,a+=2,tmp);
t81=C_SCHEME_UNDEFINED;
t82=(*a=C_VECTOR_TYPE|1,a[1]=t81,tmp=(C_word)a,a+=2,tmp);
t83=C_SCHEME_UNDEFINED;
t84=(*a=C_VECTOR_TYPE|1,a[1]=t83,tmp=(C_word)a,a+=2,tmp);
t85=C_SCHEME_UNDEFINED;
t86=(*a=C_VECTOR_TYPE|1,a[1]=t85,tmp=(C_word)a,a+=2,tmp);
t87=C_SCHEME_UNDEFINED;
t88=(*a=C_VECTOR_TYPE|1,a[1]=t87,tmp=(C_word)a,a+=2,tmp);
t89=C_SCHEME_UNDEFINED;
t90=(*a=C_VECTOR_TYPE|1,a[1]=t89,tmp=(C_word)a,a+=2,tmp);
t91=C_SCHEME_UNDEFINED;
t92=(*a=C_VECTOR_TYPE|1,a[1]=t91,tmp=(C_word)a,a+=2,tmp);
t93=C_SCHEME_UNDEFINED;
t94=(*a=C_VECTOR_TYPE|1,a[1]=t93,tmp=(C_word)a,a+=2,tmp);
t95=C_SCHEME_UNDEFINED;
t96=(*a=C_VECTOR_TYPE|1,a[1]=t95,tmp=(C_word)a,a+=2,tmp);
t97=C_SCHEME_UNDEFINED;
t98=(*a=C_VECTOR_TYPE|1,a[1]=t97,tmp=(C_word)a,a+=2,tmp);
t99=C_SCHEME_UNDEFINED;
t100=(*a=C_VECTOR_TYPE|1,a[1]=t99,tmp=(C_word)a,a+=2,tmp);
t101=C_SCHEME_UNDEFINED;
t102=(*a=C_VECTOR_TYPE|1,a[1]=t101,tmp=(C_word)a,a+=2,tmp);
t103=C_SCHEME_UNDEFINED;
t104=(*a=C_VECTOR_TYPE|1,a[1]=t103,tmp=(C_word)a,a+=2,tmp);
t105=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7715,a[2]=t2,a[3]=t5,a[4]=t3,a[5]=t1,a[6]=t100,a[7]=t102,a[8]=t96,a[9]=t104,a[10]=t98,a[11]=t88,a[12]=t86,a[13]=t4,a[14]=t84,a[15]=t90,a[16]=t94,a[17]=t92,a[18]=t82,a[19]=t80,a[20]=t6,a[21]=t78,a[22]=t76,a[23]=t74,a[24]=t72,a[25]=t70,a[26]=t68,a[27]=t66,a[28]=t64,a[29]=t62,a[30]=t60,a[31]=t58,a[32]=t56,a[33]=t54,a[34]=t52,a[35]=t50,a[36]=t48,a[37]=t46,a[38]=t44,a[39]=t42,a[40]=t40,a[41]=t38,a[42]=t36,a[43]=t34,a[44]=t32,a[45]=t30,a[46]=t28,a[47]=t26,a[48]=t24,a[49]=t22,a[50]=t20,a[51]=t18,a[52]=t16,a[53]=t14,a[54]=t12,a[55]=t10,a[56]=t8,tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t106=t5;
((C_proc3)C_retrieve_proc(t106))(3,t106,t105,lf[237]);}

/* k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7715,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[203]);
t4=C_mutate(((C_word *)((C_word*)t0)[54])+1,lf[204]);
t5=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[205]);
t6=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[206]);
t7=C_mutate(((C_word *)((C_word*)t0)[51])+1,lf[207]);
t8=C_mutate(((C_word *)((C_word*)t0)[50])+1,lf[208]);
t9=C_mutate(((C_word *)((C_word*)t0)[49])+1,lf[209]);
t10=C_mutate(((C_word *)((C_word*)t0)[48])+1,lf[210]);
t11=C_mutate(((C_word *)((C_word*)t0)[47])+1,lf[211]);
t12=C_mutate(((C_word *)((C_word*)t0)[46])+1,lf[212]);
t13=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[49],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[50],a[12]=((C_word*)t0)[47],a[13]=((C_word*)t0)[52],a[14]=((C_word*)t0)[51],a[15]=((C_word*)t0)[46],a[16]=((C_word*)t0)[48],a[17]=((C_word*)t0)[53],a[18]=((C_word*)t0)[10],a[19]=((C_word*)t0)[11],a[20]=((C_word*)t0)[55],a[21]=((C_word*)t0)[12],a[22]=((C_word*)t0)[13],a[23]=((C_word*)t0)[14],a[24]=((C_word*)t0)[15],a[25]=((C_word*)t0)[16],a[26]=((C_word*)t0)[17],a[27]=((C_word*)t0)[56],a[28]=((C_word*)t0)[18],a[29]=((C_word*)t0)[54],a[30]=((C_word*)t0)[19],a[31]=((C_word*)t0)[20],a[32]=((C_word*)t0)[21],a[33]=((C_word*)t0)[22],a[34]=((C_word*)t0)[23],a[35]=((C_word*)t0)[24],a[36]=((C_word*)t0)[25],a[37]=((C_word*)t0)[26],a[38]=((C_word*)t0)[27],a[39]=((C_word*)t0)[28],a[40]=((C_word*)t0)[29],a[41]=((C_word*)t0)[30],a[42]=((C_word*)t0)[31],a[43]=((C_word*)t0)[32],a[44]=((C_word*)t0)[33],a[45]=((C_word*)t0)[34],a[46]=((C_word*)t0)[35],a[47]=((C_word*)t0)[36],a[48]=((C_word*)t0)[37],a[49]=((C_word*)t0)[38],a[50]=((C_word*)t0)[39],a[51]=((C_word*)t0)[40],a[52]=((C_word*)t0)[41],a[53]=((C_word*)t0)[42],a[54]=((C_word*)t0)[43],a[55]=((C_word*)t0)[44],a[56]=((C_word*)t0)[45],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t14=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,lf[236]);}

/* k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7729,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[56],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[235]);}

/* k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7733,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[56],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[234]);}

/* k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7737,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[213]);
t4=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[55],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[56],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[233]);}

/* k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7742,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[214]);
t4=C_mutate(((C_word *)((C_word*)t0)[54])+1,lf[215]);
t5=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[54],a[22]=((C_word*)t0)[55],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[56],a[34]=((C_word*)t0)[31],a[35]=((C_word*)t0)[32],a[36]=((C_word*)t0)[33],a[37]=((C_word*)t0)[34],a[38]=((C_word*)t0)[35],a[39]=((C_word*)t0)[36],a[40]=((C_word*)t0)[37],a[41]=((C_word*)t0)[38],a[42]=((C_word*)t0)[39],a[43]=((C_word*)t0)[40],a[44]=((C_word*)t0)[41],a[45]=((C_word*)t0)[42],a[46]=((C_word*)t0)[43],a[47]=((C_word*)t0)[44],a[48]=((C_word*)t0)[45],a[49]=((C_word*)t0)[46],a[50]=((C_word*)t0)[47],a[51]=((C_word*)t0)[48],a[52]=((C_word*)t0)[49],a[53]=((C_word*)t0)[50],a[54]=((C_word*)t0)[51],a[55]=((C_word*)t0)[52],a[56]=((C_word*)t0)[53],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[232]);}

/* k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7748,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[56],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[231]);}

/* k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7752,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[56],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[115]);}

/* k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7756,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[56],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[49]);}

/* k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7760,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[56],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[103]);}

/* k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7764,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[216]);
t4=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[55],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[56],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[155]);}

/* k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],a[55]=((C_word*)t0)[55],a[56]=((C_word*)t0)[56],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[230]);}

/* k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7773,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[55]);
t4=C_mutate(((C_word *)((C_word*)t0)[54])+1,lf[217]);
t5=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[218]);
t6=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[54],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[55],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[56],a[23]=((C_word*)t0)[53],a[24]=((C_word*)t0)[20],a[25]=((C_word*)t0)[21],a[26]=((C_word*)t0)[22],a[27]=((C_word*)t0)[23],a[28]=((C_word*)t0)[24],a[29]=((C_word*)t0)[25],a[30]=((C_word*)t0)[26],a[31]=((C_word*)t0)[27],a[32]=((C_word*)t0)[28],a[33]=((C_word*)t0)[29],a[34]=((C_word*)t0)[30],a[35]=((C_word*)t0)[31],a[36]=((C_word*)t0)[32],a[37]=((C_word*)t0)[33],a[38]=((C_word*)t0)[34],a[39]=((C_word*)t0)[35],a[40]=((C_word*)t0)[36],a[41]=((C_word*)t0)[37],a[42]=((C_word*)t0)[38],a[43]=((C_word*)t0)[39],a[44]=((C_word*)t0)[40],a[45]=((C_word*)t0)[41],a[46]=((C_word*)t0)[42],a[47]=((C_word*)t0)[43],a[48]=((C_word*)t0)[44],a[49]=((C_word*)t0)[45],a[50]=((C_word*)t0)[46],a[51]=((C_word*)t0)[47],a[52]=((C_word*)t0)[48],a[53]=((C_word*)t0)[49],a[54]=((C_word*)t0)[50],a[55]=((C_word*)t0)[51],a[56]=((C_word*)t0)[52],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[229]);}

/* k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7780,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[219]);
t4=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[56],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[55],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[85]);}

/* k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7785,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[56],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[199]);}

/* k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7789,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[56],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[228]);}

/* k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7793,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=(*a=C_CLOSURE_TYPE|56,a[1]=(C_word)f_7797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[56],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],tmp=(C_word)a,a+=57,tmp);
/* r1975 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[227]);}

/* k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7797,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[56])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7802,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=((C_word*)t0)[22],a[21]=((C_word*)t0)[23],a[22]=((C_word*)t0)[24],a[23]=((C_word*)t0)[25],a[24]=((C_word*)t0)[26],a[25]=((C_word*)t0)[27],a[26]=((C_word*)t0)[28],a[27]=((C_word*)t0)[29],a[28]=((C_word*)t0)[30],a[29]=((C_word*)t0)[31],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[33],a[32]=((C_word*)t0)[56],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[44],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[47],a[47]=((C_word*)t0)[48],a[48]=((C_word*)t0)[49],a[49]=((C_word*)t0)[50],a[50]=((C_word*)t0)[51],a[51]=((C_word*)t0)[52],a[52]=((C_word*)t0)[53],a[53]=((C_word*)t0)[54],a[54]=((C_word*)t0)[55],tmp=(C_word)a,a+=55,tmp);
/* r1975 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[133],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7802,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7804,a[2]=((C_word*)t0)[54],a[3]=((C_word*)t0)[52],a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp));
t4=C_mutate(((C_word *)((C_word*)t0)[51])+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7810,a[2]=((C_word*)t0)[41],a[3]=((C_word*)t0)[42],a[4]=((C_word*)t0)[43],a[5]=((C_word*)t0)[44],a[6]=((C_word*)t0)[45],a[7]=((C_word*)t0)[46],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[48],a[10]=((C_word*)t0)[49],a[11]=((C_word*)t0)[50],a[12]=((C_word)li107),tmp=(C_word)a,a+=13,tmp));
t5=C_mutate(((C_word *)((C_word*)t0)[41])+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7900,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[46],a[4]=((C_word*)t0)[36],a[5]=((C_word*)t0)[37],a[6]=((C_word*)t0)[38],a[7]=((C_word*)t0)[39],a[8]=((C_word*)t0)[40],a[9]=((C_word)li109),tmp=(C_word)a,a+=10,tmp));
t6=C_mutate(((C_word *)((C_word*)t0)[35])+1,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7984,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[27],a[4]=((C_word*)t0)[28],a[5]=((C_word*)t0)[29],a[6]=((C_word*)t0)[30],a[7]=((C_word*)t0)[35],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[44],a[10]=((C_word*)t0)[40],a[11]=((C_word*)t0)[31],a[12]=((C_word*)t0)[32],a[13]=((C_word*)t0)[33],a[14]=((C_word*)t0)[50],a[15]=((C_word*)t0)[49],a[16]=((C_word*)t0)[34],a[17]=((C_word)li110),tmp=(C_word)a,a+=18,tmp));
t7=C_mutate(((C_word *)((C_word*)t0)[33])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8205,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[30],a[4]=((C_word*)t0)[47],a[5]=((C_word*)t0)[44],a[6]=((C_word*)t0)[21],a[7]=((C_word*)t0)[22],a[8]=((C_word*)t0)[40],a[9]=((C_word*)t0)[31],a[10]=((C_word*)t0)[23],a[11]=((C_word*)t0)[24],a[12]=((C_word*)t0)[25],a[13]=((C_word)li111),tmp=(C_word)a,a+=14,tmp));
t8=C_mutate(((C_word *)((C_word*)t0)[29])+1,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8327,a[2]=((C_word*)t0)[53],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[35],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[21],a[9]=((C_word*)t0)[22],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[44],a[13]=((C_word*)t0)[40],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[32],a[16]=((C_word)li113),tmp=(C_word)a,a+=17,tmp));
t9=C_mutate(((C_word *)((C_word*)t0)[36])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8615,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[53],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[30],a[7]=((C_word*)t0)[47],a[8]=((C_word*)t0)[36],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[43],a[11]=((C_word*)t0)[32],a[12]=((C_word*)t0)[34],a[13]=((C_word)li116),tmp=(C_word)a,a+=14,tmp));
t10=C_mutate(((C_word *)((C_word*)t0)[38])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8822,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[43],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[38],a[12]=((C_word*)t0)[49],a[13]=((C_word)li118),tmp=(C_word)a,a+=14,tmp));
t11=C_mutate(((C_word *)((C_word*)t0)[37])+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9076,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[37],a[4]=((C_word*)t0)[34],a[5]=((C_word)li119),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9149,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word)li120),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate(((C_word *)((C_word*)t0)[26])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9242,a[2]=((C_word*)t0)[4],a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9264,a[2]=((C_word*)t0)[53],a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate(((C_word *)((C_word*)t0)[8])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9290,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word)li123),tmp=(C_word)a,a+=5,tmp));
t16=C_mutate(((C_word *)((C_word*)t0)[11])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9310,a[2]=((C_word*)t0)[53],a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp));
/* make-transformer2017 */
t17=((C_word*)((C_word*)t0)[51])[1];
((C_proc3)C_retrieve_proc(t17))(3,t17,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_9310 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9310,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9320,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li124),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9320(t7,t1,t3);}

/* loop */
static void C_fcall f_9320(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9320,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9327,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
/* ellipsis?2016 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t4=t3;
f_9327(2,t4,C_SCHEME_FALSE);}}

/* k9325 in loop */
static void C_ccall f_9327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop2293 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9320(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* f_9290 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9290,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9297,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* segment-template?2027 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9295 */
static void C_ccall f_9297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9297,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9304,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* segment-depth2028 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* k9302 in k9295 */
static void C_ccall f_9304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(1),t1));}

/* f_9264 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9264(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9264,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(t2);
/* ellipsis?2016 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_9242 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9242,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9249,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* segment-template?2027 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9247 */
static void C_ccall f_9249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[2],lf[226],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_9149 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9149,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,t5))){
t6=t5;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_i_assq(t2,t4);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=t3;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t7,t8))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,t2,t5));}
else{
t9=t5;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}
else{
t7=t5;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9191,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* segment-template?2027 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}

/* k9189 */
static void C_ccall f_9191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9191,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* free-meta-variables2025 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9223,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* free-meta-variables2025 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[222]+1)))(3,*((C_word*)lf[222]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}}

/* k9238 in k9189 */
static void C_ccall f_9240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2025 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9221 in k9189 */
static void C_ccall f_9223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2025 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9200 in k9189 */
static void C_ccall f_9202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2025 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_9076 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_9076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9076,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[4]))){
t5=t4;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t4));}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9102,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* segment-pattern?2026 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k9100 */
static void C_ccall f_9102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9102,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* meta-variables2024 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9130,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* meta-variables2024 */
t5=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[222]+1)))(3,*((C_word*)lf[222]+1),t2,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}}

/* k9145 in k9100 */
static void C_ccall f_9147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2024 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9128 in k9100 */
static void C_ccall f_9130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2024 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8822 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_8822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8822,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(C_word)C_i_assq(t2,t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
t7=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=t2;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),t1,lf[223],t2);}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[221],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t8));}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t4,a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=t1,a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* segment-template?2027 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8867 */
static void C_ccall f_8869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8869,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8872,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* segment-depth2028 */
t3=((C_word*)((C_word*)t0)[5])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9030,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* process-template2023 */
t4=((C_word*)((C_word*)t0)[11])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[14],((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9067,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[222]+1)))(3,*((C_word*)lf[222]+1),t3,((C_word*)t0)[12]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}}}}

/* k9065 in k8867 */
static void C_ccall f_9067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2023 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9061 in k8867 */
static void C_ccall f_9063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9063,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k9028 in k8867 */
static void C_ccall f_9030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9038,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* process-template2023 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9036 in k9028 in k8867 */
static void C_ccall f_9038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9038,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t3));}

/* k8870 in k8867 */
static void C_ccall f_8872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8872,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8878,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* free-meta-variables2025 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,t2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k8876 in k8870 in k8867 */
static void C_ccall f_8878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8878,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[11],lf[224],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* process-template2023 */
t4=((C_word*)((C_word*)t0)[9])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k8888 in k8876 in k8870 in k8867 */
static void C_ccall f_8890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8893,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
if(C_truep((C_word)C_i_symbolp(t1))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_8956(t6,(C_word)C_eqp(t1,t5));}
else{
t5=t3;
f_8956(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8956(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8956(t4,C_SCHEME_FALSE);}}

/* k8954 in k8888 in k8876 in k8870 in k8867 */
static void C_fcall f_8956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8956,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8893(t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}

/* k8969 in k8954 in k8888 in k8876 in k8870 in k8867 */
static void C_ccall f_8971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8971,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_8893(t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k8891 in k8888 in k8876 in k8870 in k8867 */
static void C_fcall f_8893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8893,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8927,a[2]=t4,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8927(t6,t2,((C_word*)t0)[2],t1);}

/* doloop2227 in k8891 in k8888 in k8876 in k8870 in k8867 */
static void C_fcall f_8927(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8927,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t5)){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[54],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[225],t8);
t12=t1;
t13=t6;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k8894 in k8891 in k8888 in k8876 in k8870 in k8867 */
static void C_ccall f_8896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* segment-tail2029 */
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8923 in k8894 in k8891 in k8888 in k8876 in k8870 in k8867 */
static void C_ccall f_8925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8925,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8917,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8921,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* segment-tail2029 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k8919 in k8923 in k8894 in k8891 in k8888 in k8876 in k8870 in k8867 */
static void C_ccall f_8921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2023 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8915 in k8923 in k8894 in k8891 in k8888 in k8876 in k8870 in k8867 */
static void C_ccall f_8917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8917,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[54],t3));}

/* f_8615 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_8615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8615,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[12]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8639,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* mapit2153 */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t4,a[12]=t3,a[13]=((C_word*)t0)[11],a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* segment-pattern?2026 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8643 */
static void C_ccall f_8645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8645,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8654,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word)li114),tmp=(C_word)a,a+=8,tmp);
/* process-pattern2022 */
t4=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[7],t2,((C_word*)((C_word*)t0)[13])[1],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[14]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8705,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[14]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
/* process-pattern2022 */
t6=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[11]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[14]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8745,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(2)))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[14],t4);
/* ellipsis?2016 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t3,t5);}
else{
t4=t3;
f_8745(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}}}

/* k8743 in k8643 */
static void C_ccall f_8745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8745,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8755,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[222]+1)))(3,*((C_word*)lf[222]+1),t2,((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8768,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[3],a[9]=((C_word)li115),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_8768(t5,((C_word*)t0)[6],C_fix(0));}}

/* lp in k8743 in k8643 */
static void C_fcall f_8768(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8768,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[8]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8782,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_vector_ref(((C_word*)t0)[6],t2);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
/* process-pattern2022 */
t9=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,((C_word*)t0)[2]);}}

/* k8780 in lp in k8743 in k8643 */
static void C_ccall f_8782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8786,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2182 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8768(t4,t2,t3);}

/* k8784 in k8780 in lp in k8743 in k8643 */
static void C_ccall f_8786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8753 in k8743 in k8643 */
static void C_ccall f_8755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8755,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
/* process-pattern2022 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k8703 in k8643 */
static void C_ccall f_8705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8709,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
/* process-pattern2022 */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[2]);}

/* k8707 in k8703 in k8643 */
static void C_ccall f_8709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8653 in k8643 */
static void C_ccall f_8654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8654,3,t0,t1,t2);}
t3=(C_word)C_eqp(((C_word*)((C_word*)t0)[6])[1],t2);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
/* mapit2153 */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t9);
/* mapit2153 */
t11=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t11))(3,t11,t1,t10);}}

/* k8637 */
static void C_ccall f_8639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8639,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t2));}

/* f_8327 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_8327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8327,4,t0,t1,t2,t3);}
t4=(C_word)C_i_vector_length(t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8334,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t4,a[13]=t1,a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t6=(C_word)C_fixnum_difference(t4,C_fix(1));
t7=(C_word)C_i_vector_ref(t3,t6);
/* ellipsis?2016 */
t8=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t8))(3,t8,t5,t7);}
else{
t6=t5;
f_8334(2,t6,C_SCHEME_FALSE);}}

/* k8332 */
static void C_ccall f_8334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8334,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[16])[1],t5);
t7=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8373,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t4,a[16]=((C_word*)t0)[15],a[17]=t6,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t1)){
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_fixnum_difference(((C_word*)t0)[12],C_fix(2));
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=t7;
f_8373(t13,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t12));}
else{
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=t7;
f_8373(t12,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t11));}}

/* k8371 in k8332 */
static void C_fcall f_8373(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8373,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8377,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[17],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8381,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8383,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word)li112),tmp=(C_word)a,a+=17,tmp));
t7=((C_word*)t5)[1];
f_8383(t7,t3,C_fix(0));}

/* lp in k8371 in k8332 */
static void C_fcall f_8383(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8383,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[15]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t5=t2;
t6=(C_word)C_eqp(t5,t4);
t7=(C_truep(t6)?((C_word*)t0)[14]:C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t12);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8443,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t10,a[6]=((C_word*)t0)[10],a[7]=t13,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8447,a[2]=t14,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t17);
t19=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t20=(C_word)C_i_vector_ref(((C_word*)t0)[4],t19);
/* process-match2019 */
t21=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t21))(4,t21,t15,t18,t20);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8514,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t10);
t12=(C_word)C_i_vector_ref(((C_word*)t0)[4],t2);
/* process-match2019 */
t13=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t13))(4,t13,t8,t11,t12);}}}

/* k8512 in lp in k8371 in k8332 */
static void C_ccall f_8514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8518,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2128 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8383(t4,t2,t3);}

/* k8516 in k8512 in lp in k8371 in k8332 */
static void C_ccall f_8518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8445 in lp in k8371 in k8332 */
static void C_ccall f_8447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8447,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k8441 in lp in k8371 in k8332 */
static void C_ccall f_8443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8443,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}

/* k8379 in k8371 in k8332 */
static void C_ccall f_8381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8375 in k8371 in k8332 */
static void C_ccall f_8377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8377,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST));}

/* f_8205 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_8205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8205,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8209,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
/* process-match2019 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t6,t3);}

/* k8207 */
static void C_ccall f_8209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8209,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t7);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8281,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t6,a[8]=((C_word*)t0)[6],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t12);
t14=(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t15=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t9,t1,t14);}}

/* k8279 in k8207 */
static void C_ccall f_8281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8281,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST));}

/* f_7984 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7984,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_symbolp(t3))){
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[16]))){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[221],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[15])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[14])[1],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}
else{
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* segment-pattern?2026 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k8032 */
static void C_ccall f_8034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8034,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-segment-match2020 */
t3=((C_word*)((C_word*)t0)[14])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[13],((C_word*)t0)[12],t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8082,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8086,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t9);
t11=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-match2019 */
t12=((C_word*)((C_word*)t0)[6])[1];
((C_proc4)C_retrieve_proc(t12))(4,t12,t8,t10,t11);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[15]))){
/* process-vector-match2021 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[15]);}
else{
t2=(C_word)C_i_nullp(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8148(t4,t2);}
else{
t4=(C_word)C_booleanp(((C_word*)t0)[15]);
t5=t3;
f_8148(t5,(C_truep(t4)?t4:(C_word)C_charp(((C_word*)t0)[15])));}}}}}

/* k8146 in k8032 */
static void C_fcall f_8148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8148,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[85],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[85],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}}

/* k8084 in k8032 */
static void C_ccall f_8086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8090,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8094,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* process-match2019 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t5,t6);}

/* k8092 in k8084 in k8032 */
static void C_ccall f_8094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8088 in k8084 in k8032 */
static void C_ccall f_8090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8080 in k8032 */
static void C_ccall f_8082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8082,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* f_7900 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7900,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=t3;
f_7907(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_7907(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_7907(t4,C_SCHEME_FALSE);}}

/* k7905 */
static void C_fcall f_7907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7907,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[187]+1)))(3,*((C_word*)lf[187]+1),t2,((C_word*)t0)[10]);}
else{
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[7],lf[220],((C_word*)t0)[10]);}}

/* k7908 in k7905 */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7910,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7955,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7959,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* process-match2019 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t1);}

/* k7957 in k7908 in k7905 */
static void C_ccall f_7959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7953 in k7908 in k7905 */
static void C_ccall f_7955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7955,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7936,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7950,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp);
/* process-pattern2022 */
t5=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],t4);}

/* a7949 in k7953 in k7908 in k7905 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7950,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7934 in k7953 in k7908 in k7905 */
static void C_ccall f_7936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7944,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7948,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* meta-variables2024 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_SCHEME_END_OF_LIST);}

/* k7946 in k7934 in k7953 in k7908 in k7905 */
static void C_ccall f_7948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2023 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k7942 in k7934 in k7953 in k7908 in k7905 */
static void C_ccall f_7944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7944,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* f_7810 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[37],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7810,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7850,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7854,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* map */
t13=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)((C_word*)t0)[2])[1],t2);}

/* k7852 */
static void C_ccall f_7854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7854,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[44],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t7=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t1,t6);}

/* k7848 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7850,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t7));}

/* f_7804 in k7800 in k7795 in k7791 in k7787 in k7783 in k7778 in k7771 in k7767 in k7762 in k7758 in k7754 in k7750 in k7746 in k7740 in k7735 in k7731 in k7727 in k7713 in ##sys#process-syntax-rules in k7704 in k7701 in k7698 in k7695 in k7692 in k7689 in k7686 in k7683 in k7680 in k7677 in k7674 in k7671 in k7668 in k7665 in k7662 in k7659 in k7656 in k7652 in k7649 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7804,3,t0,t1,t2);}
/* c1976 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6796,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6800,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t6,a[6]=t2,a[7]=t1,a[8]=t4,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 828  r */
t10=t3;
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[200]);}

/* k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 829  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[199]);}

/* k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 830  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[198]);}

/* k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 831  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[197]);}

/* k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6811,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6820,a[2]=((C_word*)t0)[11],a[3]=((C_word)li91),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6863,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word)li94),tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6950,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[11],a[11]=t4,a[12]=((C_word)li101),tmp=(C_word)a,a+=13,tmp));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7424,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 928  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t8,((C_word*)t0)[11],((C_word*)t0)[5],lf[196]);}

/* k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 929  ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[73]))(2,*((C_word*)lf[73]+1),t2);}

/* k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7625,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t1;
t5=(C_word)C_i_check_structure(t4,lf[71]);
t6=(C_word)C_i_block_ref(t4,C_fix(8));
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* expand.scm: 935  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),t3,t6,t7);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7640,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t1;
t5=(C_word)C_i_check_structure(t4,lf[71]);
t6=(C_word)C_i_block_ref(t4,C_fix(7));
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* expand.scm: 938  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),t3,t6,t7);}}
else{
t3=t2;
f_7430(2,t3,C_SCHEME_UNDEFINED);}}

/* k7638 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[71]);
/* ##sys#block-set! */
t4=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(7),t1);}

/* k7623 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[71]);
/* ##sys#block-set! */
t4=*((C_word*)lf[195]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(8),t1);}

/* k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7433,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word)li104),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_7439(t7,t2,t3);}

/* loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_7439(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7439,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 941  import-spec */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6950(t5,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7452,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=C_retrieve(lf[9]);
t5=C_retrieve(lf[9]);
t6=C_retrieve(lf[9]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7470,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 947  ##sys#mark-imported-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[194]))(3,*((C_word*)lf[194]+1),t7,t2);}

/* k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7565,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7565(t6,t2,((C_word*)t0)[2]);}

/* loop1459 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_7565(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7565,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_cdr(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7615,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 952  import-env */
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7613 in loop1459 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7615,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t7=((C_word*)((C_word*)t0)[4])[1];
f_7565(t7,((C_word*)t0)[3],t6);}
else{
/* expand.scm: 954  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t3,lf[193],((C_word*)t0)[6]);}}
else{
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_7565(t5,((C_word*)t0)[3],t4);}}

/* k7585 in k7613 in loop1459 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7565(t3,((C_word*)t0)[2],t2);}

/* k7471 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7507,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7507(t6,t2,((C_word*)t0)[4]);}

/* loop1475 in k7471 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_7507(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7507,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7563,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 958  macro-env */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7561 in loop1475 in k7471 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7563,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7523,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t8=((C_word*)((C_word*)t0)[4])[1];
f_7507(t8,((C_word*)t0)[3],t7);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 960  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t3,lf[192],t7);}}
else{
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_7507(t5,((C_word*)t0)[3],t4);}}

/* k7521 in k7561 in loop1475 in k7471 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7507(t3,((C_word*)t0)[2],t2);}

/* k7474 in k7471 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7479,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7501,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7505,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 962  import-env */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7503 in k7474 in k7471 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 962  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7499 in k7474 in k7471 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 962  import-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7477 in k7474 in k7471 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7482,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7493,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7497,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 963  macro-env */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7495 in k7477 in k7474 in k7471 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 963  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7491 in k7477 in k7474 in k7471 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 963  macro-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7480 in k7477 in k7474 in k7471 in k7468 in k7450 in loop1444 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7439(t3,((C_word*)t0)[2],t2);}

/* k7431 in k7428 in k7425 in k7422 in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[191]);}

/* import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6950(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6950,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 861  import-name */
t3=((C_word*)t0)[11];
f_6863(t3,t1,t2);}
else{
t3=(C_word)C_i_listp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t4)){
t6=t5;
f_6969(t6,t4);}
else{
t6=(C_word)C_i_length(t2);
t7=t5;
f_6969(t7,(C_word)C_fixnum_lessp(t6,C_fix(2)));}}}

/* k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6969,NULL,2,t0,t1);}
if(C_truep(t1)){
/* expand.scm: 863  syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[132]))(5,*((C_word*)lf[132]+1),((C_word*)t0)[12],((C_word*)t0)[11],lf[181],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* expand.scm: 866  import-spec */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6950(t5,t3,t4);}}

/* k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6978,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 869  c */
t6=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}

/* k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6990,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6993,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 870  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t2,((C_word*)t0)[7],((C_word*)t0)[9],lf[182]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 881  c */
t4=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7070,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7073,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 882  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t2,((C_word*)t0)[6],((C_word*)t0)[8],lf[183]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* expand.scm: 892  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7177,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7180,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 893  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t2,((C_word*)t0)[5],((C_word*)t0)[9],lf[188]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7340,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 918  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7338 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7340,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 919  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[189]);}
else{
/* expand.scm: 927  syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[132]))(5,*((C_word*)lf[132]+1),((C_word*)t0)[7],((C_word*)t0)[2],lf[190],((C_word*)t0)[4]);}}

/* k7341 in k7338 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7346,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* expand.scm: 920  tostr */
t4=((C_word*)t0)[2];
f_6820(t4,t2,t3);}

/* k7344 in k7341 in k7338 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7348,a[2]=t1,a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7379,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k7377 in k7344 in k7341 in k7338 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7383,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7381 in k7377 in k7344 in k7341 in k7338 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7383,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ren in k7344 in k7341 in k7338 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7348(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7348,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7356,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7364,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7368,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* expand.scm: 924  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t5,t6);}

/* k7366 in ren in k7344 in k7341 in k7338 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 924  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7362 in ren in k7344 in k7341 in k7338 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 923  ##sys#string->symbol */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],t1);}

/* k7354 in ren in k7344 in k7341 in k7338 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7356,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k7178 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7180,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7189,a[2]=t4,a[3]=((C_word)li99),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7189(t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in k7178 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_7189(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7189,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7205,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7210,a[2]=t9,a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_7210(t11,t7,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7282,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t3,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 902  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t7,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7334,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=t2,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 909  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t7,t2);}}

/* k7332 in loop in k7178 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7334,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7315,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 912  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[187]+1)))(3,*((C_word*)lf[187]+1),t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 915  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7189(t6,((C_word*)t0)[4],t3,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k7313 in k7332 in loop in k7178 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7315,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7303,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 914  ##sys#delq */
((C_proc4)C_retrieve_symbol_proc(lf[186]))(4,*((C_word*)lf[186]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7301 in k7313 in k7332 in loop in k7178 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 911  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7189(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7280 in loop in k7178 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7282,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7263,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 906  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[187]+1)))(3,*((C_word*)lf[187]+1),t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 908  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7189(t6,((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2],t5,((C_word*)t0)[8]);}}

/* k7261 in k7280 in loop in k7178 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7263,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7251,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 907  ##sys#delq */
((C_proc4)C_retrieve_symbol_proc(lf[186]))(4,*((C_word*)lf[186]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7249 in k7261 in k7280 in loop in k7178 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 904  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7189(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop1419 in loop in k7178 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_7210(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7210,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7223,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 899  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t4,lf[185],t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7221 in loop1419 in loop in k7178 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7210(t3,((C_word*)t0)[2],t2);}

/* k7203 in loop in k7178 in k7175 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7205,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k7071 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7076,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7074 in k7071 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7076,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7081,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li97),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7081(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k7074 in k7071 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_7081(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7081,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7093,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word)li96),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7093(t7,t1,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7167,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 890  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t4,t2);}}

/* k7165 in loop in k7074 in k7071 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7167,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 890  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7081(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 891  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7081(t5,((C_word*)t0)[3],t2,t4);}}

/* loop in loop in k7074 in k7071 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_7093(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7093,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7135,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 888  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t4,t2);}}

/* k7133 in loop in loop in k7074 in k7071 in k7068 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_7135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7135,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 888  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7093(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 889  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7093(t5,((C_word*)t0)[3],t2,t4);}}

/* k6991 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6996,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k6994 in k6991 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6996,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7001,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li95),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7001(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k6994 in k6991 in k6988 in k6976 in k6967 in import-spec in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_7001(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7001,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_assq(t5,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* expand.scm: 876  loop */
t15=t1;
t16=t7;
t17=t8;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_assq(t7,((C_word*)t0)[2]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t8,t4);
/* expand.scm: 879  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t10;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
/* expand.scm: 880  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}}

/* import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6863(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6863,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6867,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 841  resolve */
t4=((C_word*)t0)[2];
f_6811(3,t4,t3,t2);}

/* k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6870,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 842  ##sys#find-module */
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t2,t1,C_SCHEME_FALSE);}

/* k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6870,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6873,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t3)[1])){
t5=t4;
f_6873(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6944,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6948,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 845  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t7,((C_word*)t0)[3]);}}

/* k6946 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 845  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),((C_word*)t0)[2],t1,lf[180]);}

/* k6942 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 844  ##sys#find-extension */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6885,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[73]);
t3=C_retrieve(lf[3]);
t4=C_retrieve(lf[4]);
t5=C_retrieve(lf[20]);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6891,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t3,a[8]=t4,a[9]=t5,a[10]=t9,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 849  ##sys#current-meta-environment */
((C_proc2)C_retrieve_symbol_proc(lf[4]))(2,*((C_word*)lf[4]+1),t10);}
else{
/* expand.scm: 854  syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[132]))(5,*((C_word*)lf[132]+1),((C_word*)t0)[4],((C_word*)t0)[2],lf[178],((C_word*)t0)[3]);}}

/* k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6891,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 850  ##sys#meta-macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[177]))(2,*((C_word*)lf[177]+1),t4);}

/* k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6894,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6895,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word)li92),tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6933,a[2]=((C_word*)t0)[2],a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t7=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t4,t6,t4);}

/* a6932 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6933,2,t0,t1);}
/* expand.scm: 851  ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[176]))(5,*((C_word*)lf[176]+1),t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k6925 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 852  ##sys#find-module */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),t2,((C_word*)t0)[2]);}

/* k6929 in k6925 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6873(2,t3,t2);}

/* swap1291 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* g129412951310 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6897 in swap1291 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* g129412951310 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[10])[1]);}

/* k6900 in k6897 in swap1291 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6902,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g129612971311 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6904 in k6900 in k6897 in swap1291 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6909,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g129612971311 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k6907 in k6904 in k6900 in k6897 in swap1291 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6909,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g129812991312 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6911 in k6907 in k6904 in k6900 in k6897 in swap1291 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g129812991312 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k6914 in k6911 in k6907 in k6904 in k6900 in k6897 in swap1291 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6916,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g130013011313 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6918 in k6914 in k6911 in k6907 in k6904 in k6900 in k6897 in swap1291 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6923,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g130013011313 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k6921 in k6918 in k6914 in k6911 in k6907 in k6904 in k6900 in k6897 in swap1291 in k6892 in k6889 in k6883 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6871 in k6868 in k6865 in import-name in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6873,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[3])[1];
t3=(C_word)C_i_check_structure(t2,lf[71]);
t4=(C_word)C_i_block_ref(t2,C_fix(10));
t5=((C_word*)((C_word*)t0)[3])[1];
t6=(C_word)C_i_check_structure(t5,lf[71]);
t7=(C_word)C_i_block_ref(t5,C_fix(11));
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,t4,t7));}

/* tostr in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6820(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6820,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6833,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 836  keyword? */
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t3,t2);}}

/* k6831 in tostr in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6833,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6840,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 836  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* expand.scm: 837  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
/* expand.scm: 838  number->string */
C_number_to_string(3,0,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* expand.scm: 839  syntax-error */
((C_proc4)C_retrieve_symbol_proc(lf[132]))(4,*((C_word*)lf[132]+1),((C_word*)t0)[4],((C_word*)t0)[2],lf[174]);}}}}

/* k6838 in k6831 in tostr in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 836  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),((C_word*)t0)[2],t1,lf[172]);}

/* resolve in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6811,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6815,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 833  lookup */
f_3170(t3,t2,C_SCHEME_END_OF_LIST);}

/* k6813 in resolve in k6807 in k6804 in k6801 in k6798 in ##sys#expand-import in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##sys#er-transformer in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6604,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6606,a[2]=t2,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp));}

/* f_6606 in ##sys#er-transformer in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6606,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6609,a[2]=t3,a[3]=t6,a[4]=((C_word)li86),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6667,a[2]=t4,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 822  handler */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t1,t2,t7,t8);}

/* compare */
static void C_ccall f_6667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6667,4,t0,t1,t2,t3);}
t4=(C_word)C_i_symbolp(t2);
t5=(C_truep(t4)?(C_word)C_i_symbolp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6680,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 793  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t6,t2,lf[7]);}
else{
t6=(C_word)C_eqp(t2,t3);
t7=C_retrieve(lf[9]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t6);}}

/* k6678 in compare */
static void C_ccall f_6680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_6683(t3,t1);}
else{
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f15795,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 815  lookup */
f_3170(t5,t3,t4);}}

/* f15795 in k6678 in compare */
static void C_ccall f15795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_retrieve(lf[9]);
if(C_truep(t1)){
t3=((C_word*)t0)[3];
f_6683(t3,t1);}
else{
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
f_6683(t4,t3);}}

/* k6681 in k6678 in compare */
static void C_fcall f_6683(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6683,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 796  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,((C_word*)t0)[3],lf[7]);}

/* k6684 in k6681 in k6678 in compare */
static void C_ccall f_6686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6689,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6689(t3,t1);}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f15788,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 815  lookup */
f_3170(t5,t3,t4);}}

/* f15788 in k6684 in k6681 in k6678 in compare */
static void C_ccall f15788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_retrieve(lf[9]);
if(C_truep(t1)){
t3=((C_word*)t0)[3];
f_6689(t3,t1);}
else{
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
f_6689(t4,t3);}}

/* k6687 in k6684 in k6681 in k6678 in compare */
static void C_fcall f_6689(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6689,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6708,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 801  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,((C_word*)t0)[3],lf[74]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6735,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 803  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t2);}}
else{
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 807  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],t1);
t3=C_retrieve(lf[9]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k6756 in k6687 in k6684 in k6681 in k6678 in compare */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(((C_word*)t0)[3],t3);
t5=C_retrieve(lf[9]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}
else{
t3=C_retrieve(lf[9]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6733 in k6687 in k6684 in k6681 in k6678 in compare */
static void C_ccall f_6735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[3]);
t5=C_retrieve(lf[9]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}
else{
t3=C_retrieve(lf[9]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6706 in k6687 in k6684 in k6681 in k6678 in compare */
static void C_ccall f_6708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6708,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 802  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,((C_word*)t0)[2],lf[74]);}

/* k6713 in k6706 in k6687 in k6684 in k6681 in k6678 in compare */
static void C_ccall f_6715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=(C_word)C_eqp(((C_word*)t0)[4],t2);
t4=C_retrieve(lf[9]);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t2=((C_word*)t0)[2];
t3=(C_word)C_eqp(((C_word*)t0)[4],t2);
t4=C_retrieve(lf[9]);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}}

/* rename */
static void C_ccall f_6609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6609,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=C_retrieve(lf[9]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cdr(t3));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 775  lookup */
f_3170(t4,t2,((C_word*)t0)[2]);}}

/* k6623 in rename */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6625,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=C_retrieve(lf[9]);
t3=t1;
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6640,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 781  macro-alias */
f_3188(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6654,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 786  macro-alias */
f_3188(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6652 in k6623 in rename */
static void C_ccall f_6654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6654,2,t0,t1);}
t2=C_retrieve(lf[9]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k6638 in k6623 in rename */
static void C_ccall f_6640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6640,2,t0,t1);}
t2=C_retrieve(lf[9]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* er-macro-transformer in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6601,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr5r,(void*)f_6139r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6139r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6139r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6141,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word)li81),tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6544,a[2]=t6,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6553,a[2]=t7,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-culprit10181132 */
t9=t8;
f_6553(t9,t1);}
else{
t9=(C_word)C_i_car(t5);
t10=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-se10191130 */
t11=t7;
f_6544(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body10161024 */
t13=t6;
f_6141(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-culprit1018 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6553(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6553,NULL,2,t0,t1);}
/* def-se10191130 */
t2=((C_word*)t0)[2];
f_6544(t2,t1,C_SCHEME_FALSE);}

/* def-se1019 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6544(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6544,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6552,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 685  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t3);}

/* k6550 in def-se1019 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body10161024 */
t2=((C_word*)t0)[4];
f_6141(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6141(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6141,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6156,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word)li72),tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6144,a[2]=t4,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6187,a[2]=((C_word*)t0)[3],a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6243,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t3,a[6]=t6,a[7]=t7,a[8]=t5,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t9=C_mutate((C_word*)lf[129]+1 /* (set! syntax-error-culprit ...) */,t2);
t10=t8;
f_6272(t10,t9);}
else{
t9=t8;
f_6272(t9,C_SCHEME_UNDEFINED);}}

/* k6270 in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6272,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6277,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],a[8]=((C_word)li80),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6277(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k6270 in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6277(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6277,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t3))){
t4=(C_word)C_i_vector_ref(t3,C_fix(0));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6296,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_eqp(t5,C_fix(1));
if(C_truep(t9)){
t10=t8;
f_6296(t10,C_fix(1));}
else{
t10=(C_word)C_fixnum_greaterp(t5,C_fix(2));
t11=t8;
f_6296(t11,(C_truep(t10)?(C_word)C_i_vector_ref(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_immp(t3))){
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* expand.scm: 738  err */
t5=((C_word*)t0)[7];
f_6156(t5,t1,lf[145]);}}
else{
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t3;
t5=(C_word)C_eqp(t4,lf[146]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t4,lf[147]);
if(C_truep(t6)){
/* expand.scm: 742  test */
t7=((C_word*)t0)[5];
f_6144(t7,t1,t2,*((C_word*)lf[148]+1),lf[149]);}
else{
t7=(C_word)C_eqp(t4,lf[150]);
if(C_truep(t7)){
/* expand.scm: 743  test */
t8=((C_word*)t0)[5];
f_6144(t8,t1,t2,*((C_word*)lf[151]+1),lf[152]);}
else{
t8=(C_word)C_eqp(t4,lf[153]);
if(C_truep(t8)){
/* expand.scm: 744  test */
t9=((C_word*)t0)[5];
f_6144(t9,t1,t2,*((C_word*)lf[151]+1),lf[154]);}
else{
t9=(C_word)C_eqp(t4,lf[155]);
if(C_truep(t9)){
/* expand.scm: 745  test */
t10=((C_word*)t0)[5];
f_6144(t10,t1,t2,((C_word*)t0)[4],lf[156]);}
else{
t10=(C_word)C_eqp(t4,lf[157]);
if(C_truep(t10)){
/* expand.scm: 746  test */
t11=((C_word*)t0)[5];
f_6144(t11,t1,t2,*((C_word*)lf[158]+1),lf[159]);}
else{
t11=(C_word)C_eqp(t4,lf[160]);
if(C_truep(t11)){
/* expand.scm: 747  test */
t12=((C_word*)t0)[5];
f_6144(t12,t1,t2,*((C_word*)lf[161]+1),lf[162]);}
else{
t12=(C_word)C_eqp(t4,lf[163]);
if(C_truep(t12)){
/* expand.scm: 748  test */
t13=((C_word*)t0)[5];
f_6144(t13,t1,t2,((C_word*)t0)[3],lf[164]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6474,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 750  test */
t14=((C_word*)t0)[5];
f_6144(t14,t1,t2,t13,lf[165]);}}}}}}}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6515,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 760  walk */
t27=t4;
t28=t5;
t29=t6;
t1=t27;
t2=t28;
t3=t29;
goto loop;}
else{
/* expand.scm: 758  err */
t4=((C_word*)t0)[7];
f_6156(t4,t1,lf[166]);}}
else{
/* expand.scm: 757  err */
t4=((C_word*)t0)[7];
f_6156(t4,t1,lf[167]);}}}}}

/* k6513 in walk in k6270 in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 761  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6277(t4,((C_word*)t0)[2],t2,t3);}

/* a6473 in walk in k6270 in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6474,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6478,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 753  lookup */
f_3170(t3,t2,((C_word*)t0)[2]);}
else{
t4=t3;
f_6478(2,t4,C_SCHEME_FALSE);}}

/* k6476 in a6473 in walk in k6270 in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
t2=t1;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[3]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[3]));}}

/* k6294 in walk in k6270 in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6296(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6296,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6301,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li78),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6301(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop1100 in k6294 in walk in k6270 in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6301(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6301,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* expand.scm: 731  err */
t5=((C_word*)t0)[6];
f_6156(t5,t1,lf[142]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6320,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* expand.scm: 733  err */
t6=((C_word*)t0)[6];
f_6156(t6,t5,lf[143]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
/* expand.scm: 736  walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6277(t7,t5,t6,((C_word*)t0)[2]);}
else{
/* expand.scm: 735  err */
t6=((C_word*)t0)[6];
f_6156(t6,t5,lf[144]);}}}}

/* k6318 in doloop1100 in k6294 in walk in k6270 in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6301(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6243(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6243,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6249,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_6249(t2));}

/* loop in proper-list? in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static C_word C_fcall f_6249(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6187(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6187,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6191,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 700  ##sys#extended-lambda-list? */
((C_proc3)C_retrieve_symbol_proc(lf[78]))(3,*((C_word*)lf[78]+1),t3,t2);}

/* k6189 in lambda-list? in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6191,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6199,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6199(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k6189 in lambda-list? in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6199,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6219,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 703  keyword? */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 707  loop */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k6217 in loop in k6189 in lambda-list? in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6144(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6144,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6151,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 688  pred */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k6149 in test in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* expand.scm: 688  err */
t2=((C_word*)t0)[3];
f_6156(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6156(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6156,NULL,3,t0,t1,t2);}
t3=C_retrieve(lf[129]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6160,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 692  get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6158 in err in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6167,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6174,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 695  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6185,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 696  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k6183 in k6158 in err in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 696  string-append */
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[140],t1,lf[141],((C_word*)t0)[2]);}

/* k6172 in k6158 in err in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6178,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 695  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k6176 in k6172 in k6158 in err in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 695  string-append */
t2=((C_word*)t0)[5];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],lf[137],((C_word*)t0)[3],lf[138],t1,lf[139],((C_word*)t0)[2]);}

/* k6165 in k6158 in err in body1016 in ##sys#check-syntax in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 693  ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6103,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[128]))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6125,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 674  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t4,C_retrieve(lf[128]),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6123 in get-line-number in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-rules-mismatch in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6097,3,t0,t1,t2);}
/* expand.scm: 667  ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),t1,lf[133],t2);}

/* ##sys#syntax-error-hook in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6086r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6086r(t0,t1,t2);}}

static void C_ccall f_6086r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6094,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 662  ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,t2);}

/* k6092 in ##sys#syntax-error-hook in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],C_retrieve(lf[130]),lf[131],t1);}

/* ##sys#expand-curried-define in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6016,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6019,a[2]=t8,a[3]=t6,a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6079,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 651  loop */
t11=((C_word*)t8)[1];
f_6019(t11,t10,t2,t3);}

/* k6077 in ##sys#expand-curried-define in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6079,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_6019(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6019,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_i_cdr(t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6045,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t9=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6072,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t8=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t3,C_SCHEME_END_OF_LIST);}}

/* k6070 in loop in ##sys#expand-curried-define in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6072,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[87],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* expand.scm: 650  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6019(t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k6043 in loop in ##sys#expand-curried-define in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6045,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[87],t2));}

/* match-expression in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5933(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5933,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5936,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=((C_word)li65),tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6014,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 638  mwalk */
t11=((C_word*)t8)[1];
f_5936(t11,t10,t2,t3);}

/* k6012 in match-expression in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* mwalk in match-expression in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5936(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5936,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5985,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 635  mwalk */
t13=t4;
t14=t5;
t15=t6;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_i_assq(t3,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t2,t5));}
else{
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[2]))){
t5=(C_word)C_a_i_cons(&a,2,t3,t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}}

/* k5983 in mwalk in match-expression in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 636  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5936(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_5163r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5163r(t0,t1,t2,t3);}}

static void C_ccall f_5163r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5165,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5876,a[2]=t4,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5881,a[2]=t5,a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-se749920 */
t7=t6;
f_5881(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-cs?750918 */
t9=t5;
f_5876(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body747755 */
t11=t4;
f_5165(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-se749 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5881,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5889,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 510  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}

/* k5887 in def-se749 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-cs?750918 */
t2=((C_word*)t0)[3];
f_5876(t2,((C_word*)t0)[2],t1);}

/* def-cs?750 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5876(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5876,NULL,3,t0,t1,t2);}
/* body747755 */
t3=((C_word*)t0)[2];
f_5165(t3,t1,t2,C_SCHEME_FALSE);}

/* body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5165(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5165,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5168,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t9,a[6]=((C_word)li55),tmp=(C_word)a,a+=7,tmp));
t11=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5412,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word)li57),tmp=(C_word)a,a+=7,tmp));
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5589,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t2,a[6]=((C_word)li60),tmp=(C_word)a,a+=7,tmp));
/* expand.scm: 619  expand */
t13=((C_word*)t9)[1];
f_5589(t13,t1,((C_word*)t0)[2]);}

/* expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5589(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5589,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word)li59),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5595(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5595(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5595,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_i_car(t7):C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t7,a[7]=t1,a[8]=t6,a[9]=t5,a[10]=t8,a[11]=((C_word*)t0)[5],a[12]=t4,a[13]=t3,a[14]=((C_word*)t0)[6],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t10)){
if(C_truep((C_word)C_i_symbolp(t10))){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5859,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 578  lookup */
f_3170(t12,t10,((C_word*)t0)[6]);}
else{
t12=t11;
f_5617(t12,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5617(t12,C_SCHEME_FALSE);}}
else{
/* expand.scm: 572  fini */
t7=((C_word*)((C_word*)t0)[3])[1];
f_5168(t7,t1,t3,t4,t5,t6,t2);}}

/* k5857 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_5617(t3,t2);}
else{
t2=((C_word*)t0)[3];
f_5617(t2,((C_word*)t0)[2]);}}

/* k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5617,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(C_word)C_eqp(lf[108],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5635,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 581  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[57]))(7,*((C_word*)lf[57]+1),t3,lf[108],((C_word*)t0)[6],lf[122],C_SCHEME_FALSE,((C_word*)t0)[14]);}
else{
t3=(C_word)C_eqp(lf[113],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5761,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 604  ##sys#check-syntax */
((C_proc6)C_retrieve_symbol_proc(lf[57]))(6,*((C_word*)lf[57]+1),t4,lf[113],((C_word*)t0)[6],lf[123],((C_word*)t0)[14]);}
else{
t4=(C_word)C_eqp(lf[107],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5773,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 607  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[57]))(7,*((C_word*)lf[57]+1),t5,lf[107],((C_word*)t0)[6],lf[124],C_SCHEME_FALSE,((C_word*)t0)[14]);}
else{
t5=(C_word)C_eqp(lf[125],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5801,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 610  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[57]))(7,*((C_word*)lf[57]+1),t6,lf[125],((C_word*)t0)[6],lf[126],C_SCHEME_FALSE,((C_word*)t0)[14]);}
else{
t6=(C_word)C_i_memq(t1,((C_word*)t0)[13]);
t7=(C_truep(t6)?t6:(C_word)C_i_memq(t1,((C_word*)t0)[9]));
if(C_truep(t7)){
/* expand.scm: 613  fini */
t8=((C_word*)((C_word*)t0)[3])[1];
f_5168(t8,((C_word*)t0)[7],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5827,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[3],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 615  ##sys#expand-0 */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),t8,((C_word*)t0)[6],((C_word*)t0)[14],((C_word*)t0)[2]);}}}}}}
else{
/* expand.scm: 579  fini */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5168(t2,((C_word*)t0)[7],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[4]);}}

/* k5825 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5827,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* expand.scm: 617  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_5168(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* expand.scm: 618  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5595(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k5799 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5808,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 611  ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k5806 in k5799 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 611  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5595(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5771 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5773,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* expand.scm: 608  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_5595(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k5759 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 605  fini/syntax */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5412(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5633 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5635,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5640,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li58),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5640(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k5633 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5640(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5640,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5687,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 593  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[57]))(7,*((C_word*)lf[57]+1),t5,lf[108],t2,lf[118],C_SCHEME_FALSE,((C_word*)t0)[8]);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5709,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 597  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[57]))(7,*((C_word*)lf[57]+1),t5,lf[108],t2,lf[119],C_SCHEME_FALSE,((C_word*)t0)[8]);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 585  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[57]))(7,*((C_word*)lf[57]+1),t4,lf[108],t2,lf[121],C_SCHEME_FALSE,((C_word*)t0)[8]);}}

/* k5651 in loop2 in k5633 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5653,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[8]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* expand.scm: 586  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_5595(t6,((C_word*)t0)[5],((C_word*)t0)[4],t2,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=(C_word)C_a_i_cons(&a,2,lf[120],((C_word*)t0)[7]);
/* expand.scm: 586  loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_5595(t5,((C_word*)t0)[5],((C_word*)t0)[4],t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5707 in loop2 in k5633 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5709,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5736,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t7=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k5734 in k5707 in loop2 in k5633 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5736,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[87],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
/* expand.scm: 599  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5595(t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5685 in loop2 in k5633 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 594  macro-alias */
f_3188(t2,lf[108],((C_word*)t0)[2]);}

/* k5696 in k5685 in loop2 in k5633 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* expand.scm: 595  ##sys#expand-curried-define */
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5700 in k5696 in k5685 in loop2 in k5633 in k5615 in loop in expand in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5702,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 594  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5640(t3,((C_word*)t0)[2],t2);}

/* fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5412(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5412,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5420,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5422,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li56),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5422(t11,t7,t6,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5422(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5422,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5437,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 552  macro-alias */
f_3188(t5,lf[112],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5468,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_length(t7);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_fix(3),t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5571,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 557  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t9,t2);}
else{
t9=t5;
f_5468(t9,C_SCHEME_FALSE);}}
else{
t7=t5;
f_5468(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 554  loop */
t12=t1;
t13=t2;
t14=t3;
t15=C_SCHEME_TRUE;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}}

/* k5569 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5571,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5567,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 558  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t3,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
f_5468(t2,C_SCHEME_FALSE);}}

/* k5565 in k5569 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 558  lookup */
f_3170(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5555 in k5569 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5560,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t1;
t4=((C_word*)t0)[3];
f_5468(t4,(C_word)C_eqp(lf[113],t3));}
else{
/* expand.scm: 558  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2]);}}

/* k5558 in k5555 in k5569 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5468(t2,(C_word)C_eqp(lf[113],t1));}

/* k5466 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5468(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5468,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5500,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 563  caadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[116]+1)))(3,*((C_word*)lf[116]+1),t5,t2);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
/* expand.scm: 560  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5422(t6,((C_word*)t0)[3],t3,t5,C_SCHEME_FALSE);}}
else{
/* expand.scm: 568  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5422(t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_TRUE);}}

/* k5498 in k5466 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5512,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 564  macro-alias */
f_3188(t2,lf[115],((C_word*)t0)[2]);}

/* k5510 in k5498 in k5466 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 564  cdadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2]);}

/* k5518 in k5510 in k5498 in k5466 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5524,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5522 in k5518 in k5510 in k5498 in k5466 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5524,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[113],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[5]);
/* expand.scm: 560  loop */
t8=((C_word*)((C_word*)t0)[4])[1];
f_5422(t8,((C_word*)t0)[3],((C_word*)t0)[2],t7,C_SCHEME_FALSE);}

/* k5435 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5445,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5453,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 553  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5451 in k5435 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 553  map */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[111]+1),t1);}

/* k5443 in k5435 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5449,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5447 in k5443 in k5435 in loop in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5449,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k5418 in fini/syntax in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 549  fini */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5168(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5168(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5168,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5180,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t10,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li50),tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_5180(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5271,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 528  reverse */
t10=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}

/* k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5392,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5404,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[54]+1),t1,((C_word*)t0)[3]);}

/* k5402 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 531  ##sys#map */
t2=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5391 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5392,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[110]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5289,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5293,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5374,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 533  reverse */
t6=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5388 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 533  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5373 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5374,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[66],t5));}

/* k5291 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5297,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5301,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5307,a[2]=((C_word*)t0)[5],a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5368,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 543  reverse */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5366 in k5291 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5372,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 544  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5370 in k5366 in k5291 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 534  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5306 in k5291 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5307,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5311,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 535  ##sys#map */
t5=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[12]),t2);}

/* k5309 in a5306 in k5291 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5311,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[87],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5338,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5342,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5344,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 540  map */
t8=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a5343 in k5309 in a5306 in k5291 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5344,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[66],t5));}

/* k5340 in k5309 in a5306 in k5291 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5336 in k5309 in a5306 in k5291 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5338,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[87],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[109],t5));}

/* k5299 in k5291 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5305,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5303 in k5299 in k5291 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5295 in k5291 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5287 in k5283 in k5269 in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5289,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[50],t2);
t4=C_retrieve(lf[9]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* loop in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5180(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5180,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5244,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5261,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 522  lookup */
f_3170(t8,t6,((C_word*)t0)[3]);}
else{
t7=t5;
f_5199(t7,C_SCHEME_FALSE);}}
else{
t6=t5;
f_5199(t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[106],((C_word*)t0)[2]));}}

/* k5259 in loop in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_5244(t3,(C_word)C_eqp(t2,lf[108]));}
else{
t2=((C_word*)t0)[3];
f_5244(t2,(C_word)C_eqp(((C_word*)t0)[2],lf[108]));}}

/* k5242 in loop in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5244,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
f_5199(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5254,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 523  lookup */
f_3170(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5252 in k5242 in loop in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_5199(t3,(C_word)C_eqp(t2,lf[107]));}
else{
t2=((C_word*)t0)[3];
f_5199(t2,(C_word)C_eqp(((C_word*)t0)[2],lf[107]));}}

/* k5197 in loop in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5199,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5210,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 526  reverse */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
/* expand.scm: 527  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5180(t4,((C_word*)t0)[8],t2,t3);}}

/* k5208 in k5197 in loop in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5218,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 526  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5589(t3,t2,((C_word*)t0)[2]);}

/* k5216 in k5208 in k5197 in loop in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5218,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* expand.scm: 526  ##sys#append */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5204 in k5197 in loop in fini in body747 in ##sys#canonicalize-body in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5206,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[106],t1));}

/* ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4569,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4572,a[2]=t2,a[3]=t4,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4589,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t10,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 417  macro-alias */
f_3188(t11,lf[103],t5);}

/* k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 419  macro-alias */
f_3188(t2,lf[102],((C_word*)t0)[4]);}

/* k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 420  macro-alias */
f_3188(t2,lf[101],((C_word*)t0)[4]);}

/* k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 421  macro-alias */
f_3188(t2,lf[100],((C_word*)t0)[4]);}

/* k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* expand.scm: 422  macro-alias */
f_3188(t2,lf[49],((C_word*)t0)[4]);}

/* k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word)li48),tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_4606(t5,((C_word*)t0)[3],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4606(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4606,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t5,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t1,a[13]=t4,tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)((C_word*)t0)[13])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 430  reverse */
t9=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}
else{
/* expand.scm: 430  reverse */
t8=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* expand.scm: 458  err */
t7=((C_word*)t0)[4];
f_4572(t7,t1,lf[89]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[13])[1])){
t7=C_mutate(((C_word *)((C_word*)t0)[10])+1,t6);
/* expand.scm: 462  loop */
t16=t1;
t17=C_fix(4);
t18=t3;
t19=t4;
t20=C_SCHEME_END_OF_LIST;
t21=C_SCHEME_END_OF_LIST;
t1=t16;
t2=t17;
t3=t18;
t4=t19;
t5=t20;
t6=t21;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[13])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[10])+1,t6);
/* expand.scm: 462  loop */
t16=t1;
t17=C_fix(4);
t18=t3;
t19=t4;
t20=C_SCHEME_END_OF_LIST;
t21=C_SCHEME_END_OF_LIST;
t1=t16;
t2=t17;
t3=t18;
t4=t19;
t5=t20;
t6=t21;
goto loop;}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4914,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[3],a[11]=t2,a[12]=t6,a[13]=t7,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t7))){
t9=(C_word)C_eqp(C_fix(3),t2);
if(C_truep(t9)){
t10=t8;
f_4914(2,t10,C_SCHEME_FALSE);}
else{
/* expand.scm: 467  lookup */
f_3170(t8,t7,((C_word*)t0)[2]);}}
else{
t9=t8;
f_4914(2,t9,C_SCHEME_FALSE);}}
else{
/* expand.scm: 464  err */
t7=((C_word*)t0)[4];
f_4572(t7,t1,lf[99]);}}}}

/* k4912 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4914,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[13]);
t3=(C_word)C_i_cdr(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t2,lf[80]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t6=t5;
f_4929(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4945,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 471  macro-alias */
f_3188(t6,lf[91],((C_word*)t0)[5]);}}
else{
t5=(C_word)C_eqp(t2,lf[79]);
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[11],C_fix(1)))){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[4],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_4963(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_4963(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 483  err */
t6=((C_word*)t0)[7];
f_4572(t6,((C_word*)t0)[9],lf[93]);}}
else{
t6=(C_word)C_eqp(t2,lf[81]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t8)){
t9=t7;
f_5009(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5028,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 485  macro-alias */
f_3188(t9,lf[91],((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[13]))){
t7=((C_word*)t0)[11];
switch(t7){
case C_fix(0):
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[13],((C_word*)t0)[8]);
/* expand.scm: 492  loop */
t9=((C_word*)((C_word*)t0)[10])[1];
f_4606(t9,((C_word*)t0)[9],C_fix(0),t8,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3);
case C_fix(1):
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[13],C_SCHEME_FALSE);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[3]);
/* expand.scm: 493  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4606(t10,((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8],t9,C_SCHEME_END_OF_LIST,t3);
case C_fix(2):
/* expand.scm: 494  err */
t8=((C_word*)t0)[7];
f_4572(t8,((C_word*)t0)[9],lf[95]);
default:
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[13]);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[2]);
/* expand.scm: 495  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4606(t10,((C_word*)t0)[9],C_fix(3),((C_word*)t0)[8],((C_word*)t0)[3],t9,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5090,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[13]))){
t8=(C_word)C_i_length(((C_word*)t0)[13]);
t9=t7;
f_5090(t9,(C_word)C_eqp(C_fix(2),t8));}
else{
t8=t7;
f_5090(t8,C_SCHEME_FALSE);}}}}}}

/* k5088 in k4912 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5090,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* expand.scm: 498  err */
t3=((C_word*)t0)[9];
f_4572(t3,((C_word*)t0)[8],lf[96]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* expand.scm: 499  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4606(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* expand.scm: 500  err */
t3=((C_word*)t0)[9];
f_4572(t3,((C_word*)t0)[8],lf[97]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* expand.scm: 501  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4606(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* expand.scm: 502  err */
t2=((C_word*)t0)[9];
f_4572(t2,((C_word*)t0)[8],lf[98]);}}

/* k5026 in k4912 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5009(t3,t2);}

/* k5007 in k4912 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_5009(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* expand.scm: 487  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_4606(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 488  err */
t2=((C_word*)t0)[2];
f_4572(t2,((C_word*)t0)[6],lf[94]);}}

/* k4961 in k4912 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4963,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_4966(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_4966(t6,t5);}}
else{
/* expand.scm: 482  err */
t2=((C_word*)t0)[2];
f_4572(t2,((C_word*)t0)[6],lf[92]);}}

/* k4964 in k4961 in k4912 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4966(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 481  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4606(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k4943 in k4912 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4929(t3,t2);}

/* k4927 in k4912 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* expand.scm: 473  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4606(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 474  err */
t3=((C_word*)t0)[2];
f_4572(t3,((C_word*)t0)[5],lf[90]);}}

/* k4871 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 430  ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t3=t2;
f_4624(t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4787,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4793,a[2]=((C_word*)t0)[11],a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4866,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 442  reverse */
t6=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}

/* k4864 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4792 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4793,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4862,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* expand.scm: 414  string->keyword */
((C_proc3)C_retrieve_symbol_proc(lf[88]))(3,*((C_word*)lf[88]+1),t4,t5);}

/* k4860 in a4792 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4862,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[85],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4846,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t8=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
/* ##sys#append */
t6=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k4844 in k4860 in a4792 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4846,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[87],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t4,C_SCHEME_END_OF_LIST);}

/* k4822 in k4860 in a4792 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4824,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[86],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k4785 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4789 in k4785 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4791,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4624(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4622 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4624,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[12]))){
t2=t1;
/* expand.scm: 429  values */
C_values(4,0,((C_word*)t0)[11],((C_word*)t0)[10],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[12],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],tmp=(C_word)a,a+=14,tmp);
t3=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t3)){
t4=t2;
f_4636(t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[12]);
t5=t2;
f_4636(t5,(C_word)C_i_nullp(t4));}
else{
t4=t2;
f_4636(t4,C_SCHEME_FALSE);}}}}

/* k4634 in k4622 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4636(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4636,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4663,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 447  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[5]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 451  reverse */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[13],a[3]=t4,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 454  reverse */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}}

/* k4737 in k4634 in k4622 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4739,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t2)){
t3=(C_word)C_a_i_list(&a,1,t2);
/* expand.scm: 454  ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t1,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_a_i_list(&a,1,t3);
/* expand.scm: 454  ##sys#append */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t1,t4);}}

/* k4729 in k4634 in k4622 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4735,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4733 in k4729 in k4634 in k4622 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
/* expand.scm: 429  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t5);}

/* k4706 in k4634 in k4622 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t3=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4710 in k4706 in k4634 in k4622 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
/* expand.scm: 429  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t5);}

/* k4661 in k4634 in k4622 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 447  cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t2,((C_word*)t0)[2]);}

/* k4681 in k4661 in k4634 in k4622 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4683,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t9=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4653 in k4681 in k4661 in k4634 in k4622 in k4618 in loop in k4599 in k4596 in k4593 in k4590 in k4587 in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4655,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* expand.scm: 429  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* err in ##sys#expand-extended-lambda-list in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4572(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4572,NULL,3,t0,t1,t2);}
/* expand.scm: 413  errh */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4526,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4532,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_4532(t2));}

/* loop in ##sys#extended-lambda-list? in k3470 in k3166 in k3162 in k3134 */
static C_word C_fcall f_4532(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_eqp(t2,lf[79]);
if(C_truep(t3)){
if(C_truep(t3)){
return(C_SCHEME_TRUE);}
else{
t4=(C_word)C_i_cdr(t1);
t10=t4;
t1=t10;
goto loop;}}
else{
t4=(C_word)C_eqp(t2,lf[80]);
if(C_truep(t4)){
if(C_truep(t4)){
return(C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t1);
t10=t5;
t1=t10;
goto loop;}}
else{
t5=(C_word)C_eqp(t2,lf[81]);
if(C_truep(t5)){
return(C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t1);
t10=t6;
t1=t10;
goto loop;}}}}
else{
return(C_SCHEME_FALSE);}}

/* ##sys#expand in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_4440r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4440r(t0,t1,t2,t3);}}

static void C_ccall f_4440r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4442,a[2]=t2,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4468,a[2]=t4,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4473,a[2]=t5,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-se556580 */
t7=t6;
f_4473(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-cs?557578 */
t9=t5;
f_4468(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body554562 */
t11=t4;
f_4442(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-se556 in ##sys#expand in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4473,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4481,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 380  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}

/* k4479 in def-se556 in ##sys#expand in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-cs?557578 */
t2=((C_word*)t0)[3];
f_4468(t2,((C_word*)t0)[2],t1);}

/* def-cs?557 in ##sys#expand in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4468(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4468,NULL,3,t0,t1,t2);}
/* body554562 */
t3=((C_word*)t0)[2];
f_4442(t3,t1,t2,C_SCHEME_FALSE);}

/* body554 in ##sys#expand in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4442(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4442,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4448,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=((C_word)li39),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4448(t7,t1,((C_word*)t0)[2]);}

/* loop in body554 in ##sys#expand in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4448(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4448,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word)li37),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4460,a[2]=((C_word*)t0)[2],a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a4459 in loop in body554 in ##sys#expand in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4460,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* expand.scm: 384  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4448(t4,t1,t2);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* a4453 in loop in body554 in ##sys#expand in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
/* expand.scm: 382  ##sys#expand-0 */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#alias-global-hook in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4354,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4357,a[2]=t3,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4386,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 360  ##sys#qualified-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[13]))(3,*((C_word*)lf[13]+1),t5,t2);}

/* k4384 in ##sys#alias-global-hook in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4386,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 361  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,((C_word*)t0)[4],lf[74]);}}

/* k4387 in k4384 in ##sys#alias-global-hook in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4389,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[9]);
t3=t1;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 365  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,((C_word*)t0)[3],lf[75]);}}

/* k4399 in k4387 in k4384 in ##sys#alias-global-hook in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4401,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[9]);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4438,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 368  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}}

/* k4436 in k4399 in k4387 in k4384 in ##sys#alias-global-hook in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4438,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=C_retrieve(lf[9]);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
/* expand.scm: 373  mrename */
t5=((C_word*)t0)[3];
f_4357(t5,((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4428,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 374  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t5,t4,lf[74]);}}
else{
/* expand.scm: 375  mrename */
t3=((C_word*)t0)[3];
f_4357(t3,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k4426 in k4436 in k4399 in k4387 in k4384 in ##sys#alias-global-hook in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* mrename in ##sys#alias-global-hook in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4357(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4357,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 354  ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[73]))(2,*((C_word*)lf[73]+1),t3);}

/* k4359 in mrename in ##sys#alias-global-hook in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4361,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=t3;
f_4370(2,t4,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 357  ##sys#register-undefined */
((C_proc4)C_retrieve_symbol_proc(lf[72]))(4,*((C_word*)lf[72]+1),t3,((C_word*)t0)[3],t1);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4368 in k4359 in mrename in ##sys#alias-global-hook in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_word)C_i_check_structure(t2,lf[71]);
t4=(C_word)C_i_block_ref(t2,C_fix(1));
/* expand.scm: 358  ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[68]))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* ##sys#module-rename in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4336,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4344,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 347  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[35]+1)))(5,*((C_word*)lf[35]+1),t4,t5,lf[70],t6);}

/* k4342 in ##sys#module-rename in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 346  ##sys#string->symbol */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],t1);}

/* ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3835,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3838,a[2]=t3,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4040,a[2]=t5,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4086,a[2]=t4,a[3]=t5,a[4]=t8,a[5]=t6,a[6]=t3,a[7]=((C_word)li32),tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_4086(t10,t1,t2);}

/* loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4086(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4086,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=t4,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 303  lookup */
f_3170(t5,t3,((C_word*)t0)[6]);}
else{
/* expand.scm: 339  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* expand.scm: 340  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4108,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[10]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=t5;
f_4114(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4319,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4326,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 305  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t7);}}

/* k4324 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 305  lookup */
f_3170(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4317 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4114(t4,t3);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4114(t4,t3);}}

/* k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4114(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4114,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[11])[1];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[49]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[50]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4123,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 307  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[57]))(7,*((C_word*)lf[57]+1),t3,lf[49],((C_word*)t0)[10],lf[59],C_SCHEME_FALSE,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)((C_word*)t0)[11])[1];
if(C_truep((C_truep((C_word)C_eqp(t4,lf[62]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[66]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t5=(C_word)C_i_car(((C_word*)t0)[10]);
t6=t3;
f_4216(t6,(C_word)C_i_pairp(t5));}
else{
t5=t3;
f_4216(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4216(t5,C_SCHEME_FALSE);}}}

/* k4214 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4216,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[11],a[3]=t2,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 324  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[57]))(7,*((C_word*)lf[57]+1),t3,lf[62],((C_word*)t0)[11],lf[63],C_SCHEME_FALSE,((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep((C_word)C_i_symbolp(((C_word*)((C_word*)t0)[5])[1]))){
/* expand.scm: 330  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,((C_word*)((C_word*)t0)[5])[1],lf[65]);}
else{
t3=t2;
f_4252(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4252(2,t3,C_SCHEME_FALSE);}}}

/* k4250 in k4214 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4252,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_cdr(t1);
/* expand.scm: 332  call-handler */
t5=((C_word*)t0)[2];
f_3838(t5,t2,((C_word*)t0)[5],t3,((C_word*)t0)[8],t4,C_SCHEME_TRUE);}
else{
/* expand.scm: 338  expand */
t2=((C_word*)t0)[7];
f_4040(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4256 in k4250 in k4214 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4258,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[7]);
if(C_truep(t2)){
/* expand.scm: 333  expand */
t3=((C_word*)t0)[6];
f_4040(t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4270,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[64]))){
/* expand.scm: 336  ##sys#compiler-syntax-hook */
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t3,((C_word*)t0)[4],t1);}
else{
/* expand.scm: 337  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4086(t4,((C_word*)t0)[5],t1);}}}

/* k4268 in k4256 in k4250 in k4214 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 337  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4086(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4220 in k4214 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4229,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[60],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* expand.scm: 326  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[61]+1)))(5,*((C_word*)lf[61]+1),t2,t5,t6,t7);}

/* k4227 in k4220 in k4214 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 325  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k4121 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4123,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 310  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[57]))(7,*((C_word*)lf[57]+1),t3,lf[49],((C_word*)t0)[5],lf[58],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
/* expand.scm: 319  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4133 in k4121 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4135,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4193,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4203,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a4202 in k4133 in k4121 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4203,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k4191 in k4133 in k4121 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4197,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k4195 in k4191 in k4133 in k4121 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4197,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[51],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[52],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[3],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4161,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 317  ##sys#map */
t12=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[56]+1),((C_word*)t0)[2]);}

/* k4159 in k4195 in k4191 in k4133 in k4121 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4155 in k4195 in k4191 in k4133 in k4121 in k4112 in k4106 in loop in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4157,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[53],t2);
/* expand.scm: 312  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_4040(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4040,NULL,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[9]);
if(C_truep((C_word)C_i_listp(t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4066,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cadr(t4);
t8=(C_word)C_i_car(t4);
/* expand.scm: 295  call-handler */
t9=((C_word*)t0)[2];
f_3838(t9,t6,t2,t7,t3,t8,C_SCHEME_FALSE);}
else{
/* expand.scm: 297  values */
C_values(4,0,t1,t3,C_SCHEME_FALSE);}}
else{
/* expand.scm: 291  ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),t1,lf[48],t3);}}

/* k4064 in expand in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 293  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_3838(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3838,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_retrieve(lf[9]);
t8=C_retrieve(lf[9]);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3851,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=t4,a[6]=t6,a[7]=t2,a[8]=((C_word)li28),tmp=(C_word)a,a+=9,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),t9,t10);}

/* a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3853,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3859,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3966,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word)li27),tmp=(C_word)a,a+=10,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[46]))(4,*((C_word*)lf[46]+1),t1,t3,t4);}

/* a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li24),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[2],a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4027 in a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4028r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4028r(t0,t1,t2);}}

static void C_ccall f_4028r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4034,a[2]=t2,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
/* k378381 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4033 in a4027 in a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3971 in a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[31],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3976,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[7])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[6],a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4009,a[2]=t4,a[3]=t6,a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word)li22),tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4020,a[2]=t6,a[3]=t4,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t2,t7,t8,t9);}
else{
/* expand.scm: 271  handler */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a4019 in a3971 in a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[44]));
t3=C_mutate((C_word*)lf[44]+1 /* (set! syntax-rules-mismatch ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a4013 in a3971 in a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4014,2,t0,t1);}
/* expand.scm: 270  handler */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4008 in a3971 in a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[44]));
t3=C_mutate((C_word*)lf[44]+1 /* (set! syntax-rules-mismatch ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* f_4003 in a3971 in a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4003,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k3974 in a3971 in a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3979,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_eqp(((C_word*)t0)[3],t1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3996,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 275  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[43]+1)))(3,*((C_word*)lf[43]+1),t6,((C_word*)t0)[2]);}
else{
t5=C_retrieve(lf[9]);
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}}

/* k3994 in k3974 in a3971 in a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 274  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[35]+1)))(5,*((C_word*)lf[35]+1),((C_word*)t0)[2],lf[41],t1,lf[42]);}

/* k3990 in k3974 in a3971 in a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 273  ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3977 in k3974 in a3971 in a3965 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[9]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* a3858 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3859,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3865,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp);
/* k378381 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3864 in a3858 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3876,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[3],lf[32]))){
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=t2;
f_3876(t4,(C_word)C_i_memq(lf[39],t3));}
else{
t3=t2;
f_3876(t3,C_SCHEME_FALSE);}}

/* k3874 in a3864 in a3858 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_3876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3876,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3887,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3893,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3893(t8,t3,t4);}
else{
t2=((C_word*)t0)[4];
/* expand.scm: 243  ##sys#abort */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),((C_word*)t0)[3],t2);}}

/* copy in k3874 in a3864 in a3858 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_3893(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3893,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_equalp(lf[38],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=t5;
f_3912(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_3912(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_3912(t6,C_SCHEME_FALSE);}}}

/* k3910 in copy in k3874 in a3864 in a3858 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_3912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3912,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3923,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 259  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[35]+1)))(6,*((C_word*)lf[35]+1),t2,lf[36],t3,lf[37],t4);}
else{
/* expand.scm: 265  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3893(t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k3921 in k3910 in copy in k3874 in a3864 in a3858 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3923,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[34],t3));}

/* k3885 in k3874 in a3864 in a3858 in a3852 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3887,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,3,lf[32],((C_word*)t0)[3],t1);
/* expand.scm: 243  ##sys#abort */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t2);}

/* k3849 in call-handler in ##sys#expand-0 in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##sys#undefine-macro! in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3829,3,t0,t1,t2);}
/* expand.scm: 231  ##sys#unregister-macro */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t1,t2);}

/* ##sys#unregister-macro in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3778,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3786,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3790,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 225  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t4);}

/* k3788 in ##sys#unregister-macro in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3792,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3792(t5,((C_word*)t0)[2],t1);}

/* loop in k3788 in ##sys#unregister-macro in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_3792(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3792,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3827,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 227  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t3,t2);}}

/* k3825 in loop in k3788 in ##sys#unregister-macro in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3827,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3819,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 228  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3792(t6,t4,t5);}}

/* k3817 in k3825 in loop in k3788 in ##sys#unregister-macro in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3819,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3784 in ##sys#unregister-macro in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 223  ##sys#macro-environment */
((C_proc3)C_retrieve_symbol_proc(lf[20]))(3,*((C_word*)lf[20]+1),((C_word*)t0)[2],t1);}

/* ##sys#macro? in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3728r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3728r(t0,t1,t2,t3);}}

static void C_ccall f_3728r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3732,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 216  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3732(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3730 in ##sys#macro? in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 217  lookup */
f_3170(t2,((C_word*)t0)[2],t1);}

/* k3733 in k3730 in ##sys#macro? in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3735,2,t0,t1);}
t2=(C_word)C_i_pairp(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3744,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 219  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t4);}}

/* k3752 in k3733 in k3730 in ##sys#macro? in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 219  lookup */
f_3170(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3742 in k3733 in k3730 in ##sys#macro? in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE));}

/* ##sys#copy-macro in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3715,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3719,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3726,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 213  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t5);}

/* k3724 in ##sys#copy-macro in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 213  lookup */
f_3170(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3717 in ##sys#copy-macro in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],C_retrieve(lf[25]),((C_word*)t0)[2],t1);}

/* ##sys#extend-macro-environment in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3682,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3686,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 202  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[20]))(2,*((C_word*)lf[20]+1),t5);}

/* k3684 in ##sys#extend-macro-environment in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3689,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 203  lookup */
f_3170(t2,((C_word*)t0)[2],t1);}

/* k3687 in k3684 in ##sys#extend-macro-environment in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3689,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_set_car(t1,((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(t1);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[4]));}
else{
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
/* expand.scm: 208  ##sys#macro-environment */
((C_proc3)C_retrieve_symbol_proc(lf[20]))(3,*((C_word*)lf[20]+1),((C_word*)t0)[5],t3);}}

/* ##sys#syntactic-environment-symbols in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3604,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3632,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3634,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li9),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3634(t10,t6,t2);}

/* loop286 in ##sys#syntactic-environment-symbols in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_3634(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3634,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3660,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 193  pred */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3658 in loop286 in ##sys#syntactic-environment-symbols in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3660,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_3634(t5,((C_word*)t0)[3],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3611,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 184  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,((C_word*)t0)[7],lf[11]);}}

/* k3609 in k3658 in loop286 in ##sys#syntactic-environment-symbols in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3611,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_3667(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 185  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,((C_word*)t0)[2],lf[7]);}}

/* k3615 in k3609 in k3658 in loop286 in ##sys#syntactic-environment-symbols in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_i_pairp(t1))){
t3=((C_word*)t0)[3];
f_3667(t3,((C_word*)t0)[2]);}
else{
t3=t1;
t4=((C_word*)t0)[3];
f_3667(t4,t3);}}
else{
t3=((C_word*)t0)[3];
f_3667(t3,((C_word*)t0)[2]);}}

/* k3665 in k3658 in loop286 in ##sys#syntactic-environment-symbols in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_3667(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3667,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 197  pred */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)((C_word*)t0)[4])[1];
f_3634(t3,((C_word*)t0)[3],t2);}}

/* k3674 in k3665 in k3658 in loop286 in ##sys#syntactic-environment-symbols in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_3634(t5,((C_word*)t0)[2],t4);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3634(t3,((C_word*)t0)[2],t2);}}

/* k3630 in ##sys#syntactic-environment-symbols in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#syntactic-environment? in k3470 in k3166 in k3162 in k3134 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3476,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3596,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
if(C_truep((C_word)C_i_listp(t4))){
t5=(C_word)C_i_nullp(t4);
if(C_truep(t5)){
t6=t3;
f_3596(t6,t5);}
else{
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_symbolp(t7))){
t8=(C_word)C_i_cdr(t6);
t9=t3;
f_3596(t9,(C_word)C_i_symbolp(t8));}
else{
t8=t3;
f_3596(t8,C_SCHEME_FALSE);}}
else{
t7=t3;
f_3596(t7,C_SCHEME_FALSE);}}}
else{
t5=t3;
f_3596(t5,C_SCHEME_FALSE);}}

/* k3594 in ##sys#syntactic-environment? in k3470 in k3166 in k3162 in k3134 */
static void C_fcall f_3596(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_length(t5);
t7=(C_word)C_eqp(C_fix(3),t6);
if(C_truep(t7)){
t8=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_symbolp(t8))){
t9=(C_word)C_i_cadr(t5);
if(C_truep((C_word)C_i_listp(t9))){
t10=(C_word)C_i_caddr(t5);
t11=t2;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_i_closurep(t10));}
else{
t10=t2;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* ##sys#strip-syntax in k3166 in k3162 in k3134 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_3263r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3263r(t0,t1,t2,t3);}}

static void C_ccall f_3263r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3265,a[2]=t2,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3416,a[2]=t4,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3421,a[2]=t5,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-se163215 */
t7=t6;
f_3421(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-alias164213 */
t9=t5;
f_3416(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body161169 */
t11=t4;
f_3265(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-se163 in ##sys#strip-syntax in k3166 in k3162 in k3134 */
static void C_fcall f_3421(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3421,NULL,2,t0,t1);}
/* def-alias164213 */
t2=((C_word*)t0)[2];
f_3416(t2,t1,C_SCHEME_FALSE);}

/* def-alias164 in ##sys#strip-syntax in k3166 in k3162 in k3134 */
static void C_fcall f_3416(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3416,NULL,3,t0,t1,t2);}
/* body161169 */
t3=((C_word*)t0)[2];
f_3265(t3,t1,t2,C_SCHEME_FALSE);}

/* body161 in ##sys#strip-syntax in k3166 in k3162 in k3134 */
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3265,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3271,a[2]=t7,a[3]=t2,a[4]=t3,a[5]=t5,a[6]=((C_word)li3),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_3271(t9,t1,((C_word*)t0)[2]);}

/* walk in body161 in ##sys#strip-syntax in k3166 in k3162 in k3134 */
static void C_fcall f_3271(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3271,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* expand.scm: 106  lookup */
f_3170(t4,t2,((C_word*)t0)[3]);}
else{
/* expand.scm: 107  get */
((C_proc4)C_retrieve_symbol_proc(lf[16]))(4,*((C_word*)lf[16]+1),t4,t2,lf[7]);}}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_FALSE);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t2);
/* expand.scm: 117  walk */
t15=t8;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3381,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 122  make-vector */
((C_proc3)C_retrieve_proc(*((C_word*)lf[17]+1)))(3,*((C_word*)lf[17]+1),t5,t4);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}}}

/* k3379 in walk in body161 in ##sys#strip-syntax in k3166 in k3162 in k3134 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3390,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word)li2),tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_3390(t5,C_fix(0)));}

/* doloop204 in k3379 in walk in body161 in ##sys#strip-syntax in k3166 in k3162 in k3134 */
static C_word C_fcall f_3390(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
return(t2);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t7=t4;
t1=t7;
goto loop;}}

/* k3359 in walk in body161 in ##sys#strip-syntax in k3166 in k3162 in k3134 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3361,2,t0,t1);}
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3353,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 118  walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3271(t5,t3,t4);}

/* k3351 in k3359 in walk in body161 in ##sys#strip-syntax in k3166 in k3162 in k3134 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_set_cdr(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}

/* k3288 in walk in body161 in ##sys#strip-syntax in k3166 in k3162 in k3134 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 108  get */
((C_proc4)C_retrieve_symbol_proc(lf[16]))(4,*((C_word*)lf[16]+1),t2,((C_word*)t0)[4],lf[11]);}

/* k3291 in k3288 in walk in body161 in ##sys#strip-syntax in k3166 in k3162 in k3134 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3293,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[2]);
t4=t2;
f_3302(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3302(t3,C_SCHEME_FALSE);}}}

/* k3300 in k3291 in k3288 in walk in body161 in ##sys#strip-syntax in k3166 in k3162 in k3134 */
static void C_fcall f_3302(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
/* expand.scm: 110  ##sys#alias-global-hook */
((C_proc4)C_retrieve_symbol_proc(lf[15]))(4,*((C_word*)lf[15]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[2];
if(C_truep(t2)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}

/* macro-alias in k3166 in k3162 in k3134 */
static void C_fcall f_3188(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3188,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3195,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 77   ##sys#qualified-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[13]))(3,*((C_word*)lf[13]+1),t4,t2);}

/* k3193 in macro-alias in k3166 in k3162 in k3134 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3198(t3,t1);}
else{
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(C_word)C_fixnum_greaterp(t4,C_fix(0));
t6=t2;
f_3198(t6,(C_truep(t5)?(C_word)C_eqp(C_make_character(35),(C_word)C_subchar(t3,C_fix(0))):C_SCHEME_FALSE));}}

/* k3196 in k3193 in macro-alias in k3166 in k3162 in k3134 */
static void C_fcall f_3198(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3198,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 83   gensym */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),t2,((C_word*)t0)[4]);}}

/* k3199 in k3196 in k3193 in macro-alias in k3166 in k3162 in k3134 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3204,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 84   lookup */
f_3170(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k3202 in k3199 in k3196 in k3193 in macro-alias in k3166 in k3162 in k3134 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3204,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3210,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 85   ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t3,((C_word*)t0)[3],lf[7],t2);}

/* k3208 in k3202 in k3199 in k3196 in k3193 in macro-alias in k3166 in k3162 in k3134 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3213,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 86   ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),t2,((C_word*)t0)[4],lf[11],((C_word*)t0)[2]);}

/* k3211 in k3208 in k3202 in k3199 in k3196 in k3193 in macro-alias in k3166 in k3162 in k3134 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_retrieve(lf[9]);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* lookup in k3166 in k3162 in k3134 */
static void C_fcall f_3170(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3170,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cdr(t4));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 73   ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t5,t2,lf[7]);}}

/* k3181 in lookup in k3166 in k3162 in k3134 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[854] = {
{"toplevel:expand_scm",(void*)C_expand_toplevel},
{"f_3136:expand_scm",(void*)f_3136},
{"f_3164:expand_scm",(void*)f_3164},
{"f_3168:expand_scm",(void*)f_3168},
{"f_3472:expand_scm",(void*)f_3472},
{"f_13811:expand_scm",(void*)f_13811},
{"f_13809:expand_scm",(void*)f_13809},
{"f_7651:expand_scm",(void*)f_7651},
{"f_13801:expand_scm",(void*)f_13801},
{"f_13799:expand_scm",(void*)f_13799},
{"f_7654:expand_scm",(void*)f_7654},
{"f_7658:expand_scm",(void*)f_7658},
{"f_13659:expand_scm",(void*)f_13659},
{"f_13669:expand_scm",(void*)f_13669},
{"f_13685:expand_scm",(void*)f_13685},
{"f_13688:expand_scm",(void*)f_13688},
{"f_13716:expand_scm",(void*)f_13716},
{"f_13691:expand_scm",(void*)f_13691},
{"f_13738:expand_scm",(void*)f_13738},
{"f_13741:expand_scm",(void*)f_13741},
{"f_13787:expand_scm",(void*)f_13787},
{"f_13744:expand_scm",(void*)f_13744},
{"f_13767:expand_scm",(void*)f_13767},
{"f_13779:expand_scm",(void*)f_13779},
{"f_13725:expand_scm",(void*)f_13725},
{"f_13728:expand_scm",(void*)f_13728},
{"f_13735:expand_scm",(void*)f_13735},
{"f_13657:expand_scm",(void*)f_13657},
{"f_7661:expand_scm",(void*)f_7661},
{"f_13600:expand_scm",(void*)f_13600},
{"f_13629:expand_scm",(void*)f_13629},
{"f_13649:expand_scm",(void*)f_13649},
{"f_13653:expand_scm",(void*)f_13653},
{"f_13598:expand_scm",(void*)f_13598},
{"f_7664:expand_scm",(void*)f_7664},
{"f_13510:expand_scm",(void*)f_13510},
{"f_13535:expand_scm",(void*)f_13535},
{"f_13542:expand_scm",(void*)f_13542},
{"f_13562:expand_scm",(void*)f_13562},
{"f_13582:expand_scm",(void*)f_13582},
{"f_13586:expand_scm",(void*)f_13586},
{"f_13508:expand_scm",(void*)f_13508},
{"f_7667:expand_scm",(void*)f_7667},
{"f_13180:expand_scm",(void*)f_13180},
{"f_13187:expand_scm",(void*)f_13187},
{"f_13190:expand_scm",(void*)f_13190},
{"f_13193:expand_scm",(void*)f_13193},
{"f_13196:expand_scm",(void*)f_13196},
{"f_13199:expand_scm",(void*)f_13199},
{"f_13202:expand_scm",(void*)f_13202},
{"f_13207:expand_scm",(void*)f_13207},
{"f_13223:expand_scm",(void*)f_13223},
{"f_13229:expand_scm",(void*)f_13229},
{"f_13271:expand_scm",(void*)f_13271},
{"f_13339:expand_scm",(void*)f_13339},
{"f_13464:expand_scm",(void*)f_13464},
{"f_13460:expand_scm",(void*)f_13460},
{"f_13342:expand_scm",(void*)f_13342},
{"f_13397:expand_scm",(void*)f_13397},
{"f_13274:expand_scm",(void*)f_13274},
{"f_13313:expand_scm",(void*)f_13313},
{"f_13265:expand_scm",(void*)f_13265},
{"f_13236:expand_scm",(void*)f_13236},
{"f_13178:expand_scm",(void*)f_13178},
{"f_7670:expand_scm",(void*)f_7670},
{"f_13013:expand_scm",(void*)f_13013},
{"f_13017:expand_scm",(void*)f_13017},
{"f_13026:expand_scm",(void*)f_13026},
{"f_13029:expand_scm",(void*)f_13029},
{"f_13032:expand_scm",(void*)f_13032},
{"f_13035:expand_scm",(void*)f_13035},
{"f_13056:expand_scm",(void*)f_13056},
{"f_13072:expand_scm",(void*)f_13072},
{"f_13078:expand_scm",(void*)f_13078},
{"f_13134:expand_scm",(void*)f_13134},
{"f_13132:expand_scm",(void*)f_13132},
{"f_13128:expand_scm",(void*)f_13128},
{"f_13120:expand_scm",(void*)f_13120},
{"f_13116:expand_scm",(void*)f_13116},
{"f_13085:expand_scm",(void*)f_13085},
{"f_13054:expand_scm",(void*)f_13054},
{"f_13011:expand_scm",(void*)f_13011},
{"f_7673:expand_scm",(void*)f_7673},
{"f_12944:expand_scm",(void*)f_12944},
{"f_12948:expand_scm",(void*)f_12948},
{"f_12957:expand_scm",(void*)f_12957},
{"f_12962:expand_scm",(void*)f_12962},
{"f_12999:expand_scm",(void*)f_12999},
{"f_12980:expand_scm",(void*)f_12980},
{"f_12942:expand_scm",(void*)f_12942},
{"f_7676:expand_scm",(void*)f_7676},
{"f_12765:expand_scm",(void*)f_12765},
{"f_12769:expand_scm",(void*)f_12769},
{"f_12781:expand_scm",(void*)f_12781},
{"f_12784:expand_scm",(void*)f_12784},
{"f_12787:expand_scm",(void*)f_12787},
{"f_12922:expand_scm",(void*)f_12922},
{"f_12802:expand_scm",(void*)f_12802},
{"f_12920:expand_scm",(void*)f_12920},
{"f_12829:expand_scm",(void*)f_12829},
{"f_12910:expand_scm",(void*)f_12910},
{"f_12845:expand_scm",(void*)f_12845},
{"f_12867:expand_scm",(void*)f_12867},
{"f_12865:expand_scm",(void*)f_12865},
{"f_12861:expand_scm",(void*)f_12861},
{"f_12763:expand_scm",(void*)f_12763},
{"f_7679:expand_scm",(void*)f_7679},
{"f_12370:expand_scm",(void*)f_12370},
{"f_12374:expand_scm",(void*)f_12374},
{"f_12377:expand_scm",(void*)f_12377},
{"f_12380:expand_scm",(void*)f_12380},
{"f_12383:expand_scm",(void*)f_12383},
{"f_12752:expand_scm",(void*)f_12752},
{"f_12664:expand_scm",(void*)f_12664},
{"f_12668:expand_scm",(void*)f_12668},
{"f_12693:expand_scm",(void*)f_12693},
{"f_12739:expand_scm",(void*)f_12739},
{"f_12724:expand_scm",(void*)f_12724},
{"f_12395:expand_scm",(void*)f_12395},
{"f_12442:expand_scm",(void*)f_12442},
{"f_12489:expand_scm",(void*)f_12489},
{"f_12650:expand_scm",(void*)f_12650},
{"f_12658:expand_scm",(void*)f_12658},
{"f_12636:expand_scm",(void*)f_12636},
{"f_12625:expand_scm",(void*)f_12625},
{"f_12633:expand_scm",(void*)f_12633},
{"f_12610:expand_scm",(void*)f_12610},
{"f_12598:expand_scm",(void*)f_12598},
{"f_12579:expand_scm",(void*)f_12579},
{"f_12537:expand_scm",(void*)f_12537},
{"f_12514:expand_scm",(void*)f_12514},
{"f_12468:expand_scm",(void*)f_12468},
{"f_12417:expand_scm",(void*)f_12417},
{"f_12413:expand_scm",(void*)f_12413},
{"f_12385:expand_scm",(void*)f_12385},
{"f_12393:expand_scm",(void*)f_12393},
{"f_12368:expand_scm",(void*)f_12368},
{"f_7682:expand_scm",(void*)f_7682},
{"f_12337:expand_scm",(void*)f_12337},
{"f_12341:expand_scm",(void*)f_12341},
{"f_12335:expand_scm",(void*)f_12335},
{"f_7685:expand_scm",(void*)f_7685},
{"f_12056:expand_scm",(void*)f_12056},
{"f_12063:expand_scm",(void*)f_12063},
{"f_12066:expand_scm",(void*)f_12066},
{"f_12069:expand_scm",(void*)f_12069},
{"f_12072:expand_scm",(void*)f_12072},
{"f_12234:expand_scm",(void*)f_12234},
{"f_12287:expand_scm",(void*)f_12287},
{"f_12309:expand_scm",(void*)f_12309},
{"f_12316:expand_scm",(void*)f_12316},
{"f_12303:expand_scm",(void*)f_12303},
{"f_12250:expand_scm",(void*)f_12250},
{"f_12248:expand_scm",(void*)f_12248},
{"f_12084:expand_scm",(void*)f_12084},
{"f_12115:expand_scm",(void*)f_12115},
{"f_12161:expand_scm",(void*)f_12161},
{"f_12211:expand_scm",(void*)f_12211},
{"f_12218:expand_scm",(void*)f_12218},
{"f_12176:expand_scm",(void*)f_12176},
{"f_12190:expand_scm",(void*)f_12190},
{"f_12133:expand_scm",(void*)f_12133},
{"f_12144:expand_scm",(void*)f_12144},
{"f_12074:expand_scm",(void*)f_12074},
{"f_12054:expand_scm",(void*)f_12054},
{"f_7688:expand_scm",(void*)f_7688},
{"f_12035:expand_scm",(void*)f_12035},
{"f_12033:expand_scm",(void*)f_12033},
{"f_7691:expand_scm",(void*)f_7691},
{"f_12014:expand_scm",(void*)f_12014},
{"f_12012:expand_scm",(void*)f_12012},
{"f_7694:expand_scm",(void*)f_7694},
{"f_11963:expand_scm",(void*)f_11963},
{"f_11967:expand_scm",(void*)f_11967},
{"f_12004:expand_scm",(void*)f_12004},
{"f_11990:expand_scm",(void*)f_11990},
{"f_11961:expand_scm",(void*)f_11961},
{"f_7697:expand_scm",(void*)f_7697},
{"f_11919:expand_scm",(void*)f_11919},
{"f_11923:expand_scm",(void*)f_11923},
{"f_11953:expand_scm",(void*)f_11953},
{"f_11926:expand_scm",(void*)f_11926},
{"f_11941:expand_scm",(void*)f_11941},
{"f_11917:expand_scm",(void*)f_11917},
{"f_7700:expand_scm",(void*)f_7700},
{"f_11800:expand_scm",(void*)f_11800},
{"f_11807:expand_scm",(void*)f_11807},
{"f_11810:expand_scm",(void*)f_11810},
{"f_11830:expand_scm",(void*)f_11830},
{"f_11868:expand_scm",(void*)f_11868},
{"f_11853:expand_scm",(void*)f_11853},
{"f_11843:expand_scm",(void*)f_11843},
{"f_11813:expand_scm",(void*)f_11813},
{"f_11828:expand_scm",(void*)f_11828},
{"f_11820:expand_scm",(void*)f_11820},
{"f_11816:expand_scm",(void*)f_11816},
{"f_11798:expand_scm",(void*)f_11798},
{"f_7703:expand_scm",(void*)f_7703},
{"f_11763:expand_scm",(void*)f_11763},
{"f_11767:expand_scm",(void*)f_11767},
{"f_11785:expand_scm",(void*)f_11785},
{"f_11761:expand_scm",(void*)f_11761},
{"f_7706:expand_scm",(void*)f_7706},
{"f_11757:expand_scm",(void*)f_11757},
{"f_9504:expand_scm",(void*)f_9504},
{"f_11753:expand_scm",(void*)f_11753},
{"f_9508:expand_scm",(void*)f_9508},
{"f_9512:expand_scm",(void*)f_9512},
{"f_11319:expand_scm",(void*)f_11319},
{"f_11732:expand_scm",(void*)f_11732},
{"f_11744:expand_scm",(void*)f_11744},
{"f_11335:expand_scm",(void*)f_11335},
{"f_11689:expand_scm",(void*)f_11689},
{"f_11691:expand_scm",(void*)f_11691},
{"f_11730:expand_scm",(void*)f_11730},
{"f_11704:expand_scm",(void*)f_11704},
{"f_11715:expand_scm",(void*)f_11715},
{"f_11338:expand_scm",(void*)f_11338},
{"f_11562:expand_scm",(void*)f_11562},
{"f_11613:expand_scm",(void*)f_11613},
{"f_11663:expand_scm",(void*)f_11663},
{"f_11625:expand_scm",(void*)f_11625},
{"f_11649:expand_scm",(void*)f_11649},
{"f_11645:expand_scm",(void*)f_11645},
{"f_11641:expand_scm",(void*)f_11641},
{"f_11610:expand_scm",(void*)f_11610},
{"f_11595:expand_scm",(void*)f_11595},
{"f_11599:expand_scm",(void*)f_11599},
{"f_11341:expand_scm",(void*)f_11341},
{"f_11457:expand_scm",(void*)f_11457},
{"f_11459:expand_scm",(void*)f_11459},
{"f_11486:expand_scm",(void*)f_11486},
{"f_11489:expand_scm",(void*)f_11489},
{"f_11526:expand_scm",(void*)f_11526},
{"f_11552:expand_scm",(void*)f_11552},
{"f_11540:expand_scm",(void*)f_11540},
{"f_11544:expand_scm",(void*)f_11544},
{"f_11524:expand_scm",(void*)f_11524},
{"f_11520:expand_scm",(void*)f_11520},
{"f_11513:expand_scm",(void*)f_11513},
{"f_11509:expand_scm",(void*)f_11509},
{"f_11505:expand_scm",(void*)f_11505},
{"f_11472:expand_scm",(void*)f_11472},
{"f_11344:expand_scm",(void*)f_11344},
{"f_11347:expand_scm",(void*)f_11347},
{"f_11450:expand_scm",(void*)f_11450},
{"f_11414:expand_scm",(void*)f_11414},
{"f_11442:expand_scm",(void*)f_11442},
{"f_11350:expand_scm",(void*)f_11350},
{"f_11408:expand_scm",(void*)f_11408},
{"f_11412:expand_scm",(void*)f_11412},
{"f_11353:expand_scm",(void*)f_11353},
{"f_11356:expand_scm",(void*)f_11356},
{"f_11370:expand_scm",(void*)f_11370},
{"f_11383:expand_scm",(void*)f_11383},
{"f_11359:expand_scm",(void*)f_11359},
{"f_11365:expand_scm",(void*)f_11365},
{"f_11234:expand_scm",(void*)f_11234},
{"f_11245:expand_scm",(void*)f_11245},
{"f_11247:expand_scm",(void*)f_11247},
{"f_11296:expand_scm",(void*)f_11296},
{"f_11292:expand_scm",(void*)f_11292},
{"f_11275:expand_scm",(void*)f_11275},
{"f_11153:expand_scm",(void*)f_11153},
{"f_11157:expand_scm",(void*)f_11157},
{"f_11160:expand_scm",(void*)f_11160},
{"f_11199:expand_scm",(void*)f_11199},
{"f_11213:expand_scm",(void*)f_11213},
{"f_11175:expand_scm",(void*)f_11175},
{"f_11181:expand_scm",(void*)f_11181},
{"f_11179:expand_scm",(void*)f_11179},
{"f_11136:expand_scm",(void*)f_11136},
{"f_11147:expand_scm",(void*)f_11147},
{"f_11140:expand_scm",(void*)f_11140},
{"f_11143:expand_scm",(void*)f_11143},
{"f_10877:expand_scm",(void*)f_10877},
{"f_10881:expand_scm",(void*)f_10881},
{"f_11090:expand_scm",(void*)f_11090},
{"f_11111:expand_scm",(void*)f_11111},
{"f_10907:expand_scm",(void*)f_10907},
{"f_10910:expand_scm",(void*)f_10910},
{"f_11058:expand_scm",(void*)f_11058},
{"f_11080:expand_scm",(void*)f_11080},
{"f_10913:expand_scm",(void*)f_10913},
{"f_11040:expand_scm",(void*)f_11040},
{"f_11052:expand_scm",(void*)f_11052},
{"f_10916:expand_scm",(void*)f_10916},
{"f_11034:expand_scm",(void*)f_11034},
{"f_11038:expand_scm",(void*)f_11038},
{"f_10922:expand_scm",(void*)f_10922},
{"f_10925:expand_scm",(void*)f_10925},
{"f_10944:expand_scm",(void*)f_10944},
{"f_10970:expand_scm",(void*)f_10970},
{"f_11006:expand_scm",(void*)f_11006},
{"f_10483:expand_scm",(void*)f_10483},
{"f_10875:expand_scm",(void*)f_10875},
{"f_10506:expand_scm",(void*)f_10506},
{"f_10845:expand_scm",(void*)f_10845},
{"f_10514:expand_scm",(void*)f_10514},
{"f_10827:expand_scm",(void*)f_10827},
{"f_10522:expand_scm",(void*)f_10522},
{"f_10815:expand_scm",(void*)f_10815},
{"f_10742:expand_scm",(void*)f_10742},
{"f_10740:expand_scm",(void*)f_10740},
{"f_10736:expand_scm",(void*)f_10736},
{"f_10670:expand_scm",(void*)f_10670},
{"f_10702:expand_scm",(void*)f_10702},
{"f_10668:expand_scm",(void*)f_10668},
{"f_10664:expand_scm",(void*)f_10664},
{"f_10590:expand_scm",(void*)f_10590},
{"f_10660:expand_scm",(void*)f_10660},
{"f_10613:expand_scm",(void*)f_10613},
{"f_10656:expand_scm",(void*)f_10656},
{"f_10648:expand_scm",(void*)f_10648},
{"f_10644:expand_scm",(void*)f_10644},
{"f_10624:expand_scm",(void*)f_10624},
{"f_10578:expand_scm",(void*)f_10578},
{"f_10574:expand_scm",(void*)f_10574},
{"f_10518:expand_scm",(void*)f_10518},
{"f_10510:expand_scm",(void*)f_10510},
{"f_10423:expand_scm",(void*)f_10423},
{"f_10427:expand_scm",(void*)f_10427},
{"f_10438:expand_scm",(void*)f_10438},
{"f_10477:expand_scm",(void*)f_10477},
{"f_10469:expand_scm",(void*)f_10469},
{"f_10433:expand_scm",(void*)f_10433},
{"f_10147:expand_scm",(void*)f_10147},
{"f_10228:expand_scm",(void*)f_10228},
{"f_10255:expand_scm",(void*)f_10255},
{"f_10257:expand_scm",(void*)f_10257},
{"f_10417:expand_scm",(void*)f_10417},
{"f_10405:expand_scm",(void*)f_10405},
{"f_10386:expand_scm",(void*)f_10386},
{"f_10368:expand_scm",(void*)f_10368},
{"f_10353:expand_scm",(void*)f_10353},
{"f_10323:expand_scm",(void*)f_10323},
{"f_10304:expand_scm",(void*)f_10304},
{"f_10308:expand_scm",(void*)f_10308},
{"f_10280:expand_scm",(void*)f_10280},
{"f_10205:expand_scm",(void*)f_10205},
{"f_10217:expand_scm",(void*)f_10217},
{"f_10213:expand_scm",(void*)f_10213},
{"f_10084:expand_scm",(void*)f_10084},
{"f_10090:expand_scm",(void*)f_10090},
{"f_10113:expand_scm",(void*)f_10113},
{"f_10103:expand_scm",(void*)f_10103},
{"f_10016:expand_scm",(void*)f_10016},
{"f_10036:expand_scm",(void*)f_10036},
{"f_10031:expand_scm",(void*)f_10031},
{"f_10018:expand_scm",(void*)f_10018},
{"f_9994:expand_scm",(void*)f_9994},
{"f_10001:expand_scm",(void*)f_10001},
{"f_9913:expand_scm",(void*)f_9913},
{"f_9923:expand_scm",(void*)f_9923},
{"f_9926:expand_scm",(void*)f_9926},
{"f_9932:expand_scm",(void*)f_9932},
{"f_9975:expand_scm",(void*)f_9975},
{"f_9979:expand_scm",(void*)f_9979},
{"f_9935:expand_scm",(void*)f_9935},
{"f_9941:expand_scm",(void*)f_9941},
{"f_9824:expand_scm",(void*)f_9824},
{"f_9834:expand_scm",(void*)f_9834},
{"f_9837:expand_scm",(void*)f_9837},
{"f_9900:expand_scm",(void*)f_9900},
{"f_9840:expand_scm",(void*)f_9840},
{"f_9896:expand_scm",(void*)f_9896},
{"f_9843:expand_scm",(void*)f_9843},
{"f_9882:expand_scm",(void*)f_9882},
{"f_9886:expand_scm",(void*)f_9886},
{"f_9846:expand_scm",(void*)f_9846},
{"f_9849:expand_scm",(void*)f_9849},
{"f_9803:expand_scm",(void*)f_9803},
{"f_9810:expand_scm",(void*)f_9810},
{"f_9783:expand_scm",(void*)f_9783},
{"f_9787:expand_scm",(void*)f_9787},
{"f_9780:expand_scm",(void*)f_9780},
{"f_9740:expand_scm",(void*)f_9740},
{"f_9744:expand_scm",(void*)f_9744},
{"f_9716:expand_scm",(void*)f_9716},
{"f_9616:expand_scm",(void*)f_9616},
{"f_9607:expand_scm",(void*)f_9607},
{"f_9526:expand_scm",(void*)f_9526},
{"f_9414:expand_scm",(void*)f_9414},
{"f_9418:expand_scm",(void*)f_9418},
{"f_9421:expand_scm",(void*)f_9421},
{"f_9426:expand_scm",(void*)f_9426},
{"f_9460:expand_scm",(void*)f_9460},
{"f_9424:expand_scm",(void*)f_9424},
{"f_9349:expand_scm",(void*)f_9349},
{"f_9353:expand_scm",(void*)f_9353},
{"f_9363:expand_scm",(void*)f_9363},
{"f_9365:expand_scm",(void*)f_9365},
{"f_9386:expand_scm",(void*)f_9386},
{"f_9356:expand_scm",(void*)f_9356},
{"f_7708:expand_scm",(void*)f_7708},
{"f_7715:expand_scm",(void*)f_7715},
{"f_7729:expand_scm",(void*)f_7729},
{"f_7733:expand_scm",(void*)f_7733},
{"f_7737:expand_scm",(void*)f_7737},
{"f_7742:expand_scm",(void*)f_7742},
{"f_7748:expand_scm",(void*)f_7748},
{"f_7752:expand_scm",(void*)f_7752},
{"f_7756:expand_scm",(void*)f_7756},
{"f_7760:expand_scm",(void*)f_7760},
{"f_7764:expand_scm",(void*)f_7764},
{"f_7769:expand_scm",(void*)f_7769},
{"f_7773:expand_scm",(void*)f_7773},
{"f_7780:expand_scm",(void*)f_7780},
{"f_7785:expand_scm",(void*)f_7785},
{"f_7789:expand_scm",(void*)f_7789},
{"f_7793:expand_scm",(void*)f_7793},
{"f_7797:expand_scm",(void*)f_7797},
{"f_7802:expand_scm",(void*)f_7802},
{"f_9310:expand_scm",(void*)f_9310},
{"f_9320:expand_scm",(void*)f_9320},
{"f_9327:expand_scm",(void*)f_9327},
{"f_9290:expand_scm",(void*)f_9290},
{"f_9297:expand_scm",(void*)f_9297},
{"f_9304:expand_scm",(void*)f_9304},
{"f_9264:expand_scm",(void*)f_9264},
{"f_9242:expand_scm",(void*)f_9242},
{"f_9249:expand_scm",(void*)f_9249},
{"f_9149:expand_scm",(void*)f_9149},
{"f_9191:expand_scm",(void*)f_9191},
{"f_9240:expand_scm",(void*)f_9240},
{"f_9223:expand_scm",(void*)f_9223},
{"f_9202:expand_scm",(void*)f_9202},
{"f_9076:expand_scm",(void*)f_9076},
{"f_9102:expand_scm",(void*)f_9102},
{"f_9147:expand_scm",(void*)f_9147},
{"f_9130:expand_scm",(void*)f_9130},
{"f_8822:expand_scm",(void*)f_8822},
{"f_8869:expand_scm",(void*)f_8869},
{"f_9067:expand_scm",(void*)f_9067},
{"f_9063:expand_scm",(void*)f_9063},
{"f_9030:expand_scm",(void*)f_9030},
{"f_9038:expand_scm",(void*)f_9038},
{"f_8872:expand_scm",(void*)f_8872},
{"f_8878:expand_scm",(void*)f_8878},
{"f_8890:expand_scm",(void*)f_8890},
{"f_8956:expand_scm",(void*)f_8956},
{"f_8971:expand_scm",(void*)f_8971},
{"f_8893:expand_scm",(void*)f_8893},
{"f_8927:expand_scm",(void*)f_8927},
{"f_8896:expand_scm",(void*)f_8896},
{"f_8925:expand_scm",(void*)f_8925},
{"f_8921:expand_scm",(void*)f_8921},
{"f_8917:expand_scm",(void*)f_8917},
{"f_8615:expand_scm",(void*)f_8615},
{"f_8645:expand_scm",(void*)f_8645},
{"f_8745:expand_scm",(void*)f_8745},
{"f_8768:expand_scm",(void*)f_8768},
{"f_8782:expand_scm",(void*)f_8782},
{"f_8786:expand_scm",(void*)f_8786},
{"f_8755:expand_scm",(void*)f_8755},
{"f_8705:expand_scm",(void*)f_8705},
{"f_8709:expand_scm",(void*)f_8709},
{"f_8654:expand_scm",(void*)f_8654},
{"f_8639:expand_scm",(void*)f_8639},
{"f_8327:expand_scm",(void*)f_8327},
{"f_8334:expand_scm",(void*)f_8334},
{"f_8373:expand_scm",(void*)f_8373},
{"f_8383:expand_scm",(void*)f_8383},
{"f_8514:expand_scm",(void*)f_8514},
{"f_8518:expand_scm",(void*)f_8518},
{"f_8447:expand_scm",(void*)f_8447},
{"f_8443:expand_scm",(void*)f_8443},
{"f_8381:expand_scm",(void*)f_8381},
{"f_8377:expand_scm",(void*)f_8377},
{"f_8205:expand_scm",(void*)f_8205},
{"f_8209:expand_scm",(void*)f_8209},
{"f_8281:expand_scm",(void*)f_8281},
{"f_7984:expand_scm",(void*)f_7984},
{"f_8034:expand_scm",(void*)f_8034},
{"f_8148:expand_scm",(void*)f_8148},
{"f_8086:expand_scm",(void*)f_8086},
{"f_8094:expand_scm",(void*)f_8094},
{"f_8090:expand_scm",(void*)f_8090},
{"f_8082:expand_scm",(void*)f_8082},
{"f_7900:expand_scm",(void*)f_7900},
{"f_7907:expand_scm",(void*)f_7907},
{"f_7910:expand_scm",(void*)f_7910},
{"f_7959:expand_scm",(void*)f_7959},
{"f_7955:expand_scm",(void*)f_7955},
{"f_7950:expand_scm",(void*)f_7950},
{"f_7936:expand_scm",(void*)f_7936},
{"f_7948:expand_scm",(void*)f_7948},
{"f_7944:expand_scm",(void*)f_7944},
{"f_7810:expand_scm",(void*)f_7810},
{"f_7854:expand_scm",(void*)f_7854},
{"f_7850:expand_scm",(void*)f_7850},
{"f_7804:expand_scm",(void*)f_7804},
{"f_6796:expand_scm",(void*)f_6796},
{"f_6800:expand_scm",(void*)f_6800},
{"f_6803:expand_scm",(void*)f_6803},
{"f_6806:expand_scm",(void*)f_6806},
{"f_6809:expand_scm",(void*)f_6809},
{"f_7424:expand_scm",(void*)f_7424},
{"f_7427:expand_scm",(void*)f_7427},
{"f_7640:expand_scm",(void*)f_7640},
{"f_7625:expand_scm",(void*)f_7625},
{"f_7430:expand_scm",(void*)f_7430},
{"f_7439:expand_scm",(void*)f_7439},
{"f_7452:expand_scm",(void*)f_7452},
{"f_7470:expand_scm",(void*)f_7470},
{"f_7565:expand_scm",(void*)f_7565},
{"f_7615:expand_scm",(void*)f_7615},
{"f_7587:expand_scm",(void*)f_7587},
{"f_7473:expand_scm",(void*)f_7473},
{"f_7507:expand_scm",(void*)f_7507},
{"f_7563:expand_scm",(void*)f_7563},
{"f_7523:expand_scm",(void*)f_7523},
{"f_7476:expand_scm",(void*)f_7476},
{"f_7505:expand_scm",(void*)f_7505},
{"f_7501:expand_scm",(void*)f_7501},
{"f_7479:expand_scm",(void*)f_7479},
{"f_7497:expand_scm",(void*)f_7497},
{"f_7493:expand_scm",(void*)f_7493},
{"f_7482:expand_scm",(void*)f_7482},
{"f_7433:expand_scm",(void*)f_7433},
{"f_6950:expand_scm",(void*)f_6950},
{"f_6969:expand_scm",(void*)f_6969},
{"f_6978:expand_scm",(void*)f_6978},
{"f_6990:expand_scm",(void*)f_6990},
{"f_7070:expand_scm",(void*)f_7070},
{"f_7177:expand_scm",(void*)f_7177},
{"f_7340:expand_scm",(void*)f_7340},
{"f_7343:expand_scm",(void*)f_7343},
{"f_7346:expand_scm",(void*)f_7346},
{"f_7379:expand_scm",(void*)f_7379},
{"f_7383:expand_scm",(void*)f_7383},
{"f_7348:expand_scm",(void*)f_7348},
{"f_7368:expand_scm",(void*)f_7368},
{"f_7364:expand_scm",(void*)f_7364},
{"f_7356:expand_scm",(void*)f_7356},
{"f_7180:expand_scm",(void*)f_7180},
{"f_7189:expand_scm",(void*)f_7189},
{"f_7334:expand_scm",(void*)f_7334},
{"f_7315:expand_scm",(void*)f_7315},
{"f_7303:expand_scm",(void*)f_7303},
{"f_7282:expand_scm",(void*)f_7282},
{"f_7263:expand_scm",(void*)f_7263},
{"f_7251:expand_scm",(void*)f_7251},
{"f_7210:expand_scm",(void*)f_7210},
{"f_7223:expand_scm",(void*)f_7223},
{"f_7205:expand_scm",(void*)f_7205},
{"f_7073:expand_scm",(void*)f_7073},
{"f_7076:expand_scm",(void*)f_7076},
{"f_7081:expand_scm",(void*)f_7081},
{"f_7167:expand_scm",(void*)f_7167},
{"f_7093:expand_scm",(void*)f_7093},
{"f_7135:expand_scm",(void*)f_7135},
{"f_6993:expand_scm",(void*)f_6993},
{"f_6996:expand_scm",(void*)f_6996},
{"f_7001:expand_scm",(void*)f_7001},
{"f_6863:expand_scm",(void*)f_6863},
{"f_6867:expand_scm",(void*)f_6867},
{"f_6870:expand_scm",(void*)f_6870},
{"f_6948:expand_scm",(void*)f_6948},
{"f_6944:expand_scm",(void*)f_6944},
{"f_6885:expand_scm",(void*)f_6885},
{"f_6891:expand_scm",(void*)f_6891},
{"f_6894:expand_scm",(void*)f_6894},
{"f_6933:expand_scm",(void*)f_6933},
{"f_6927:expand_scm",(void*)f_6927},
{"f_6931:expand_scm",(void*)f_6931},
{"f_6895:expand_scm",(void*)f_6895},
{"f_6899:expand_scm",(void*)f_6899},
{"f_6902:expand_scm",(void*)f_6902},
{"f_6906:expand_scm",(void*)f_6906},
{"f_6909:expand_scm",(void*)f_6909},
{"f_6913:expand_scm",(void*)f_6913},
{"f_6916:expand_scm",(void*)f_6916},
{"f_6920:expand_scm",(void*)f_6920},
{"f_6923:expand_scm",(void*)f_6923},
{"f_6873:expand_scm",(void*)f_6873},
{"f_6820:expand_scm",(void*)f_6820},
{"f_6833:expand_scm",(void*)f_6833},
{"f_6840:expand_scm",(void*)f_6840},
{"f_6811:expand_scm",(void*)f_6811},
{"f_6815:expand_scm",(void*)f_6815},
{"f_6604:expand_scm",(void*)f_6604},
{"f_6606:expand_scm",(void*)f_6606},
{"f_6667:expand_scm",(void*)f_6667},
{"f_6680:expand_scm",(void*)f_6680},
{"f15795:expand_scm",(void*)f15795},
{"f_6683:expand_scm",(void*)f_6683},
{"f_6686:expand_scm",(void*)f_6686},
{"f15788:expand_scm",(void*)f15788},
{"f_6689:expand_scm",(void*)f_6689},
{"f_6758:expand_scm",(void*)f_6758},
{"f_6735:expand_scm",(void*)f_6735},
{"f_6708:expand_scm",(void*)f_6708},
{"f_6715:expand_scm",(void*)f_6715},
{"f_6609:expand_scm",(void*)f_6609},
{"f_6625:expand_scm",(void*)f_6625},
{"f_6654:expand_scm",(void*)f_6654},
{"f_6640:expand_scm",(void*)f_6640},
{"f_6601:expand_scm",(void*)f_6601},
{"f_6139:expand_scm",(void*)f_6139},
{"f_6553:expand_scm",(void*)f_6553},
{"f_6544:expand_scm",(void*)f_6544},
{"f_6552:expand_scm",(void*)f_6552},
{"f_6141:expand_scm",(void*)f_6141},
{"f_6272:expand_scm",(void*)f_6272},
{"f_6277:expand_scm",(void*)f_6277},
{"f_6515:expand_scm",(void*)f_6515},
{"f_6474:expand_scm",(void*)f_6474},
{"f_6478:expand_scm",(void*)f_6478},
{"f_6296:expand_scm",(void*)f_6296},
{"f_6301:expand_scm",(void*)f_6301},
{"f_6320:expand_scm",(void*)f_6320},
{"f_6243:expand_scm",(void*)f_6243},
{"f_6249:expand_scm",(void*)f_6249},
{"f_6187:expand_scm",(void*)f_6187},
{"f_6191:expand_scm",(void*)f_6191},
{"f_6199:expand_scm",(void*)f_6199},
{"f_6219:expand_scm",(void*)f_6219},
{"f_6144:expand_scm",(void*)f_6144},
{"f_6151:expand_scm",(void*)f_6151},
{"f_6156:expand_scm",(void*)f_6156},
{"f_6160:expand_scm",(void*)f_6160},
{"f_6185:expand_scm",(void*)f_6185},
{"f_6174:expand_scm",(void*)f_6174},
{"f_6178:expand_scm",(void*)f_6178},
{"f_6167:expand_scm",(void*)f_6167},
{"f_6103:expand_scm",(void*)f_6103},
{"f_6125:expand_scm",(void*)f_6125},
{"f_6097:expand_scm",(void*)f_6097},
{"f_6086:expand_scm",(void*)f_6086},
{"f_6094:expand_scm",(void*)f_6094},
{"f_6016:expand_scm",(void*)f_6016},
{"f_6079:expand_scm",(void*)f_6079},
{"f_6019:expand_scm",(void*)f_6019},
{"f_6072:expand_scm",(void*)f_6072},
{"f_6045:expand_scm",(void*)f_6045},
{"f_5933:expand_scm",(void*)f_5933},
{"f_6014:expand_scm",(void*)f_6014},
{"f_5936:expand_scm",(void*)f_5936},
{"f_5985:expand_scm",(void*)f_5985},
{"f_5163:expand_scm",(void*)f_5163},
{"f_5881:expand_scm",(void*)f_5881},
{"f_5889:expand_scm",(void*)f_5889},
{"f_5876:expand_scm",(void*)f_5876},
{"f_5165:expand_scm",(void*)f_5165},
{"f_5589:expand_scm",(void*)f_5589},
{"f_5595:expand_scm",(void*)f_5595},
{"f_5859:expand_scm",(void*)f_5859},
{"f_5617:expand_scm",(void*)f_5617},
{"f_5827:expand_scm",(void*)f_5827},
{"f_5801:expand_scm",(void*)f_5801},
{"f_5808:expand_scm",(void*)f_5808},
{"f_5773:expand_scm",(void*)f_5773},
{"f_5761:expand_scm",(void*)f_5761},
{"f_5635:expand_scm",(void*)f_5635},
{"f_5640:expand_scm",(void*)f_5640},
{"f_5653:expand_scm",(void*)f_5653},
{"f_5709:expand_scm",(void*)f_5709},
{"f_5736:expand_scm",(void*)f_5736},
{"f_5687:expand_scm",(void*)f_5687},
{"f_5698:expand_scm",(void*)f_5698},
{"f_5702:expand_scm",(void*)f_5702},
{"f_5412:expand_scm",(void*)f_5412},
{"f_5422:expand_scm",(void*)f_5422},
{"f_5571:expand_scm",(void*)f_5571},
{"f_5567:expand_scm",(void*)f_5567},
{"f_5557:expand_scm",(void*)f_5557},
{"f_5560:expand_scm",(void*)f_5560},
{"f_5468:expand_scm",(void*)f_5468},
{"f_5500:expand_scm",(void*)f_5500},
{"f_5512:expand_scm",(void*)f_5512},
{"f_5520:expand_scm",(void*)f_5520},
{"f_5524:expand_scm",(void*)f_5524},
{"f_5437:expand_scm",(void*)f_5437},
{"f_5453:expand_scm",(void*)f_5453},
{"f_5445:expand_scm",(void*)f_5445},
{"f_5449:expand_scm",(void*)f_5449},
{"f_5420:expand_scm",(void*)f_5420},
{"f_5168:expand_scm",(void*)f_5168},
{"f_5271:expand_scm",(void*)f_5271},
{"f_5404:expand_scm",(void*)f_5404},
{"f_5392:expand_scm",(void*)f_5392},
{"f_5285:expand_scm",(void*)f_5285},
{"f_5390:expand_scm",(void*)f_5390},
{"f_5374:expand_scm",(void*)f_5374},
{"f_5293:expand_scm",(void*)f_5293},
{"f_5368:expand_scm",(void*)f_5368},
{"f_5372:expand_scm",(void*)f_5372},
{"f_5307:expand_scm",(void*)f_5307},
{"f_5311:expand_scm",(void*)f_5311},
{"f_5344:expand_scm",(void*)f_5344},
{"f_5342:expand_scm",(void*)f_5342},
{"f_5338:expand_scm",(void*)f_5338},
{"f_5301:expand_scm",(void*)f_5301},
{"f_5305:expand_scm",(void*)f_5305},
{"f_5297:expand_scm",(void*)f_5297},
{"f_5289:expand_scm",(void*)f_5289},
{"f_5180:expand_scm",(void*)f_5180},
{"f_5261:expand_scm",(void*)f_5261},
{"f_5244:expand_scm",(void*)f_5244},
{"f_5254:expand_scm",(void*)f_5254},
{"f_5199:expand_scm",(void*)f_5199},
{"f_5210:expand_scm",(void*)f_5210},
{"f_5218:expand_scm",(void*)f_5218},
{"f_5206:expand_scm",(void*)f_5206},
{"f_4569:expand_scm",(void*)f_4569},
{"f_4589:expand_scm",(void*)f_4589},
{"f_4592:expand_scm",(void*)f_4592},
{"f_4595:expand_scm",(void*)f_4595},
{"f_4598:expand_scm",(void*)f_4598},
{"f_4601:expand_scm",(void*)f_4601},
{"f_4606:expand_scm",(void*)f_4606},
{"f_4914:expand_scm",(void*)f_4914},
{"f_5090:expand_scm",(void*)f_5090},
{"f_5028:expand_scm",(void*)f_5028},
{"f_5009:expand_scm",(void*)f_5009},
{"f_4963:expand_scm",(void*)f_4963},
{"f_4966:expand_scm",(void*)f_4966},
{"f_4945:expand_scm",(void*)f_4945},
{"f_4929:expand_scm",(void*)f_4929},
{"f_4873:expand_scm",(void*)f_4873},
{"f_4620:expand_scm",(void*)f_4620},
{"f_4866:expand_scm",(void*)f_4866},
{"f_4793:expand_scm",(void*)f_4793},
{"f_4862:expand_scm",(void*)f_4862},
{"f_4846:expand_scm",(void*)f_4846},
{"f_4824:expand_scm",(void*)f_4824},
{"f_4787:expand_scm",(void*)f_4787},
{"f_4791:expand_scm",(void*)f_4791},
{"f_4624:expand_scm",(void*)f_4624},
{"f_4636:expand_scm",(void*)f_4636},
{"f_4739:expand_scm",(void*)f_4739},
{"f_4731:expand_scm",(void*)f_4731},
{"f_4735:expand_scm",(void*)f_4735},
{"f_4708:expand_scm",(void*)f_4708},
{"f_4712:expand_scm",(void*)f_4712},
{"f_4663:expand_scm",(void*)f_4663},
{"f_4683:expand_scm",(void*)f_4683},
{"f_4655:expand_scm",(void*)f_4655},
{"f_4572:expand_scm",(void*)f_4572},
{"f_4526:expand_scm",(void*)f_4526},
{"f_4532:expand_scm",(void*)f_4532},
{"f_4440:expand_scm",(void*)f_4440},
{"f_4473:expand_scm",(void*)f_4473},
{"f_4481:expand_scm",(void*)f_4481},
{"f_4468:expand_scm",(void*)f_4468},
{"f_4442:expand_scm",(void*)f_4442},
{"f_4448:expand_scm",(void*)f_4448},
{"f_4460:expand_scm",(void*)f_4460},
{"f_4454:expand_scm",(void*)f_4454},
{"f_4354:expand_scm",(void*)f_4354},
{"f_4386:expand_scm",(void*)f_4386},
{"f_4389:expand_scm",(void*)f_4389},
{"f_4401:expand_scm",(void*)f_4401},
{"f_4438:expand_scm",(void*)f_4438},
{"f_4428:expand_scm",(void*)f_4428},
{"f_4357:expand_scm",(void*)f_4357},
{"f_4361:expand_scm",(void*)f_4361},
{"f_4370:expand_scm",(void*)f_4370},
{"f_4336:expand_scm",(void*)f_4336},
{"f_4344:expand_scm",(void*)f_4344},
{"f_3835:expand_scm",(void*)f_3835},
{"f_4086:expand_scm",(void*)f_4086},
{"f_4108:expand_scm",(void*)f_4108},
{"f_4326:expand_scm",(void*)f_4326},
{"f_4319:expand_scm",(void*)f_4319},
{"f_4114:expand_scm",(void*)f_4114},
{"f_4216:expand_scm",(void*)f_4216},
{"f_4252:expand_scm",(void*)f_4252},
{"f_4258:expand_scm",(void*)f_4258},
{"f_4270:expand_scm",(void*)f_4270},
{"f_4222:expand_scm",(void*)f_4222},
{"f_4229:expand_scm",(void*)f_4229},
{"f_4123:expand_scm",(void*)f_4123},
{"f_4135:expand_scm",(void*)f_4135},
{"f_4203:expand_scm",(void*)f_4203},
{"f_4193:expand_scm",(void*)f_4193},
{"f_4197:expand_scm",(void*)f_4197},
{"f_4161:expand_scm",(void*)f_4161},
{"f_4157:expand_scm",(void*)f_4157},
{"f_4040:expand_scm",(void*)f_4040},
{"f_4066:expand_scm",(void*)f_4066},
{"f_3838:expand_scm",(void*)f_3838},
{"f_3853:expand_scm",(void*)f_3853},
{"f_3966:expand_scm",(void*)f_3966},
{"f_4028:expand_scm",(void*)f_4028},
{"f_4034:expand_scm",(void*)f_4034},
{"f_3972:expand_scm",(void*)f_3972},
{"f_4020:expand_scm",(void*)f_4020},
{"f_4014:expand_scm",(void*)f_4014},
{"f_4009:expand_scm",(void*)f_4009},
{"f_4003:expand_scm",(void*)f_4003},
{"f_3976:expand_scm",(void*)f_3976},
{"f_3996:expand_scm",(void*)f_3996},
{"f_3992:expand_scm",(void*)f_3992},
{"f_3979:expand_scm",(void*)f_3979},
{"f_3859:expand_scm",(void*)f_3859},
{"f_3865:expand_scm",(void*)f_3865},
{"f_3876:expand_scm",(void*)f_3876},
{"f_3893:expand_scm",(void*)f_3893},
{"f_3912:expand_scm",(void*)f_3912},
{"f_3923:expand_scm",(void*)f_3923},
{"f_3887:expand_scm",(void*)f_3887},
{"f_3851:expand_scm",(void*)f_3851},
{"f_3829:expand_scm",(void*)f_3829},
{"f_3778:expand_scm",(void*)f_3778},
{"f_3790:expand_scm",(void*)f_3790},
{"f_3792:expand_scm",(void*)f_3792},
{"f_3827:expand_scm",(void*)f_3827},
{"f_3819:expand_scm",(void*)f_3819},
{"f_3786:expand_scm",(void*)f_3786},
{"f_3728:expand_scm",(void*)f_3728},
{"f_3732:expand_scm",(void*)f_3732},
{"f_3735:expand_scm",(void*)f_3735},
{"f_3754:expand_scm",(void*)f_3754},
{"f_3744:expand_scm",(void*)f_3744},
{"f_3715:expand_scm",(void*)f_3715},
{"f_3726:expand_scm",(void*)f_3726},
{"f_3719:expand_scm",(void*)f_3719},
{"f_3682:expand_scm",(void*)f_3682},
{"f_3686:expand_scm",(void*)f_3686},
{"f_3689:expand_scm",(void*)f_3689},
{"f_3604:expand_scm",(void*)f_3604},
{"f_3634:expand_scm",(void*)f_3634},
{"f_3660:expand_scm",(void*)f_3660},
{"f_3611:expand_scm",(void*)f_3611},
{"f_3617:expand_scm",(void*)f_3617},
{"f_3667:expand_scm",(void*)f_3667},
{"f_3676:expand_scm",(void*)f_3676},
{"f_3632:expand_scm",(void*)f_3632},
{"f_3476:expand_scm",(void*)f_3476},
{"f_3596:expand_scm",(void*)f_3596},
{"f_3263:expand_scm",(void*)f_3263},
{"f_3421:expand_scm",(void*)f_3421},
{"f_3416:expand_scm",(void*)f_3416},
{"f_3265:expand_scm",(void*)f_3265},
{"f_3271:expand_scm",(void*)f_3271},
{"f_3381:expand_scm",(void*)f_3381},
{"f_3390:expand_scm",(void*)f_3390},
{"f_3361:expand_scm",(void*)f_3361},
{"f_3353:expand_scm",(void*)f_3353},
{"f_3290:expand_scm",(void*)f_3290},
{"f_3293:expand_scm",(void*)f_3293},
{"f_3302:expand_scm",(void*)f_3302},
{"f_3188:expand_scm",(void*)f_3188},
{"f_3195:expand_scm",(void*)f_3195},
{"f_3198:expand_scm",(void*)f_3198},
{"f_3201:expand_scm",(void*)f_3201},
{"f_3204:expand_scm",(void*)f_3204},
{"f_3210:expand_scm",(void*)f_3210},
{"f_3213:expand_scm",(void*)f_3213},
{"f_3170:expand_scm",(void*)f_3170},
{"f_3183:expand_scm",(void*)f_3183},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
