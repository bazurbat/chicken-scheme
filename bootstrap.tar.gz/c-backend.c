/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-28 22:56
   Version 4.1.4 - SVN rev. 15427
   linux-unix-gnu-x86 [ ptables applyhook ]
   compiled 2009-08-13 on x (Linux)
   command line: c-backend.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature debugbuild -scrutinize -types ./types.db -no-lambda-info -local -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[853];
static double C_possibly_force_alignment;


/* from getsize */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2213(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2213(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2209(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2209(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9506)
static void C_ccall f_9506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9509)
static void C_ccall f_9509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9536)
static void C_ccall f_9536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9532)
static void C_ccall f_9532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9515)
static void C_ccall f_9515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9528)
static void C_ccall f_9528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9518)
static void C_ccall f_9518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9521)
static void C_ccall f_9521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9524)
static void C_ccall f_9524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9206)
static void C_ccall f_9206(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9482)
static void C_ccall f_9482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9480)
static void C_ccall f_9480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9468)
static void C_ccall f_9468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9438)
static void C_ccall f_9438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9399)
static void C_ccall f_9399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9386)
static void C_ccall f_9386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9382)
static void C_ccall f_9382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9268)
static void C_ccall f_9268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9215)
static C_word C_fcall f_9215(C_word *a,C_word t0);
C_noret_decl(f_8604)
static void C_ccall f_8604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8715)
static void C_fcall f_8715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8880)
static void C_ccall f_8880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8902)
static void C_fcall f_8902(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9080)
static void C_ccall f_9080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9083)
static void C_ccall f_9083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9089)
static void C_ccall f_9089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9059)
static void C_ccall f_9059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9062)
static void C_ccall f_9062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9065)
static void C_ccall f_9065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9068)
static void C_ccall f_9068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9041)
static void C_ccall f_9041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9044)
static void C_ccall f_9044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9047)
static void C_ccall f_9047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9001)
static void C_ccall f_9001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9004)
static void C_ccall f_9004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9007)
static void C_ccall f_9007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9010)
static void C_ccall f_9010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8983)
static void C_ccall f_8983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8986)
static void C_ccall f_8986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8989)
static void C_ccall f_8989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8959)
static void C_ccall f_8959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8962)
static void C_ccall f_8962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8965)
static void C_ccall f_8965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8968)
static void C_ccall f_8968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8938)
static void C_ccall f_8938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8941)
static void C_ccall f_8941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8944)
static void C_ccall f_8944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8947)
static void C_ccall f_8947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8917)
static void C_ccall f_8917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8920)
static void C_ccall f_8920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8923)
static void C_ccall f_8923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8926)
static void C_ccall f_8926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8850)
static void C_ccall f_8850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8853)
static void C_ccall f_8853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8856)
static void C_ccall f_8856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8859)
static void C_ccall f_8859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8829)
static void C_ccall f_8829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8832)
static void C_ccall f_8832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8835)
static void C_ccall f_8835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8838)
static void C_ccall f_8838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8808)
static void C_ccall f_8808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8811)
static void C_ccall f_8811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8814)
static void C_ccall f_8814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8817)
static void C_ccall f_8817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8784)
static void C_ccall f_8784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8787)
static void C_ccall f_8787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8790)
static void C_ccall f_8790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8793)
static void C_ccall f_8793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8763)
static void C_ccall f_8763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8766)
static void C_ccall f_8766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8769)
static void C_ccall f_8769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8772)
static void C_ccall f_8772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_ccall f_8739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8742)
static void C_ccall f_8742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8745)
static void C_ccall f_8745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8748)
static void C_ccall f_8748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8718)
static void C_ccall f_8718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8721)
static void C_ccall f_8721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8727)
static void C_ccall f_8727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8694)
static void C_ccall f_8694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8697)
static void C_ccall f_8697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8700)
static void C_ccall f_8700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8703)
static void C_ccall f_8703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8673)
static void C_ccall f_8673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8676)
static void C_ccall f_8676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8682)
static void C_ccall f_8682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8606)
static void C_fcall f_8606(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8119)
static void C_ccall f_8119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8149)
static void C_fcall f_8149(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8176)
static void C_fcall f_8176(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8371)
static void C_fcall f_8371(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8380)
static void C_fcall f_8380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8389)
static void C_ccall f_8389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8411)
static void C_fcall f_8411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8488)
static void C_ccall f_8488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8121)
static void C_fcall f_8121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7274)
static void C_ccall f_7274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7351)
static void C_fcall f_7351(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7453)
static void C_fcall f_7453(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7486)
static void C_fcall f_7486(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7582)
static void C_fcall f_7582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7594)
static void C_fcall f_7594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7609)
static void C_ccall f_7609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7649)
static void C_fcall f_7649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7666)
static void C_fcall f_7666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7683)
static void C_fcall f_7683(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7722)
static void C_fcall f_7722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7739)
static void C_fcall f_7739(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7756)
static void C_fcall f_7756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7773)
static void C_fcall f_7773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7790)
static void C_fcall f_7790(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7807)
static void C_fcall f_7807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7824)
static void C_fcall f_7824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7836)
static void C_ccall f_7836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7843)
static void C_ccall f_7843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7853)
static void C_ccall f_7853(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7814)
static void C_ccall f_7814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7797)
static void C_ccall f_7797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7763)
static void C_ccall f_7763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7746)
static void C_ccall f_7746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7729)
static void C_ccall f_7729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7694)
static void C_ccall f_7694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7704)
static void C_ccall f_7704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7702)
static void C_ccall f_7702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7698)
static void C_ccall f_7698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7690)
static void C_ccall f_7690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7677)
static void C_ccall f_7677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7660)
static void C_ccall f_7660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7281)
static void C_fcall f_7281(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7276)
static void C_fcall f_7276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7209)
static void C_ccall f_7209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7213)
static void C_ccall f_7213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7216)
static void C_ccall f_7216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7219)
static void C_ccall f_7219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7222)
static void C_ccall f_7222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7228)
static void C_ccall f_7228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7272)
static void C_ccall f_7272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7231)
static void C_ccall f_7231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7239)
static void C_ccall f_7239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7260)
static void C_ccall f_7260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7243)
static void C_ccall f_7243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7234)
static void C_ccall f_7234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6768)
static void C_fcall f_6768(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6784)
static void C_ccall f_6784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6790)
static void C_ccall f_6790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6796)
static void C_ccall f_6796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7137)
static void C_ccall f_7137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7207)
static void C_ccall f_7207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7143)
static void C_ccall f_7143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7149)
static void C_ccall f_7149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7192)
static void C_ccall f_7192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7200)
static void C_ccall f_7200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7155)
static void C_ccall f_7155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7190)
static void C_ccall f_7190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7161)
static void C_ccall f_7161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7164)
static void C_ccall f_7164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7167)
static void C_ccall f_7167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6798)
static void C_ccall f_6798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6808)
static void C_fcall f_6808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6817)
static void C_fcall f_6817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6829)
static void C_fcall f_6829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6841)
static void C_fcall f_6841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6847)
static void C_ccall f_6847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6881)
static void C_fcall f_6881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6504)
static void C_ccall f_6504(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6510)
static void C_fcall f_6510(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6760)
static void C_ccall f_6760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6538)
static void C_ccall f_6538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6556)
static void C_ccall f_6556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6562)
static void C_ccall f_6562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6749)
static void C_ccall f_6749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6568)
static void C_ccall f_6568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6574)
static void C_ccall f_6574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6580)
static void C_ccall f_6580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6583)
static void C_ccall f_6583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6688)
static void C_ccall f_6688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6720)
static void C_ccall f_6720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6708)
static void C_ccall f_6708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6696)
static void C_ccall f_6696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6704)
static void C_ccall f_6704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6589)
static void C_ccall f_6589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6592)
static void C_ccall f_6592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6629)
static void C_ccall f_6629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6632)
static void C_ccall f_6632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6670)
static void C_ccall f_6670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6666)
static void C_ccall f_6666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6635)
static void C_ccall f_6635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6611)
static void C_ccall f_6611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6595)
static void C_ccall f_6595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6470)
static void C_ccall f_6470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6476)
static void C_fcall f_6476(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6489)
static void C_ccall f_6489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6492)
static void C_ccall f_6492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6431)
static void C_fcall f_6431(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6453)
static void C_ccall f_6453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6412)
static void C_ccall f_6412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6404)
static void C_ccall f_6404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6310)
static void C_fcall f_6310(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6339)
static void C_fcall f_6339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6349)
static void C_ccall f_6349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6228)
static void C_ccall f_6228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6242)
static void C_fcall f_6242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6287)
static void C_ccall f_6287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6261)
static void C_ccall f_6261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6234)
static void C_ccall f_6234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6237)
static void C_ccall f_6237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6191)
static void C_ccall f_6191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6201)
static void C_ccall f_6201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6216)
static void C_ccall f_6216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6219)
static void C_ccall f_6219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_fcall f_5428(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5434)
static void C_fcall f_5434(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5456)
static void C_ccall f_5456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_fcall f_5465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5477)
static void C_ccall f_5477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5483)
static void C_ccall f_5483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5489)
static void C_ccall f_5489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5495)
static void C_ccall f_5495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6118)
static void C_ccall f_6118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6124)
static void C_ccall f_6124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_fcall f_6090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5531)
static void C_fcall f_5531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_fcall f_6050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6052)
static void C_fcall f_6052(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5995)
static void C_fcall f_5995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6007)
static void C_ccall f_6007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6010)
static void C_ccall f_6010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5959)
static void C_fcall f_5959(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5926)
static void C_fcall f_5926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5856)
static void C_ccall f_5856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5865)
static void C_ccall f_5865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5880)
static void C_fcall f_5880(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5847)
static void C_ccall f_5847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5785)
static void C_ccall f_5785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5797)
static void C_ccall f_5797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5570)
static void C_fcall f_5570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5711)
static void C_ccall f_5711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5576)
static void C_ccall f_5576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5585)
static void C_ccall f_5585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5588)
static void C_ccall f_5588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5591)
static void C_ccall f_5591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5594)
static void C_ccall f_5594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5655)
static void C_ccall f_5655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5600)
static void C_ccall f_5600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_ccall f_5603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5606)
static void C_ccall f_5606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_ccall f_5612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_fcall f_5630(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5615)
static void C_ccall f_5615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5166)
static void C_fcall f_5166(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5113)
static void C_ccall f_5113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5105)
static void C_ccall f_5105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5076)
static void C_ccall f_5076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_fcall f_4983(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_fcall f_4989(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5197)
static void C_fcall f_5197(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5337)
static void C_ccall f_5337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5204)
static void C_fcall f_5204(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5293)
static void C_fcall f_5293(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5296)
static void C_ccall f_5296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5260)
static void C_ccall f_5260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5339)
static void C_fcall f_5339(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_fcall f_5354(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5370)
static void C_fcall f_5370(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_fcall f_5416(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_fcall f_4621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_fcall f_4848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_fcall f_4876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_fcall f_4879(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4932)
static void C_fcall f_4932(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_fcall f_4803(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4828)
static void C_ccall f_4828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_fcall f_4777(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4746)
static void C_ccall f_4746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_fcall f_4751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_fcall f_4660(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_ccall f_4672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_fcall f_4624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_fcall f_4637(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_fcall f_4299(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4366)
static void C_fcall f_4366(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4385)
static void C_fcall f_4385(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4394)
static void C_ccall f_4394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_fcall f_4406(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_fcall f_4559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11595)
static void C_ccall f11595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_fcall f_4478(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4466)
static void C_ccall f_4466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_fcall f_4311(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4343)
static void C_fcall f_4343(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_fcall f_4134(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_fcall f_4277(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_fcall f_4155(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_fcall f_4224(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_fcall f_4197(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_fcall f_3971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_fcall f_4044(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_fcall f_3974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_fcall f_2398(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3939)
static void C_fcall f_3939(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_fcall f_2401(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_fcall f_3840(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3784)
static void C_ccall f_3784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3787)
static void C_ccall f_3787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3768)
static void C_ccall f_3768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3772)
static void C_ccall f_3772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11560)
static void C_ccall f11560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_fcall f_3078(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_fcall f_3084(C_word t0,C_word t1) C_noret;
C_noret_decl(f11556)
static void C_ccall f11556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_fcall f_3217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_fcall f_3322(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11551)
static void C_ccall f11551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11547)
static void C_ccall f11547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11542)
static void C_ccall f11542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11537)
static void C_ccall f11537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2750)
static void C_ccall f_2750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_fcall f_2583(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_fcall f_2356(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2286)
static void C_fcall f_2286(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8715)
static void C_fcall trf_8715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8715(t0,t1);}

C_noret_decl(trf_8902)
static void C_fcall trf_8902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8902(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8902(t0,t1);}

C_noret_decl(trf_8606)
static void C_fcall trf_8606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8606(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8606(t0,t1);}

C_noret_decl(trf_8149)
static void C_fcall trf_8149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8149(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8149(t0,t1);}

C_noret_decl(trf_8176)
static void C_fcall trf_8176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8176(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8176(t0,t1);}

C_noret_decl(trf_8371)
static void C_fcall trf_8371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8371(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8371(t0,t1);}

C_noret_decl(trf_8380)
static void C_fcall trf_8380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8380(t0,t1);}

C_noret_decl(trf_8411)
static void C_fcall trf_8411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8411(t0,t1);}

C_noret_decl(trf_8121)
static void C_fcall trf_8121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8121(t0,t1);}

C_noret_decl(trf_7351)
static void C_fcall trf_7351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7351(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7351(t0,t1);}

C_noret_decl(trf_7453)
static void C_fcall trf_7453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7453(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7453(t0,t1);}

C_noret_decl(trf_7486)
static void C_fcall trf_7486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7486(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7486(t0,t1);}

C_noret_decl(trf_7582)
static void C_fcall trf_7582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7582(t0,t1);}

C_noret_decl(trf_7594)
static void C_fcall trf_7594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7594(t0,t1);}

C_noret_decl(trf_7649)
static void C_fcall trf_7649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7649(t0,t1);}

C_noret_decl(trf_7666)
static void C_fcall trf_7666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7666(t0,t1);}

C_noret_decl(trf_7683)
static void C_fcall trf_7683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7683(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7683(t0,t1);}

C_noret_decl(trf_7722)
static void C_fcall trf_7722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7722(t0,t1);}

C_noret_decl(trf_7739)
static void C_fcall trf_7739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7739(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7739(t0,t1);}

C_noret_decl(trf_7756)
static void C_fcall trf_7756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7756(t0,t1);}

C_noret_decl(trf_7773)
static void C_fcall trf_7773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7773(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7773(t0,t1);}

C_noret_decl(trf_7790)
static void C_fcall trf_7790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7790(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7790(t0,t1);}

C_noret_decl(trf_7807)
static void C_fcall trf_7807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7807(t0,t1);}

C_noret_decl(trf_7824)
static void C_fcall trf_7824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7824(t0,t1);}

C_noret_decl(trf_7281)
static void C_fcall trf_7281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7281(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7281(t0,t1,t2);}

C_noret_decl(trf_7276)
static void C_fcall trf_7276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7276(t0,t1);}

C_noret_decl(trf_6768)
static void C_fcall trf_6768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6768(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6768(t0,t1,t2);}

C_noret_decl(trf_6808)
static void C_fcall trf_6808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6808(t0,t1);}

C_noret_decl(trf_6817)
static void C_fcall trf_6817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6817(t0,t1);}

C_noret_decl(trf_6829)
static void C_fcall trf_6829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6829(t0,t1);}

C_noret_decl(trf_6841)
static void C_fcall trf_6841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6841(t0,t1);}

C_noret_decl(trf_6881)
static void C_fcall trf_6881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6881(t0,t1);}

C_noret_decl(trf_6510)
static void C_fcall trf_6510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6510(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6510(t0,t1,t2);}

C_noret_decl(trf_6476)
static void C_fcall trf_6476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6476(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6476(t0,t1,t2);}

C_noret_decl(trf_6431)
static void C_fcall trf_6431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6431(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6431(t0,t1,t2);}

C_noret_decl(trf_6310)
static void C_fcall trf_6310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6310(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6310(t0,t1,t2);}

C_noret_decl(trf_6339)
static void C_fcall trf_6339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6339(t0,t1);}

C_noret_decl(trf_6242)
static void C_fcall trf_6242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6242(t0,t1,t2);}

C_noret_decl(trf_5428)
static void C_fcall trf_5428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5428(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5428(t0,t1);}

C_noret_decl(trf_5434)
static void C_fcall trf_5434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5434(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5434(t0,t1,t2);}

C_noret_decl(trf_5465)
static void C_fcall trf_5465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5465(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5465(t0,t1);}

C_noret_decl(trf_6090)
static void C_fcall trf_6090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6090(t0,t1);}

C_noret_decl(trf_5531)
static void C_fcall trf_5531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5531(t0,t1);}

C_noret_decl(trf_6050)
static void C_fcall trf_6050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6050(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6050(t0,t1);}

C_noret_decl(trf_6052)
static void C_fcall trf_6052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6052(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6052(t0,t1,t2,t3);}

C_noret_decl(trf_5995)
static void C_fcall trf_5995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5995(t0,t1);}

C_noret_decl(trf_5959)
static void C_fcall trf_5959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5959(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5959(t0,t1);}

C_noret_decl(trf_5926)
static void C_fcall trf_5926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5926(t0,t1);}

C_noret_decl(trf_5880)
static void C_fcall trf_5880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5880(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5880(t0,t1);}

C_noret_decl(trf_5570)
static void C_fcall trf_5570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5570(t0,t1);}

C_noret_decl(trf_5630)
static void C_fcall trf_5630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5630(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5630(t0,t1,t2,t3);}

C_noret_decl(trf_5166)
static void C_fcall trf_5166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5166(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5166(t0,t1,t2,t3);}

C_noret_decl(trf_4983)
static void C_fcall trf_4983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4983(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4983(t0,t1);}

C_noret_decl(trf_4989)
static void C_fcall trf_4989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4989(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4989(t0,t1,t2,t3);}

C_noret_decl(trf_5197)
static void C_fcall trf_5197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5197(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5197(t0,t1,t2,t3);}

C_noret_decl(trf_5204)
static void C_fcall trf_5204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5204(t0,t1);}

C_noret_decl(trf_5293)
static void C_fcall trf_5293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5293(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5293(t0,t1);}

C_noret_decl(trf_5339)
static void C_fcall trf_5339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5339(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5339(t0,t1,t2);}

C_noret_decl(trf_5354)
static void C_fcall trf_5354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5354(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5354(t0,t1,t2,t3);}

C_noret_decl(trf_5370)
static void C_fcall trf_5370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5370(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5370(t0,t1);}

C_noret_decl(trf_5416)
static void C_fcall trf_5416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5416(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5416(t0,t1,t2,t3);}

C_noret_decl(trf_4621)
static void C_fcall trf_4621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4621(t0,t1);}

C_noret_decl(trf_4848)
static void C_fcall trf_4848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4848(t0,t1,t2);}

C_noret_decl(trf_4876)
static void C_fcall trf_4876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4876(t0,t1);}

C_noret_decl(trf_4879)
static void C_fcall trf_4879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4879(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4879(t0,t1);}

C_noret_decl(trf_4932)
static void C_fcall trf_4932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4932(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4932(t0,t1);}

C_noret_decl(trf_4803)
static void C_fcall trf_4803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4803(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4803(t0,t1,t2);}

C_noret_decl(trf_4777)
static void C_fcall trf_4777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4777(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4777(t0,t1,t2);}

C_noret_decl(trf_4751)
static void C_fcall trf_4751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4751(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4751(t0,t1,t2);}

C_noret_decl(trf_4660)
static void C_fcall trf_4660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4660(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4660(t0,t1,t2);}

C_noret_decl(trf_4624)
static void C_fcall trf_4624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4624(t0,t1);}

C_noret_decl(trf_4637)
static void C_fcall trf_4637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4637(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4637(t0,t1,t2,t3);}

C_noret_decl(trf_4299)
static void C_fcall trf_4299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4299(t0,t1);}

C_noret_decl(trf_4366)
static void C_fcall trf_4366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4366(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4366(t0,t1,t2);}

C_noret_decl(trf_4385)
static void C_fcall trf_4385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4385(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4385(t0,t1);}

C_noret_decl(trf_4406)
static void C_fcall trf_4406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4406(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4406(t0,t1);}

C_noret_decl(trf_4559)
static void C_fcall trf_4559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4559(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4559(t0,t1,t2);}

C_noret_decl(trf_4478)
static void C_fcall trf_4478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4478(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4478(t0,t1);}

C_noret_decl(trf_4311)
static void C_fcall trf_4311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4311(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4311(t0,t1,t2);}

C_noret_decl(trf_4343)
static void C_fcall trf_4343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4343(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4343(t0,t1,t2);}

C_noret_decl(trf_4134)
static void C_fcall trf_4134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4134(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4134(t0,t1);}

C_noret_decl(trf_4277)
static void C_fcall trf_4277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4277(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4277(t0,t1,t2);}

C_noret_decl(trf_4155)
static void C_fcall trf_4155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4155(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4155(t0,t1,t2,t3);}

C_noret_decl(trf_4224)
static void C_fcall trf_4224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4224(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4224(t0,t1,t2);}

C_noret_decl(trf_4197)
static void C_fcall trf_4197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4197(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4197(t0,t1,t2);}

C_noret_decl(trf_3971)
static void C_fcall trf_3971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3971(t0,t1);}

C_noret_decl(trf_4044)
static void C_fcall trf_4044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4044(t0,t1,t2);}

C_noret_decl(trf_3974)
static void C_fcall trf_3974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3974(t0,t1);}

C_noret_decl(trf_2398)
static void C_fcall trf_2398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2398(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2398(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3939)
static void C_fcall trf_3939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3939(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3939(t0,t1,t2,t3);}

C_noret_decl(trf_2401)
static void C_fcall trf_2401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2401(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2401(t0,t1,t2,t3);}

C_noret_decl(trf_3840)
static void C_fcall trf_3840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3840(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3840(t0,t1,t2,t3);}

C_noret_decl(trf_3078)
static void C_fcall trf_3078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3078(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3078(t0,t1);}

C_noret_decl(trf_3084)
static void C_fcall trf_3084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3084(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3084(t0,t1);}

C_noret_decl(trf_3217)
static void C_fcall trf_3217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3217(t0,t1);}

C_noret_decl(trf_3322)
static void C_fcall trf_3322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3322(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3322(t0,t1);}

C_noret_decl(trf_2583)
static void C_fcall trf_2583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2583(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2583(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2356)
static void C_fcall trf_2356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2356(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2356(t0,t1,t2);}

C_noret_decl(trf_2327)
static void C_fcall trf_2327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2327(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2327(t0,t1,t2);}

C_noret_decl(trf_2286)
static void C_fcall trf_2286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2286(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2286(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2452)){
C_save(t1);
C_rereclaim2(2452*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,853);
lf[0]=C_h_intern(&lf[0],15,"\010compileroutput");
lf[1]=C_h_intern(&lf[1],12,"\010compilergen");
lf[2]=C_h_intern(&lf[2],7,"newline");
lf[3]=C_h_intern(&lf[3],7,"display");
lf[4]=C_h_intern(&lf[4],17,"\010compilergen-list");
lf[5]=C_h_intern(&lf[5],11,"intersperse");
lf[6]=C_h_intern(&lf[6],18,"\010compilerunique-id");
lf[7]=C_h_intern(&lf[7],22,"\010compilergenerate-code");
lf[8]=C_h_intern(&lf[8],13,"\010compilerbomb");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[10]=C_h_intern(&lf[10],17,"lambda-literal-id");
lf[11]=C_h_intern(&lf[11],4,"find");
lf[12]=C_h_intern(&lf[12],14,"\004coreimmediate");
lf[13]=C_h_intern(&lf[13],4,"bool");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[16]=C_h_intern(&lf[16],4,"char");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[18]=C_h_intern(&lf[18],3,"nil");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[20]=C_h_intern(&lf[20],3,"fix");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[22]=C_h_intern(&lf[22],3,"eof");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[25]=C_h_intern(&lf[25],12,"\004coreliteral");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[29]=C_h_intern(&lf[29],2,"if");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[33]=C_h_intern(&lf[33],9,"\004coreproc");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[35]=C_h_intern(&lf[35],9,"\004corebind");
lf[36]=C_h_intern(&lf[36],8,"\004coreref");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[39]=C_h_intern(&lf[39],10,"\004coreunbox");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[42]=C_h_intern(&lf[42],13,"\004coreupdate_i");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[44]=C_h_intern(&lf[44],11,"\004coreupdate");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[48]=C_h_intern(&lf[48],16,"\004coreupdatebox_i");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[51]=C_h_intern(&lf[51],14,"\004coreupdatebox");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[54]=C_h_intern(&lf[54],12,"\004coreclosure");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[59]=C_h_intern(&lf[59],8,"for-each");
lf[60]=C_h_intern(&lf[60],4,"iota");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[62]=C_h_intern(&lf[62],8,"\004corebox");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[65]=C_h_intern(&lf[65],10,"\004corelocal");
lf[66]=C_h_intern(&lf[66],13,"\004coresetlocal");
lf[67]=C_h_intern(&lf[67],11,"\004coreglobal");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[72]=C_h_intern(&lf[72],21,"\010compilerc-ify-string");
lf[73]=C_h_intern(&lf[73],14,"symbol->string");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[78]=C_h_intern(&lf[78],14,"\004coresetglobal");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\012 /* (set! ");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) */,");
lf[81]=C_h_intern(&lf[81],17,"string-translate*");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[83]=C_h_intern(&lf[83],8,"->string");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[88]=C_h_intern(&lf[88],16,"\004coresetglobal_i");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\005 */ =");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\006 */,0,");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[97]=C_h_intern(&lf[97],14,"\004coreundefined");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[99]=C_h_intern(&lf[99],9,"\004corecall");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[105]=C_h_intern(&lf[105],26,"lambda-literal-temporaries");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[107]=C_h_intern(&lf[107],22,"lambda-literal-looping");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\030C_retrieve2_symbol_proc(");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[114]=C_h_intern(&lf[114],13,"string-append");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\032C_retrieve_symbol_proc(lf[");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[130]=C_h_intern(&lf[130],6,"unsafe");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[135]=C_h_intern(&lf[135],28,"\010compilerno-procedure-checks");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[138]=C_h_intern(&lf[138],24,"\010compileremit-trace-info");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[141]=C_h_intern(&lf[141],16,"string-translate");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[146]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[147]=C_h_intern(&lf[147],27,"lambda-literal-closure-size");
lf[148]=C_h_intern(&lf[148],28,"\010compilersource-info->string");
lf[149]=C_h_intern(&lf[149],12,"\004corerecurse");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[153]=C_h_intern(&lf[153],16,"\004coredirect_call");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[155]=C_h_intern(&lf[155],13,"\004corecallunit");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[160]=C_h_intern(&lf[160],11,"\004corereturn");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[163]=C_h_intern(&lf[163],11,"\004coreinline");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[165]=C_h_intern(&lf[165],20,"\004coreinline_allocate");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[168]=C_h_intern(&lf[168],15,"\004coreinline_ref");
lf[169]=C_h_intern(&lf[169],34,"\010compilerforeign-result-conversion");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[171]=C_h_intern(&lf[171],18,"\004coreinline_update");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[174]=C_h_intern(&lf[174],36,"\010compilerforeign-argument-conversion");
lf[175]=C_h_intern(&lf[175],33,"\010compilerforeign-type-declaration");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[177]=C_h_intern(&lf[177],19,"\004coreinline_loc_ref");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[183]=C_h_intern(&lf[183],22,"\004coreinline_loc_update");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[189]=C_h_intern(&lf[189],11,"\004coreswitch");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[194]=C_h_intern(&lf[194],9,"\004corecond");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[198]=C_h_intern(&lf[198],13,"pair-for-each");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[200]=C_h_intern(&lf[200],30,"\010compilerexternal-protos-first");
lf[201]=C_h_intern(&lf[201],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[202]=C_h_intern(&lf[202],22,"foreign-callback-stubs");
lf[203]=C_h_intern(&lf[203],29,"\010compilerforeign-declarations");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[206]=C_h_intern(&lf[206],28,"\010compilertarget-include-file");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[208]=C_h_intern(&lf[208],18,"\010compilerunit-name");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[210]=C_h_intern(&lf[210],19,"\010compilerused-units");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[212]=C_h_intern(&lf[212],27,"\010compilercompiler-arguments");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[218]=C_h_intern(&lf[218],18,"string-intersperse");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[222]=C_h_intern(&lf[222],7,"\003sysmap");
lf[223]=C_h_intern(&lf[223],12,"string-split");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[225]=C_h_intern(&lf[225],15,"chicken-version");
lf[226]=C_h_intern(&lf[226],18,"\003sysdecode-seconds");
lf[227]=C_h_intern(&lf[227],15,"current-seconds");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[232]=C_h_intern(&lf[232],23,"\003syslambda-info->string");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[242]=C_h_intern(&lf[242],9,"make-list");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[246]=C_h_intern(&lf[246],4,"none");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[257]=C_h_intern(&lf[257],8,"toplevel");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[260]=C_h_intern(&lf[260],27,"\010compileremit-unsafe-marker");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[273]=C_h_intern(&lf[273],21,"small-parameter-limit");
lf[274]=C_h_intern(&lf[274],11,"lset-adjoin");
lf[275]=C_h_intern(&lf[275],1,"=");
lf[276]=C_h_intern(&lf[276],32,"lambda-literal-callee-signatures");
lf[277]=C_h_intern(&lf[277],24,"lambda-literal-allocated");
lf[278]=C_h_intern(&lf[278],21,"lambda-literal-direct");
lf[279]=C_h_intern(&lf[279],33,"lambda-literal-rest-argument-mode");
lf[280]=C_h_intern(&lf[280],28,"lambda-literal-rest-argument");
lf[281]=C_h_intern(&lf[281],27,"\010compilermake-variable-list");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[283]=C_h_intern(&lf[283],27,"lambda-literal-customizable");
lf[284]=C_h_intern(&lf[284],29,"lambda-literal-argument-count");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[291]=C_h_intern(&lf[291],27,"\010compilermake-argument-list");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[331]=C_h_intern(&lf[331],6,"vector");
lf[332]=C_h_intern(&lf[332],23,"lambda-literal-external");
lf[333]=C_h_intern(&lf[333],14,"\003syscopy-bytes");
lf[334]=C_h_intern(&lf[334],11,"make-string");
lf[335]=C_h_intern(&lf[335],6,"modulo");
lf[336]=C_h_intern(&lf[336],3,"fx/");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[339]=C_h_intern(&lf[339],19,"\003sysundefined-value");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[350]=C_h_intern(&lf[350],23,"\010compilerencode-literal");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[353]=C_h_intern(&lf[353],32,"\010compilerblock-variable-literal\077");
lf[354]=C_h_intern(&lf[354],20,"\010compilerbig-fixnum\077");
lf[355]=C_h_intern(&lf[355],17,"get-output-string");
lf[356]=C_h_intern(&lf[356],19,"\003syswrite-char/port");
lf[357]=C_h_intern(&lf[357],5,"write");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[359]=C_h_intern(&lf[359],18,"open-output-string");
lf[360]=C_h_intern(&lf[360],25,"\010compilerwords-per-flonum");
lf[361]=C_h_intern(&lf[361],6,"reduce");
lf[362]=C_h_intern(&lf[362],1,"+");
lf[363]=C_h_intern(&lf[363],12,"vector->list");
lf[364]=C_h_intern(&lf[364],14,"\010compilerwords");
lf[365]=C_h_intern(&lf[365],15,"\003sysbytevector\077");
lf[366]=C_h_intern(&lf[366],19,"\010compilerimmediate\077");
lf[367]=C_h_intern(&lf[367],19,"lambda-literal-body");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[380]=C_h_intern(&lf[380],4,"list");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[419]=C_h_intern(&lf[419],26,"\010compilertarget-stack-size");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[422]=C_h_intern(&lf[422],30,"\010compilertarget-heap-shrinkage");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[424]=C_h_intern(&lf[424],27,"\010compilertarget-heap-growth");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[426]=C_h_intern(&lf[426],33,"\010compilertarget-initial-heap-size");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[429]=C_h_intern(&lf[429],25,"\010compilertarget-heap-size");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[433]=C_h_intern(&lf[433],40,"\010compilerdisable-stack-overflow-checking");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[439]=C_h_intern(&lf[439],4,"fold");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[442]=C_h_intern(&lf[442],28,"\010compilerinsert-timer-checks");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[447]=C_h_intern(&lf[447],23,"\010compilerno-argc-checks");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[484]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[494]=C_h_intern(&lf[494],16,"\010compilercleanup");
lf[495]=C_h_intern(&lf[495],18,"\010compilerdebugging");
lf[496]=C_h_intern(&lf[496],1,"o");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[502]=C_h_intern(&lf[502],18,"\010compilerreal-name");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[504]=C_h_intern(&lf[504],25,"emit-procedure-table-info");
lf[505]=C_h_intern(&lf[505],31,"generate-foreign-callback-stubs");
lf[506]=C_h_intern(&lf[506],31,"\010compilergenerate-foreign-stubs");
lf[507]=C_h_intern(&lf[507],29,"\010compilerforeign-lambda-stubs");
lf[508]=C_h_intern(&lf[508],36,"\010compilergenerate-external-variables");
lf[509]=C_h_intern(&lf[509],27,"\010compilerexternal-variables");
lf[510]=C_h_intern(&lf[510],1,"p");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[528]=C_h_intern(&lf[528],29,"\010compilerstring->c-identifier");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[532]=C_h_intern(&lf[532],11,"string-copy");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[534]=C_h_intern(&lf[534],13,"list-tabulate");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[537]=C_h_intern(&lf[537],41,"\010compilergenerate-foreign-callback-header");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[550]=C_h_intern(&lf[550],4,"void");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[569]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[571]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[574]=C_h_intern(&lf[574],21,"foreign-stub-callback");
lf[575]=C_h_intern(&lf[575],16,"foreign-stub-cps");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[577]=C_h_intern(&lf[577],27,"foreign-stub-argument-names");
lf[578]=C_h_intern(&lf[578],17,"foreign-stub-body");
lf[579]=C_h_intern(&lf[579],17,"foreign-stub-name");
lf[580]=C_h_intern(&lf[580],24,"foreign-stub-return-type");
lf[581]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[582]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[583]=C_h_intern(&lf[583],27,"foreign-stub-argument-types");
lf[584]=C_h_intern(&lf[584],19,"\010compilerreal-name2");
lf[585]=C_h_intern(&lf[585],15,"foreign-stub-id");
lf[586]=C_h_intern(&lf[586],5,"float");
lf[587]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[588]=C_h_intern(&lf[588],8,"c-string");
lf[589]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[590]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[591]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[592]=C_h_intern(&lf[592],16,"nonnull-c-string");
lf[593]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[594]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[595]=C_h_intern(&lf[595],3,"ref");
lf[596]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[597]=C_h_intern(&lf[597],5,"const");
lf[598]=C_h_intern(&lf[598],7,"pointer");
lf[599]=C_h_intern(&lf[599],9,"c-pointer");
lf[600]=C_h_intern(&lf[600],15,"nonnull-pointer");
lf[601]=C_h_intern(&lf[601],17,"nonnull-c-pointer");
lf[602]=C_h_intern(&lf[602],8,"function");
lf[603]=C_h_intern(&lf[603],8,"instance");
lf[604]=C_h_intern(&lf[604],16,"nonnull-instance");
lf[605]=C_h_intern(&lf[605],12,"instance-ref");
lf[606]=C_h_intern(&lf[606],18,"\003syshash-table-ref");
lf[607]=C_h_intern(&lf[607],27,"\010compilerforeign-type-table");
lf[608]=C_h_intern(&lf[608],17,"nonnull-c-string*");
lf[609]=C_h_intern(&lf[609],25,"nonnull-unsigned-c-string");
lf[610]=C_h_intern(&lf[610],26,"nonnull-unsigned-c-string*");
lf[611]=C_h_intern(&lf[611],6,"symbol");
lf[612]=C_h_intern(&lf[612],9,"c-string*");
lf[613]=C_h_intern(&lf[613],17,"unsigned-c-string");
lf[614]=C_h_intern(&lf[614],18,"unsigned-c-string*");
lf[615]=C_h_intern(&lf[615],6,"double");
lf[616]=C_h_intern(&lf[616],16,"unsigned-integer");
lf[617]=C_h_intern(&lf[617],18,"unsigned-integer32");
lf[618]=C_h_intern(&lf[618],4,"long");
lf[619]=C_h_intern(&lf[619],7,"integer");
lf[620]=C_h_intern(&lf[620],9,"integer32");
lf[621]=C_h_intern(&lf[621],13,"unsigned-long");
lf[622]=C_h_intern(&lf[622],6,"number");
lf[623]=C_h_intern(&lf[623],9,"integer64");
lf[624]=C_h_intern(&lf[624],13,"c-string-list");
lf[625]=C_h_intern(&lf[625],14,"c-string-list*");
lf[626]=C_h_intern(&lf[626],3,"int");
lf[627]=C_h_intern(&lf[627],5,"int32");
lf[628]=C_h_intern(&lf[628],5,"short");
lf[629]=C_h_intern(&lf[629],14,"unsigned-short");
lf[630]=C_h_intern(&lf[630],13,"scheme-object");
lf[631]=C_h_intern(&lf[631],13,"unsigned-char");
lf[632]=C_h_intern(&lf[632],12,"unsigned-int");
lf[633]=C_h_intern(&lf[633],14,"unsigned-int32");
lf[634]=C_h_intern(&lf[634],4,"byte");
lf[635]=C_h_intern(&lf[635],13,"unsigned-byte");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[651]=C_h_intern(&lf[651],36,"foreign-callback-stub-argument-types");
lf[652]=C_h_intern(&lf[652],33,"foreign-callback-stub-return-type");
lf[653]=C_h_intern(&lf[653],24,"foreign-callback-stub-id");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[656]=C_h_intern(&lf[656],32,"foreign-callback-stub-qualifiers");
lf[657]=C_h_intern(&lf[657],26,"foreign-callback-stub-name");
lf[658]=C_h_intern(&lf[658],4,"quit");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[660]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[661]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[663]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[664]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[666]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[667]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[669]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[670]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[672]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[673]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[675]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[676]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[678]=C_h_intern(&lf[678],11,"byte-vector");
lf[679]=C_h_intern(&lf[679],19,"nonnull-byte-vector");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[681]=C_h_intern(&lf[681],4,"blob");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[683]=C_h_intern(&lf[683],9,"u16vector");
lf[684]=C_h_intern(&lf[684],17,"nonnull-u16vector");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[686]=C_h_intern(&lf[686],8,"s8vector");
lf[687]=C_h_intern(&lf[687],16,"nonnull-s8vector");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[689]=C_h_intern(&lf[689],9,"u32vector");
lf[690]=C_h_intern(&lf[690],17,"nonnull-u32vector");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[692]=C_h_intern(&lf[692],9,"s16vector");
lf[693]=C_h_intern(&lf[693],17,"nonnull-s16vector");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[695]=C_h_intern(&lf[695],9,"s32vector");
lf[696]=C_h_intern(&lf[696],17,"nonnull-s32vector");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[698]=C_h_intern(&lf[698],9,"f32vector");
lf[699]=C_h_intern(&lf[699],17,"nonnull-f32vector");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[701]=C_h_intern(&lf[701],9,"f64vector");
lf[702]=C_h_intern(&lf[702],17,"nonnull-f64vector");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[705]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[710]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[711]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[712]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[713]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[727]=C_h_intern(&lf[727],3,"...");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[732]=C_h_intern(&lf[732],9,"\003syserror");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[734]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[735]=C_h_intern(&lf[735],4,"enum");
lf[736]=C_h_intern(&lf[736],5,"union");
lf[737]=C_h_intern(&lf[737],6,"struct");
lf[738]=C_h_intern(&lf[738],8,"template");
lf[739]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c"
"-pointer\376\377\016");
lf[740]=C_h_intern(&lf[740],12,"nonnull-blob");
lf[741]=C_h_intern(&lf[741],8,"u8vector");
lf[742]=C_h_intern(&lf[742],16,"nonnull-u8vector");
lf[743]=C_h_intern(&lf[743],14,"scheme-pointer");
lf[744]=C_h_intern(&lf[744],22,"nonnull-scheme-pointer");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\012C_flonum(&");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000\012C_number(&");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\023C_a_double_to_num(&");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000\027C_unsigned_int_to_num(&");
lf[816]=C_decode_literal(C_heaptop,"\376B\000\000\017C_long_to_num(&");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\030C_unsigned_long_to_num(&");
lf[818]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[819]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[821]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[822]=C_decode_literal(C_heaptop,"\376B\000\000\011,(void*)&");
lf[823]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[824]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[825]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[826]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[827]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[828]=C_decode_literal(C_heaptop,"\376B\000\000\011,(void*)&");
lf[829]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[830]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[831]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[832]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[833]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[834]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[835]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[836]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[837]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[838]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[839]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[840]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[841]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[842]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[843]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[844]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[845]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[846]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[847]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid literal - cannot encode");
lf[848]=C_h_intern(&lf[848],17,"\003sysstring-append");
lf[849]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[850]=C_h_intern(&lf[850],5,"cons*");
lf[851]=C_h_intern(&lf[851],6,"random");
lf[852]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
C_register_lf2(lf,853,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2262,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2260 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2265,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2263 in k2260 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2266 in k2263 in k2260 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2277,2,t0,t1);}
t2=C_set_block_item(lf[0] /* output */,0,C_SCHEME_FALSE);
t3=C_mutate((C_word*)lf[1]+1 /* (set! gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2280,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[4]+1 /* (set! gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2317,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9506,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t6);}

/* k9504 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9509,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[852],t1);}

/* k9507 in k9504 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9532,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9536,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 57   random");
((C_proc3)C_retrieve_symbol_proc(lf[851]))(3,*((C_word*)lf[851]+1),t4,C_fix(16777216));}

/* k9534 in k9507 in k9504 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("number->string");
C_number_to_string(4,0,((C_word*)t0)[2],t1,C_fix(16));}

/* k9530 in k9507 in k9504 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9510 in k9507 in k9504 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(95),((C_word*)t0)[2]);}

/* k9513 in k9510 in k9507 in k9504 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9528,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 57   current-seconds");
((C_proc2)C_retrieve_symbol_proc(lf[227]))(2,*((C_word*)lf[227]+1),t3);}

/* k9526 in k9513 in k9510 in k9507 in k9504 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9516 in k9513 in k9510 in k9507 in k9504 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(95),((C_word*)t0)[2]);}

/* k9519 in k9516 in k9513 in k9510 in k9507 in k9504 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9524,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),t2,((C_word*)t0)[2]);}

/* k9522 in k9519 in k9516 in k9513 in k9510 in k9507 in k9504 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 56   string->c-identifier");
((C_proc3)C_retrieve_symbol_proc(lf[528]))(3,*((C_word*)lf[528]+1),((C_word*)t0)[2],t1);}

/* k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1 /* (set! unique-id ...) */,t1);
t3=C_mutate((C_word*)lf[7]+1 /* (set! generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2353,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[504]+1 /* (set! emit-procedure-table-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6224,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[494]+1 /* (set! cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6301,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[281]+1 /* (set! make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6390,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[291]+1 /* (set! make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6406,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[508]+1 /* (set! generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6422,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[201]+1 /* (set! generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6470,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[506]+1 /* (set! generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6504,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[505]+1 /* (set! generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6762,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[537]+1 /* (set! generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7209,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[175]+1 /* (set! foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7274,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[174]+1 /* (set! foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8119,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[169]+1 /* (set! foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8604,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[350]+1 /* (set! encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9206,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9206(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9206,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9215,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9268,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t5)){
t6=t1;
t7=(C_word)C_a_i_string(&a,1,C_make_character(254));
C_trace("c-backend.scm: 1362 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t6,t7,lf[835]);}
else{
t6=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t6)){
t7=t1;
t8=(C_word)C_a_i_string(&a,1,C_make_character(254));
C_trace("c-backend.scm: 1362 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t7,t8,lf[836]);}
else{
if(C_truep((C_word)C_charp(t2))){
t7=(C_word)C_fix((C_word)C_character_code(t2));
t8=f_9215(C_a_i(&a,4),t7);
C_trace("c-backend.scm: 1366 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t4,lf[837],t8);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t7=t1;
t8=(C_word)C_a_i_string(&a,1,C_make_character(254));
C_trace("c-backend.scm: 1362 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t7,t8,lf[838]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t7=t1;
t8=(C_word)C_a_i_string(&a,1,C_make_character(254));
C_trace("c-backend.scm: 1362 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t7,t8,lf[839]);}
else{
t7=C_retrieve(lf[339]);
t8=(C_word)C_eqp(t7,t2);
if(C_truep(t8)){
t9=t1;
t10=(C_word)C_a_i_string(&a,1,C_make_character(254));
C_trace("c-backend.scm: 1362 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t9,t10,lf[840]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9386,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 1371 big-fixnum?");
((C_proc3)C_retrieve_symbol_proc(lf[354]))(3,*((C_word*)lf[354]+1),t9,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9399,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1380 number->string");
C_number_to_string(3,0,t9,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_i_string_length(t9);
t11=f_9215(C_a_i(&a,4),t10);
C_trace("c-backend.scm: 1383 string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),t4,lf[846],t11,t9);}
else{
if(C_truep((C_word)C_immp(t2))){
C_trace("c-backend.scm: 1388 bomb");
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t4,lf[847],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9438,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=(C_word)stub2209(C_SCHEME_UNDEFINED,t10);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,1,t12);
t14=t2;
t15=(C_word)stub2213(C_SCHEME_UNDEFINED,t14);
t16=f_9215(C_a_i(&a,4),t15);
C_trace("c-backend.scm: 1391 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t9,t13,t16);}
else{
t9=t2;
t10=(C_word)stub2213(C_SCHEME_UNDEFINED,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9468,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t12=t2;
t13=(C_word)stub2209(C_SCHEME_UNDEFINED,t12);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_9215(C_a_i(&a,4),t10);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9480,a[2]=t16,a[3]=t15,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9482,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1401 list-tabulate");
((C_proc4)C_retrieve_symbol_proc(lf[534]))(4,*((C_word*)lf[534]+1),t17,t10,t18);}}}}}}}}}}}}

/* a9481 in ##compiler#encode-literal in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9482,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
C_trace("c-backend.scm: 1401 encode-literal");
((C_proc3)C_retrieve_symbol_proc(lf[350]))(3,*((C_word*)lf[350]+1),t1,t3);}

/* k9478 in ##compiler#encode-literal in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1398 cons*");
((C_proc5)C_retrieve_symbol_proc(lf[850]))(5,*((C_word*)lf[850]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9466 in ##compiler#encode-literal in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1397 string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[218]))(4,*((C_word*)lf[218]+1),((C_word*)t0)[2],t1,lf[849]);}

/* k9436 in ##compiler#encode-literal in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1390 ##sys#string-append");
((C_proc4)C_retrieve_symbol_proc(lf[848]))(4,*((C_word*)lf[848]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9397 in ##compiler#encode-literal in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1380 string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),((C_word*)t0)[2],lf[844],t1,lf[845]);}

/* k9384 in ##compiler#encode-literal in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9386,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9382,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1378 number->string");
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
C_trace("c-backend.scm: 1372 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),((C_word*)t0)[3],lf[843],t13);}}

/* k9380 in k9384 in ##compiler#encode-literal in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1378 string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),((C_word*)t0)[2],lf[841],t1,lf[842]);}

/* k9266 in ##compiler#encode-literal in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9268,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
C_trace("c-backend.scm: 1362 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static C_word C_fcall f_9215(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8604,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8606,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[16]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[631]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[800]);}
else{
t8=(C_word)C_eqp(t5,lf[626]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[627]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[801]);}
else{
t10=(C_word)C_eqp(t5,lf[632]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[633]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[802]);}
else{
t12=(C_word)C_eqp(t5,lf[628]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[803]);}
else{
t13=(C_word)C_eqp(t5,lf[629]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[804]);}
else{
t14=(C_word)C_eqp(t5,lf[634]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[805]);}
else{
t15=(C_word)C_eqp(t5,lf[635]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[806]);}
else{
t16=(C_word)C_eqp(t5,lf[586]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[615]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8673,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t18);}
else{
t18=(C_word)C_eqp(t5,lf[622]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8694,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t19);}
else{
t19=(C_word)C_eqp(t5,lf[592]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8715,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_8715(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[588]);
if(C_truep(t21)){
t22=t20;
f_8715(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[601]);
if(C_truep(t22)){
t23=t20;
f_8715(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[612]);
if(C_truep(t23)){
t24=t20;
f_8715(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t24)){
t25=t20;
f_8715(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[613]);
if(C_truep(t25)){
t26=t20;
f_8715(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[614]);
if(C_truep(t26)){
t27=t20;
f_8715(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t27)){
t28=t20;
f_8715(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[610]);
if(C_truep(t28)){
t29=t20;
f_8715(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[611]);
if(C_truep(t29)){
t30=t20;
f_8715(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[624]);
t31=t20;
f_8715(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[625])));}}}}}}}}}}}}}}}}}}}}

/* k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_8715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8715,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8718,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[599]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8739,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[619]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[620]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8763,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[623]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8784,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[616]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[617]));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8808,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t8);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[618]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8829,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[621]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8850,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t10);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[13]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[818]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[550]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[630]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[819]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 1315 ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[606]))(4,*((C_word*)lf[606]+1),t13,C_retrieve(lf[607]),((C_word*)t0)[3]);}
else{
t14=t13;
f_8880(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8880,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(0));
C_trace("c-backend.scm: 1317 foreign-result-conversion");
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),((C_word*)t0)[5],t2,((C_word*)t0)[4]);}
else{
t2=t1;
C_trace("c-backend.scm: 1317 foreign-result-conversion");
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),((C_word*)t0)[5],t2,((C_word*)t0)[4]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8902(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8902(t3,C_SCHEME_FALSE);}}}

/* k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_8902(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8902,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[600]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[601]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t5);}
else{
t5=(C_word)C_eqp(t2,lf[595]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t6);}
else{
t6=(C_word)C_eqp(t2,lf[603]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t7);}
else{
t7=(C_word)C_eqp(t2,lf[604]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t8);}
else{
t8=(C_word)C_eqp(t2,lf[605]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t9);}
else{
t9=(C_word)C_eqp(t2,lf[597]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(((C_word*)t0)[5]);
C_trace("c-backend.scm: 1330 foreign-result-conversion");
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),((C_word*)t0)[4],t10,((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(t2,lf[598]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[599]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9038,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t12);}
else{
t12=(C_word)C_eqp(t2,lf[602]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t13);}
else{
t13=(C_word)C_eqp(t2,lf[735]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t14);}
else{
C_trace("c-backend.scm: 1335 err");
t14=((C_word*)t0)[2];
f_8606(t14,((C_word*)t0)[4]);}}}}}}}}}}
else{
C_trace("c-backend.scm: 1336 err");
t2=((C_word*)t0)[2];
f_8606(t2,((C_word*)t0)[4]);}}

/* k9078 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9083,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[834],t1);}

/* k9081 in k9078 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9084 in k9081 in k9078 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9087 in k9084 in k9081 in k9078 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9057 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9062,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[833],t1);}

/* k9060 in k9057 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9063 in k9060 in k9057 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[832],((C_word*)t0)[2]);}

/* k9066 in k9063 in k9060 in k9057 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9036 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9041,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[831],t1);}

/* k9039 in k9036 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9042 in k9039 in k9036 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[830],((C_word*)t0)[2]);}

/* k9045 in k9042 in k9039 in k9036 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8999 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9004,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[829],t1);}

/* k9002 in k8999 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9007,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9005 in k9002 in k8999 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[828],((C_word*)t0)[2]);}

/* k9008 in k9005 in k9002 in k8999 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_9010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8978 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8983,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[827],t1);}

/* k8981 in k8978 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8986,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8984 in k8981 in k8978 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[826],((C_word*)t0)[2]);}

/* k8987 in k8984 in k8981 in k8978 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8957 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8962,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[825],t1);}

/* k8960 in k8957 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8963 in k8960 in k8957 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[824],((C_word*)t0)[2]);}

/* k8966 in k8963 in k8960 in k8957 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8936 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8941,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[823],t1);}

/* k8939 in k8936 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8942 in k8939 in k8936 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[822],((C_word*)t0)[2]);}

/* k8945 in k8942 in k8939 in k8936 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8915 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8920,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[821],t1);}

/* k8918 in k8915 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8921 in k8918 in k8915 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[820],((C_word*)t0)[2]);}

/* k8924 in k8921 in k8918 in k8915 in k8900 in k8878 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8848 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8853,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[817],t1);}

/* k8851 in k8848 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8854 in k8851 in k8848 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k8857 in k8854 in k8851 in k8848 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8827 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8832,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[816],t1);}

/* k8830 in k8827 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8833 in k8830 in k8827 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k8836 in k8833 in k8830 in k8827 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8806 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8811,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[815],t1);}

/* k8809 in k8806 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8812 in k8809 in k8806 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k8815 in k8812 in k8809 in k8806 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8782 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8787,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[814],t1);}

/* k8785 in k8782 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8788 in k8785 in k8782 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k8791 in k8788 in k8785 in k8782 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8761 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8766,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[813],t1);}

/* k8764 in k8761 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8767 in k8764 in k8761 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k8770 in k8767 in k8764 in k8761 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8737 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8742,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[812],t1);}

/* k8740 in k8737 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8743 in k8740 in k8737 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[811],((C_word*)t0)[2]);}

/* k8746 in k8743 in k8740 in k8737 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8716 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8721,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[810],t1);}

/* k8719 in k8716 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8722 in k8719 in k8716 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[809],((C_word*)t0)[2]);}

/* k8725 in k8722 in k8719 in k8716 in k8713 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8692 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8697,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[808],t1);}

/* k8695 in k8692 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8698 in k8695 in k8692 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k8701 in k8698 in k8695 in k8692 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8671 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8676,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[807],t1);}

/* k8674 in k8671 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8679,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8677 in k8674 in k8671 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k8680 in k8677 in k8674 in k8671 in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-result-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_8606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8606,NULL,2,t0,t1);}
C_trace("c-backend.scm: 1291 quit");
((C_proc4)C_retrieve_symbol_proc(lf[658]))(4,*((C_word*)lf[658]+1),t1,lf[799],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8119,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8121,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[630]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[746]);}
else{
t6=(C_word)C_eqp(t4,lf[16]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[631]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[747]);}
else{
t8=(C_word)C_eqp(t4,lf[634]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8149,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_8149(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[626]);
if(C_truep(t10)){
t11=t9;
f_8149(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[632]);
if(C_truep(t11)){
t12=t9;
f_8149(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[633]);
t13=t9;
f_8149(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[635])));}}}}}}

/* k8147 in ##compiler#foreign-argument-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_8149(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8149,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[748]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[628]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[749]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[629]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[750]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[621]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[751]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[615]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_8176(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[622]);
t8=t6;
f_8176(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[586])));}}}}}}

/* k8174 in k8147 in ##compiler#foreign-argument-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_8176(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8176,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[752]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[619]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[620]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[753]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[623]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[754]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[618]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[755]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[616]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[617]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[756]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[598]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[757]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[600]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[758]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[743]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[759]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[744]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[760]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[599]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[761]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[601]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[762]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[681]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[763]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[740]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[764]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[678]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[765]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[679]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[766]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[741]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[767]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[742]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[768]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[683]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[769]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[684]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[770]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[689]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[771]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[690]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[772]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[686]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[773]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[687]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[774]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[692]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[775]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[693]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[776]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[695]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[777]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[696]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[778]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[698]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[779]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[699]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[780]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[701]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[781]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[702]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[782]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_8371(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[612]);
if(C_truep(t36)){
t37=t35;
f_8371(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[613]);
t38=t35;
f_8371(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[614])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k8369 in k8174 in k8147 in ##compiler#foreign-argument-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_8371(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8371,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[783]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8380(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t4)){
t5=t3;
f_8380(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[609]);
if(C_truep(t5)){
t6=t3;
f_8380(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[610]);
t7=t3;
f_8380(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[611])));}}}}}

/* k8378 in k8369 in k8174 in k8147 in ##compiler#foreign-argument-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_8380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8380,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[784]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[13]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[785]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 1264 ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[606]))(4,*((C_word*)lf[606]+1),t3,C_retrieve(lf[607]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8389(2,t4,C_SCHEME_FALSE);}}}}

/* k8387 in k8378 in k8369 in k8174 in k8147 in ##compiler#foreign-argument-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8389,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(0));
C_trace("c-backend.scm: 1266 foreign-argument-conversion");
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),((C_word*)t0)[4],t2);}
else{
t2=t1;
C_trace("c-backend.scm: 1266 foreign-argument-conversion");
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),((C_word*)t0)[4],t2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8411(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8411(t3,C_SCHEME_FALSE);}}}

/* k8409 in k8387 in k8378 in k8369 in k8174 in k8147 in ##compiler#foreign-argument-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_8411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8411,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[786]);}
else{
t4=(C_word)C_eqp(t2,lf[600]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[787]);}
else{
t5=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[788]);}
else{
t6=(C_word)C_eqp(t2,lf[601]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[789]);}
else{
t7=(C_word)C_eqp(t2,lf[603]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[790]);}
else{
t8=(C_word)C_eqp(t2,lf[604]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[791]);}
else{
t9=(C_word)C_eqp(t2,lf[602]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[792]);}
else{
t10=(C_word)C_eqp(t2,lf[597]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1277 foreign-argument-conversion");
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),((C_word*)t0)[3],t11);}
else{
t11=(C_word)C_eqp(t2,lf[735]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[793]);}
else{
t12=(C_word)C_eqp(t2,lf[595]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8488,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1280 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t13,t14,lf[796]);}
else{
t13=(C_word)C_eqp(t2,lf[605]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1283 string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),((C_word*)t0)[3],lf[797],t14,lf[798]);}
else{
C_trace("c-backend.scm: 1284 err");
t14=((C_word*)t0)[2];
f_8121(t14,((C_word*)t0)[3]);}}}}}}}}}}}}
else{
C_trace("c-backend.scm: 1285 err");
t2=((C_word*)t0)[2];
f_8121(t2,((C_word*)t0)[3]);}}

/* k8486 in k8409 in k8387 in k8378 in k8369 in k8174 in k8147 in ##compiler#foreign-argument-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_8488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1280 string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),((C_word*)t0)[2],lf[794],t1,lf[795]);}

/* err in ##compiler#foreign-argument-conversion in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_8121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8121,NULL,2,t0,t1);}
C_trace("c-backend.scm: 1218 quit");
((C_proc4)C_retrieve_symbol_proc(lf[658]))(4,*((C_word*)lf[658]+1),t1,lf[745],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7274,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7276,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7281,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[630]);
if(C_truep(t7)){
C_trace("c-backend.scm: 1125 str");
t8=t5;
f_7281(t8,t1,lf[661]);}
else{
t8=(C_word)C_eqp(t6,lf[16]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[634]));
if(C_truep(t9)){
C_trace("c-backend.scm: 1126 str");
t10=t5;
f_7281(t10,t1,lf[662]);}
else{
t10=(C_word)C_eqp(t6,lf[631]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[635]));
if(C_truep(t11)){
C_trace("c-backend.scm: 1127 str");
t12=t5;
f_7281(t12,t1,lf[663]);}
else{
t12=(C_word)C_eqp(t6,lf[632]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[616]));
if(C_truep(t13)){
C_trace("c-backend.scm: 1128 str");
t14=t5;
f_7281(t14,t1,lf[664]);}
else{
t14=(C_word)C_eqp(t6,lf[633]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[617]));
if(C_truep(t15)){
C_trace("c-backend.scm: 1129 str");
t16=t5;
f_7281(t16,t1,lf[665]);}
else{
t16=(C_word)C_eqp(t6,lf[626]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7351,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7351(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[619]);
t19=t17;
f_7351(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[13])));}}}}}}}

/* k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7351(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7351,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1130 str");
t2=((C_word*)t0)[7];
f_7281(t2,((C_word*)t0)[6],lf[666]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[627]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[620]));
if(C_truep(t3)){
C_trace("c-backend.scm: 1131 str");
t4=((C_word*)t0)[7];
f_7281(t4,((C_word*)t0)[6],lf[667]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[623]);
if(C_truep(t4)){
C_trace("c-backend.scm: 1132 str");
t5=((C_word*)t0)[7];
f_7281(t5,((C_word*)t0)[6],lf[668]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[628]);
if(C_truep(t5)){
C_trace("c-backend.scm: 1133 str");
t6=((C_word*)t0)[7];
f_7281(t6,((C_word*)t0)[6],lf[669]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[618]);
if(C_truep(t6)){
C_trace("c-backend.scm: 1134 str");
t7=((C_word*)t0)[7];
f_7281(t7,((C_word*)t0)[6],lf[670]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[629]);
if(C_truep(t7)){
C_trace("c-backend.scm: 1135 str");
t8=((C_word*)t0)[7];
f_7281(t8,((C_word*)t0)[6],lf[671]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[621]);
if(C_truep(t8)){
C_trace("c-backend.scm: 1136 str");
t9=((C_word*)t0)[7];
f_7281(t9,((C_word*)t0)[6],lf[672]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t9)){
C_trace("c-backend.scm: 1137 str");
t10=((C_word*)t0)[7];
f_7281(t10,((C_word*)t0)[6],lf[673]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[615]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[622]));
if(C_truep(t11)){
C_trace("c-backend.scm: 1138 str");
t12=((C_word*)t0)[7];
f_7281(t12,((C_word*)t0)[6],lf[674]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[600]));
if(C_truep(t13)){
C_trace("c-backend.scm: 1140 str");
t14=((C_word*)t0)[7];
f_7281(t14,((C_word*)t0)[6],lf[675]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[599]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_7453(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
if(C_truep(t16)){
t17=t15;
f_7453(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[743]);
t18=t15;
f_7453(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[744])));}}}}}}}}}}}}}

/* k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7453(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7453,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1141 str");
t2=((C_word*)t0)[7];
f_7281(t2,((C_word*)t0)[6],lf[676]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[624]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[625]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[677]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[678]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[679]));
if(C_truep(t5)){
C_trace("c-backend.scm: 1144 str");
t6=((C_word*)t0)[7];
f_7281(t6,((C_word*)t0)[6],lf[680]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[681]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7486(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[740]);
if(C_truep(t8)){
t9=t7;
f_7486(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[741]);
t10=t7;
f_7486(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[742])));}}}}}}

/* k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7486(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7486,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1145 str");
t2=((C_word*)t0)[7];
f_7281(t2,((C_word*)t0)[6],lf[682]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[683]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[684]));
if(C_truep(t3)){
C_trace("c-backend.scm: 1146 str");
t4=((C_word*)t0)[7];
f_7281(t4,((C_word*)t0)[6],lf[685]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[686]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[687]));
if(C_truep(t5)){
C_trace("c-backend.scm: 1147 str");
t6=((C_word*)t0)[7];
f_7281(t6,((C_word*)t0)[6],lf[688]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[689]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[690]));
if(C_truep(t7)){
C_trace("c-backend.scm: 1148 str");
t8=((C_word*)t0)[7];
f_7281(t8,((C_word*)t0)[6],lf[691]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[692]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[693]));
if(C_truep(t9)){
C_trace("c-backend.scm: 1149 str");
t10=((C_word*)t0)[7];
f_7281(t10,((C_word*)t0)[6],lf[694]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[695]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[696]));
if(C_truep(t11)){
C_trace("c-backend.scm: 1150 str");
t12=((C_word*)t0)[7];
f_7281(t12,((C_word*)t0)[6],lf[697]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[698]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[699]));
if(C_truep(t13)){
C_trace("c-backend.scm: 1151 str");
t14=((C_word*)t0)[7];
f_7281(t14,((C_word*)t0)[6],lf[700]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[701]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[702]));
if(C_truep(t15)){
C_trace("c-backend.scm: 1152 str");
t16=((C_word*)t0)[7];
f_7281(t16,((C_word*)t0)[6],lf[703]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7582(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
if(C_truep(t18)){
t19=t17;
f_7582(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[608]);
if(C_truep(t19)){
t20=t17;
f_7582(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[612]);
t21=t17;
f_7582(t21,(C_truep(t20)?t20:(C_word)C_eqp(((C_word*)t0)[5],lf[611])));}}}}}}}}}}}}

/* k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7582,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1154 str");
t2=((C_word*)t0)[7];
f_7281(t2,((C_word*)t0)[6],lf[704]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[609]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7594(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[610]);
if(C_truep(t4)){
t5=t3;
f_7594(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[613]);
t6=t3;
f_7594(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[614])));}}}}

/* k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7594,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1156 str");
t2=((C_word*)t0)[7];
f_7281(t2,((C_word*)t0)[6],lf[705]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[550]);
if(C_truep(t2)){
C_trace("c-backend.scm: 1157 str");
t3=((C_word*)t0)[7];
f_7281(t3,((C_word*)t0)[6],lf[706]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 1159 ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[606]))(4,*((C_word*)lf[606]+1),t3,C_retrieve(lf[607]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7609(2,t4,C_SCHEME_FALSE);}}}}

/* k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7609,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(0));
C_trace("c-backend.scm: 1161 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),((C_word*)t0)[6],t2,((C_word*)t0)[5]);}
else{
t2=t1;
C_trace("c-backend.scm: 1161 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),((C_word*)t0)[6],t2,((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
C_trace("c-backend.scm: 1162 str");
t2=((C_word*)t0)[3];
f_7281(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t2=(C_word)C_i_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7649,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_7649(t6,(C_word)C_i_memq(t5,lf[739]));}
else{
t5=t3;
f_7649(t5,C_SCHEME_FALSE);}}
else{
C_trace("c-backend.scm: 1212 err");
t2=((C_word*)t0)[2];
f_7276(t2,((C_word*)t0)[6]);}}}}

/* k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7649(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7649,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7660,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 1169 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t3,lf[707],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_fix(2),((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=t2;
f_7666(t5,(C_word)C_eqp(lf[595],t4));}
else{
t4=t2;
f_7666(t4,C_SCHEME_FALSE);}}}

/* k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7666,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7677,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 1172 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t3,lf[708],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[2],C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_7683(t4,(C_word)C_eqp(lf[738],t3));}
else{
t3=t2;
f_7683(t3,C_SCHEME_FALSE);}}}

/* k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7683(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7683,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7690,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7694,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
C_trace("c-backend.scm: 1177 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t3,t4,lf[713]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7722(t5,(C_word)C_eqp(lf[597],t4));}
else{
t4=t2;
f_7722(t4,C_SCHEME_FALSE);}}}

/* k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7722,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7729,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
C_trace("c-backend.scm: 1184 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7739(t5,(C_word)C_eqp(lf[737],t4));}
else{
t4=t2;
f_7739(t4,C_SCHEME_FALSE);}}}

/* k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7739(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7739,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7746,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1186 ->string");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7756(t5,(C_word)C_eqp(lf[736],t4));}
else{
t4=t2;
f_7756(t4,C_SCHEME_FALSE);}}}

/* k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7756,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7763,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1188 ->string");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7773(t5,(C_word)C_eqp(lf[735],t4));}
else{
t4=t2;
f_7773(t4,C_SCHEME_FALSE);}}}

/* k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7773,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7780,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1190 ->string");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7790(t5,(C_word)C_i_memq(t4,lf[734]));}
else{
t4=t2;
f_7790(t4,C_SCHEME_FALSE);}}}

/* k7788 in k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7790(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7790,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7797,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1192 ->string");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7807(t5,(C_word)C_eqp(lf[605],t4));}
else{
t4=t2;
f_7807(t4,C_SCHEME_FALSE);}}}

/* k7805 in k7788 in k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7807,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7814,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1194 ->string");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(3)))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7824(t4,(C_word)C_eqp(lf[602],t3));}
else{
t3=t2;
f_7824(t3,C_SCHEME_FALSE);}}}

/* k7822 in k7805 in k7788 in k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7824,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7836,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7836(2,t6,lf[731]);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7836(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[732]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[733],t4);}}}
else{
C_trace("c-backend.scm: 1211 err");
t2=((C_word*)t0)[2];
f_7276(t2,((C_word*)t0)[4]);}}

/* k7834 in k7822 in k7805 in k7788 in k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7843,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1200 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t2,((C_word*)t0)[2],lf[730]);}

/* k7841 in k7834 in k7822 in k7805 in k7788 in k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7851,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7853,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t5=*((C_word*)lf[222]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7852 in k7841 in k7834 in k7822 in k7805 in k7788 in k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7853(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7853,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[727],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[728]);}
else{
C_trace("c-backend.scm: 1207 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t1,t2,lf[729]);}}

/* k7849 in k7841 in k7834 in k7822 in k7805 in k7788 in k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1203 string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[218]))(4,*((C_word*)lf[218]+1),((C_word*)t0)[2],t1,lf[726]);}

/* k7845 in k7841 in k7834 in k7822 in k7805 in k7788 in k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1199 string-append");
((C_proc9)C_retrieve_proc(*((C_word*)lf[114]+1)))(9,*((C_word*)lf[114]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[723],((C_word*)t0)[2],lf[724],t1,lf[725]);}

/* k7812 in k7805 in k7788 in k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1194 string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),((C_word*)t0)[3],t1,lf[722],((C_word*)t0)[2]);}

/* k7795 in k7788 in k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1192 string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),((C_word*)t0)[3],t1,lf[721],((C_word*)t0)[2]);}

/* k7778 in k7771 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1190 string-append");
((C_proc6)C_retrieve_proc(*((C_word*)lf[114]+1)))(6,*((C_word*)lf[114]+1),((C_word*)t0)[3],lf[719],t1,lf[720],((C_word*)t0)[2]);}

/* k7761 in k7754 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1188 string-append");
((C_proc6)C_retrieve_proc(*((C_word*)lf[114]+1)))(6,*((C_word*)lf[114]+1),((C_word*)t0)[3],lf[717],t1,lf[718],((C_word*)t0)[2]);}

/* k7744 in k7737 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1186 string-append");
((C_proc6)C_retrieve_proc(*((C_word*)lf[114]+1)))(6,*((C_word*)lf[114]+1),((C_word*)t0)[3],lf[715],t1,lf[716],((C_word*)t0)[2]);}

/* k7727 in k7720 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1184 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),((C_word*)t0)[2],lf[714],t1);}

/* k7692 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7698,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7702,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7704,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
C_trace("map");
t6=*((C_word*)lf[222]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7703 in k7692 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7704,3,t0,t1,t2);}
C_trace("##compiler#foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t1,t2,lf[712]);}

/* k7700 in k7692 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1179 string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[218]))(4,*((C_word*)lf[218]+1),((C_word*)t0)[2],t1,lf[711]);}

/* k7696 in k7692 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1176 string-append");
((C_proc6)C_retrieve_proc(*((C_word*)lf[114]+1)))(6,*((C_word*)lf[114]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[709],t1,lf[710]);}

/* k7688 in k7681 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1175 str");
t2=((C_word*)t0)[3];
f_7281(t2,((C_word*)t0)[2],t1);}

/* k7675 in k7664 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1172 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7658 in k7647 in k7607 in k7592 in k7580 in k7484 in k7451 in k7349 in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1169 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* str in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7281(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7281,NULL,3,t0,t1,t2);}
C_trace("c-backend.scm: 1123 string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),t1,t2,lf[660],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_7276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7276,NULL,2,t0,t1);}
C_trace("c-backend.scm: 1122 quit");
((C_proc4)C_retrieve_symbol_proc(lf[658]))(4,*((C_word*)lf[658]+1),t1,lf[659],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7209,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7213,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1104 foreign-callback-stub-name");
((C_proc3)C_retrieve_symbol_proc(lf[657]))(3,*((C_word*)lf[657]+1),t4,t3);}

/* k7211 in ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7216,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1105 foreign-callback-stub-qualifiers");
((C_proc3)C_retrieve_symbol_proc(lf[656]))(3,*((C_word*)lf[656]+1),t2,((C_word*)t0)[2]);}

/* k7214 in k7211 in ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 1106 foreign-callback-stub-return-type");
((C_proc3)C_retrieve_symbol_proc(lf[652]))(3,*((C_word*)lf[652]+1),t2,((C_word*)t0)[2]);}

/* k7217 in k7214 in k7211 in ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7222,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 1107 foreign-callback-stub-argument-types");
((C_proc3)C_retrieve_symbol_proc(lf[651]))(3,*((C_word*)lf[651]+1),t2,((C_word*)t0)[2]);}

/* k7220 in k7217 in k7214 in k7211 in ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7222,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 1109 make-argument-list");
((C_proc4)C_retrieve_symbol_proc(lf[291]))(4,*((C_word*)lf[291]+1),t3,t2,lf[655]);}

/* k7226 in k7220 in k7217 in k7214 in k7211 in ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7231,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7272,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1110 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t3,((C_word*)t0)[2],lf[654]);}

/* k7270 in k7226 in k7220 in k7217 in k7214 in k7211 in ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1110 gen");
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k7229 in k7226 in k7220 in k7217 in k7214 in k7211 in ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7234,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7239,tmp=(C_word)a,a+=2,tmp);
C_trace("c-backend.scm: 1111 pair-for-each");
((C_proc5)C_retrieve_symbol_proc(lf[198]))(5,*((C_word*)lf[198]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7238 in k7229 in k7226 in k7220 in k7217 in k7214 in k7211 in ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7239,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7243,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7260,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
C_trace("c-backend.scm: 1113 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t5,t6,t7);}

/* k7258 in a7238 in k7229 in k7226 in k7220 in k7217 in k7214 in k7211 in ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1113 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* k7241 in a7238 in k7229 in k7226 in k7220 in k7217 in k7214 in k7211 in ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
C_trace("c-backend.scm: 1114 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7232 in k7229 in k7226 in k7220 in k7217 in k7214 in k7211 in ##compiler#generate-foreign-callback-header in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1116 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6762,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6768,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6768(t7,t1,t2);}

/* loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6768(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6768,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6781,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 1051 foreign-callback-stub-id");
((C_proc3)C_retrieve_symbol_proc(lf[653]))(3,*((C_word*)lf[653]+1),t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6784,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 1052 real-name2");
((C_proc4)C_retrieve_symbol_proc(lf[584]))(4,*((C_word*)lf[584]+1),t2,t1,((C_word*)t0)[2]);}

/* k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6787,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 1053 foreign-callback-stub-return-type");
((C_proc3)C_retrieve_symbol_proc(lf[652]))(3,*((C_word*)lf[652]+1),t2,((C_word*)t0)[2]);}

/* k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 1054 foreign-callback-stub-argument-types");
((C_proc3)C_retrieve_symbol_proc(lf[651]))(3,*((C_word*)lf[651]+1),t2,((C_word*)t0)[3]);}

/* k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6790,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 1056 make-argument-list");
((C_proc4)C_retrieve_symbol_proc(lf[291]))(4,*((C_word*)lf[291]+1),t3,t2,lf[650]);}

/* k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6796,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6798,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 1083 fold");
((C_proc6)C_retrieve_symbol_proc(lf[439]))(6,*((C_word*)lf[439]+1),t5,((C_word*)t3)[1],lf[649],((C_word*)t0)[4],t1);}

/* k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("c-backend.scm: 1084 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7207,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1086 cleanup");
((C_proc3)C_retrieve_symbol_proc(lf[494]))(3,*((C_word*)lf[494]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_7143(2,t3,C_SCHEME_UNDEFINED);}}

/* k7205 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1086 gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[647],t1,lf[648]);}

/* k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 1087 generate-foreign-callback-header");
((C_proc4)C_retrieve_symbol_proc(lf[537]))(4,*((C_word*)lf[537]+1),t2,lf[646],((C_word*)t0)[2]);}

/* k7144 in k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 1088 gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_make_character(123),C_SCHEME_TRUE,lf[644],((C_word*)t0)[2],lf[645]);}

/* k7147 in k7144 in k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 1089 gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[643]);}

/* k7150 in k7147 in k7144 in k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7155,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7192,tmp=(C_word)a,a+=2,tmp);
C_trace("c-backend.scm: 1090 for-each");
((C_proc5)C_retrieve_proc(*((C_word*)lf[59]+1)))(5,*((C_word*)lf[59]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7191 in k7150 in k7147 in k7144 in k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7192,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7200,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 1092 foreign-result-conversion");
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t4,t3,lf[642]);}

/* k7198 in a7191 in k7150 in k7147 in k7144 in k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1092 gen");
((C_proc9)C_retrieve_proc(*((C_word*)lf[1]+1)))(9,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[639],t1,((C_word*)t0)[2],lf[640],C_SCHEME_TRUE,lf[641]);}

/* k7153 in k7150 in k7147 in k7144 in k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(lf[550],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_7158(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7190,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1097 foreign-argument-conversion");
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t4,((C_word*)t0)[4]);}}

/* k7188 in k7153 in k7150 in k7147 in k7144 in k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1097 gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[638],t1);}

/* k7156 in k7153 in k7150 in k7147 in k7144 in k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7161,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1098 gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,lf[637],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k7159 in k7156 in k7153 in k7150 in k7147 in k7144 in k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7164,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[550],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_7164(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 1099 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k7162 in k7159 in k7156 in k7153 in k7150 in k7147 in k7144 in k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1100 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[636]);}

/* k7165 in k7162 in k7159 in k7156 in k7153 in k7150 in k7147 in k7144 in k7141 in k7138 in k7135 in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_7167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6768(t3,((C_word*)t0)[2],t2);}

/* compute-size in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6798(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6798,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[16]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6808,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_6808(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[626]);
if(C_truep(t8)){
t9=t7;
f_6808(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[627]);
if(C_truep(t9)){
t10=t7;
f_6808(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[628]);
if(C_truep(t10)){
t11=t7;
f_6808(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[13]);
if(C_truep(t11)){
t12=t7;
f_6808(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[550]);
if(C_truep(t12)){
t13=t7;
f_6808(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[629]);
if(C_truep(t13)){
t14=t7;
f_6808(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[630]);
if(C_truep(t14)){
t15=t7;
f_6808(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[631]);
if(C_truep(t15)){
t16=t7;
f_6808(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[632]);
if(C_truep(t16)){
t17=t7;
f_6808(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[633]);
if(C_truep(t17)){
t18=t7;
f_6808(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[634]);
t19=t7;
f_6808(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[635])));}}}}}}}}}}}}

/* k6806 in compute-size in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6808,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6817(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[615]);
if(C_truep(t4)){
t5=t3;
f_6817(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[599]);
if(C_truep(t5)){
t6=t3;
f_6817(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[616]);
if(C_truep(t6)){
t7=t3;
f_6817(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[617]);
if(C_truep(t7)){
t8=t3;
f_6817(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[618]);
if(C_truep(t8)){
t9=t3;
f_6817(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[619]);
if(C_truep(t9)){
t10=t3;
f_6817(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[620]);
if(C_truep(t10)){
t11=t3;
f_6817(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[621]);
if(C_truep(t11)){
t12=t3;
f_6817(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
if(C_truep(t12)){
t13=t3;
f_6817(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[622]);
if(C_truep(t13)){
t14=t3;
f_6817(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[623]);
if(C_truep(t14)){
t15=t3;
f_6817(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[624]);
t16=t3;
f_6817(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[625])));}}}}}}}}}}}}}}

/* k6815 in k6806 in compute-size in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6817,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1065 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[587]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6829(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[612]);
if(C_truep(t4)){
t5=t3;
f_6829(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[613]);
if(C_truep(t5)){
t6=t3;
f_6829(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[613]);
t7=t3;
f_6829(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[614])));}}}}}

/* k6827 in k6815 in k6806 in compute-size in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6829,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1067 string-append");
((C_proc8)C_retrieve_proc(*((C_word*)lf[114]+1)))(8,*((C_word*)lf[114]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[589],((C_word*)t0)[5],lf[590],((C_word*)t0)[5],lf[591]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6841(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t4)){
t5=t3;
f_6841(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[609]);
if(C_truep(t5)){
t6=t3;
f_6841(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[610]);
t7=t3;
f_6841(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[611])));}}}}}

/* k6839 in k6827 in k6815 in k6806 in compute-size in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6841,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1069 string-append");
((C_proc6)C_retrieve_proc(*((C_word*)lf[114]+1)))(6,*((C_word*)lf[114]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[593],((C_word*)t0)[4],lf[594]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
C_trace("c-backend.scm: 1071 ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[606]))(4,*((C_word*)lf[606]+1),t2,C_retrieve(lf[607]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6847(2,t3,C_SCHEME_FALSE);}}}

/* k6845 in k6839 in k6827 in k6815 in k6806 in compute-size in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6847,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(C_word)C_i_vector_ref(t1,C_fix(0));
C_trace("c-backend.scm: 1073 compute-size");
t3=((C_word*)((C_word*)t0)[6])[1];
f_6798(5,t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=t1;
C_trace("c-backend.scm: 1073 compute-size");
t3=((C_word*)((C_word*)t0)[6])[1];
f_6798(5,t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[595]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6881,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6881(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t5)){
t6=t4;
f_6881(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t6)){
t7=t4;
f_6881(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[600]);
if(C_truep(t7)){
t8=t4;
f_6881(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[601]);
if(C_truep(t8)){
t9=t4;
f_6881(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[602]);
if(C_truep(t9)){
t10=t4;
f_6881(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[603]);
if(C_truep(t10)){
t11=t4;
f_6881(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[604]);
t12=t4;
f_6881(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[605])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k6879 in k6845 in k6839 in k6827 in k6815 in k6806 in compute-size in k6794 in k6788 in k6785 in k6782 in k6779 in loop1327 in generate-foreign-callback-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
C_trace("c-backend.scm: 1078 string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[596]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1079 compute-size");
t4=((C_word*)((C_word*)t0)[3])[1];
f_6798(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}

/* ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6504(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6504,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6510,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6510(t7,t1,t2);}

/* loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6510(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6510,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6523,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 984  foreign-stub-id");
((C_proc3)C_retrieve_symbol_proc(lf[585]))(3,*((C_word*)lf[585]+1),t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6526,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 985  real-name2");
((C_proc4)C_retrieve_symbol_proc(lf[584]))(4,*((C_word*)lf[584]+1),t2,t1,((C_word*)t0)[2]);}

/* k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6529,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 986  foreign-stub-argument-types");
((C_proc3)C_retrieve_symbol_proc(lf[583]))(3,*((C_word*)lf[583]+1),t2,((C_word*)t0)[2]);}

/* k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6529,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6760,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 988  make-variable-list");
((C_proc4)C_retrieve_symbol_proc(lf[281]))(4,*((C_word*)lf[281]+1),t4,t2,lf[582]);}

/* k6758 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6760,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[581],t1);
C_trace("c-backend.scm: 988  intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t2,C_make_character(44));}

/* k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 989  foreign-stub-return-type");
((C_proc3)C_retrieve_symbol_proc(lf[580]))(3,*((C_word*)lf[580]+1),t2,((C_word*)t0)[2]);}

/* k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 990  foreign-stub-name");
((C_proc3)C_retrieve_symbol_proc(lf[579]))(3,*((C_word*)lf[579]+1),t2,((C_word*)t0)[2]);}

/* k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("c-backend.scm: 991  foreign-stub-body");
((C_proc3)C_retrieve_symbol_proc(lf[578]))(3,*((C_word*)lf[578]+1),t2,((C_word*)t0)[2]);}

/* k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("c-backend.scm: 992  foreign-stub-argument-names");
((C_proc3)C_retrieve_symbol_proc(lf[577]))(3,*((C_word*)lf[577]+1),t2,((C_word*)t0)[2]);}

/* k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=t2;
f_6550(2,t3,t1);}
else{
C_trace("c-backend.scm: 992  make-list");
((C_proc4)C_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
C_trace("c-backend.scm: 993  foreign-result-conversion");
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t2,((C_word*)t0)[9],lf[576]);}

/* k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
C_trace("c-backend.scm: 994  foreign-stub-cps");
((C_proc3)C_retrieve_symbol_proc(lf[575]))(3,*((C_word*)lf[575]+1),t2,((C_word*)t0)[2]);}

/* k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
C_trace("c-backend.scm: 995  foreign-stub-callback");
((C_proc3)C_retrieve_symbol_proc(lf[574]))(3,*((C_word*)lf[574]+1),t2,((C_word*)t0)[2]);}

/* k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
C_trace("c-backend.scm: 996  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6749,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 998  cleanup");
((C_proc3)C_retrieve_symbol_proc(lf[494]))(3,*((C_word*)lf[494]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6565(2,t3,C_SCHEME_UNDEFINED);}}

/* k6747 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 998  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[572],t1,lf[573]);}

/* k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[12])){
C_trace("c-backend.scm: 1000 gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[570],((C_word*)t0)[6],lf[571]);}
else{
t3=t2;
f_6568(2,t3,C_SCHEME_UNDEFINED);}}

/* k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[10])){
C_trace("c-backend.scm: 1003 gen");
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[565],((C_word*)t0)[2],lf[566],C_SCHEME_TRUE,lf[567],((C_word*)t0)[2],lf[568]);}
else{
C_trace("c-backend.scm: 1005 gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[569],((C_word*)t0)[2],C_make_character(40));}}

/* k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[3]);}

/* k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6577,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[10])){
C_trace("c-backend.scm: 1008 gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,lf[560],C_SCHEME_TRUE,lf[561],((C_word*)t0)[2],lf[562]);}
else{
C_trace("c-backend.scm: 1009 gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,lf[563],C_SCHEME_TRUE,lf[564],((C_word*)t0)[2],C_make_character(40));}}

/* k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6580,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_trace("c-backend.scm: 1011 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[559]);}

/* k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_trace("c-backend.scm: 1012 gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[558]);}

/* k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6589,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6688,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1021 iota");
((C_proc3)C_retrieve_symbol_proc(lf[60]))(3,*((C_word*)lf[60]+1),t4,((C_word*)t0)[6]);}

/* k6725 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1013 for-each");
((C_proc6)C_retrieve_proc(*((C_word*)lf[59]+1)))(6,*((C_word*)lf[59]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6687 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6688,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6696,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6708,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
C_trace("c-backend.scm: 1018 symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t6,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6714,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t7);}}

/* k6712 in a6687 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6717,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(116),t1);}

/* k6715 in k6712 in a6687 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6718 in k6715 in k6712 in a6687 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6706 in a6687 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1016 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6694 in a6687 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1019 foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t2,((C_word*)t0)[2],lf[557]);}

/* k6698 in k6694 in a6687 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6704,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1020 foreign-argument-conversion");
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t2,((C_word*)t0)[2]);}

/* k6702 in k6698 in k6694 in a6687 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1015 gen");
((C_proc11)C_retrieve_proc(*((C_word*)lf[1]+1)))(11,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[554],((C_word*)t0)[3],C_make_character(41),t1,lf[555],((C_word*)t0)[2],lf[556]);}

/* k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[7])){
C_trace("c-backend.scm: 1022 gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[553]);}
else{
t3=t2;
f_6592(2,t3,C_SCHEME_UNDEFINED);}}

/* k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6595,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6608,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1024 gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[544]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[550]);
if(C_truep(t4)){
C_trace("c-backend.scm: 1035 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
C_trace("c-backend.scm: 1034 gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[552],((C_word*)t0)[2]);}}}

/* k6627 in k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 1036 gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(40));}

/* k6630 in k6627 in k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6635,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6666,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6670,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1037 make-argument-list");
((C_proc4)C_retrieve_symbol_proc(lf[291]))(4,*((C_word*)lf[291]+1),t4,((C_word*)t0)[2],lf[551]);}

/* k6668 in k6630 in k6627 in k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1037 intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k6664 in k6630 in k6627 in k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k6633 in k6630 in k6627 in k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[550]);
if(C_truep(t3)){
t4=t2;
f_6638(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 1038 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k6636 in k6633 in k6630 in k6627 in k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1039 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[549]);}

/* k6639 in k6636 in k6633 in k6630 in k6627 in k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
C_trace("c-backend.scm: 1041 gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[545],C_SCHEME_TRUE,lf[546]);}
else{
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 1043 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[547]);}
else{
C_trace("c-backend.scm: 1044 gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[548]);}}}

/* k6606 in k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1026 gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[543],C_SCHEME_TRUE);}

/* k6609 in k6606 in k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
C_trace("c-backend.scm: 1028 gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[539],C_SCHEME_TRUE,lf[540]);}
else{
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 1030 gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[541]);}
else{
C_trace("c-backend.scm: 1031 gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[542]);}}}

/* k6593 in k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1045 gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(125));}

/* k6596 in k6593 in k6590 in k6587 in k6584 in k6581 in k6578 in k6575 in k6572 in k6569 in k6566 in k6563 in k6560 in k6557 in k6554 in k6551 in k6548 in k6545 in k6542 in k6539 in k6536 in k6533 in k6527 in k6524 in k6521 in loop1236 in ##compiler#generate-foreign-stubs in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6510(t3,((C_word*)t0)[2],t2);}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6470,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6476,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6476(t6,t1,t2);}

/* loop1221 in ##compiler#generate-foreign-callback-stub-prototypes in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6476(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6476,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6489,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 976  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6487 in loop1221 in ##compiler#generate-foreign-callback-stub-prototypes in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 977  generate-foreign-callback-header");
((C_proc4)C_retrieve_symbol_proc(lf[537]))(4,*((C_word*)lf[537]+1),t2,lf[538],((C_word*)t0)[2]);}

/* k6490 in k6487 in loop1221 in ##compiler#generate-foreign-callback-stub-prototypes in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 978  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(59));}

/* k6493 in k6490 in k6487 in loop1221 in ##compiler#generate-foreign-callback-stub-prototypes in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6476(t3,((C_word*)t0)[2],t2);}

/* ##compiler#generate-external-variables in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6422,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6426,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 961  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}

/* k6424 in ##compiler#generate-external-variables in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6426,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6431,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6431(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1205 in k6424 in ##compiler#generate-external-variables in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6431(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6431,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_vector_ref(t3,C_fix(0));
t5=(C_word)C_i_vector_ref(t3,C_fix(1));
t6=(C_word)C_i_vector_ref(t3,C_fix(2));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6453,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=(C_truep(t6)?lf[535]:lf[536]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6468,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 967  foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t9,t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6466 in loop1205 in k6424 in ##compiler#generate-external-variables in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 967  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* k6451 in loop1205 in k6424 in ##compiler#generate-external-variables in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6431(t3,((C_word*)t0)[2],t2);}

/* ##compiler#make-argument-list in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6406,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6412,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 953  list-tabulate");
((C_proc4)C_retrieve_symbol_proc(lf[534]))(4,*((C_word*)lf[534]+1),t1,t2,t4);}

/* a6411 in ##compiler#make-argument-list in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6412,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 955  number->string");
C_number_to_string(3,0,t3,t2);}

/* k6418 in a6411 in ##compiler#make-argument-list in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 955  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6390,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6396,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 948  list-tabulate");
((C_proc4)C_retrieve_symbol_proc(lf[534]))(4,*((C_word*)lf[534]+1),t1,t2,t4);}

/* a6395 in ##compiler#make-variable-list in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6396,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6404,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 950  number->string");
C_number_to_string(3,0,t3,t2);}

/* k6402 in a6395 in ##compiler#make-variable-list in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 950  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),((C_word*)t0)[3],lf[533],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6301,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6310,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6310(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6310(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6310,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)t0)[3];
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6339,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_6339(t7,t5);}
else{
t7=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t7)){
t8=t6;
f_6339(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t8)){
t9=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t10=t2;
if(C_truep((C_word)C_fixnum_lessp(t10,t9))){
t11=(C_word)C_fixnum_increase(t2);
t12=(C_word)C_i_string_ref(((C_word*)t0)[3],t11);
t13=t6;
f_6339(t13,(C_word)C_eqp(C_make_character(47),t12));}
else{
t11=t6;
f_6339(t11,C_SCHEME_FALSE);}}
else{
t9=t6;
f_6339(t9,C_SCHEME_FALSE);}}}}}

/* k6337 in loop in ##compiler#cleanup in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6339,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=(C_word)C_i_string_set(((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_make_character(126));
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
C_trace("c-backend.scm: 942  loop");
t4=((C_word*)((C_word*)t0)[5])[1];
f_6310(t4,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6349,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 939  string-copy");
((C_proc3)C_retrieve_symbol_proc(lf[532]))(3,*((C_word*)lf[532]+1),t2,((C_word*)t0)[3]);}}
else{
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=(C_word)C_i_string_set(((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[2]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
C_trace("c-backend.scm: 942  loop");
t4=((C_word*)((C_word*)t0)[5])[1];
f_6310(t4,((C_word*)t0)[4],t3);}
else{
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
C_trace("c-backend.scm: 942  loop");
t3=((C_word*)((C_word*)t0)[5])[1];
f_6310(t3,((C_word*)t0)[4],t2);}}}

/* k6347 in k6337 in loop in ##compiler#cleanup in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_make_character(126));
t4=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
C_trace("c-backend.scm: 942  loop");
t5=((C_word*)((C_word*)t0)[3])[1];
f_6310(t5,((C_word*)t0)[2],t4);}

/* emit-procedure-table-info in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6224,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6228,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
C_trace("c-backend.scm: 904  gen");
((C_proc9)C_retrieve_proc(*((C_word*)lf[1]+1)))(9,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[529],C_SCHEME_TRUE,lf[530],t6,lf[531]);}

/* k6226 in emit-procedure-table-info in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6231,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6242,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6242(t6,t2,((C_word*)t0)[2]);}

/* doloop1147 in k6226 in emit-procedure-table-info in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6242,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("c-backend.scm: 908  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,lf[521]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6255,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
C_trace("c-backend.scm: 909  lambda-literal-id");
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t3,t4);}}

/* k6253 in doloop1147 in k6226 in emit-procedure-table-info in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6258,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6287,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 910  string->c-identifier");
((C_proc3)C_retrieve_symbol_proc(lf[528]))(3,*((C_word*)lf[528]+1),t3,((C_word*)t0)[2]);}

/* k6285 in k6253 in doloop1147 in k6226 in emit-procedure-table-info in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 910  gen");
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[526],((C_word*)t0)[2],C_make_character(58),t1,lf[527]);}

/* k6256 in k6253 in doloop1147 in k6226 in emit-procedure-table-info in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[257],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[208]))){
C_trace("c-backend.scm: 913  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[522],C_retrieve(lf[208]),lf[523]);}
else{
C_trace("c-backend.scm: 914  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[524]);}}
else{
C_trace("c-backend.scm: 915  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[525]);}}

/* k6259 in k6256 in k6253 in doloop1147 in k6226 in emit-procedure-table-info in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6242(t3,((C_word*)t0)[2],t2);}

/* k6229 in k6226 in emit-procedure-table-info in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6234,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 916  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[520]);}

/* k6232 in k6229 in k6226 in emit-procedure-table-info in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6237,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 917  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[519]);}

/* k6235 in k6232 in k6229 in k6226 in emit-procedure-table-info in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 918  gen");
((C_proc15)C_retrieve_proc(*((C_word*)lf[1]+1)))(15,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[512],C_SCHEME_TRUE,lf[513],C_SCHEME_TRUE,lf[514],C_SCHEME_TRUE,lf[515],C_SCHEME_TRUE,lf[516],C_SCHEME_TRUE,lf[517],C_SCHEME_TRUE,lf[518]);}

/* ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[56],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_2353,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2356,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2398,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3971,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4134,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4299,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4621,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5416,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5339,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5197,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4983,a[2]=t2,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5038,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t22=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5428,a[2]=t4,a[3]=t8,a[4]=t20,a[5]=t18,a[6]=t2,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t23=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6191,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t8,a[6]=t14,a[7]=t22,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 887  debugging");
((C_proc4)C_retrieve_symbol_proc(lf[495]))(4,*((C_word*)lf[495]+1),t23,lf[510],lf[511]);}

/* k6189 in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6191,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! output ...) */,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 889  header");
t4=((C_word*)t0)[2];
f_3971(t4,t3);}

/* k6193 in k6189 in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 890  declarations");
t3=((C_word*)t0)[2];
f_4134(t3,t2);}

/* k6196 in k6193 in k6189 in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 891  generate-external-variables");
((C_proc3)C_retrieve_symbol_proc(lf[508]))(3,*((C_word*)lf[508]+1),t2,C_retrieve(lf[509]));}

/* k6199 in k6196 in k6193 in k6189 in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 892  generate-foreign-stubs");
((C_proc4)C_retrieve_symbol_proc(lf[506]))(4,*((C_word*)lf[506]+1),t2,C_retrieve(lf[507]),((C_word*)t0)[3]);}

/* k6202 in k6199 in k6196 in k6193 in k6189 in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 893  prototypes");
t3=((C_word*)t0)[2];
f_4299(t3,t2);}

/* k6205 in k6202 in k6199 in k6196 in k6193 in k6189 in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 894  generate-foreign-callback-stubs");
((C_proc4)C_retrieve_symbol_proc(lf[505]))(4,*((C_word*)lf[505]+1),t2,C_retrieve(lf[202]),((C_word*)t0)[2]);}

/* k6208 in k6205 in k6202 in k6199 in k6196 in k6193 in k6189 in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6213,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 895  trampolines");
t3=((C_word*)t0)[2];
f_4621(t3,t2);}

/* k6211 in k6208 in k6205 in k6202 in k6199 in k6196 in k6193 in k6189 in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 896  procedures");
t3=((C_word*)t0)[2];
f_5428(t3,t2);}

/* k6214 in k6211 in k6208 in k6205 in k6202 in k6199 in k6196 in k6193 in k6189 in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6219,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 897  emit-procedure-table-info");
((C_proc4)C_retrieve_symbol_proc(lf[504]))(4,*((C_word*)lf[504]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6217 in k6214 in k6211 in k6208 in k6205 in k6202 in k6199 in k6196 in k6193 in k6189 in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
C_trace("c-backend.scm: 468  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[503],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5428(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5428,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5434,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5434(t5,t1,((C_word*)t0)[2]);}

/* loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5434(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5434,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 711  lambda-literal-argument-count");
((C_proc3)C_retrieve_symbol_proc(lf[284]))(3,*((C_word*)lf[284]+1),t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 712  lambda-literal-id");
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[6]);}

/* k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5453,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 713  real-name");
((C_proc4)C_retrieve_symbol_proc(lf[502]))(4,*((C_word*)lf[502]+1),t2,t1,((C_word*)t0)[2]);}

/* k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5456,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("c-backend.scm: 714  lambda-literal-allocated");
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[6]);}

/* k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("c-backend.scm: 715  lambda-literal-rest-argument");
((C_proc3)C_retrieve_symbol_proc(lf[280]))(3,*((C_word*)lf[280]+1),t2,((C_word*)t0)[7]);}

/* k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5459,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
C_trace("c-backend.scm: 716  lambda-literal-customizable");
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t4,((C_word*)t0)[8]);}

/* k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6188,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 717  lambda-literal-closure-size");
((C_proc3)C_retrieve_symbol_proc(lf[147]))(3,*((C_word*)lf[147]+1),t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_5465(t3,C_SCHEME_FALSE);}}

/* k6186 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5465(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5465(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5465,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(1)):(C_word)C_a_i_minus(&a,2,((C_word*)t0)[15],C_fix(0)));
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5471,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],tmp=(C_word)a,a+=18,tmp);
C_trace("c-backend.scm: 719  make-variable-list");
((C_proc4)C_retrieve_symbol_proc(lf[281]))(4,*((C_word*)lf[281]+1),t3,((C_word*)t0)[15],lf[501]);}

/* k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5474,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
C_trace("c-backend.scm: 720  make-argument-list");
((C_proc4)C_retrieve_symbol_proc(lf[291]))(4,*((C_word*)lf[291]+1),t2,((C_word*)t0)[13],lf[500]);}

/* k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5477,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("c-backend.scm: 721  intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,t3,C_make_character(44));}
else{
t3=((C_word*)t0)[2];
C_trace("c-backend.scm: 721  intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,t3,C_make_character(44));}}

/* k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5480,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("c-backend.scm: 722  intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,t3,C_make_character(44));}
else{
t3=((C_word*)t0)[2];
C_trace("c-backend.scm: 722  intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,t3,C_make_character(44));}}

/* k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_5483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
C_trace("c-backend.scm: 723  lambda-literal-external");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t2,((C_word*)t0)[12]);}

/* k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
C_trace("c-backend.scm: 724  lambda-literal-looping");
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),t2,((C_word*)t0)[13]);}

/* k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5489,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
C_trace("c-backend.scm: 725  lambda-literal-direct");
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t2,((C_word*)t0)[14]);}

/* k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
C_trace("c-backend.scm: 726  lambda-literal-rest-argument-mode");
((C_proc3)C_retrieve_symbol_proc(lf[279]))(3,*((C_word*)lf[279]+1),t2,((C_word*)t0)[15]);}

/* k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
C_trace("c-backend.scm: 727  lambda-literal-temporaries");
((C_proc3)C_retrieve_symbol_proc(lf[105]))(3,*((C_word*)lf[105]+1),t2,((C_word*)t0)[16]);}

/* k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
if(C_truep(C_retrieve(lf[208]))){
C_trace("c-backend.scm: 729  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t2,C_retrieve(lf[208]),lf[498]);}
else{
t3=t2;
f_5498(2,t3,lf[499]);}}

/* k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_5501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("c-backend.scm: 731  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[495]))(5,*((C_word*)lf[495]+1),t2,lf[496],lf[497],((C_word*)t0)[14]);}
else{
t3=t2;
f_5501(2,t3,C_SCHEME_UNDEFINED);}}

/* k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_5504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
C_trace("c-backend.scm: 732  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],tmp=(C_word)a,a+=25,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6157,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 733  cleanup");
((C_proc3)C_retrieve_symbol_proc(lf[494]))(3,*((C_word*)lf[494]+1),t3,((C_word*)t0)[2]);}

/* k6155 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 733  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[492],t1,lf[493],C_SCHEME_TRUE);}

/* k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
t3=(C_word)C_eqp(lf[257],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 742  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t4,lf[486]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6118,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 735  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t4,lf[491]);}}

/* k6116 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 736  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[489]);}
else{
C_trace("c-backend.scm: 736  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[490]);}}

/* k6119 in k6116 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6124,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 738  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[487]);}
else{
C_trace("c-backend.scm: 739  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[488]);}}

/* k6122 in k6119 in k6116 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 740  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6138 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[208]))){
t3=t2;
f_6143(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 744  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[485]);}}

/* k6141 in k6138 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 745  gen");
((C_proc16)C_retrieve_proc(*((C_word*)lf[1]+1)))(16,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[479],C_SCHEME_TRUE,lf[480],C_SCHEME_TRUE,lf[481],C_SCHEME_TRUE,lf[482],((C_word*)t0)[2],lf[483],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[484],((C_word*)t0)[2]);}

/* k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
C_trace("c-backend.scm: 750  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_5516(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 751  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[478]);}}

/* k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6090,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_6090(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_6090(t4,C_SCHEME_FALSE);}}

/* k6088 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6090,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 753  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[477]);}
else{
t2=((C_word*)t0)[2];
f_5519(2,t2,C_SCHEME_UNDEFINED);}}

/* k6091 in k6088 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 754  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_5519(2,t3,t2);}}

/* k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[15]);}

/* k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
C_trace("c-backend.scm: 756  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[476]);}
else{
t3=t2;
f_5525(2,t3,C_SCHEME_UNDEFINED);}}

/* k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
C_trace("c-backend.scm: 757  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[475]);}

/* k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[246]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_5531(t5,t4);}
else{
t4=t2;
f_5531(t4,C_SCHEME_UNDEFINED);}}

/* k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5531,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
C_trace("c-backend.scm: 759  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[474]);}

/* k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
C_trace("c-backend.scm: 761  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[472],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[20],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[20]);
t5=t3;
f_6050(t5,(C_word)C_fixnum_plus(((C_word*)t0)[16],t4));}
else{
t4=t3;
f_6050(t4,((C_word*)t0)[16]);}}}

/* k6048 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6050,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6052,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6052(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* doloop922 in k6048 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_6052(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6052,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6062,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 765  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[473],t2,C_make_character(59));}}

/* k6060 in doloop922 in k6048 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_6052(t4,((C_word*)t0)[2],t2,t3);}

/* k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5540,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],a[17]=((C_word*)t0)[23],a[18]=((C_word*)t0)[24],tmp=(C_word)a,a+=19,tmp);
t3=(C_word)C_eqp(lf[257],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5764,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5839,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 767  fold");
((C_proc5)C_retrieve_symbol_proc(lf[439]))(5,*((C_word*)lf[439]+1),t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5853,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 801  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[453]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5917,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[2],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5995,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_5995(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_5995(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k5993 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5995,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
C_trace("c-backend.scm: 815  gen");
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[463],C_SCHEME_TRUE,lf[464],C_SCHEME_TRUE,lf[465],((C_word*)t0)[3],lf[466]);}
else{
C_trace("c-backend.scm: 818  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[467],((C_word*)t0)[3],lf[468]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6007,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_6007(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 820  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[471]);}}}

/* k6005 in k5993 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 821  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[470]);}
else{
t3=t2;
f_6010(2,t3,C_SCHEME_UNDEFINED);}}

/* k6008 in k6005 in k5993 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_6010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
t2=C_retrieve(lf[130]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_5917(2,t4,t3);}
else{
t3=C_retrieve(lf[433]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
f_5917(2,t5,t4);}
else{
C_trace("c-backend.scm: 823  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[469]);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_5917(2,t3,t2);}}

/* k5915 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5920,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5959,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[130]);
if(C_truep(t4)){
t5=t3;
f_5959(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[447]);
t6=t3;
f_5959(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_5959(t4,C_SCHEME_FALSE);}}

/* k5957 in k5915 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5959(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[246]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
C_trace("c-backend.scm: 827  gen");
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[457],((C_word*)t0)[3],lf[458],((C_word*)t0)[3],lf[459]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
f_5920(2,t5,t4);}}
else{
C_trace("c-backend.scm: 828  gen");
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[460],((C_word*)t0)[3],lf[461],((C_word*)t0)[3],lf[462]);}}
else{
t2=((C_word*)t0)[2];
f_5920(2,t2,C_SCHEME_UNDEFINED);}}

/* k5918 in k5915 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5926,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_5926(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=((C_word*)t0)[2];
t5=t2;
f_5926(t5,t4);}
else{
t4=((C_word*)t0)[5];
t5=t2;
f_5926(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k5924 in k5918 in k5915 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5926,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[442]))){
C_trace("c-backend.scm: 830  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[456]);}
else{
t3=t2;
f_5929(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_5540(2,t3,t2);}}

/* k5927 in k5924 in k5918 in k5915 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
C_trace("c-backend.scm: 832  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[454]);}
else{
C_trace("c-backend.scm: 833  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[455]);}}
else{
C_trace("c-backend.scm: 833  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[455]);}}

/* k5851 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 802  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[452]);}

/* k5854 in k5851 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 803  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[451]);}

/* k5857 in k5854 in k5851 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
C_trace("c-backend.scm: 805  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_make_character(116),t4);}
else{
C_trace("c-backend.scm: 806  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[450]);}}

/* k5860 in k5857 in k5854 in k5851 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 807  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[448],((C_word*)t0)[3],lf[449]);}

/* k5863 in k5860 in k5857 in k5854 in k5851 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5880,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[130]);
if(C_truep(t4)){
t5=t3;
f_5880(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[447]);
if(C_truep(t5)){
t6=t3;
f_5880(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_5880(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k5878 in k5863 in k5860 in k5857 in k5854 in k5851 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("c-backend.scm: 809  gen");
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[444],((C_word*)t0)[2],lf[445],((C_word*)t0)[2],lf[446]);}
else{
t2=((C_word*)t0)[3];
f_5868(2,t2,C_SCHEME_UNDEFINED);}}

/* k5866 in k5863 in k5860 in k5857 in k5854 in k5851 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[442]))){
C_trace("c-backend.scm: 810  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[443]);}
else{
C_trace("c-backend.scm: 811  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[440],((C_word*)t0)[2],lf[441]);}}

/* k5869 in k5866 in k5863 in k5860 in k5857 in k5854 in k5851 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 811  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[440],((C_word*)t0)[2],lf[441]);}

/* a5838 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5839,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5847,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 767  literal-size");
t5=((C_word*)((C_word*)t0)[2])[1];
f_5038(3,t5,t4,t2);}

/* k5845 in a5838 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5764,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5770,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 769  gen");
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[435],C_SCHEME_TRUE,lf[436],C_SCHEME_TRUE,lf[437],((C_word*)t0)[2],lf[438]);}

/* k5768 in k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[433]))){
C_trace("c-backend.scm: 773  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[434]);}
else{
t3=t2;
f_5773(2,t3,C_SCHEME_UNDEFINED);}}

/* k5771 in k5768 in k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[208]))){
t3=t2;
f_5776(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5807,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[426]))){
C_trace("c-backend.scm: 776  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[427],C_retrieve(lf[426]),lf[428]);}
else{
if(C_truep(C_retrieve(lf[429]))){
C_trace("c-backend.scm: 778  gen");
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[430],C_retrieve(lf[429]),lf[431],C_SCHEME_TRUE,lf[432]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t3;
f_5807(2,t5,t4);}}}}

/* k5805 in k5771 in k5768 in k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5810,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[424]))){
C_trace("c-backend.scm: 781  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[425],C_retrieve(lf[424]),C_make_character(59));}
else{
t3=t2;
f_5810(2,t3,C_SCHEME_UNDEFINED);}}

/* k5808 in k5805 in k5771 in k5768 in k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5813,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[422]))){
C_trace("c-backend.scm: 783  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[423],C_retrieve(lf[422]),C_make_character(59));}
else{
t3=t2;
f_5813(2,t3,C_SCHEME_UNDEFINED);}}

/* k5811 in k5808 in k5805 in k5771 in k5768 in k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve(lf[419]))){
C_trace("c-backend.scm: 785  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[420],C_retrieve(lf[419]),lf[421]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_5776(2,t3,t2);}}

/* k5774 in k5771 in k5768 in k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 786  gen");
((C_proc16)C_retrieve_proc(*((C_word*)lf[1]+1)))(16,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[412],((C_word*)t0)[3],lf[413],C_SCHEME_TRUE,lf[414],((C_word*)t0)[3],lf[415],C_SCHEME_TRUE,lf[416],C_SCHEME_TRUE,lf[417],C_SCHEME_TRUE,lf[418]);}

/* k5777 in k5774 in k5771 in k5768 in k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5782,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 791  gen");
((C_proc14)C_retrieve_proc(*((C_word*)lf[1]+1)))(14,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[406],((C_word*)t0)[2],lf[407],C_SCHEME_TRUE,lf[408],C_SCHEME_TRUE,lf[409],((C_word*)t0)[2],lf[410],C_SCHEME_TRUE,lf[411]);}

/* k5780 in k5777 in k5774 in k5771 in k5768 in k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5785,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 795  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[404],((C_word*)t0)[2],lf[405]);}

/* k5783 in k5780 in k5777 in k5774 in k5771 in k5768 in k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5785,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_5540(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 797  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[402],((C_word*)t0)[4],lf[403]);}}

/* k5792 in k5783 in k5780 in k5777 in k5774 in k5771 in k5768 in k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 798  literal-frame");
t3=((C_word*)t0)[2];
f_4983(t3,t2);}

/* k5795 in k5792 in k5783 in k5780 in k5777 in k5774 in k5771 in k5768 in k5762 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 799  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[400],((C_word*)t0)[2],lf[401]);}

/* k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[18],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5570,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[257],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_5570(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_5570(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_5570(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=((C_word*)t0)[2];
t8=t3;
f_5570(t8,t7);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_5570(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5570,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0)))){
C_trace("c-backend.scm: 844  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[391],lf[392],((C_word*)t0)[9],C_make_character(114));}
else{
C_trace("c-backend.scm: 844  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[393],lf[392],((C_word*)t0)[9],C_make_character(114));}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5705,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0)))){
C_trace("c-backend.scm: 870  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[397],lf[398]);}
else{
C_trace("c-backend.scm: 870  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[399],lf[398]);}}}
else{
t2=((C_word*)t0)[10];
f_5543(2,t2,C_SCHEME_UNDEFINED);}}

/* k5703 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5708,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("c-backend.scm: 872  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[3],lf[395]);}
else{
C_trace("c-backend.scm: 873  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[396],((C_word*)t0)[3]);}}

/* k5706 in k5703 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5711,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5720,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 875  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
C_trace("c-backend.scm: 877  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[4],lf[394]);}}

/* k5718 in k5706 in k5703 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k5709 in k5706 in k5703 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 877  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[394]);}

/* k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[331]);
if(C_truep(t3)){
C_trace("c-backend.scm: 845  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(118));}
else{
t4=t2;
f_5579(2,t4,C_SCHEME_UNDEFINED);}}

/* k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 846  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[389],((C_word*)t0)[5],lf[390]);}

/* k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5585,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5686,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 848  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5585(2,t3,C_SCHEME_UNDEFINED);}}

/* k5684 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 850  gen");
((C_proc9)C_retrieve_proc(*((C_word*)lf[1]+1)))(9,*((C_word*)lf[1]+1),t2,lf[385],C_SCHEME_TRUE,lf[386],C_SCHEME_TRUE,lf[387],((C_word*)t0)[6],lf[388]);}

/* k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[380]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
C_trace("c-backend.scm: 854  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[381],((C_word*)t0)[6],lf[382]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[331]);
if(C_truep(t5)){
C_trace("c-backend.scm: 855  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[383],((C_word*)t0)[6],lf[384]);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t2;
f_5591(2,t7,t6);}}}

/* k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 856  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[379]);}

/* k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5655,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5659,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 857  make-argument-list");
((C_proc4)C_retrieve_symbol_proc(lf[291]))(4,*((C_word*)lf[291]+1),t4,((C_word*)t0)[5],lf[378]);}

/* k5657 in k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 857  intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k5653 in k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k5595 in k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 858  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[376],((C_word*)t0)[5],lf[377]);}

/* k5598 in k5595 in k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 860  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[374],((C_word*)t0)[2],lf[375]);}

/* k5601 in k5598 in k5595 in k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k5604 in k5601 in k5598 in k5595 in k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 862  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[372],((C_word*)t0)[3],lf[373]);}

/* k5607 in k5604 in k5601 in k5598 in k5595 in k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 863  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[371]);}

/* k5610 in k5607 in k5604 in k5601 in k5598 in k5595 in k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5615,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5630,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5630(t7,t2,t3,((C_word*)t0)[2]);}

/* doloop1069 in k5610 in k5607 in k5604 in k5601 in k5598 in k5595 in k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5630(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5630,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5640,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 867  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[370],t2,C_make_character(59));}}

/* k5638 in doloop1069 in k5610 in k5607 in k5604 in k5601 in k5598 in k5595 in k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5630(t4,((C_word*)t0)[2],t2,t3);}

/* k5613 in k5610 in k5607 in k5604 in k5601 in k5598 in k5595 in k5592 in k5589 in k5586 in k5583 in k5580 in k5577 in k5574 in k5568 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
C_trace("c-backend.scm: 868  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[368],((C_word*)t0)[3],lf[369]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_5543(2,t4,t3);}}

/* k5541 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5546,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5560,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 879  lambda-literal-body");
((C_proc3)C_retrieve_symbol_proc(lf[367]))(3,*((C_word*)lf[367]+1),t3,((C_word*)t0)[2]);}

/* k5558 in k5541 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
C_trace("c-backend.scm: 878  expression");
t3=((C_word*)t0)[4];
f_2398(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
C_trace("c-backend.scm: 878  expression");
t3=((C_word*)t0)[4];
f_2398(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}}

/* k5544 in k5541 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 884  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(125));}

/* k5547 in k5544 in k5541 in k5538 in k5535 in k5532 in k5529 in k5526 in k5523 in k5520 in k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in loop867 in procedures in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5434(t3,((C_word*)t0)[2],t2);}

/* literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5038,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5045,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 646  immediate?");
((C_proc3)C_retrieve_symbol_proc(lf[366]))(3,*((C_word*)lf[366]+1),t3,t2);}

/* k5043 in literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5045,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t2=C_retrieve(lf[360]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("c-backend.scm: 650  literal-size");
t4=((C_word*)((C_word*)t0)[2])[1];
f_5038(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[3]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5105,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5109,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5113,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 651  vector->list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[363]+1)))(3,*((C_word*)lf[363]+1),t5,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 652  block-variable-literal?");
((C_proc3)C_retrieve_symbol_proc(lf[353]))(3,*((C_word*)lf[353]+1),t2,((C_word*)t0)[3]);}}}}}}}

/* k5117 in k5043 in literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5119,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
C_trace("c-backend.scm: 643  bomb");
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t2,lf[352],t3);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 655  ##sys#bytevector?");
((C_proc3)C_retrieve_proc(*((C_word*)lf[365]+1)))(3,*((C_word*)lf[365]+1),t2,((C_word*)t0)[3]);}}}}

/* k5135 in k5117 in k5043 in literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5137,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
C_trace("c-backend.scm: 655  words");
((C_proc3)C_retrieve_symbol_proc(lf[364]))(3,*((C_word*)lf[364]+1),t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[3]))){
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5166(t7,((C_word*)t0)[4],C_fix(0),t3);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
C_trace("c-backend.scm: 643  bomb");
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t2,lf[352],t3);}}}

/* loop in k5135 in k5117 in k5043 in literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5166(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5166,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5188,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
C_trace("c-backend.scm: 661  literal-size");
t8=((C_word*)((C_word*)t0)[2])[1];
f_5038(3,t8,t6,t7);}}

/* k5186 in loop in k5135 in k5117 in k5043 in literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
C_trace("c-backend.scm: 661  loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_5166(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5142 in k5135 in k5117 in k5043 in literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k5111 in k5043 in literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[222]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k5107 in k5043 in literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 651  reduce");
((C_proc5)C_retrieve_symbol_proc(lf[361]))(5,*((C_word*)lf[361]+1),((C_word*)t0)[2],*((C_word*)lf[362]+1),C_fix(0),t1);}

/* k5103 in k5043 in literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k5074 in k5043 in literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5080,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("c-backend.scm: 650  literal-size");
t4=((C_word*)((C_word*)t0)[2])[1];
f_5038(3,t4,t2,t3);}

/* k5078 in k5074 in k5043 in literal-size in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4983(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4983,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4989(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* doloop775 in literal-frame in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4989(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4989,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4999,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5018,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[359]))(2,*((C_word*)lf[359]+1),t6);}}

/* k5016 in doloop775 in literal-frame in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[358],t1);}

/* k5019 in k5016 in doloop775 in literal-frame in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[357]+1)))(4,*((C_word*)lf[357]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5022 in k5019 in k5016 in doloop775 in literal-frame in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[356]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(93),((C_word*)t0)[2]);}

/* k5025 in k5022 in k5019 in k5016 in doloop775 in literal-frame in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[355]))(3,*((C_word*)lf[355]+1),t2,((C_word*)t0)[2]);}

/* k5028 in k5025 in k5022 in k5019 in k5016 in doloop775 in literal-frame in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 640  gen-lit");
t2=((C_word*)t0)[4];
f_5197(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4997 in doloop775 in literal-frame in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4989(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5197(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5197,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5204,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5337,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 666  big-fixnum?");
((C_proc3)C_retrieve_symbol_proc(lf[354]))(3,*((C_word*)lf[354]+1),t5,t2);}
else{
t5=t4;
f_5204(t5,C_SCHEME_FALSE);}}

/* k5335 in gen-lit in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5204(t2,(C_word)C_i_not(t1));}

/* k5202 in gen-lit in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5204(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5204,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 667  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[337],((C_word*)t0)[3],lf[338]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 668  block-variable-literal?");
((C_proc3)C_retrieve_symbol_proc(lf[353]))(3,*((C_word*)lf[353]+1),t2,((C_word*)t0)[3]);}}

/* k5208 in k5202 in gen-lit in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5210,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_retrieve(lf[339]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t3)){
C_trace("c-backend.scm: 670  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],lf[340]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[4]))){
if(C_truep(((C_word*)t0)[4])){
C_trace("c-backend.scm: 672  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],C_make_character(61),lf[341],C_make_character(59));}
else{
C_trace("c-backend.scm: 672  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],C_make_character(61),lf[342],C_make_character(59));}}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[4]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[4]));
C_trace("c-backend.scm: 674  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],lf[343],t4,lf[344]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 677  c-ify-string");
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
C_trace("c-backend.scm: 682  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],lf[348]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[4]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[4]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_5293(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[4]);
t9=t7;
f_5293(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k5291 in k5208 in k5202 in gen-lit in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5293(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5293,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 686  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[351]);}
else{
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[3];
C_trace("c-backend.scm: 643  bomb");
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t2,lf[352],t3);}}

/* k5294 in k5291 in k5208 in k5202 in gen-lit in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5299,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5306,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 687  encode-literal");
((C_proc3)C_retrieve_symbol_proc(lf[350]))(3,*((C_word*)lf[350]+1),t3,((C_word*)t0)[2]);}

/* k5304 in k5294 in k5291 in k5208 in k5202 in gen-lit in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 687  gen-string-constant");
t2=((C_word*)t0)[3];
f_5339(t2,((C_word*)t0)[2],t1);}

/* k5297 in k5294 in k5291 in k5208 in k5202 in gen-lit in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 688  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[349]);}

/* k5258 in k5208 in k5202 in gen-lit in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5260,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5266,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 679  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[347]);}

/* k5264 in k5258 in k5208 in k5202 in gen-lit in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 680  gen");
((C_proc9)C_retrieve_proc(*((C_word*)lf[1]+1)))(9,*((C_word*)lf[1]+1),((C_word*)t0)[5],lf[345],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[346]);}

/* gen-string-constant in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5339(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5339,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5346,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 693  fx/");
((C_proc4)C_retrieve_proc(*((C_word*)lf[336]+1)))(4,*((C_word*)lf[336]+1),t4,t3,C_fix(80));}

/* k5344 in gen-string-constant in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5349,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 694  modulo");
((C_proc4)C_retrieve_proc(*((C_word*)lf[335]+1)))(4,*((C_word*)lf[335]+1),t2,((C_word*)t0)[5],C_fix(80));}

/* k5347 in k5344 in gen-string-constant in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5349,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5354,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5354(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop843 in k5347 in k5344 in gen-string-constant in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5354(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5354,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5370,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5370(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_5370(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5391,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5406,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5410,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
C_trace("c-backend.scm: 700  string-like-substring");
f_5416(t7,((C_word*)t0)[4],t3,t8);}}

/* k5408 in doloop843 in k5347 in k5344 in gen-string-constant in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 700  c-ify-string");
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k5404 in doloop843 in k5347 in k5344 in gen-string-constant in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 700  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k5389 in doloop843 in k5347 in k5344 in gen-string-constant in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5354(t4,((C_word*)t0)[2],t2,t3);}

/* k5368 in doloop843 in k5347 in k5344 in gen-string-constant in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5370(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5370,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5377,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5381,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 699  string-like-substring");
f_5416(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5379 in k5368 in doloop843 in k5347 in k5344 in gen-string-constant in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 699  c-ify-string");
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k5375 in k5368 in doloop843 in k5347 in k5344 in gen-string-constant in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 699  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_5416(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5416,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5423,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 704  make-string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[334]+1)))(3,*((C_word*)lf[334]+1),t6,t5);}

/* k5421 in string-like-substring in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5426,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 705  ##sys#copy-bytes");
((C_proc7)C_retrieve_symbol_proc(lf[333]))(7,*((C_word*)lf[333]+1),t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5424 in k5421 in string-like-substring in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4621,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4624,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4660,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4740,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t7,a[6]=t1,a[7]=t9,tmp=(C_word)a,a+=8,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4848,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_4848(t14,t10,((C_word*)t0)[2]);}

/* loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4848(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4848,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4861,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 599  lambda-literal-argument-count");
((C_proc3)C_retrieve_symbol_proc(lf[284]))(3,*((C_word*)lf[284]+1),t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4861,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 600  lambda-literal-rest-argument");
((C_proc3)C_retrieve_symbol_proc(lf[280]))(3,*((C_word*)lf[280]+1),t4,((C_word*)t0)[2]);}

/* k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4867,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 601  lambda-literal-rest-argument-mode");
((C_proc3)C_retrieve_symbol_proc(lf[279]))(3,*((C_word*)lf[279]+1),t2,((C_word*)t0)[2]);}

/* k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("c-backend.scm: 602  lambda-literal-id");
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[2]);}

/* k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("c-backend.scm: 603  lambda-literal-customizable");
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t2,((C_word*)t0)[2]);}

/* k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4981,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 604  lambda-literal-closure-size");
((C_proc3)C_retrieve_symbol_proc(lf[147]))(3,*((C_word*)lf[147]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4876(t3,C_SCHEME_FALSE);}}

/* k4979 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4876(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4876,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_4879(t5,t4);}
else{
t3=t2;
f_4879(t3,C_SCHEME_UNDEFINED);}}

/* k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4879,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
C_trace("c-backend.scm: 606  lambda-literal-direct");
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t3,((C_word*)t0)[2]);}

/* k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t3=((C_word*)((C_word*)t0)[14])[1];
f_4848(t3,((C_word*)t0)[13],t2);}
else{
if(C_truep(((C_word*)t0)[12])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4898,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 608  gen");
((C_proc11)C_retrieve_proc(*((C_word*)lf[1]+1)))(11,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[327],((C_word*)t0)[9],lf[328],C_SCHEME_TRUE,lf[329],((C_word*)t0)[9],lf[330]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4926(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 616  lambda-literal-allocated");
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t3,((C_word*)t0)[2]);}}}}

/* k4968 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4926(2,t3,t2);}
else{
C_trace("c-backend.scm: 616  lambda-literal-external");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4924 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4926,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4932,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[246]);
t4=t2;
f_4932(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_4932(t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=((C_word*)((C_word*)t0)[7])[1];
f_4848(t3,((C_word*)t0)[6],t2);}}

/* k4930 in k4924 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4932(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4932,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[331]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 619  lset-adjoin");
((C_proc5)C_retrieve_symbol_proc(lf[274]))(5,*((C_word*)lf[274]+1),t3,*((C_word*)lf[275]+1),((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 620  lset-adjoin");
((C_proc5)C_retrieve_symbol_proc(lf[274]))(5,*((C_word*)lf[274]+1),t3,*((C_word*)lf[275]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4950,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 621  lset-adjoin");
((C_proc5)C_retrieve_symbol_proc(lf[274]))(5,*((C_word*)lf[274]+1),t2,*((C_word*)lf[275]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4948 in k4930 in k4924 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4848(t4,((C_word*)t0)[2],t3);}

/* k4944 in k4930 in k4924 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4848(t4,((C_word*)t0)[2],t3);}

/* k4940 in k4930 in k4924 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4848(t4,((C_word*)t0)[2],t3);}

/* k4896 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 610  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[325],((C_word*)t0)[3],lf[326]);}

/* k4899 in k4896 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 611  restore");
f_4624(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k4902 in k4899 in k4896 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 612  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k4905 in k4902 in k4899 in k4896 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 613  make-argument-list");
((C_proc4)C_retrieve_symbol_proc(lf[291]))(4,*((C_word*)lf[291]+1),t2,((C_word*)((C_word*)t0)[2])[1],lf[324]);}

/* k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4920,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 614  intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,t1,C_make_character(44));}

/* k4918 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k4911 in k4908 in k4905 in k4902 in k4899 in k4896 in k4890 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 615  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[323]);}

/* k4880 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4859 in loop660 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4848(t3,((C_word*)t0)[2],t2);}

/* k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4743,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4803,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4803(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop739 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4803(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4803,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4816,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 625  gen");
((C_proc13)C_retrieve_proc(*((C_word*)lf[1]+1)))(13,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[318],t3,lf[319],C_SCHEME_TRUE,lf[320],t3,lf[321],t3,lf[322]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4814 in loop739 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 627  gen");
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[315],((C_word*)t0)[3],lf[316],((C_word*)t0)[3],lf[317]);}

/* k4817 in k4814 in loop739 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 628  restore");
f_4624(t2,((C_word*)t0)[3]);}

/* k4820 in k4817 in k4814 in loop739 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 629  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[314],((C_word*)t0)[2],C_make_character(44));}

/* k4823 in k4820 in k4817 in k4814 in loop739 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4846,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 630  make-argument-list");
((C_proc4)C_retrieve_symbol_proc(lf[291]))(4,*((C_word*)lf[291]+1),t4,((C_word*)t0)[2],lf[313]);}

/* k4844 in k4823 in k4820 in k4817 in k4814 in loop739 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 630  intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4840 in k4823 in k4820 in k4817 in k4814 in loop739 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k4826 in k4823 in k4820 in k4817 in k4814 in loop739 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 631  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[312]);}

/* k4829 in k4826 in k4823 in k4820 in k4817 in k4814 in loop739 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4803(t3,((C_word*)t0)[2],t2);}

/* k4741 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4746,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4777(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop754 in k4741 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4777(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4777,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4787,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4801,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 633  emitter");
t6=((C_word*)t0)[2];
f_4660(t6,t5,C_SCHEME_FALSE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4799 in loop754 in k4741 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4785 in loop754 in k4741 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4777(t3,((C_word*)t0)[2],t2);}

/* k4744 in k4741 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4746,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4751,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4751(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* loop763 in k4744 in k4741 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4751,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4761,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4775,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 634  emitter");
t6=((C_word*)t0)[2];
f_4660(t6,t5,C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4773 in loop763 in k4744 in k4741 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4759 in loop763 in k4744 in k4741 in k4738 in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4751(t3,((C_word*)t0)[2],t2);}

/* emitter in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4660(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4660,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4662,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_4662 in emitter in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4662,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[307]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[308]);
C_trace("c-backend.scm: 577  gen");
((C_proc14)C_retrieve_proc(*((C_word*)lf[1]+1)))(14,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[309],t2,C_make_character(114),t4,lf[310],C_SCHEME_TRUE,lf[311],t2,C_make_character(114),t5);}

/* k4664 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 579  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[305],((C_word*)t0)[4],lf[306]);}

/* k4667 in k4664 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 580  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[304],((C_word*)t0)[4],C_make_character(114));}

/* k4670 in k4667 in k4664 */
static void C_ccall f_4672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("c-backend.scm: 581  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(118));}
else{
t3=t2;
f_4675(2,t3,C_SCHEME_UNDEFINED);}}

/* k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 582  gen");
((C_proc11)C_retrieve_proc(*((C_word*)lf[1]+1)))(11,*((C_word*)lf[1]+1),t2,lf[300],((C_word*)t0)[4],lf[301],C_SCHEME_TRUE,lf[302],C_SCHEME_TRUE,lf[303],((C_word*)t0)[4],C_make_character(59));}

/* k4676 in k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 585  restore");
f_4624(t2,((C_word*)t0)[4]);}

/* k4679 in k4676 in k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 586  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[299]);}

/* k4682 in k4679 in k4676 in k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 588  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[297]);}
else{
C_trace("c-backend.scm: 589  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[298]);}}

/* k4685 in k4682 in k4679 in k4676 in k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 590  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[296]);}

/* k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 591  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[295]);}
else{
t3=t2;
f_4693(2,t3,C_SCHEME_UNDEFINED);}}

/* k4691 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 592  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[294]);}

/* k4694 in k4691 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 593  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[293]);}

/* k4697 in k4694 in k4691 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4702,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4709,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4713,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
C_trace("c-backend.scm: 594  make-argument-list");
((C_proc4)C_retrieve_symbol_proc(lf[291]))(4,*((C_word*)lf[291]+1),t4,t5,lf[292]);}

/* k4711 in k4697 in k4694 in k4691 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 594  intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4707 in k4697 in k4694 in k4691 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k4700 in k4697 in k4694 in k4691 in k4688 in k4685 in k4682 in k4679 in k4676 in k4673 in k4670 in k4667 in k4664 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 595  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[290]);}

/* restore in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4624(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4624,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4628,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4637,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4637(t8,t3,t4,C_fix(0));}

/* doloop666 in restore in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4637(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4637,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4647,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 572  gen");
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[287],t2,lf[288],t3,lf[289]);}}

/* k4645 in doloop666 in restore in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4637(t4,((C_word*)t0)[2],t2,t3);}

/* k4626 in restore in trampolines in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 573  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[285],((C_word*)t0)[2],lf[286]);}

/* prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4299,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 501  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE);}

/* k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4366(t6,t2,((C_word*)t0)[2]);}

/* loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4366(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4366,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4379,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 504  lambda-literal-argument-count");
((C_proc3)C_retrieve_symbol_proc(lf[284]))(3,*((C_word*)lf[284]+1),t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 505  lambda-literal-customizable");
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t2,((C_word*)t0)[2]);}

/* k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4619,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 506  lambda-literal-closure-size");
((C_proc3)C_retrieve_symbol_proc(lf[147]))(3,*((C_word*)lf[147]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4385(t3,C_SCHEME_FALSE);}}

/* k4617 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4385(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4385(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4385,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4605,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
C_trace("c-backend.scm: 507  make-variable-list");
((C_proc4)C_retrieve_symbol_proc(lf[281]))(4,*((C_word*)lf[281]+1),t3,t4,lf[282]);}
else{
t4=((C_word*)t0)[5];
C_trace("c-backend.scm: 507  make-variable-list");
((C_proc4)C_retrieve_symbol_proc(lf[281]))(4,*((C_word*)lf[281]+1),t3,t4,lf[282]);}}

/* k4603 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 507  intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 508  lambda-literal-id");
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[2]);}

/* k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 509  lambda-literal-rest-argument");
((C_proc3)C_retrieve_symbol_proc(lf[280]))(3,*((C_word*)lf[280]+1),t2,((C_word*)t0)[2]);}

/* k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 510  lambda-literal-rest-argument-mode");
((C_proc3)C_retrieve_symbol_proc(lf[279]))(3,*((C_word*)lf[279]+1),t2,((C_word*)t0)[2]);}

/* k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("c-backend.scm: 511  lambda-literal-direct");
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t2,((C_word*)t0)[2]);}

/* k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("c-backend.scm: 512  lambda-literal-allocated");
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[2]);}

/* k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[273]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4597,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
C_trace("c-backend.scm: 514  lset-adjoin");
((C_proc5)C_retrieve_symbol_proc(lf[274]))(5,*((C_word*)lf[274]+1),t5,*((C_word*)lf[275]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_4406(t5,C_SCHEME_UNDEFINED);}}

/* k4595 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4406(t3,t2);}

/* k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4406(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4406,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
C_trace("c-backend.scm: 515  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4557,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 520  lambda-literal-callee-signatures");
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t3,((C_word*)t0)[2]);}

/* k4555 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4557,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4559,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4559(t5,((C_word*)t0)[2],t1);}

/* loop574 in k4555 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4559,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=C_retrieve(lf[273]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4586,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_fixnum_increase(t3);
C_trace("c-backend.scm: 519  lset-adjoin");
((C_proc5)C_retrieve_symbol_proc(lf[274]))(5,*((C_word*)lf[274]+1),t5,*((C_word*)lf[275]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t10=t1;
t11=t5;
t1=t10;
t2=t11;
goto loop;}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4584 in loop574 in k4555 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4559(t4,((C_word*)t0)[2],t3);}

/* k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_eqp(lf[257],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4531,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[208]))){
C_trace("c-backend.scm: 530  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t4,C_retrieve(lf[208]),lf[264]);}
else{
t5=t4;
f_4531(2,t5,lf[265]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4506,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 522  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t4,lf[271],((C_word*)t0)[5],lf[272],C_SCHEME_TRUE);}}

/* k4504 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 523  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[270]);}

/* k4507 in k4504 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 524  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[268]);}
else{
C_trace("c-backend.scm: 524  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[269]);}}

/* k4510 in k4507 in k4504 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 526  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[266]);}
else{
C_trace("c-backend.scm: 527  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[267]);}}

/* k4513 in k4510 in k4507 in k4504 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 528  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4529 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4534,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 531  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,lf[262],t1,lf[263],C_SCHEME_TRUE);}

/* k4532 in k4529 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[260]))){
C_trace("c-backend.scm: 533  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,lf[261],C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f11595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 534  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,lf[259]);}}

/* f11595 in k4532 in k4529 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f11595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 535  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[258],((C_word*)t0)[2]);}

/* k4535 in k4532 in k4529 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 534  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[259]);}

/* k4538 in k4535 in k4532 in k4529 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 535  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[258],((C_word*)t0)[2]);}

/* k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
C_trace("c-backend.scm: 536  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4421(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 537  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[256]);}}

/* k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4478,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4478(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4478(t4,C_SCHEME_FALSE);}}

/* k4476 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4478,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 539  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[255]);}
else{
t2=((C_word*)t0)[2];
f_4424(2,t2,C_SCHEME_UNDEFINED);}}

/* k4479 in k4476 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 540  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_4424(2,t3,t2);}}

/* k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[4]);}

/* k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[7])){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 543  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,lf[253]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4466,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 551  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,C_make_character(41));}}

/* k4464 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4469,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 554  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_make_character(59));}
else{
C_trace("c-backend.scm: 553  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[254]);}}

/* k4467 in k4464 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 554  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k4438 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[246]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t4=((C_word*)((C_word*)t0)[7])[1];
f_4366(t4,((C_word*)t0)[6],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4449,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 546  gen");
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[249],((C_word*)t0)[2],lf[250],C_SCHEME_TRUE,lf[251],((C_word*)t0)[2],lf[252]);}}

/* k4447 in k4438 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k4450 in k4447 in k4438 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
C_trace("c-backend.scm: 549  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[247],t2,lf[248]);}

/* k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in k4383 in k4380 in k4377 in loop552 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4366(t3,((C_word*)t0)[2],t2);}

/* k4304 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4311,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4311(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* loop634 in k4304 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4311(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4311,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4324,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 558  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[244],t3,lf[245]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4322 in loop634 in k4304 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4341,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 559  make-list");
((C_proc4)C_retrieve_symbol_proc(lf[242]))(4,*((C_word*)lf[242]+1),t3,((C_word*)t0)[2],lf[243]);}

/* k4339 in k4322 in loop634 in k4304 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4341,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4343,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4343(t5,((C_word*)t0)[2],t1);}

/* loop642 in k4339 in k4322 in loop634 in k4304 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4343(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4343,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4353,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("##compiler#gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4351 in loop642 in k4339 in k4322 in loop634 in k4304 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4343(t3,((C_word*)t0)[2],t2);}

/* k4325 in k4322 in loop634 in k4304 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 560  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[241]);}

/* k4328 in k4325 in k4322 in loop634 in k4304 in k4301 in prototypes in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4311(t3,((C_word*)t0)[2],t2);}

/* declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4134(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4134,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4141,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 472  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[240]);}

/* k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4277,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4277(t6,t2,C_retrieve(lf[210]));}

/* loop507 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4277(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4277,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4290,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 475  gen");
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[236],t3,lf[237],C_SCHEME_TRUE,lf[238],t3,lf[239]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4288 in loop507 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4277(t3,((C_word*)t0)[2],t2);}

/* k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4147,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_4147(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 479  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[234],((C_word*)t0)[2],lf[235]);}}

/* k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 480  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[233]);}

/* k4148 in k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4150,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4155,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4155(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* doloop517 in k4148 in k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4155(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4155,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4165,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
C_trace("c-backend.scm: 484  ##sys#lambda-info->string");
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),t4,t5);}}

/* k4163 in doloop517 in k4148 in k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4171,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
C_trace("c-backend.scm: 486  gen");
((C_proc12)C_retrieve_proc(*((C_word*)lf[1]+1)))(12,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[230],((C_word*)t0)[5],lf[231],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k4169 in k4163 in doloop517 in k4148 in k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4224,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4224(t6,t2,C_fix(0));}

/* doloop526 in k4169 in k4163 in doloop517 in k4148 in k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4224(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4224,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4234,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
C_trace("c-backend.scm: 493  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t4,C_make_character(44),t6);}}

/* k4232 in doloop526 in k4169 in k4163 in doloop517 in k4148 in k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4224(t3,((C_word*)t0)[2],t2);}

/* k4172 in k4169 in k4163 in doloop517 in k4148 in k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_fixnum_and(C_fix(16777208),t3);
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4197,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4197(t9,t2,t5);}

/* doloop533 in k4172 in k4169 in k4163 in doloop517 in k4148 in k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4197(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4197,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4207,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 496  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t4,lf[229]);}}

/* k4205 in doloop533 in k4172 in k4169 in k4163 in doloop517 in k4148 in k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4197(t3,((C_word*)t0)[2],t2);}

/* k4175 in k4172 in k4169 in k4163 in doloop517 in k4148 in k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 497  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[228]);}

/* k4178 in k4175 in k4172 in k4169 in k4163 in doloop517 in k4148 in k4145 in k4142 in k4139 in declarations in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4155(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_3971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3971,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3974,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3991,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4126,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 438  current-seconds");
((C_proc2)C_retrieve_symbol_proc(lf[227]))(2,*((C_word*)lf[227]+1),t4);}

/* k4124 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 438  ##sys#decode-seconds");
((C_proc4)C_retrieve_symbol_proc(lf[226]))(4,*((C_word*)lf[226]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=(C_word)C_i_vector_ref(t1,C_fix(2));
t4=(C_word)C_i_vector_ref(t1,C_fix(3));
t5=(C_word)C_i_vector_ref(t1,C_fix(4));
t6=(C_word)C_i_vector_ref(t1,C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4084,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
C_trace("c-backend.scm: 446  pad0");
f_3974(t9,t10);}

/* k4082 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 446  pad0");
f_3974(t2,((C_word*)t0)[2]);}

/* k4086 in k4082 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 446  pad0");
f_3974(t2,((C_word*)t0)[2]);}

/* k4090 in k4086 in k4082 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4096,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 446  pad0");
f_3974(t2,((C_word*)t0)[2]);}

/* k4094 in k4090 in k4086 in k4082 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4100,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4104,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4106,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4114,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4118,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 449  chicken-version");
((C_proc3)C_retrieve_symbol_proc(lf[225]))(3,*((C_word*)lf[225]+1),t6,C_SCHEME_TRUE);}

/* k4116 in k4094 in k4090 in k4086 in k4082 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 449  string-split");
((C_proc4)C_retrieve_symbol_proc(lf[223]))(4,*((C_word*)lf[223]+1),((C_word*)t0)[2],t1,lf[224]);}

/* k4112 in k4094 in k4090 in k4086 in k4082 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[222]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4105 in k4094 in k4090 in k4086 in k4082 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4106,3,t0,t1,t2);}
C_trace("string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),t1,lf[220],t2,lf[221]);}

/* k4102 in k4094 in k4090 in k4086 in k4082 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 447  string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[218]))(4,*((C_word*)lf[218]+1),((C_word*)t0)[2],t1,lf[219]);}

/* k4098 in k4094 in k4090 in k4086 in k4082 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 444  gen");
((C_proc21)C_retrieve_proc(*((C_word*)lf[1]+1)))(21,*((C_word*)lf[1]+1),((C_word*)t0)[8],lf[213],((C_word*)t0)[7],lf[214],C_SCHEME_TRUE,lf[215],C_SCHEME_TRUE,lf[216],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[217]);}

/* k4007 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 452  gen-list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),t2,C_retrieve(lf[212]));}

/* k4010 in k4007 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 453  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4013 in k4010 in k4007 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[208]))){
C_trace("c-backend.scm: 454  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,lf[209],C_retrieve(lf[208]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4073,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 456  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,lf[211]);}}

/* k4071 in k4013 in k4010 in k4007 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 457  gen-list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),((C_word*)t0)[2],C_retrieve(lf[210]));}

/* k4016 in k4013 in k4010 in k4007 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 458  gen");
((C_proc9)C_retrieve_proc(*((C_word*)lf[1]+1)))(9,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[204],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[205],C_retrieve(lf[206]),lf[207]);}

/* k4019 in k4016 in k4013 in k4010 in k4007 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4024,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[200]))){
C_trace("c-backend.scm: 460  generate-foreign-callback-stub-prototypes");
((C_proc3)C_retrieve_symbol_proc(lf[201]))(3,*((C_word*)lf[201]+1),t2,C_retrieve(lf[202]));}
else{
t3=t2;
f_4024(2,t3,C_SCHEME_UNDEFINED);}}

/* k4022 in k4019 in k4016 in k4013 in k4010 in k4007 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[203])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4039,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 462  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
if(C_truep(C_retrieve(lf[200]))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
C_trace("c-backend.scm: 465  generate-foreign-callback-stub-prototypes");
((C_proc3)C_retrieve_symbol_proc(lf[201]))(3,*((C_word*)lf[201]+1),((C_word*)t0)[2],C_retrieve(lf[202]));}}}

/* k4037 in k4022 in k4019 in k4016 in k4013 in k4010 in k4007 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4039,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4044,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4044(t5,((C_word*)t0)[2],C_retrieve(lf[203]));}

/* loop485 in k4037 in k4022 in k4019 in k4016 in k4013 in k4010 in k4007 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_4044(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4044,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4057,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 463  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4055 in loop485 in k4037 in k4022 in k4019 in k4016 in k4013 in k4010 in k4007 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4044(t3,((C_word*)t0)[2],t2);}

/* k4025 in k4022 in k4019 in k4016 in k4013 in k4010 in k4007 in k3989 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve(lf[200]))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
C_trace("c-backend.scm: 465  generate-foreign-callback-stub-prototypes");
((C_proc3)C_retrieve_symbol_proc(lf[201]))(3,*((C_word*)lf[201]+1),((C_word*)t0)[2],C_retrieve(lf[202]));}}

/* pad0 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_3974(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3974,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3988,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 436  number->string");
C_number_to_string(3,0,t4,t2);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3986 in pad0 in header in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 436  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),((C_word*)t0)[2],lf[199],t1);}

/* expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_2398(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2398,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3939,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
C_trace("c-backend.scm: 431  expr");
t11=((C_word*)t6)[1];
f_2401(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_3939(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3939,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3945,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 425  pair-for-each");
((C_proc4)C_retrieve_symbol_proc(lf[198]))(4,*((C_word*)lf[198]+1),t1,t4,t2);}

/* a3944 in expr-args in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3945,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3949,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t2);
C_trace("c-backend.scm: 428  expr");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2401(t6,t1,t5,((C_word*)t0)[3]);}
else{
C_trace("c-backend.scm: 427  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}}

/* k3947 in a3944 in expr-args in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 428  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2401(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_2401(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2401,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[12]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t11,lf[13]);
if(C_truep(t12)){
if(C_truep((C_word)C_i_cadr(t7))){
C_trace("c-backend.scm: 84   gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t1,lf[14]);}
else{
C_trace("c-backend.scm: 84   gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t1,lf[15]);}}
else{
t13=(C_word)C_eqp(t11,lf[16]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t7);
t15=(C_word)C_fix((C_word)C_character_code(t14));
C_trace("c-backend.scm: 85   gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[17],t15,C_make_character(41));}
else{
t14=(C_word)C_eqp(t11,lf[18]);
if(C_truep(t14)){
C_trace("c-backend.scm: 86   gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t1,lf[19]);}
else{
t15=(C_word)C_eqp(t11,lf[20]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t7);
C_trace("c-backend.scm: 87   gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[21],t16,C_make_character(41));}
else{
t16=(C_word)C_eqp(t11,lf[22]);
if(C_truep(t16)){
C_trace("c-backend.scm: 88   gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t1,lf[23]);}
else{
C_trace("c-backend.scm: 89   bomb");
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t1,lf[24]);}}}}}}
else{
t11=(C_word)C_eqp(t9,lf[25]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_vectorp(t12))){
t13=(C_word)C_i_vector_ref(t12,C_fix(0));
C_trace("c-backend.scm: 94   gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[26],t13,lf[27]);}
else{
t13=(C_word)C_i_car(t7);
C_trace("c-backend.scm: 95   gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[28],t13,C_make_character(93));}}
else{
t12=(C_word)C_eqp(t9,lf[29]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2525,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 98   gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t13,C_SCHEME_TRUE,lf[32]);}
else{
t13=(C_word)C_eqp(t9,lf[33]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
C_trace("c-backend.scm: 107  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t1,lf[34],t14);}
else{
t14=(C_word)C_eqp(t9,lf[35]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[5],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_2583(t19,t1,t5,t3,t15);}
else{
t15=(C_word)C_eqp(t9,lf[36]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2634,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 119  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t16,lf[38]);}
else{
t16=(C_word)C_eqp(t9,lf[39]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2661,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 124  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t17,lf[41]);}
else{
t17=(C_word)C_eqp(t9,lf[42]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2680,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 129  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t18,lf[43]);}
else{
t18=(C_word)C_eqp(t9,lf[44]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2713,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 136  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t19,lf[47]);}
else{
t19=(C_word)C_eqp(t9,lf[48]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2750,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 143  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t20,lf[50]);}
else{
t20=(C_word)C_eqp(t9,lf[51]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2779,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 150  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t21,lf[53]);}
else{
t21=(C_word)C_eqp(t9,lf[54]);
if(C_truep(t21)){
t22=(C_word)C_i_car(t7);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2811,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t22,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 158  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t23,lf[61],t22,C_make_character(44));}
else{
t22=(C_word)C_eqp(t9,lf[62]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2846,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 168  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t23,lf[64]);}
else{
t23=(C_word)C_eqp(t9,lf[65]);
if(C_truep(t23)){
t24=(C_word)C_i_car(t7);
C_trace("c-backend.scm: 172  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t1,C_make_character(116),t24);}
else{
t24=(C_word)C_eqp(t9,lf[66]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2878,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(t7);
C_trace("c-backend.scm: 175  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t25,C_make_character(116),t26,C_make_character(61));}
else{
t25=(C_word)C_eqp(t9,lf[67]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t7);
t27=(C_word)C_i_cadr(t7);
if(C_truep((C_word)C_i_caddr(t7))){
if(C_truep(t27)){
C_trace("c-backend.scm: 184  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[68],t26,lf[69]);}
else{
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2920,a[2]=t26,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2924,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(C_word)C_i_cadddr(t7);
C_trace("c-backend.scm: 185  symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t29,t30);}}
else{
if(C_truep(t27)){
C_trace("c-backend.scm: 186  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[74],t26,lf[75]);}
else{
C_trace("c-backend.scm: 187  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[76],t26,lf[77]);}}}
else{
t26=(C_word)C_eqp(t9,lf[78]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t7);
t28=(C_word)C_i_cadr(t7);
t29=(C_word)C_i_caddr(t7);
t30=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2955,a[2]=t29,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t28)){
C_trace("c-backend.scm: 194  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t30,lf[84],t27,lf[85]);}
else{
C_trace("c-backend.scm: 195  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t30,lf[86],t27,lf[87]);}}
else{
t27=(C_word)C_eqp(t9,lf[88]);
if(C_truep(t27)){
t28=(C_word)C_i_car(t7);
t29=(C_word)C_i_cadr(t7);
t30=(C_word)C_i_caddr(t7);
if(C_truep(t29)){
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3003,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3017,a[2]=t28,a[3]=t31,tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3021,a[2]=t32,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 206  symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t33,t30);}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3024,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3038,a[2]=t28,a[3]=t31,tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3042,a[2]=t32,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 211  symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t33,t30);}}
else{
t28=(C_word)C_eqp(t9,lf[97]);
if(C_truep(t28)){
C_trace("c-backend.scm: 215  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t1,lf[98]);}
else{
t29=(C_word)C_eqp(t9,lf[99]);
if(C_truep(t29)){
t30=(C_word)C_i_cdr(t5);
t31=(C_word)C_i_length(t30);
t32=t3;
t33=(C_word)C_fixnum_increase(t31);
t34=(C_word)C_i_cdr(t7);
t35=(C_word)C_i_pairp(t34);
t36=(C_truep(t35)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t37=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3075,a[2]=t35,a[3]=((C_word*)t0)[2],a[4]=t36,a[5]=t32,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=t31,a[9]=t33,a[10]=t3,a[11]=t30,a[12]=((C_word*)t0)[4],a[13]=t1,a[14]=t5,a[15]=t7,tmp=(C_word)a,a+=16,tmp);
C_trace("c-backend.scm: 224  source-info->string");
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),t37,t36);}
else{
t30=(C_word)C_eqp(t9,lf[149]);
if(C_truep(t30)){
t31=(C_word)C_i_length(t5);
t32=(C_word)C_fixnum_increase(t31);
t33=(C_word)C_i_car(t7);
t34=(C_word)C_i_cadr(t7);
t35=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3499,a[2]=t34,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t32,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=t31,a[10]=t1,a[11]=t33,tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 308  lambda-literal-closure-size");
((C_proc3)C_retrieve_symbol_proc(lf[147]))(3,*((C_word*)lf[147]+1),t35,((C_word*)t0)[3]);}
else{
t31=(C_word)C_eqp(t9,lf[153]);
if(C_truep(t31)){
t32=(C_word)C_i_cdr(t5);
t33=(C_word)C_i_length(t32);
t34=(C_word)C_fixnum_increase(t33);
t35=(C_word)C_i_caddr(t7);
t36=(C_word)C_i_cadddr(t7);
t37=(C_word)C_eqp(t36,C_fix(0));
t38=(C_word)C_i_not(t37);
t39=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3584,a[2]=t35,a[3]=t36,a[4]=t38,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t32,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3588,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 336  find-lambda");
t41=((C_word*)t0)[2];
f_2356(t41,t40,t35);}
else{
t32=(C_word)C_eqp(t9,lf[155]);
if(C_truep(t32)){
t33=(C_word)C_i_length(t5);
t34=(C_word)C_fixnum_plus(t33,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3607,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
C_trace("c-backend.scm: 353  gen");
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t35,C_SCHEME_TRUE,lf[157],t36,lf[158],t34,lf[159]);}
else{
t33=(C_word)C_eqp(t9,lf[160]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3626,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 358  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t34,C_SCHEME_TRUE,lf[162]);}
else{
t34=(C_word)C_eqp(t9,lf[163]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3645,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
C_trace("c-backend.scm: 363  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t35,lf[164],t36,C_make_character(40));}
else{
t35=(C_word)C_eqp(t9,lf[165]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3664,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=(C_word)C_i_car(t7);
t38=(C_word)C_i_length(t5);
C_trace("c-backend.scm: 368  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t36,lf[166],t37,lf[167],t38);}
else{
t36=(C_word)C_eqp(t9,lf[168]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3700,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t38=(C_word)C_i_cadr(t7);
C_trace("c-backend.scm: 376  foreign-result-conversion");
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t37,t38,lf[170]);}
else{
t37=(C_word)C_eqp(t9,lf[171]);
if(C_truep(t37)){
t38=(C_word)C_i_cadr(t7);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3720,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3738,a[2]=t38,a[3]=t40,a[4]=t39,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 380  foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t41,t38,lf[176]);}
else{
t38=(C_word)C_eqp(t9,lf[177]);
if(C_truep(t38)){
t39=(C_word)C_i_car(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3754,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3768,a[2]=t39,a[3]=t40,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 386  foreign-result-conversion");
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t41,t39,lf[182]);}
else{
t39=(C_word)C_eqp(t9,lf[183]);
if(C_truep(t39)){
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3784,a[2]=t40,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3812,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 392  foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t42,t40,lf[188]);}
else{
t40=(C_word)C_eqp(t9,lf[189]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3821,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 399  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t41,C_SCHEME_TRUE,lf[193]);}
else{
t41=(C_word)C_eqp(t9,lf[194]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3904,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 414  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t42,lf[196]);}
else{
C_trace("c-backend.scm: 422  bomb");
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t1,lf[197]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k3902 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 415  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3905 in k3902 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 416  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[195]);}

/* k3908 in k3905 in k3902 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 417  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3911 in k3908 in k3905 in k3902 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 418  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k3914 in k3911 in k3908 in k3905 in k3902 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 419  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 420  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3819 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 400  expr");
t4=((C_word*)((C_word*)t0)[4])[1];
f_2401(t4,t2,t3,((C_word*)t0)[3]);}

/* k3822 in k3819 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 401  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[192]);}

/* k3825 in k3822 in k3819 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3827,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3840,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3840(t7,((C_word*)t0)[2],t2,t3);}

/* doloop428 in k3825 in k3822 in k3819 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_3840(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3840,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3850,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 405  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[190]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 408  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[191]);}}

/* k3861 in doloop428 in k3825 in k3822 in k3819 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
C_trace("c-backend.scm: 409  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3864 in k3861 in doloop428 in k3825 in k3822 in k3819 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 410  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k3867 in k3864 in k3861 in doloop428 in k3825 in k3822 in k3819 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3872,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
C_trace("c-backend.scm: 411  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3870 in k3867 in k3864 in k3861 in doloop428 in k3825 in k3822 in k3819 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3840(t4,((C_word*)t0)[2],t2,t3);}

/* k3848 in doloop428 in k3825 in k3822 in k3819 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 406  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3851 in k3848 in doloop428 in k3825 in k3822 in k3819 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 407  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* k3810 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 392  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[186],t1,lf[187]);}

/* k3782 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 393  expr");
t4=((C_word*)((C_word*)t0)[4])[1];
f_2401(t4,t2,t3,((C_word*)t0)[3]);}

/* k3785 in k3782 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3804,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 394  foreign-argument-conversion");
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t3,((C_word*)t0)[2]);}

/* k3802 in k3785 in k3782 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 394  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[185],t1);}

/* k3788 in k3785 in k3782 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3793,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 395  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3791 in k3788 in k3785 in k3782 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 396  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[184]);}

/* k3766 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3772,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 386  foreign-type-declaration");
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t2,((C_word*)t0)[2],lf[181]);}

/* k3770 in k3766 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 386  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[179],t1,lf[180]);}

/* k3752 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 387  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3755 in k3752 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 388  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[178]);}

/* k3736 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3742,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 380  foreign-argument-conversion");
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t2,((C_word*)t0)[2]);}

/* k3740 in k3736 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 380  gen");
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[173],((C_word*)t0)[2],C_make_character(41),t1);}

/* k3718 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 381  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3721 in k3718 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 382  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[172]);}

/* k3698 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("c-backend.scm: 376  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k3662 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 371  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}
else{
C_trace("c-backend.scm: 373  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_make_character(41));}}

/* k3674 in k3662 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 372  expr-args");
t2=((C_word*)((C_word*)t0)[5])[1];
f_3939(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3665 in k3662 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 373  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3643 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3648,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 364  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3939(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3646 in k3643 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 365  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3624 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3629,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 359  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3627 in k3624 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 360  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[161]);}

/* k3605 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 354  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3939(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3608 in k3605 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 355  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[156]);}

/* k3586 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 336  lambda-literal-closure-size");
((C_proc3)C_retrieve_symbol_proc(lf[147]))(3,*((C_word*)lf[147]+1),((C_word*)t0)[2],t1);}

/* k3582 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3584,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 338  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t4,((C_word*)t0)[2],C_make_character(40));}

/* k3530 in k3582 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3535,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 340  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,lf[154],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_3535(2,t3,C_SCHEME_UNDEFINED);}}

/* k3563 in k3530 in k3582 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
if(C_truep(t2)){
if(C_truep(t2)){
C_trace("c-backend.scm: 341  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_make_character(44));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_3535(2,t4,t3);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
C_trace("c-backend.scm: 341  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_make_character(44));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_3535(2,t4,t3);}}}

/* k3533 in k3530 in k3582 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3538,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_3538(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3553,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 343  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k3551 in k3533 in k3530 in k3582 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 344  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3538(2,t3,t2);}}

/* k3536 in k3533 in k3530 in k3582 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3541,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
C_trace("c-backend.scm: 345  expr-args");
t3=((C_word*)((C_word*)t0)[3])[1];
f_3939(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
C_trace("c-backend.scm: 346  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_make_character(41));}}

/* k3539 in k3536 in k3533 in k3530 in k3582 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 346  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 310  lambda-literal-temporaries");
((C_proc3)C_retrieve_symbol_proc(lf[105]))(3,*((C_word*)lf[105]+1),t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3483,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 323  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t3,((C_word*)t0)[2],C_make_character(40));}}

/* k3481 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11560,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 325  expr-args");
t4=((C_word*)((C_word*)t0)[5])[1];
f_3939(t4,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
C_trace("c-backend.scm: 324  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[152]);}}

/* f11560 in k3481 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f11560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 326  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3484 in k3481 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3489,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 325  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3939(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3487 in k3484 in k3481 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 326  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3440 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
C_trace("c-backend.scm: 311  iota");
((C_proc5)C_retrieve_symbol_proc(lf[60]))(5,*((C_word*)lf[60]+1),t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k3443 in k3440 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 312  for-each");
((C_proc5)C_retrieve_proc(*((C_word*)lf[59]+1)))(5,*((C_word*)lf[59]+1),t2,t3,((C_word*)t0)[2],t1);}

/* a3465 in k3443 in k3440 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3466,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3470,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 314  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3468 in a3465 in k3443 in k3440 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 315  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2401(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3471 in k3468 in a3465 in k3443 in k3440 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 316  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3446 in k3443 in k3440 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3456,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 320  iota");
((C_proc5)C_retrieve_symbol_proc(lf[60]))(5,*((C_word*)lf[60]+1),t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3462 in k3446 in k3443 in k3440 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 318  for-each");
((C_proc5)C_retrieve_proc(*((C_word*)lf[59]+1)))(5,*((C_word*)lf[59]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3455 in k3446 in k3443 in k3440 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3456,4,t0,t1,t2,t3);}
C_trace("c-backend.scm: 319  gen");
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[151],t2,C_make_character(59));}

/* k3449 in k3446 in k3443 in k3440 in k3497 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 321  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[150]);}

/* k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3078,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[15]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_3078(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3078(t3,C_SCHEME_FALSE);}}

/* k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_3078(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3078,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[15]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3084,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3388,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3392,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 227  find-lambda");
t6=((C_word*)t0)[2];
f_2356(t6,t5,t1);}
else{
t4=t3;
f_3084(t4,C_SCHEME_FALSE);}}

/* k3390 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 227  lambda-literal-closure-size");
((C_proc3)C_retrieve_symbol_proc(lf[147]))(3,*((C_word*)lf[147]+1),((C_word*)t0)[2],t1);}

/* k3386 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3084(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_3084(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3084,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3090,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(C_retrieve(lf[138]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3374,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2386,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 71   ->string");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3381,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11556,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 72   ->string");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t6,t5);}}
else{
t4=t3;
f_3090(2,t4,C_SCHEME_UNDEFINED);}}

/* f11556 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f11556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 72   string-translate*");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1,lf[146]);}

/* k3379 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 232  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[144],t1,lf[145]);}

/* k2384 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 71   string-translate");
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),((C_word*)t0)[2],t1,lf[142],lf[143]);}

/* k3372 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 231  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[139],t1,lf[140]);}

/* k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3090,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t3=(C_word)C_eqp(lf[33],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t4);
C_trace("c-backend.scm: 235  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[101]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3211,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 239  lambda-literal-id");
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3217,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t6=(C_word)C_eqp(lf[67],t5);
if(C_truep(t6)){
t7=C_retrieve(lf[130]);
if(C_truep(t7)){
t8=t4;
f_3217(t8,C_SCHEME_FALSE);}
else{
t8=C_retrieve(lf[135]);
if(C_truep(t8)){
t9=t4;
f_3217(t9,C_SCHEME_FALSE);}
else{
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=t4;
f_3217(t10,(C_word)C_i_not(t9));}}}
else{
t7=t4;
f_3217(t7,C_SCHEME_FALSE);}}}}

/* k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_3217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3217,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3232,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 273  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t8,C_SCHEME_TRUE,lf[125],((C_word*)t0)[5],lf[126]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 292  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}

/* k3299 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 293  expr");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2401(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k3302 in k3299 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 294  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_make_character(59),C_SCHEME_TRUE,lf[136],((C_word*)t0)[4],lf[137]);}

/* k3305 in k3302 in k3299 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[130]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3322,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3322(t5,t3);}
else{
t5=C_retrieve(lf[135]);
t6=t4;
f_3322(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k3320 in k3305 in k3302 in k3299 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_3322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("c-backend.scm: 297  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[131],((C_word*)t0)[2],lf[132]);}
else{
C_trace("c-backend.scm: 298  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[133],((C_word*)t0)[2],lf[134]);}}

/* k3308 in k3305 in k3302 in k3299 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 299  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,lf[128],((C_word*)t0)[3],lf[129],((C_word*)t0)[2],C_make_character(44));}

/* k3311 in k3308 in k3305 in k3302 in k3299 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 300  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3939(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 301  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[127]);}

/* k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3248,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3273,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 275  number->string");
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3280,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3287,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 282  number->string");
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3298,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 286  number->string");
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}}}

/* k3296 in k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 286  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),((C_word*)t0)[2],lf[123],t1,lf[124]);}

/* k3289 in k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
C_trace("c-backend.scm: 287  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[121],((C_word*)t0)[2],lf[122]);}

/* k3285 in k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 282  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),((C_word*)t0)[2],lf[119],t1,lf[120]);}

/* k3278 in k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
C_trace("c-backend.scm: 283  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[117],((C_word*)((C_word*)t0)[3])[1],lf[118]);}

/* k3271 in k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 275  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[114]+1)))(5,*((C_word*)lf[114]+1),((C_word*)t0)[2],lf[115],t1,lf[116]);}

/* k3246 in k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3248,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
C_trace("c-backend.scm: 277  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[110],((C_word*)((C_word*)t0)[5])[1],lf[111]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3261,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3265,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
C_trace("c-backend.scm: 279  symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t4,t5);}}

/* k3263 in k3246 in k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 279  c-ify-string");
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k3259 in k3246 in k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 278  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[112],((C_word*)((C_word*)t0)[2])[1],lf[113],t1,C_make_character(41));}

/* k3233 in k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 288  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,lf[109],((C_word*)t0)[3],C_make_character(44),((C_word*)((C_word*)t0)[2])[1],C_make_character(44));}

/* k3236 in k3233 in k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3241,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 289  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3939(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3239 in k3236 in k3233 in k3230 in k3215 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 290  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[108]);}

/* k3209 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
C_trace("c-backend.scm: 240  lambda-literal-looping");
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_3121(2,t3,C_SCHEME_FALSE);}}

/* k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3121,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3124,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 241  lambda-literal-temporaries");
((C_proc3)C_retrieve_symbol_proc(lf[105]))(3,*((C_word*)lf[105]+1),t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3171(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3195,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 256  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k3193 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3198,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 257  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2401(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3196 in k3193 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 258  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3169 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 259  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3172 in k3169 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3177,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3177(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 260  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(44));}}

/* k3175 in k3172 in k3169 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11551,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 262  expr-args");
t4=((C_word*)((C_word*)t0)[6])[1];
f_3939(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
C_trace("c-backend.scm: 261  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* f11551 in k3175 in k3172 in k3169 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f11551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 263  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[106]);}

/* k3178 in k3175 in k3172 in k3169 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 262  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3939(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3181 in k3178 in k3175 in k3172 in k3169 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 263  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[106]);}

/* k3122 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
C_trace("c-backend.scm: 242  iota");
((C_proc5)C_retrieve_symbol_proc(lf[60]))(5,*((C_word*)lf[60]+1),t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k3125 in k3122 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3130,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 243  for-each");
((C_proc5)C_retrieve_proc(*((C_word*)lf[59]+1)))(5,*((C_word*)lf[59]+1),t2,t3,((C_word*)t0)[2],t1);}

/* a3153 in k3125 in k3122 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3154,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 245  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3156 in a3153 in k3125 in k3122 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 246  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2401(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3159 in k3156 in a3153 in k3125 in k3122 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 247  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3128 in k3125 in k3122 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3133,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3144,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3152,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 251  iota");
((C_proc5)C_retrieve_symbol_proc(lf[60]))(5,*((C_word*)lf[60]+1),t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3150 in k3128 in k3125 in k3122 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 249  for-each");
((C_proc5)C_retrieve_proc(*((C_word*)lf[59]+1)))(5,*((C_word*)lf[59]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3143 in k3128 in k3125 in k3122 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3144,4,t0,t1,t2,t3);}
C_trace("c-backend.scm: 250  gen");
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[104],t2,C_make_character(59));}

/* k3131 in k3128 in k3125 in k3122 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("c-backend.scm: 253  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[102]);}
else{
C_trace("c-backend.scm: 252  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[103],((C_word*)t0)[2],C_make_character(59));}}

/* k3134 in k3131 in k3128 in k3125 in k3122 in k3119 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 253  gen");
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[102]);}

/* k3100 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 236  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3939(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3103 in k3100 in k3088 in k3082 in k3076 in k3073 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 237  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[100]);}

/* k3040 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11547,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 72   ->string");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t1);}

/* f11547 in k3040 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f11547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 72   string-translate*");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1,lf[96]);}

/* k3036 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 210  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[93],((C_word*)t0)[2],lf[94],t1,lf[95]);}

/* k3022 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 212  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3025 in k3022 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 213  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3019 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11542,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 72   ->string");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t1);}

/* f11542 in k3019 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f11542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 72   string-translate*");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1,lf[92]);}

/* k3015 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 205  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[89],((C_word*)t0)[2],lf[90],t1,lf[91]);}

/* k3001 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 207  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k3004 in k3001 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 208  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k2953 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2972,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 196  symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t4,((C_word*)t0)[2]);}

/* k2974 in k2953 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11537,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 72   ->string");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t1);}

/* f11537 in k2974 in k2953 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f11537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 72   string-translate*");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1,lf[82]);}

/* k2970 in k2953 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 196  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[79],t1,lf[80]);}

/* k2956 in k2953 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2961,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 197  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2959 in k2956 in k2953 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 198  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2922 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 185  c-ify-string");
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k2918 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 185  gen");
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[70],((C_word*)t0)[2],lf[71],t1,C_make_character(41));}

/* k2876 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 176  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2401(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2844 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2849,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 169  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2847 in k2844 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 170  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[63]);}

/* k2809 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2814,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2837,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 164  iota");
((C_proc5)C_retrieve_symbol_proc(lf[60]))(5,*((C_word*)lf[60]+1),t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k2835 in k2809 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 159  for-each");
((C_proc5)C_retrieve_proc(*((C_word*)lf[59]+1)))(5,*((C_word*)lf[59]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2822 in k2809 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2823,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 161  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t4,lf[57],t3,lf[58]);}

/* k2825 in a2822 in k2809 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 162  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2401(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2828 in k2825 in a2822 in k2809 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 163  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}

/* k2812 in k2809 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
C_trace("c-backend.scm: 165  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[55],t2,lf[56]);}

/* k2777 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 151  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2780 in k2777 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 152  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[52]);}

/* k2783 in k2780 in k2777 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 153  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2786 in k2783 in k2780 in k2777 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 154  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2748 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 144  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2751 in k2748 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 145  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[49]);}

/* k2754 in k2751 in k2748 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2759,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 146  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2757 in k2754 in k2751 in k2748 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 147  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2711 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 137  expr");
t4=((C_word*)((C_word*)t0)[4])[1];
f_2401(t4,t2,t3,((C_word*)t0)[3]);}

/* k2714 in k2711 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2719,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
C_trace("c-backend.scm: 138  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[45],t4,lf[46]);}

/* k2717 in k2714 in k2711 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 139  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2720 in k2717 in k2714 in k2711 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 140  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2678 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 130  expr");
t4=((C_word*)((C_word*)t0)[4])[1];
f_2401(t4,t2,t3,((C_word*)t0)[3]);}

/* k2681 in k2678 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("c-backend.scm: 131  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_make_character(44),t3,C_make_character(44));}

/* k2684 in k2681 in k2678 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 132  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2687 in k2684 in k2681 in k2678 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 133  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2659 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 125  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2662 in k2659 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 126  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[40]);}

/* k2632 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 120  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2635 in k2632 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
C_trace("c-backend.scm: 121  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[37],t3,C_make_character(93));}

/* loop in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_2583(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2583,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 112  gen");
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
C_trace("c-backend.scm: 116  expr");
t7=((C_word*)((C_word*)t0)[2])[1];
f_2401(t7,t1,t6,t3);}}

/* k2591 in loop in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
C_trace("c-backend.scm: 113  expr");
t4=((C_word*)((C_word*)t0)[2])[1];
f_2401(t4,t2,t3,((C_word*)t0)[6]);}

/* k2594 in k2591 in loop in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 114  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(59));}

/* k2597 in k2594 in k2591 in loop in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
C_trace("c-backend.scm: 115  loop");
t5=((C_word*)((C_word*)t0)[3])[1];
f_2583(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k2523 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 99   expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2526 in k2523 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 100  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[31]);}

/* k2529 in k2526 in k2523 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 101  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2532 in k2529 in k2526 in k2523 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 102  gen");
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_make_character(125),C_SCHEME_TRUE,lf[30]);}

/* k2535 in k2532 in k2529 in k2526 in k2523 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 103  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2401(t4,t2,t3,((C_word*)t0)[2]);}

/* k2538 in k2535 in k2532 in k2529 in k2526 in k2523 in expr in expression in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 104  gen");
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* find-lambda in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_2356(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2356,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2360,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2368,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 68   find");
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t3,t4,((C_word*)t0)[2]);}

/* a2367 in find-lambda in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2368,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 68   lambda-literal-id");
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t3,t2);}

/* k2374 in a2367 in find-lambda in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k2358 in find-lambda in ##compiler#generate-code in k2349 in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
C_trace("c-backend.scm: 69   bomb");
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[9],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2317,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2325,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 50   intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,t2,C_make_character(32));}

/* k2323 in ##compiler#gen-list in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2325,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2327,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2327(t5,((C_word*)t0)[2],t1);}

/* loop46 in k2323 in ##compiler#gen-list in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2327,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2340,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 49   display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t4,t3,*((C_word*)lf[0]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2338 in loop46 in k2323 in ##compiler#gen-list in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2327(t3,((C_word*)t0)[2],t2);}

/* ##compiler#gen in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2280r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2280r(t0,t1,t2);}}

static void C_ccall f_2280r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2286,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2286(t6,t1,t2);}

/* loop34 in ##compiler#gen in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_fcall f_2286(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2286,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2299,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t3);
if(C_truep(t5)){
C_trace("c-backend.scm: 43   newline");
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t4,*((C_word*)lf[0]+1));}
else{
C_trace("c-backend.scm: 44   display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t4,t3,*((C_word*)lf[0]+1));}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2297 in loop34 in ##compiler#gen in k2275 in k2272 in k2269 in k2266 in k2263 in k2260 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2286(t3,((C_word*)t0)[2],t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[767] = {
{"toplevel:c_backend_scm",(void*)C_backend_toplevel},
{"f_2262:c_backend_scm",(void*)f_2262},
{"f_2265:c_backend_scm",(void*)f_2265},
{"f_2268:c_backend_scm",(void*)f_2268},
{"f_2271:c_backend_scm",(void*)f_2271},
{"f_2274:c_backend_scm",(void*)f_2274},
{"f_2277:c_backend_scm",(void*)f_2277},
{"f_9506:c_backend_scm",(void*)f_9506},
{"f_9509:c_backend_scm",(void*)f_9509},
{"f_9536:c_backend_scm",(void*)f_9536},
{"f_9532:c_backend_scm",(void*)f_9532},
{"f_9512:c_backend_scm",(void*)f_9512},
{"f_9515:c_backend_scm",(void*)f_9515},
{"f_9528:c_backend_scm",(void*)f_9528},
{"f_9518:c_backend_scm",(void*)f_9518},
{"f_9521:c_backend_scm",(void*)f_9521},
{"f_9524:c_backend_scm",(void*)f_9524},
{"f_2351:c_backend_scm",(void*)f_2351},
{"f_9206:c_backend_scm",(void*)f_9206},
{"f_9482:c_backend_scm",(void*)f_9482},
{"f_9480:c_backend_scm",(void*)f_9480},
{"f_9468:c_backend_scm",(void*)f_9468},
{"f_9438:c_backend_scm",(void*)f_9438},
{"f_9399:c_backend_scm",(void*)f_9399},
{"f_9386:c_backend_scm",(void*)f_9386},
{"f_9382:c_backend_scm",(void*)f_9382},
{"f_9268:c_backend_scm",(void*)f_9268},
{"f_9215:c_backend_scm",(void*)f_9215},
{"f_8604:c_backend_scm",(void*)f_8604},
{"f_8715:c_backend_scm",(void*)f_8715},
{"f_8880:c_backend_scm",(void*)f_8880},
{"f_8902:c_backend_scm",(void*)f_8902},
{"f_9080:c_backend_scm",(void*)f_9080},
{"f_9083:c_backend_scm",(void*)f_9083},
{"f_9086:c_backend_scm",(void*)f_9086},
{"f_9089:c_backend_scm",(void*)f_9089},
{"f_9059:c_backend_scm",(void*)f_9059},
{"f_9062:c_backend_scm",(void*)f_9062},
{"f_9065:c_backend_scm",(void*)f_9065},
{"f_9068:c_backend_scm",(void*)f_9068},
{"f_9038:c_backend_scm",(void*)f_9038},
{"f_9041:c_backend_scm",(void*)f_9041},
{"f_9044:c_backend_scm",(void*)f_9044},
{"f_9047:c_backend_scm",(void*)f_9047},
{"f_9001:c_backend_scm",(void*)f_9001},
{"f_9004:c_backend_scm",(void*)f_9004},
{"f_9007:c_backend_scm",(void*)f_9007},
{"f_9010:c_backend_scm",(void*)f_9010},
{"f_8980:c_backend_scm",(void*)f_8980},
{"f_8983:c_backend_scm",(void*)f_8983},
{"f_8986:c_backend_scm",(void*)f_8986},
{"f_8989:c_backend_scm",(void*)f_8989},
{"f_8959:c_backend_scm",(void*)f_8959},
{"f_8962:c_backend_scm",(void*)f_8962},
{"f_8965:c_backend_scm",(void*)f_8965},
{"f_8968:c_backend_scm",(void*)f_8968},
{"f_8938:c_backend_scm",(void*)f_8938},
{"f_8941:c_backend_scm",(void*)f_8941},
{"f_8944:c_backend_scm",(void*)f_8944},
{"f_8947:c_backend_scm",(void*)f_8947},
{"f_8917:c_backend_scm",(void*)f_8917},
{"f_8920:c_backend_scm",(void*)f_8920},
{"f_8923:c_backend_scm",(void*)f_8923},
{"f_8926:c_backend_scm",(void*)f_8926},
{"f_8850:c_backend_scm",(void*)f_8850},
{"f_8853:c_backend_scm",(void*)f_8853},
{"f_8856:c_backend_scm",(void*)f_8856},
{"f_8859:c_backend_scm",(void*)f_8859},
{"f_8829:c_backend_scm",(void*)f_8829},
{"f_8832:c_backend_scm",(void*)f_8832},
{"f_8835:c_backend_scm",(void*)f_8835},
{"f_8838:c_backend_scm",(void*)f_8838},
{"f_8808:c_backend_scm",(void*)f_8808},
{"f_8811:c_backend_scm",(void*)f_8811},
{"f_8814:c_backend_scm",(void*)f_8814},
{"f_8817:c_backend_scm",(void*)f_8817},
{"f_8784:c_backend_scm",(void*)f_8784},
{"f_8787:c_backend_scm",(void*)f_8787},
{"f_8790:c_backend_scm",(void*)f_8790},
{"f_8793:c_backend_scm",(void*)f_8793},
{"f_8763:c_backend_scm",(void*)f_8763},
{"f_8766:c_backend_scm",(void*)f_8766},
{"f_8769:c_backend_scm",(void*)f_8769},
{"f_8772:c_backend_scm",(void*)f_8772},
{"f_8739:c_backend_scm",(void*)f_8739},
{"f_8742:c_backend_scm",(void*)f_8742},
{"f_8745:c_backend_scm",(void*)f_8745},
{"f_8748:c_backend_scm",(void*)f_8748},
{"f_8718:c_backend_scm",(void*)f_8718},
{"f_8721:c_backend_scm",(void*)f_8721},
{"f_8724:c_backend_scm",(void*)f_8724},
{"f_8727:c_backend_scm",(void*)f_8727},
{"f_8694:c_backend_scm",(void*)f_8694},
{"f_8697:c_backend_scm",(void*)f_8697},
{"f_8700:c_backend_scm",(void*)f_8700},
{"f_8703:c_backend_scm",(void*)f_8703},
{"f_8673:c_backend_scm",(void*)f_8673},
{"f_8676:c_backend_scm",(void*)f_8676},
{"f_8679:c_backend_scm",(void*)f_8679},
{"f_8682:c_backend_scm",(void*)f_8682},
{"f_8606:c_backend_scm",(void*)f_8606},
{"f_8119:c_backend_scm",(void*)f_8119},
{"f_8149:c_backend_scm",(void*)f_8149},
{"f_8176:c_backend_scm",(void*)f_8176},
{"f_8371:c_backend_scm",(void*)f_8371},
{"f_8380:c_backend_scm",(void*)f_8380},
{"f_8389:c_backend_scm",(void*)f_8389},
{"f_8411:c_backend_scm",(void*)f_8411},
{"f_8488:c_backend_scm",(void*)f_8488},
{"f_8121:c_backend_scm",(void*)f_8121},
{"f_7274:c_backend_scm",(void*)f_7274},
{"f_7351:c_backend_scm",(void*)f_7351},
{"f_7453:c_backend_scm",(void*)f_7453},
{"f_7486:c_backend_scm",(void*)f_7486},
{"f_7582:c_backend_scm",(void*)f_7582},
{"f_7594:c_backend_scm",(void*)f_7594},
{"f_7609:c_backend_scm",(void*)f_7609},
{"f_7649:c_backend_scm",(void*)f_7649},
{"f_7666:c_backend_scm",(void*)f_7666},
{"f_7683:c_backend_scm",(void*)f_7683},
{"f_7722:c_backend_scm",(void*)f_7722},
{"f_7739:c_backend_scm",(void*)f_7739},
{"f_7756:c_backend_scm",(void*)f_7756},
{"f_7773:c_backend_scm",(void*)f_7773},
{"f_7790:c_backend_scm",(void*)f_7790},
{"f_7807:c_backend_scm",(void*)f_7807},
{"f_7824:c_backend_scm",(void*)f_7824},
{"f_7836:c_backend_scm",(void*)f_7836},
{"f_7843:c_backend_scm",(void*)f_7843},
{"f_7853:c_backend_scm",(void*)f_7853},
{"f_7851:c_backend_scm",(void*)f_7851},
{"f_7847:c_backend_scm",(void*)f_7847},
{"f_7814:c_backend_scm",(void*)f_7814},
{"f_7797:c_backend_scm",(void*)f_7797},
{"f_7780:c_backend_scm",(void*)f_7780},
{"f_7763:c_backend_scm",(void*)f_7763},
{"f_7746:c_backend_scm",(void*)f_7746},
{"f_7729:c_backend_scm",(void*)f_7729},
{"f_7694:c_backend_scm",(void*)f_7694},
{"f_7704:c_backend_scm",(void*)f_7704},
{"f_7702:c_backend_scm",(void*)f_7702},
{"f_7698:c_backend_scm",(void*)f_7698},
{"f_7690:c_backend_scm",(void*)f_7690},
{"f_7677:c_backend_scm",(void*)f_7677},
{"f_7660:c_backend_scm",(void*)f_7660},
{"f_7281:c_backend_scm",(void*)f_7281},
{"f_7276:c_backend_scm",(void*)f_7276},
{"f_7209:c_backend_scm",(void*)f_7209},
{"f_7213:c_backend_scm",(void*)f_7213},
{"f_7216:c_backend_scm",(void*)f_7216},
{"f_7219:c_backend_scm",(void*)f_7219},
{"f_7222:c_backend_scm",(void*)f_7222},
{"f_7228:c_backend_scm",(void*)f_7228},
{"f_7272:c_backend_scm",(void*)f_7272},
{"f_7231:c_backend_scm",(void*)f_7231},
{"f_7239:c_backend_scm",(void*)f_7239},
{"f_7260:c_backend_scm",(void*)f_7260},
{"f_7243:c_backend_scm",(void*)f_7243},
{"f_7234:c_backend_scm",(void*)f_7234},
{"f_6762:c_backend_scm",(void*)f_6762},
{"f_6768:c_backend_scm",(void*)f_6768},
{"f_6781:c_backend_scm",(void*)f_6781},
{"f_6784:c_backend_scm",(void*)f_6784},
{"f_6787:c_backend_scm",(void*)f_6787},
{"f_6790:c_backend_scm",(void*)f_6790},
{"f_6796:c_backend_scm",(void*)f_6796},
{"f_7137:c_backend_scm",(void*)f_7137},
{"f_7140:c_backend_scm",(void*)f_7140},
{"f_7207:c_backend_scm",(void*)f_7207},
{"f_7143:c_backend_scm",(void*)f_7143},
{"f_7146:c_backend_scm",(void*)f_7146},
{"f_7149:c_backend_scm",(void*)f_7149},
{"f_7152:c_backend_scm",(void*)f_7152},
{"f_7192:c_backend_scm",(void*)f_7192},
{"f_7200:c_backend_scm",(void*)f_7200},
{"f_7155:c_backend_scm",(void*)f_7155},
{"f_7190:c_backend_scm",(void*)f_7190},
{"f_7158:c_backend_scm",(void*)f_7158},
{"f_7161:c_backend_scm",(void*)f_7161},
{"f_7164:c_backend_scm",(void*)f_7164},
{"f_7167:c_backend_scm",(void*)f_7167},
{"f_6798:c_backend_scm",(void*)f_6798},
{"f_6808:c_backend_scm",(void*)f_6808},
{"f_6817:c_backend_scm",(void*)f_6817},
{"f_6829:c_backend_scm",(void*)f_6829},
{"f_6841:c_backend_scm",(void*)f_6841},
{"f_6847:c_backend_scm",(void*)f_6847},
{"f_6881:c_backend_scm",(void*)f_6881},
{"f_6504:c_backend_scm",(void*)f_6504},
{"f_6510:c_backend_scm",(void*)f_6510},
{"f_6523:c_backend_scm",(void*)f_6523},
{"f_6526:c_backend_scm",(void*)f_6526},
{"f_6529:c_backend_scm",(void*)f_6529},
{"f_6760:c_backend_scm",(void*)f_6760},
{"f_6535:c_backend_scm",(void*)f_6535},
{"f_6538:c_backend_scm",(void*)f_6538},
{"f_6541:c_backend_scm",(void*)f_6541},
{"f_6544:c_backend_scm",(void*)f_6544},
{"f_6547:c_backend_scm",(void*)f_6547},
{"f_6550:c_backend_scm",(void*)f_6550},
{"f_6553:c_backend_scm",(void*)f_6553},
{"f_6556:c_backend_scm",(void*)f_6556},
{"f_6559:c_backend_scm",(void*)f_6559},
{"f_6562:c_backend_scm",(void*)f_6562},
{"f_6749:c_backend_scm",(void*)f_6749},
{"f_6565:c_backend_scm",(void*)f_6565},
{"f_6568:c_backend_scm",(void*)f_6568},
{"f_6571:c_backend_scm",(void*)f_6571},
{"f_6574:c_backend_scm",(void*)f_6574},
{"f_6577:c_backend_scm",(void*)f_6577},
{"f_6580:c_backend_scm",(void*)f_6580},
{"f_6583:c_backend_scm",(void*)f_6583},
{"f_6586:c_backend_scm",(void*)f_6586},
{"f_6727:c_backend_scm",(void*)f_6727},
{"f_6688:c_backend_scm",(void*)f_6688},
{"f_6714:c_backend_scm",(void*)f_6714},
{"f_6717:c_backend_scm",(void*)f_6717},
{"f_6720:c_backend_scm",(void*)f_6720},
{"f_6708:c_backend_scm",(void*)f_6708},
{"f_6696:c_backend_scm",(void*)f_6696},
{"f_6700:c_backend_scm",(void*)f_6700},
{"f_6704:c_backend_scm",(void*)f_6704},
{"f_6589:c_backend_scm",(void*)f_6589},
{"f_6592:c_backend_scm",(void*)f_6592},
{"f_6629:c_backend_scm",(void*)f_6629},
{"f_6632:c_backend_scm",(void*)f_6632},
{"f_6670:c_backend_scm",(void*)f_6670},
{"f_6666:c_backend_scm",(void*)f_6666},
{"f_6635:c_backend_scm",(void*)f_6635},
{"f_6638:c_backend_scm",(void*)f_6638},
{"f_6641:c_backend_scm",(void*)f_6641},
{"f_6608:c_backend_scm",(void*)f_6608},
{"f_6611:c_backend_scm",(void*)f_6611},
{"f_6595:c_backend_scm",(void*)f_6595},
{"f_6598:c_backend_scm",(void*)f_6598},
{"f_6470:c_backend_scm",(void*)f_6470},
{"f_6476:c_backend_scm",(void*)f_6476},
{"f_6489:c_backend_scm",(void*)f_6489},
{"f_6492:c_backend_scm",(void*)f_6492},
{"f_6495:c_backend_scm",(void*)f_6495},
{"f_6422:c_backend_scm",(void*)f_6422},
{"f_6426:c_backend_scm",(void*)f_6426},
{"f_6431:c_backend_scm",(void*)f_6431},
{"f_6468:c_backend_scm",(void*)f_6468},
{"f_6453:c_backend_scm",(void*)f_6453},
{"f_6406:c_backend_scm",(void*)f_6406},
{"f_6412:c_backend_scm",(void*)f_6412},
{"f_6420:c_backend_scm",(void*)f_6420},
{"f_6390:c_backend_scm",(void*)f_6390},
{"f_6396:c_backend_scm",(void*)f_6396},
{"f_6404:c_backend_scm",(void*)f_6404},
{"f_6301:c_backend_scm",(void*)f_6301},
{"f_6310:c_backend_scm",(void*)f_6310},
{"f_6339:c_backend_scm",(void*)f_6339},
{"f_6349:c_backend_scm",(void*)f_6349},
{"f_6224:c_backend_scm",(void*)f_6224},
{"f_6228:c_backend_scm",(void*)f_6228},
{"f_6242:c_backend_scm",(void*)f_6242},
{"f_6255:c_backend_scm",(void*)f_6255},
{"f_6287:c_backend_scm",(void*)f_6287},
{"f_6258:c_backend_scm",(void*)f_6258},
{"f_6261:c_backend_scm",(void*)f_6261},
{"f_6231:c_backend_scm",(void*)f_6231},
{"f_6234:c_backend_scm",(void*)f_6234},
{"f_6237:c_backend_scm",(void*)f_6237},
{"f_2353:c_backend_scm",(void*)f_2353},
{"f_6191:c_backend_scm",(void*)f_6191},
{"f_6195:c_backend_scm",(void*)f_6195},
{"f_6198:c_backend_scm",(void*)f_6198},
{"f_6201:c_backend_scm",(void*)f_6201},
{"f_6204:c_backend_scm",(void*)f_6204},
{"f_6207:c_backend_scm",(void*)f_6207},
{"f_6210:c_backend_scm",(void*)f_6210},
{"f_6213:c_backend_scm",(void*)f_6213},
{"f_6216:c_backend_scm",(void*)f_6216},
{"f_6219:c_backend_scm",(void*)f_6219},
{"f_5428:c_backend_scm",(void*)f_5428},
{"f_5434:c_backend_scm",(void*)f_5434},
{"f_5447:c_backend_scm",(void*)f_5447},
{"f_5450:c_backend_scm",(void*)f_5450},
{"f_5453:c_backend_scm",(void*)f_5453},
{"f_5456:c_backend_scm",(void*)f_5456},
{"f_5459:c_backend_scm",(void*)f_5459},
{"f_5462:c_backend_scm",(void*)f_5462},
{"f_6188:c_backend_scm",(void*)f_6188},
{"f_5465:c_backend_scm",(void*)f_5465},
{"f_5471:c_backend_scm",(void*)f_5471},
{"f_5474:c_backend_scm",(void*)f_5474},
{"f_5477:c_backend_scm",(void*)f_5477},
{"f_5480:c_backend_scm",(void*)f_5480},
{"f_5483:c_backend_scm",(void*)f_5483},
{"f_5486:c_backend_scm",(void*)f_5486},
{"f_5489:c_backend_scm",(void*)f_5489},
{"f_5492:c_backend_scm",(void*)f_5492},
{"f_5495:c_backend_scm",(void*)f_5495},
{"f_5498:c_backend_scm",(void*)f_5498},
{"f_5501:c_backend_scm",(void*)f_5501},
{"f_5504:c_backend_scm",(void*)f_5504},
{"f_6157:c_backend_scm",(void*)f_6157},
{"f_5507:c_backend_scm",(void*)f_5507},
{"f_6118:c_backend_scm",(void*)f_6118},
{"f_6121:c_backend_scm",(void*)f_6121},
{"f_6124:c_backend_scm",(void*)f_6124},
{"f_6140:c_backend_scm",(void*)f_6140},
{"f_6143:c_backend_scm",(void*)f_6143},
{"f_5510:c_backend_scm",(void*)f_5510},
{"f_5513:c_backend_scm",(void*)f_5513},
{"f_5516:c_backend_scm",(void*)f_5516},
{"f_6090:c_backend_scm",(void*)f_6090},
{"f_6093:c_backend_scm",(void*)f_6093},
{"f_5519:c_backend_scm",(void*)f_5519},
{"f_5522:c_backend_scm",(void*)f_5522},
{"f_5525:c_backend_scm",(void*)f_5525},
{"f_5528:c_backend_scm",(void*)f_5528},
{"f_5531:c_backend_scm",(void*)f_5531},
{"f_5534:c_backend_scm",(void*)f_5534},
{"f_6050:c_backend_scm",(void*)f_6050},
{"f_6052:c_backend_scm",(void*)f_6052},
{"f_6062:c_backend_scm",(void*)f_6062},
{"f_5537:c_backend_scm",(void*)f_5537},
{"f_5995:c_backend_scm",(void*)f_5995},
{"f_6007:c_backend_scm",(void*)f_6007},
{"f_6010:c_backend_scm",(void*)f_6010},
{"f_5917:c_backend_scm",(void*)f_5917},
{"f_5959:c_backend_scm",(void*)f_5959},
{"f_5920:c_backend_scm",(void*)f_5920},
{"f_5926:c_backend_scm",(void*)f_5926},
{"f_5929:c_backend_scm",(void*)f_5929},
{"f_5853:c_backend_scm",(void*)f_5853},
{"f_5856:c_backend_scm",(void*)f_5856},
{"f_5859:c_backend_scm",(void*)f_5859},
{"f_5862:c_backend_scm",(void*)f_5862},
{"f_5865:c_backend_scm",(void*)f_5865},
{"f_5880:c_backend_scm",(void*)f_5880},
{"f_5868:c_backend_scm",(void*)f_5868},
{"f_5871:c_backend_scm",(void*)f_5871},
{"f_5839:c_backend_scm",(void*)f_5839},
{"f_5847:c_backend_scm",(void*)f_5847},
{"f_5764:c_backend_scm",(void*)f_5764},
{"f_5770:c_backend_scm",(void*)f_5770},
{"f_5773:c_backend_scm",(void*)f_5773},
{"f_5807:c_backend_scm",(void*)f_5807},
{"f_5810:c_backend_scm",(void*)f_5810},
{"f_5813:c_backend_scm",(void*)f_5813},
{"f_5776:c_backend_scm",(void*)f_5776},
{"f_5779:c_backend_scm",(void*)f_5779},
{"f_5782:c_backend_scm",(void*)f_5782},
{"f_5785:c_backend_scm",(void*)f_5785},
{"f_5794:c_backend_scm",(void*)f_5794},
{"f_5797:c_backend_scm",(void*)f_5797},
{"f_5540:c_backend_scm",(void*)f_5540},
{"f_5570:c_backend_scm",(void*)f_5570},
{"f_5705:c_backend_scm",(void*)f_5705},
{"f_5708:c_backend_scm",(void*)f_5708},
{"f_5720:c_backend_scm",(void*)f_5720},
{"f_5711:c_backend_scm",(void*)f_5711},
{"f_5576:c_backend_scm",(void*)f_5576},
{"f_5579:c_backend_scm",(void*)f_5579},
{"f_5582:c_backend_scm",(void*)f_5582},
{"f_5686:c_backend_scm",(void*)f_5686},
{"f_5585:c_backend_scm",(void*)f_5585},
{"f_5588:c_backend_scm",(void*)f_5588},
{"f_5591:c_backend_scm",(void*)f_5591},
{"f_5594:c_backend_scm",(void*)f_5594},
{"f_5659:c_backend_scm",(void*)f_5659},
{"f_5655:c_backend_scm",(void*)f_5655},
{"f_5597:c_backend_scm",(void*)f_5597},
{"f_5600:c_backend_scm",(void*)f_5600},
{"f_5603:c_backend_scm",(void*)f_5603},
{"f_5606:c_backend_scm",(void*)f_5606},
{"f_5609:c_backend_scm",(void*)f_5609},
{"f_5612:c_backend_scm",(void*)f_5612},
{"f_5630:c_backend_scm",(void*)f_5630},
{"f_5640:c_backend_scm",(void*)f_5640},
{"f_5615:c_backend_scm",(void*)f_5615},
{"f_5543:c_backend_scm",(void*)f_5543},
{"f_5560:c_backend_scm",(void*)f_5560},
{"f_5546:c_backend_scm",(void*)f_5546},
{"f_5549:c_backend_scm",(void*)f_5549},
{"f_5038:c_backend_scm",(void*)f_5038},
{"f_5045:c_backend_scm",(void*)f_5045},
{"f_5119:c_backend_scm",(void*)f_5119},
{"f_5137:c_backend_scm",(void*)f_5137},
{"f_5166:c_backend_scm",(void*)f_5166},
{"f_5188:c_backend_scm",(void*)f_5188},
{"f_5144:c_backend_scm",(void*)f_5144},
{"f_5113:c_backend_scm",(void*)f_5113},
{"f_5109:c_backend_scm",(void*)f_5109},
{"f_5105:c_backend_scm",(void*)f_5105},
{"f_5076:c_backend_scm",(void*)f_5076},
{"f_5080:c_backend_scm",(void*)f_5080},
{"f_4983:c_backend_scm",(void*)f_4983},
{"f_4989:c_backend_scm",(void*)f_4989},
{"f_5018:c_backend_scm",(void*)f_5018},
{"f_5021:c_backend_scm",(void*)f_5021},
{"f_5024:c_backend_scm",(void*)f_5024},
{"f_5027:c_backend_scm",(void*)f_5027},
{"f_5030:c_backend_scm",(void*)f_5030},
{"f_4999:c_backend_scm",(void*)f_4999},
{"f_5197:c_backend_scm",(void*)f_5197},
{"f_5337:c_backend_scm",(void*)f_5337},
{"f_5204:c_backend_scm",(void*)f_5204},
{"f_5210:c_backend_scm",(void*)f_5210},
{"f_5293:c_backend_scm",(void*)f_5293},
{"f_5296:c_backend_scm",(void*)f_5296},
{"f_5306:c_backend_scm",(void*)f_5306},
{"f_5299:c_backend_scm",(void*)f_5299},
{"f_5260:c_backend_scm",(void*)f_5260},
{"f_5266:c_backend_scm",(void*)f_5266},
{"f_5339:c_backend_scm",(void*)f_5339},
{"f_5346:c_backend_scm",(void*)f_5346},
{"f_5349:c_backend_scm",(void*)f_5349},
{"f_5354:c_backend_scm",(void*)f_5354},
{"f_5410:c_backend_scm",(void*)f_5410},
{"f_5406:c_backend_scm",(void*)f_5406},
{"f_5391:c_backend_scm",(void*)f_5391},
{"f_5370:c_backend_scm",(void*)f_5370},
{"f_5381:c_backend_scm",(void*)f_5381},
{"f_5377:c_backend_scm",(void*)f_5377},
{"f_5416:c_backend_scm",(void*)f_5416},
{"f_5423:c_backend_scm",(void*)f_5423},
{"f_5426:c_backend_scm",(void*)f_5426},
{"f_4621:c_backend_scm",(void*)f_4621},
{"f_4848:c_backend_scm",(void*)f_4848},
{"f_4861:c_backend_scm",(void*)f_4861},
{"f_4864:c_backend_scm",(void*)f_4864},
{"f_4867:c_backend_scm",(void*)f_4867},
{"f_4870:c_backend_scm",(void*)f_4870},
{"f_4873:c_backend_scm",(void*)f_4873},
{"f_4981:c_backend_scm",(void*)f_4981},
{"f_4876:c_backend_scm",(void*)f_4876},
{"f_4879:c_backend_scm",(void*)f_4879},
{"f_4892:c_backend_scm",(void*)f_4892},
{"f_4970:c_backend_scm",(void*)f_4970},
{"f_4926:c_backend_scm",(void*)f_4926},
{"f_4932:c_backend_scm",(void*)f_4932},
{"f_4950:c_backend_scm",(void*)f_4950},
{"f_4946:c_backend_scm",(void*)f_4946},
{"f_4942:c_backend_scm",(void*)f_4942},
{"f_4898:c_backend_scm",(void*)f_4898},
{"f_4901:c_backend_scm",(void*)f_4901},
{"f_4904:c_backend_scm",(void*)f_4904},
{"f_4907:c_backend_scm",(void*)f_4907},
{"f_4910:c_backend_scm",(void*)f_4910},
{"f_4920:c_backend_scm",(void*)f_4920},
{"f_4913:c_backend_scm",(void*)f_4913},
{"f_4882:c_backend_scm",(void*)f_4882},
{"f_4740:c_backend_scm",(void*)f_4740},
{"f_4803:c_backend_scm",(void*)f_4803},
{"f_4816:c_backend_scm",(void*)f_4816},
{"f_4819:c_backend_scm",(void*)f_4819},
{"f_4822:c_backend_scm",(void*)f_4822},
{"f_4825:c_backend_scm",(void*)f_4825},
{"f_4846:c_backend_scm",(void*)f_4846},
{"f_4842:c_backend_scm",(void*)f_4842},
{"f_4828:c_backend_scm",(void*)f_4828},
{"f_4831:c_backend_scm",(void*)f_4831},
{"f_4743:c_backend_scm",(void*)f_4743},
{"f_4777:c_backend_scm",(void*)f_4777},
{"f_4801:c_backend_scm",(void*)f_4801},
{"f_4787:c_backend_scm",(void*)f_4787},
{"f_4746:c_backend_scm",(void*)f_4746},
{"f_4751:c_backend_scm",(void*)f_4751},
{"f_4775:c_backend_scm",(void*)f_4775},
{"f_4761:c_backend_scm",(void*)f_4761},
{"f_4660:c_backend_scm",(void*)f_4660},
{"f_4662:c_backend_scm",(void*)f_4662},
{"f_4666:c_backend_scm",(void*)f_4666},
{"f_4669:c_backend_scm",(void*)f_4669},
{"f_4672:c_backend_scm",(void*)f_4672},
{"f_4675:c_backend_scm",(void*)f_4675},
{"f_4678:c_backend_scm",(void*)f_4678},
{"f_4681:c_backend_scm",(void*)f_4681},
{"f_4684:c_backend_scm",(void*)f_4684},
{"f_4687:c_backend_scm",(void*)f_4687},
{"f_4690:c_backend_scm",(void*)f_4690},
{"f_4693:c_backend_scm",(void*)f_4693},
{"f_4696:c_backend_scm",(void*)f_4696},
{"f_4699:c_backend_scm",(void*)f_4699},
{"f_4713:c_backend_scm",(void*)f_4713},
{"f_4709:c_backend_scm",(void*)f_4709},
{"f_4702:c_backend_scm",(void*)f_4702},
{"f_4624:c_backend_scm",(void*)f_4624},
{"f_4637:c_backend_scm",(void*)f_4637},
{"f_4647:c_backend_scm",(void*)f_4647},
{"f_4628:c_backend_scm",(void*)f_4628},
{"f_4299:c_backend_scm",(void*)f_4299},
{"f_4303:c_backend_scm",(void*)f_4303},
{"f_4366:c_backend_scm",(void*)f_4366},
{"f_4379:c_backend_scm",(void*)f_4379},
{"f_4382:c_backend_scm",(void*)f_4382},
{"f_4619:c_backend_scm",(void*)f_4619},
{"f_4385:c_backend_scm",(void*)f_4385},
{"f_4605:c_backend_scm",(void*)f_4605},
{"f_4388:c_backend_scm",(void*)f_4388},
{"f_4391:c_backend_scm",(void*)f_4391},
{"f_4394:c_backend_scm",(void*)f_4394},
{"f_4397:c_backend_scm",(void*)f_4397},
{"f_4400:c_backend_scm",(void*)f_4400},
{"f_4403:c_backend_scm",(void*)f_4403},
{"f_4597:c_backend_scm",(void*)f_4597},
{"f_4406:c_backend_scm",(void*)f_4406},
{"f_4409:c_backend_scm",(void*)f_4409},
{"f_4557:c_backend_scm",(void*)f_4557},
{"f_4559:c_backend_scm",(void*)f_4559},
{"f_4586:c_backend_scm",(void*)f_4586},
{"f_4412:c_backend_scm",(void*)f_4412},
{"f_4506:c_backend_scm",(void*)f_4506},
{"f_4509:c_backend_scm",(void*)f_4509},
{"f_4512:c_backend_scm",(void*)f_4512},
{"f_4515:c_backend_scm",(void*)f_4515},
{"f_4531:c_backend_scm",(void*)f_4531},
{"f_4534:c_backend_scm",(void*)f_4534},
{"f11595:c_backend_scm",(void*)f11595},
{"f_4537:c_backend_scm",(void*)f_4537},
{"f_4540:c_backend_scm",(void*)f_4540},
{"f_4415:c_backend_scm",(void*)f_4415},
{"f_4418:c_backend_scm",(void*)f_4418},
{"f_4421:c_backend_scm",(void*)f_4421},
{"f_4478:c_backend_scm",(void*)f_4478},
{"f_4481:c_backend_scm",(void*)f_4481},
{"f_4424:c_backend_scm",(void*)f_4424},
{"f_4427:c_backend_scm",(void*)f_4427},
{"f_4466:c_backend_scm",(void*)f_4466},
{"f_4469:c_backend_scm",(void*)f_4469},
{"f_4440:c_backend_scm",(void*)f_4440},
{"f_4449:c_backend_scm",(void*)f_4449},
{"f_4452:c_backend_scm",(void*)f_4452},
{"f_4430:c_backend_scm",(void*)f_4430},
{"f_4306:c_backend_scm",(void*)f_4306},
{"f_4311:c_backend_scm",(void*)f_4311},
{"f_4324:c_backend_scm",(void*)f_4324},
{"f_4341:c_backend_scm",(void*)f_4341},
{"f_4343:c_backend_scm",(void*)f_4343},
{"f_4353:c_backend_scm",(void*)f_4353},
{"f_4327:c_backend_scm",(void*)f_4327},
{"f_4330:c_backend_scm",(void*)f_4330},
{"f_4134:c_backend_scm",(void*)f_4134},
{"f_4141:c_backend_scm",(void*)f_4141},
{"f_4277:c_backend_scm",(void*)f_4277},
{"f_4290:c_backend_scm",(void*)f_4290},
{"f_4144:c_backend_scm",(void*)f_4144},
{"f_4147:c_backend_scm",(void*)f_4147},
{"f_4150:c_backend_scm",(void*)f_4150},
{"f_4155:c_backend_scm",(void*)f_4155},
{"f_4165:c_backend_scm",(void*)f_4165},
{"f_4171:c_backend_scm",(void*)f_4171},
{"f_4224:c_backend_scm",(void*)f_4224},
{"f_4234:c_backend_scm",(void*)f_4234},
{"f_4174:c_backend_scm",(void*)f_4174},
{"f_4197:c_backend_scm",(void*)f_4197},
{"f_4207:c_backend_scm",(void*)f_4207},
{"f_4177:c_backend_scm",(void*)f_4177},
{"f_4180:c_backend_scm",(void*)f_4180},
{"f_3971:c_backend_scm",(void*)f_3971},
{"f_4126:c_backend_scm",(void*)f_4126},
{"f_3991:c_backend_scm",(void*)f_3991},
{"f_4084:c_backend_scm",(void*)f_4084},
{"f_4088:c_backend_scm",(void*)f_4088},
{"f_4092:c_backend_scm",(void*)f_4092},
{"f_4096:c_backend_scm",(void*)f_4096},
{"f_4118:c_backend_scm",(void*)f_4118},
{"f_4114:c_backend_scm",(void*)f_4114},
{"f_4106:c_backend_scm",(void*)f_4106},
{"f_4104:c_backend_scm",(void*)f_4104},
{"f_4100:c_backend_scm",(void*)f_4100},
{"f_4009:c_backend_scm",(void*)f_4009},
{"f_4012:c_backend_scm",(void*)f_4012},
{"f_4015:c_backend_scm",(void*)f_4015},
{"f_4073:c_backend_scm",(void*)f_4073},
{"f_4018:c_backend_scm",(void*)f_4018},
{"f_4021:c_backend_scm",(void*)f_4021},
{"f_4024:c_backend_scm",(void*)f_4024},
{"f_4039:c_backend_scm",(void*)f_4039},
{"f_4044:c_backend_scm",(void*)f_4044},
{"f_4057:c_backend_scm",(void*)f_4057},
{"f_4027:c_backend_scm",(void*)f_4027},
{"f_3974:c_backend_scm",(void*)f_3974},
{"f_3988:c_backend_scm",(void*)f_3988},
{"f_2398:c_backend_scm",(void*)f_2398},
{"f_3939:c_backend_scm",(void*)f_3939},
{"f_3945:c_backend_scm",(void*)f_3945},
{"f_3949:c_backend_scm",(void*)f_3949},
{"f_2401:c_backend_scm",(void*)f_2401},
{"f_3904:c_backend_scm",(void*)f_3904},
{"f_3907:c_backend_scm",(void*)f_3907},
{"f_3910:c_backend_scm",(void*)f_3910},
{"f_3913:c_backend_scm",(void*)f_3913},
{"f_3916:c_backend_scm",(void*)f_3916},
{"f_3919:c_backend_scm",(void*)f_3919},
{"f_3821:c_backend_scm",(void*)f_3821},
{"f_3824:c_backend_scm",(void*)f_3824},
{"f_3827:c_backend_scm",(void*)f_3827},
{"f_3840:c_backend_scm",(void*)f_3840},
{"f_3863:c_backend_scm",(void*)f_3863},
{"f_3866:c_backend_scm",(void*)f_3866},
{"f_3869:c_backend_scm",(void*)f_3869},
{"f_3872:c_backend_scm",(void*)f_3872},
{"f_3850:c_backend_scm",(void*)f_3850},
{"f_3853:c_backend_scm",(void*)f_3853},
{"f_3812:c_backend_scm",(void*)f_3812},
{"f_3784:c_backend_scm",(void*)f_3784},
{"f_3787:c_backend_scm",(void*)f_3787},
{"f_3804:c_backend_scm",(void*)f_3804},
{"f_3790:c_backend_scm",(void*)f_3790},
{"f_3793:c_backend_scm",(void*)f_3793},
{"f_3768:c_backend_scm",(void*)f_3768},
{"f_3772:c_backend_scm",(void*)f_3772},
{"f_3754:c_backend_scm",(void*)f_3754},
{"f_3757:c_backend_scm",(void*)f_3757},
{"f_3738:c_backend_scm",(void*)f_3738},
{"f_3742:c_backend_scm",(void*)f_3742},
{"f_3720:c_backend_scm",(void*)f_3720},
{"f_3723:c_backend_scm",(void*)f_3723},
{"f_3700:c_backend_scm",(void*)f_3700},
{"f_3664:c_backend_scm",(void*)f_3664},
{"f_3676:c_backend_scm",(void*)f_3676},
{"f_3667:c_backend_scm",(void*)f_3667},
{"f_3645:c_backend_scm",(void*)f_3645},
{"f_3648:c_backend_scm",(void*)f_3648},
{"f_3626:c_backend_scm",(void*)f_3626},
{"f_3629:c_backend_scm",(void*)f_3629},
{"f_3607:c_backend_scm",(void*)f_3607},
{"f_3610:c_backend_scm",(void*)f_3610},
{"f_3588:c_backend_scm",(void*)f_3588},
{"f_3584:c_backend_scm",(void*)f_3584},
{"f_3532:c_backend_scm",(void*)f_3532},
{"f_3565:c_backend_scm",(void*)f_3565},
{"f_3535:c_backend_scm",(void*)f_3535},
{"f_3553:c_backend_scm",(void*)f_3553},
{"f_3538:c_backend_scm",(void*)f_3538},
{"f_3541:c_backend_scm",(void*)f_3541},
{"f_3499:c_backend_scm",(void*)f_3499},
{"f_3483:c_backend_scm",(void*)f_3483},
{"f11560:c_backend_scm",(void*)f11560},
{"f_3486:c_backend_scm",(void*)f_3486},
{"f_3489:c_backend_scm",(void*)f_3489},
{"f_3442:c_backend_scm",(void*)f_3442},
{"f_3445:c_backend_scm",(void*)f_3445},
{"f_3466:c_backend_scm",(void*)f_3466},
{"f_3470:c_backend_scm",(void*)f_3470},
{"f_3473:c_backend_scm",(void*)f_3473},
{"f_3448:c_backend_scm",(void*)f_3448},
{"f_3464:c_backend_scm",(void*)f_3464},
{"f_3456:c_backend_scm",(void*)f_3456},
{"f_3451:c_backend_scm",(void*)f_3451},
{"f_3075:c_backend_scm",(void*)f_3075},
{"f_3078:c_backend_scm",(void*)f_3078},
{"f_3392:c_backend_scm",(void*)f_3392},
{"f_3388:c_backend_scm",(void*)f_3388},
{"f_3084:c_backend_scm",(void*)f_3084},
{"f11556:c_backend_scm",(void*)f11556},
{"f_3381:c_backend_scm",(void*)f_3381},
{"f_2386:c_backend_scm",(void*)f_2386},
{"f_3374:c_backend_scm",(void*)f_3374},
{"f_3090:c_backend_scm",(void*)f_3090},
{"f_3217:c_backend_scm",(void*)f_3217},
{"f_3301:c_backend_scm",(void*)f_3301},
{"f_3304:c_backend_scm",(void*)f_3304},
{"f_3307:c_backend_scm",(void*)f_3307},
{"f_3322:c_backend_scm",(void*)f_3322},
{"f_3310:c_backend_scm",(void*)f_3310},
{"f_3313:c_backend_scm",(void*)f_3313},
{"f_3316:c_backend_scm",(void*)f_3316},
{"f_3232:c_backend_scm",(void*)f_3232},
{"f_3298:c_backend_scm",(void*)f_3298},
{"f_3291:c_backend_scm",(void*)f_3291},
{"f_3287:c_backend_scm",(void*)f_3287},
{"f_3280:c_backend_scm",(void*)f_3280},
{"f_3273:c_backend_scm",(void*)f_3273},
{"f_3248:c_backend_scm",(void*)f_3248},
{"f_3265:c_backend_scm",(void*)f_3265},
{"f_3261:c_backend_scm",(void*)f_3261},
{"f_3235:c_backend_scm",(void*)f_3235},
{"f_3238:c_backend_scm",(void*)f_3238},
{"f_3241:c_backend_scm",(void*)f_3241},
{"f_3211:c_backend_scm",(void*)f_3211},
{"f_3121:c_backend_scm",(void*)f_3121},
{"f_3195:c_backend_scm",(void*)f_3195},
{"f_3198:c_backend_scm",(void*)f_3198},
{"f_3171:c_backend_scm",(void*)f_3171},
{"f_3174:c_backend_scm",(void*)f_3174},
{"f_3177:c_backend_scm",(void*)f_3177},
{"f11551:c_backend_scm",(void*)f11551},
{"f_3180:c_backend_scm",(void*)f_3180},
{"f_3183:c_backend_scm",(void*)f_3183},
{"f_3124:c_backend_scm",(void*)f_3124},
{"f_3127:c_backend_scm",(void*)f_3127},
{"f_3154:c_backend_scm",(void*)f_3154},
{"f_3158:c_backend_scm",(void*)f_3158},
{"f_3161:c_backend_scm",(void*)f_3161},
{"f_3130:c_backend_scm",(void*)f_3130},
{"f_3152:c_backend_scm",(void*)f_3152},
{"f_3144:c_backend_scm",(void*)f_3144},
{"f_3133:c_backend_scm",(void*)f_3133},
{"f_3136:c_backend_scm",(void*)f_3136},
{"f_3102:c_backend_scm",(void*)f_3102},
{"f_3105:c_backend_scm",(void*)f_3105},
{"f_3042:c_backend_scm",(void*)f_3042},
{"f11547:c_backend_scm",(void*)f11547},
{"f_3038:c_backend_scm",(void*)f_3038},
{"f_3024:c_backend_scm",(void*)f_3024},
{"f_3027:c_backend_scm",(void*)f_3027},
{"f_3021:c_backend_scm",(void*)f_3021},
{"f11542:c_backend_scm",(void*)f11542},
{"f_3017:c_backend_scm",(void*)f_3017},
{"f_3003:c_backend_scm",(void*)f_3003},
{"f_3006:c_backend_scm",(void*)f_3006},
{"f_2955:c_backend_scm",(void*)f_2955},
{"f_2976:c_backend_scm",(void*)f_2976},
{"f11537:c_backend_scm",(void*)f11537},
{"f_2972:c_backend_scm",(void*)f_2972},
{"f_2958:c_backend_scm",(void*)f_2958},
{"f_2961:c_backend_scm",(void*)f_2961},
{"f_2924:c_backend_scm",(void*)f_2924},
{"f_2920:c_backend_scm",(void*)f_2920},
{"f_2878:c_backend_scm",(void*)f_2878},
{"f_2846:c_backend_scm",(void*)f_2846},
{"f_2849:c_backend_scm",(void*)f_2849},
{"f_2811:c_backend_scm",(void*)f_2811},
{"f_2837:c_backend_scm",(void*)f_2837},
{"f_2823:c_backend_scm",(void*)f_2823},
{"f_2827:c_backend_scm",(void*)f_2827},
{"f_2830:c_backend_scm",(void*)f_2830},
{"f_2814:c_backend_scm",(void*)f_2814},
{"f_2779:c_backend_scm",(void*)f_2779},
{"f_2782:c_backend_scm",(void*)f_2782},
{"f_2785:c_backend_scm",(void*)f_2785},
{"f_2788:c_backend_scm",(void*)f_2788},
{"f_2750:c_backend_scm",(void*)f_2750},
{"f_2753:c_backend_scm",(void*)f_2753},
{"f_2756:c_backend_scm",(void*)f_2756},
{"f_2759:c_backend_scm",(void*)f_2759},
{"f_2713:c_backend_scm",(void*)f_2713},
{"f_2716:c_backend_scm",(void*)f_2716},
{"f_2719:c_backend_scm",(void*)f_2719},
{"f_2722:c_backend_scm",(void*)f_2722},
{"f_2680:c_backend_scm",(void*)f_2680},
{"f_2683:c_backend_scm",(void*)f_2683},
{"f_2686:c_backend_scm",(void*)f_2686},
{"f_2689:c_backend_scm",(void*)f_2689},
{"f_2661:c_backend_scm",(void*)f_2661},
{"f_2664:c_backend_scm",(void*)f_2664},
{"f_2634:c_backend_scm",(void*)f_2634},
{"f_2637:c_backend_scm",(void*)f_2637},
{"f_2583:c_backend_scm",(void*)f_2583},
{"f_2593:c_backend_scm",(void*)f_2593},
{"f_2596:c_backend_scm",(void*)f_2596},
{"f_2599:c_backend_scm",(void*)f_2599},
{"f_2525:c_backend_scm",(void*)f_2525},
{"f_2528:c_backend_scm",(void*)f_2528},
{"f_2531:c_backend_scm",(void*)f_2531},
{"f_2534:c_backend_scm",(void*)f_2534},
{"f_2537:c_backend_scm",(void*)f_2537},
{"f_2540:c_backend_scm",(void*)f_2540},
{"f_2356:c_backend_scm",(void*)f_2356},
{"f_2368:c_backend_scm",(void*)f_2368},
{"f_2376:c_backend_scm",(void*)f_2376},
{"f_2360:c_backend_scm",(void*)f_2360},
{"f_2317:c_backend_scm",(void*)f_2317},
{"f_2325:c_backend_scm",(void*)f_2325},
{"f_2327:c_backend_scm",(void*)f_2327},
{"f_2340:c_backend_scm",(void*)f_2340},
{"f_2280:c_backend_scm",(void*)f_2280},
{"f_2286:c_backend_scm",(void*)f_2286},
{"f_2299:c_backend_scm",(void*)f_2299},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
