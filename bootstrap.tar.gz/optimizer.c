/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-28 22:55
   Version 4.1.4 - SVN rev. 15427
   linux-unix-gnu-x86 [ ptables applyhook ]
   compiled 2009-08-13 on x (Linux)
   command line: optimizer.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature debugbuild -scrutinize -types ./types.db -no-lambda-info -local -extend private-namespace.scm -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[267];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11669)
static void C_ccall f_11669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_11677)
static void C_ccall f_11677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11682)
static void C_fcall f_11682(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11727)
static void C_ccall f_11727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11731)
static void C_ccall f_11731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11692)
static void C_ccall f_11692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11716)
static void C_ccall f_11716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10694)
static void C_ccall f_10694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_10728)
static void C_ccall f_10728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10830)
static void C_ccall f_10830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10840)
static void C_fcall f_10840(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10904)
static void C_ccall f_10904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10933)
static void C_fcall f_10933(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11070)
static void C_ccall f_11070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11062)
static void C_ccall f_11062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10949)
static void C_fcall f_10949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10996)
static void C_ccall f_10996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10986)
static void C_ccall f_10986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10994)
static void C_ccall f_10994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11140)
static void C_ccall f_11140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_11153)
static void C_ccall f_11153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11188)
static void C_ccall f_11188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11172)
static void C_ccall f_11172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11176)
static void C_ccall f_11176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11165)
static void C_ccall f_11165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11354)
static void C_ccall f_11354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_11367)
static void C_ccall f_11367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11373)
static void C_ccall f_11373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11419)
static void C_ccall f_11419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11411)
static void C_ccall f_11411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11395)
static void C_ccall f_11395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11399)
static void C_ccall f_11399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11403)
static void C_ccall f_11403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10372)
static void C_ccall f_10372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_10394)
static void C_ccall f_10394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10449)
static void C_ccall f_10449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10419)
static void C_ccall f_10419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10441)
static void C_ccall f_10441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10445)
static void C_ccall f_10445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10437)
static void C_ccall f_10437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10417)
static void C_ccall f_10417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10543)
static void C_ccall f_10543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_10557)
static void C_ccall f_10557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5231)
static void C_ccall f_5231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8317)
static void C_ccall f_8317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10251)
static void C_ccall f_10251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10254)
static void C_ccall f_10254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10257)
static void C_ccall f_10257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10260)
static void C_ccall f_10260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10263)
static void C_ccall f_10263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10266)
static void C_ccall f_10266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10343)
static void C_ccall f_10343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10269)
static void C_ccall f_10269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10272)
static void C_ccall f_10272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10275)
static void C_ccall f_10275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10337)
static void C_ccall f_10337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10278)
static void C_ccall f_10278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10281)
static void C_ccall f_10281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10334)
static void C_ccall f_10334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8990)
static void C_fcall f_8990(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9008)
static void C_ccall f_9008(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9014)
static void C_ccall f_9014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8994)
static void C_ccall f_8994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10284)
static void C_ccall f_10284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10326)
static void C_ccall f_10326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10324)
static void C_ccall f_10324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10287)
static void C_ccall f_10287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10290)
static void C_ccall f_10290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10293)
static void C_ccall f_10293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10317)
static void C_ccall f_10317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10296)
static void C_ccall f_10296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10299)
static void C_ccall f_10299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10302)
static void C_ccall f_10302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10305)
static void C_ccall f_10305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10308)
static void C_ccall f_10308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10311)
static void C_ccall f_10311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10035)
static void C_fcall f_10035(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10041)
static void C_fcall f_10041(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10227)
static void C_fcall f_10227(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10237)
static void C_ccall f_10237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10201)
static void C_fcall f_10201(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10211)
static void C_ccall f_10211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10176)
static void C_ccall f_10176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10185)
static void C_ccall f_10185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10188)
static void C_ccall f_10188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10146)
static void C_fcall f_10146(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10156)
static void C_ccall f_10156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10060)
static void C_ccall f_10060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10065)
static void C_fcall f_10065(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10103)
static void C_ccall f_10103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10088)
static void C_ccall f_10088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10099)
static void C_ccall f_10099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10095)
static void C_ccall f_10095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9902)
static void C_fcall f_9902(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9908)
static void C_fcall f_9908(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10012)
static void C_fcall f_10012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10022)
static void C_ccall f_10022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9987)
static void C_ccall f_9987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9983)
static void C_ccall f_9983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9930)
static void C_ccall f_9930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9939)
static void C_fcall f_9939(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9949)
static void C_ccall f_9949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9584)
static void C_fcall f_9584(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9598)
static void C_ccall f_9598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9605)
static void C_ccall f_9605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9608)
static void C_ccall f_9608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9617)
static void C_ccall f_9617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9624)
static void C_ccall f_9624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9627)
static void C_ccall f_9627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9723)
static void C_fcall f_9723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9879)
static void C_fcall f_9879(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9889)
static void C_ccall f_9889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9855)
static void C_ccall f_9855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9874)
static void C_ccall f_9874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9870)
static void C_ccall f_9870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9836)
static void C_ccall f_9836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9802)
static void C_ccall f_9802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9807)
static void C_fcall f_9807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9817)
static void C_ccall f_9817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9789)
static void C_ccall f_9789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9772)
static void C_ccall f_9772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9742)
static void C_ccall f_9742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9747)
static void C_fcall f_9747(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9757)
static void C_ccall f_9757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9708)
static void C_ccall f_9708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9630)
static void C_ccall f_9630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9679)
static void C_ccall f_9679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9667)
static void C_ccall f_9667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9663)
static void C_ccall f_9663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9596)
static void C_ccall f_9596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9298)
static void C_fcall f_9298(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9570)
static void C_ccall f_9570(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9409)
static void C_ccall f_9409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9547)
static void C_fcall f_9547(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9557)
static void C_ccall f_9557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9502)
static void C_ccall f_9502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9507)
static void C_ccall f_9507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9545)
static void C_ccall f_9545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9307)
static void C_fcall f_9307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9385)
static void C_fcall f_9385(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9395)
static void C_ccall f_9395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9368)
static void C_ccall f_9368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9373)
static void C_ccall f_9373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9327)
static void C_ccall f_9327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9332)
static void C_fcall f_9332(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9342)
static void C_ccall f_9342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9305)
static void C_ccall f_9305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9537)
static void C_ccall f_9537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9523)
static void C_ccall f_9523(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9521)
static void C_ccall f_9521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9411)
static void C_fcall f_9411(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9495)
static void C_ccall f_9495(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9493)
static void C_ccall f_9493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9465)
static void C_fcall f_9465(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9478)
static void C_ccall f_9478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9431)
static void C_ccall f_9431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9455)
static void C_ccall f_9455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9453)
static void C_ccall f_9453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9449)
static void C_ccall f_9449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9441)
static void C_ccall f_9441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9024)
static void C_fcall f_9024(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9030)
static void C_fcall f_9030(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9049)
static void C_fcall f_9049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9255)
static void C_fcall f_9255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9268)
static void C_ccall f_9268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9162)
static void C_ccall f_9162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9178)
static void C_fcall f_9178(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9231)
static void C_ccall f_9231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9198)
static void C_ccall f_9198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9207)
static void C_fcall f_9207(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9217)
static void C_ccall f_9217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9135)
static void C_ccall f_9135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9140)
static void C_fcall f_9140(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9153)
static void C_ccall f_9153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9111)
static void C_ccall f_9111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9123)
static void C_ccall f_9123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9060)
static void C_fcall f_9060(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9081)
static void C_ccall f_9081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9078)
static void C_ccall f_9078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9028)
static void C_ccall f_9028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8764)
static void C_fcall f_8764(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8770)
static void C_fcall f_8770(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8789)
static void C_fcall f_8789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8891)
static void C_fcall f_8891(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8904)
static void C_ccall f_8904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8882)
static void C_ccall f_8882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8848)
static void C_fcall f_8848(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8857)
static void C_ccall f_8857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8869)
static void C_ccall f_8869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8800)
static void C_fcall f_8800(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8821)
static void C_ccall f_8821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8818)
static void C_ccall f_8818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8768)
static void C_ccall f_8768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8665)
static void C_fcall f_8665(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8671)
static void C_ccall f_8671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8715)
static void C_ccall f_8715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8720)
static void C_fcall f_8720(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8727)
static void C_ccall f_8727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8742)
static void C_ccall f_8742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8740)
static void C_ccall f_8740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8705)
static void C_ccall f_8705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8683)
static void C_ccall f_8683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8690)
static void C_ccall f_8690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8420)
static void C_fcall f_8420(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8606)
static void C_fcall f_8606(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8647)
static void C_ccall f_8647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8630)
static void C_ccall f_8630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8634)
static void C_ccall f_8634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8604)
static void C_ccall f_8604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8423)
static void C_fcall f_8423(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8578)
static void C_fcall f_8578(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8591)
static void C_ccall f_8591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8561)
static void C_ccall f_8561(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8573)
static void C_ccall f_8573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8507)
static void C_fcall f_8507(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8531)
static void C_ccall f_8531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8489)
static void C_ccall f_8489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8448)
static void C_fcall f_8448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8451)
static void C_fcall f_8451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8456)
static void C_fcall f_8456(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8469)
static void C_ccall f_8469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8320)
static void C_fcall f_8320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8326)
static void C_ccall f_8326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8357)
static void C_fcall f_8357(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8365)
static void C_ccall f_8365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8324)
static void C_ccall f_8324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8312)
static void C_ccall f_8312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_fcall f_7128(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7284)
static void C_fcall f_7284(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7297)
static void C_ccall f_7297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7264)
static void C_ccall f_7264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_ccall f_7238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7184)
static void C_ccall f_7184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7190)
static void C_ccall f_7190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7196)
static void C_ccall f_7196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7153)
static void C_ccall f_7153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7306)
static void C_fcall f_7306(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7716)
static void C_ccall f_7716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7723)
static void C_ccall f_7723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7309)
static void C_fcall f_7309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7690)
static void C_ccall f_7690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7557)
static void C_fcall f_7557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7562)
static void C_ccall f_7562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7504)
static void C_ccall f_7504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7510)
static void C_fcall f_7510(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7463)
static void C_ccall f_7463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7469)
static void C_fcall f_7469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7443)
static void C_ccall f_7443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7413)
static void C_ccall f_7413(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7376)
static void C_ccall f_7376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7392)
static void C_ccall f_7392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7358)
static void C_ccall f_7358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7725)
static void C_fcall f_7725(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8302)
static void C_ccall f_8302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8300)
static void C_ccall f_8300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7729)
static void C_ccall f_7729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7748)
static void C_fcall f_7748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7754)
static void C_ccall f_7754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7757)
static void C_ccall f_7757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7763)
static void C_ccall f_7763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7971)
static void C_fcall f_7971(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8234)
static void C_fcall f_8234(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8244)
static void C_ccall f_8244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8208)
static void C_fcall f_8208(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8218)
static void C_ccall f_8218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8193)
static void C_ccall f_8193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8196)
static void C_ccall f_8196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8146)
static void C_ccall f_8146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8149)
static void C_ccall f_8149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8015)
static void C_ccall f_8015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8070)
static void C_ccall f_8070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8073)
static void C_ccall f_8073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8100)
static void C_ccall f_8100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8076)
static void C_ccall f_8076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8079)
static void C_ccall f_8079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8024)
static void C_ccall f_8024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8027)
static void C_ccall f_8027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8030)
static void C_ccall f_8030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7766)
static void C_ccall f_7766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7953)
static void C_ccall f_7953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7882)
static void C_fcall f_7882(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7901)
static void C_ccall f_7901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7769)
static void C_ccall f_7769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7781)
static void C_ccall f_7781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7836)
static void C_ccall f_7836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7784)
static void C_ccall f_7784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7792)
static void C_fcall f_7792(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7834)
static void C_ccall f_7834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7047)
static void C_fcall f_7047(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7096)
static void C_ccall f_7096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5278)
static void C_fcall f_5278(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7041)
static void C_ccall f_7041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7014)
static void C_ccall f_7014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6942)
static void C_ccall f_6942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6884)
static void C_ccall f_6884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6853)
static void C_ccall f_6853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6825)
static void C_ccall f_6825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6745)
static void C_ccall f_6745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6585)
static void C_ccall f_6585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6666)
static void C_ccall f_6666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6594)
static void C_ccall f_6594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6647)
static void C_ccall f_6647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6645)
static void C_ccall f_6645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6610)
static void C_ccall f_6610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6556)
static void C_ccall f_6556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6566)
static void C_ccall f_6566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6511)
static void C_fcall f_6511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6440)
static void C_fcall f_6440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_ccall f_6257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_fcall f_6213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6216)
static void C_ccall f_6216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6081)
static void C_fcall f_6081(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6087)
static void C_ccall f_6087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6004)
static void C_ccall f_6004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6016)
static void C_ccall f_6016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5838)
static void C_ccall f_5838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5860)
static void C_fcall f_5860(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_fcall f_5863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5900)
static void C_ccall f_5900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5898)
static void C_ccall f_5898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5874)
static void C_ccall f_5874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5762)
static void C_ccall f_5762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5775)
static void C_ccall f_5775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5446)
static void C_fcall f_5446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5313)
static void C_fcall f_5313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5233)
static void C_ccall f_5233(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5233)
static void C_ccall f_5233r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5237)
static void C_ccall f_5237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5218)
static void C_ccall f_5218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_fcall f_5144(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_fcall f_5069(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5085)
static void C_ccall f_5085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4933)
static void C_ccall f_4933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4953)
static void C_ccall f_4953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4966)
static void C_fcall f_4966(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_fcall f_4879(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4885)
static void C_fcall f_4885(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4909)
static void C_ccall f_4909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4642)
static void C_fcall f_4642(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4680)
static void C_fcall f_4680(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_fcall f_4695(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_fcall f_4707(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4716)
static void C_fcall f_4716(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_fcall f_4608(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4604)
static C_word C_fcall f_4604(C_word t0);
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4543)
static void C_fcall f_4543(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4556)
static void C_ccall f_4556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_fcall f_4464(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_fcall f_3335(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_fcall f_4414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4385)
static void C_fcall f_4385(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3892)
static void C_fcall f_3892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4261)
static void C_ccall f_4261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_fcall f_3913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_fcall f_4150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_fcall f_3999(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_fcall f_3945(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_ccall f_3774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_fcall f_3798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_fcall f_3753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_fcall f_3721(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3711)
static void C_ccall f_3711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static void C_fcall f_3438(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3360)
static void C_fcall f_3360(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_fcall f_3121(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3205)
static void C_ccall f_3205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_fcall f_3232(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3029)
static void C_fcall f_3029(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3054)
static void C_ccall f_3054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static C_word C_fcall f_3025(C_word t0);
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2999)
static void C_fcall f_2999(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2838)
static void C_fcall f_2838(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2890)
static void C_fcall f_2890(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2863)
static void C_fcall f_2863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_fcall f_2810(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2816)
static void C_fcall f_2816(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2750)
static void C_ccall f_2750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2758)
static void C_fcall f_2758(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static C_word C_fcall f_2729(C_word *a,C_word t0,C_word t1);

C_noret_decl(trf_11682)
static void C_fcall trf_11682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11682(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11682(t0,t1,t2);}

C_noret_decl(trf_10840)
static void C_fcall trf_10840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10840(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10840(t0,t1,t2,t3);}

C_noret_decl(trf_10933)
static void C_fcall trf_10933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10933(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10933(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10949)
static void C_fcall trf_10949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10949(t0,t1);}

C_noret_decl(trf_8990)
static void C_fcall trf_8990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8990(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8990(t0,t1,t2,t3);}

C_noret_decl(trf_10035)
static void C_fcall trf_10035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10035(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10035(t0,t1,t2);}

C_noret_decl(trf_10041)
static void C_fcall trf_10041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10041(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10041(t0,t1,t2);}

C_noret_decl(trf_10227)
static void C_fcall trf_10227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10227(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10227(t0,t1,t2);}

C_noret_decl(trf_10201)
static void C_fcall trf_10201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10201(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10201(t0,t1,t2);}

C_noret_decl(trf_10146)
static void C_fcall trf_10146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10146(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10146(t0,t1,t2);}

C_noret_decl(trf_10065)
static void C_fcall trf_10065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10065(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10065(t0,t1,t2,t3);}

C_noret_decl(trf_9902)
static void C_fcall trf_9902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9902(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9902(t0,t1,t2);}

C_noret_decl(trf_9908)
static void C_fcall trf_9908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9908(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9908(t0,t1,t2);}

C_noret_decl(trf_10012)
static void C_fcall trf_10012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10012(t0,t1,t2);}

C_noret_decl(trf_9939)
static void C_fcall trf_9939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9939(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9939(t0,t1,t2);}

C_noret_decl(trf_9584)
static void C_fcall trf_9584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9584(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9584(t0,t1,t2,t3);}

C_noret_decl(trf_9723)
static void C_fcall trf_9723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9723(t0,t1,t2);}

C_noret_decl(trf_9879)
static void C_fcall trf_9879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9879(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9879(t0,t1,t2);}

C_noret_decl(trf_9807)
static void C_fcall trf_9807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9807(t0,t1,t2);}

C_noret_decl(trf_9747)
static void C_fcall trf_9747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9747(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9747(t0,t1,t2);}

C_noret_decl(trf_9298)
static void C_fcall trf_9298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9298(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9298(t0,t1,t2);}

C_noret_decl(trf_9547)
static void C_fcall trf_9547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9547(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9547(t0,t1,t2);}

C_noret_decl(trf_9307)
static void C_fcall trf_9307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9307(t0,t1,t2);}

C_noret_decl(trf_9385)
static void C_fcall trf_9385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9385(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9385(t0,t1,t2);}

C_noret_decl(trf_9332)
static void C_fcall trf_9332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9332(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9332(t0,t1,t2);}

C_noret_decl(trf_9411)
static void C_fcall trf_9411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9411(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9411(t0,t1,t2);}

C_noret_decl(trf_9465)
static void C_fcall trf_9465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9465(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9465(t0,t1,t2);}

C_noret_decl(trf_9024)
static void C_fcall trf_9024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9024(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9024(t0,t1,t2);}

C_noret_decl(trf_9030)
static void C_fcall trf_9030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9030(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9030(t0,t1,t2,t3);}

C_noret_decl(trf_9049)
static void C_fcall trf_9049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9049(t0,t1);}

C_noret_decl(trf_9255)
static void C_fcall trf_9255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9255(t0,t1,t2);}

C_noret_decl(trf_9178)
static void C_fcall trf_9178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9178(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9178(t0,t1,t2);}

C_noret_decl(trf_9207)
static void C_fcall trf_9207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9207(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9207(t0,t1,t2);}

C_noret_decl(trf_9140)
static void C_fcall trf_9140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9140(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9140(t0,t1,t2);}

C_noret_decl(trf_9060)
static void C_fcall trf_9060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9060(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9060(t0,t1,t2,t3);}

C_noret_decl(trf_8764)
static void C_fcall trf_8764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8764(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8764(t0,t1,t2);}

C_noret_decl(trf_8770)
static void C_fcall trf_8770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8770(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8770(t0,t1,t2,t3);}

C_noret_decl(trf_8789)
static void C_fcall trf_8789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8789(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8789(t0,t1);}

C_noret_decl(trf_8891)
static void C_fcall trf_8891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8891(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8891(t0,t1,t2);}

C_noret_decl(trf_8848)
static void C_fcall trf_8848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8848(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8848(t0,t1);}

C_noret_decl(trf_8800)
static void C_fcall trf_8800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8800(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8800(t0,t1,t2,t3);}

C_noret_decl(trf_8665)
static void C_fcall trf_8665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8665(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8665(t0,t1,t2,t3);}

C_noret_decl(trf_8720)
static void C_fcall trf_8720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8720(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8720(t0,t1,t2,t3);}

C_noret_decl(trf_8420)
static void C_fcall trf_8420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8420(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8420(t0,t1,t2);}

C_noret_decl(trf_8606)
static void C_fcall trf_8606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8606(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8606(t0,t1,t2);}

C_noret_decl(trf_8423)
static void C_fcall trf_8423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8423(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8423(t0,t1,t2,t3);}

C_noret_decl(trf_8578)
static void C_fcall trf_8578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8578(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8578(t0,t1,t2);}

C_noret_decl(trf_8507)
static void C_fcall trf_8507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8507(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8507(t0,t1,t2,t3);}

C_noret_decl(trf_8448)
static void C_fcall trf_8448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8448(t0,t1);}

C_noret_decl(trf_8451)
static void C_fcall trf_8451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8451(t0,t1);}

C_noret_decl(trf_8456)
static void C_fcall trf_8456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8456(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8456(t0,t1,t2);}

C_noret_decl(trf_8320)
static void C_fcall trf_8320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8320(t0,t1);}

C_noret_decl(trf_8357)
static void C_fcall trf_8357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8357(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8357(t0,t1);}

C_noret_decl(trf_7128)
static void C_fcall trf_7128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7128(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7128(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7284)
static void C_fcall trf_7284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7284(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7284(t0,t1,t2);}

C_noret_decl(trf_7306)
static void C_fcall trf_7306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7306(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7306(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7309)
static void C_fcall trf_7309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7309(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7309(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7557)
static void C_fcall trf_7557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7557(t0,t1);}

C_noret_decl(trf_7510)
static void C_fcall trf_7510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7510(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7510(t0,t1);}

C_noret_decl(trf_7469)
static void C_fcall trf_7469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7469(t0,t1);}

C_noret_decl(trf_7725)
static void C_fcall trf_7725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7725(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7725(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7748)
static void C_fcall trf_7748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7748(t0,t1);}

C_noret_decl(trf_7971)
static void C_fcall trf_7971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7971(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7971(t0,t1,t2);}

C_noret_decl(trf_8234)
static void C_fcall trf_8234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8234(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8234(t0,t1,t2);}

C_noret_decl(trf_8208)
static void C_fcall trf_8208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8208(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8208(t0,t1,t2);}

C_noret_decl(trf_7882)
static void C_fcall trf_7882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7882(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7882(t0,t1,t2);}

C_noret_decl(trf_7792)
static void C_fcall trf_7792(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7792(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7792(t0,t1,t2);}

C_noret_decl(trf_7047)
static void C_fcall trf_7047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7047(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7047(t0,t1,t2,t3);}

C_noret_decl(trf_5278)
static void C_fcall trf_5278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5278(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5278(t0,t1);}

C_noret_decl(trf_6511)
static void C_fcall trf_6511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6511(t0,t1);}

C_noret_decl(trf_6440)
static void C_fcall trf_6440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6440(t0,t1);}

C_noret_decl(trf_6213)
static void C_fcall trf_6213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6213(t0,t1);}

C_noret_decl(trf_6081)
static void C_fcall trf_6081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6081(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6081(t0,t1);}

C_noret_decl(trf_5860)
static void C_fcall trf_5860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5860(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5860(t0,t1);}

C_noret_decl(trf_5863)
static void C_fcall trf_5863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5863(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5863(t0,t1);}

C_noret_decl(trf_5446)
static void C_fcall trf_5446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5446(t0,t1);}

C_noret_decl(trf_5313)
static void C_fcall trf_5313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5313(t0,t1);}

C_noret_decl(trf_5144)
static void C_fcall trf_5144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5144(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5144(t0,t1,t2);}

C_noret_decl(trf_5069)
static void C_fcall trf_5069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5069(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5069(t0,t1,t2);}

C_noret_decl(trf_4966)
static void C_fcall trf_4966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4966(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4966(t0,t1);}

C_noret_decl(trf_4879)
static void C_fcall trf_4879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4879(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4879(t0,t1,t2,t3);}

C_noret_decl(trf_4885)
static void C_fcall trf_4885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4885(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4885(t0,t1,t2,t3);}

C_noret_decl(trf_4642)
static void C_fcall trf_4642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4642(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4642(t0,t1,t2);}

C_noret_decl(trf_4680)
static void C_fcall trf_4680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4680(t0,t1);}

C_noret_decl(trf_4695)
static void C_fcall trf_4695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4695(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4695(t0,t1);}

C_noret_decl(trf_4707)
static void C_fcall trf_4707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4707(t0,t1);}

C_noret_decl(trf_4716)
static void C_fcall trf_4716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4716(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4716(t0,t1);}

C_noret_decl(trf_4608)
static void C_fcall trf_4608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4608(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4608(t0,t1,t2,t3);}

C_noret_decl(trf_4543)
static void C_fcall trf_4543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4543(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4543(t0,t1,t2);}

C_noret_decl(trf_4464)
static void C_fcall trf_4464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4464(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4464(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3335)
static void C_fcall trf_3335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3335(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3335(t0,t1,t2,t3);}

C_noret_decl(trf_4414)
static void C_fcall trf_4414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4414(t0,t1);}

C_noret_decl(trf_4385)
static void C_fcall trf_4385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4385(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4385(t0,t1);}

C_noret_decl(trf_3892)
static void C_fcall trf_3892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3892(t0,t1);}

C_noret_decl(trf_3913)
static void C_fcall trf_3913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3913(t0,t1);}

C_noret_decl(trf_4150)
static void C_fcall trf_4150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4150(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4150(t0,t1);}

C_noret_decl(trf_3999)
static void C_fcall trf_3999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3999(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3999(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3945)
static void C_fcall trf_3945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3945(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3945(t0,t1,t2);}

C_noret_decl(trf_3798)
static void C_fcall trf_3798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3798(t0,t1);}

C_noret_decl(trf_3753)
static void C_fcall trf_3753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3753(t0,t1);}

C_noret_decl(trf_3721)
static void C_fcall trf_3721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3721(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3721(t0,t1,t2);}

C_noret_decl(trf_3438)
static void C_fcall trf_3438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3438(t0,t1);}

C_noret_decl(trf_3360)
static void C_fcall trf_3360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3360(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3360(t0,t1,t2);}

C_noret_decl(trf_3121)
static void C_fcall trf_3121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3121(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3121(t0,t1,t2,t3);}

C_noret_decl(trf_3232)
static void C_fcall trf_3232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3232(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3232(t0,t1);}

C_noret_decl(trf_3029)
static void C_fcall trf_3029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3029(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3029(t0,t1,t2);}

C_noret_decl(trf_2999)
static void C_fcall trf_2999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2999(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2999(t0,t1,t2,t3);}

C_noret_decl(trf_2838)
static void C_fcall trf_2838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2838(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2838(t0,t1,t2,t3);}

C_noret_decl(trf_2890)
static void C_fcall trf_2890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2890(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2890(t0,t1);}

C_noret_decl(trf_2863)
static void C_fcall trf_2863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2863(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2863(t0,t1);}

C_noret_decl(trf_2810)
static void C_fcall trf_2810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2810(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2810(t0,t1,t2,t3);}

C_noret_decl(trf_2816)
static void C_fcall trf_2816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2816(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2816(t0,t1,t2);}

C_noret_decl(trf_2758)
static void C_fcall trf_2758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2758(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2758(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1977)){
C_save(t1);
C_rereclaim2(1977*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,267);
lf[0]=C_h_intern(&lf[0],34,"\010compilerscan-toplevel-assignments");
lf[1]=C_h_intern(&lf[1],8,"\003sysput!");
lf[2]=C_h_intern(&lf[2],21,"\010compileralways-bound");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[5]=C_h_intern(&lf[5],18,"\010compilerdebugging");
lf[6]=C_h_intern(&lf[6],1,"o");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[8]=C_h_intern(&lf[8],13,"\004corevariable");
lf[9]=C_h_intern(&lf[9],2,"if");
lf[10]=C_h_intern(&lf[10],3,"let");
lf[11]=C_h_intern(&lf[11],6,"append");
lf[12]=C_h_intern(&lf[12],6,"lambda");
lf[13]=C_h_intern(&lf[13],13,"\004corecallunit");
lf[14]=C_h_intern(&lf[14],9,"\004corecall");
lf[15]=C_h_intern(&lf[15],4,"set!");
lf[16]=C_h_intern(&lf[16],9,"\004corecond");
lf[17]=C_h_intern(&lf[17],11,"\004coreswitch");
lf[18]=C_h_intern(&lf[18],30,"call-with-current-continuation");
lf[19]=C_h_intern(&lf[19],1,"p");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[21]=C_h_intern(&lf[21],24,"\010compilersimplifications");
lf[22]=C_h_intern(&lf[22],23,"\010compilersimplified-ops");
lf[23]=C_h_intern(&lf[23],41,"\010compilerperform-high-level-optimizations");
lf[24]=C_h_intern(&lf[24],12,"\010compilerget");
lf[25]=C_h_intern(&lf[25],5,"quote");
lf[26]=C_h_intern(&lf[26],10,"alist-cons");
lf[27]=C_h_intern(&lf[27],4,"caar");
lf[28]=C_h_intern(&lf[28],7,"\003sysmap");
lf[29]=C_h_intern(&lf[29],19,"\010compilermatch-node");
lf[30]=C_h_intern(&lf[30],3,"any");
lf[31]=C_h_intern(&lf[31],18,"\003syshash-table-ref");
lf[32]=C_h_intern(&lf[32],30,"\010compilerbroken-constant-nodes");
lf[33]=C_h_intern(&lf[33],11,"lset-adjoin");
lf[34]=C_h_intern(&lf[34],3,"eq\077");
lf[35]=C_h_intern(&lf[35],4,"node");
lf[36]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[37]=C_h_intern(&lf[37],14,"\010compilerqnode");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[39]=C_h_intern(&lf[39],4,"eval");
lf[40]=C_h_intern(&lf[40],22,"with-exception-handler");
lf[41]=C_h_intern(&lf[41],5,"every");
lf[42]=C_h_intern(&lf[42],9,"foldable\077");
lf[43]=C_h_intern(&lf[43],7,"\003sysget");
lf[44]=C_h_intern(&lf[44],18,"\010compilerintrinsic");
lf[45]=C_h_intern(&lf[45],5,"value");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[47]=C_h_intern(&lf[47],16,"\010compilervarnode");
lf[48]=C_h_intern(&lf[48],11,"collapsable");
lf[49]=C_h_intern(&lf[49],10,"replacable");
lf[50]=C_h_intern(&lf[50],9,"replacing");
lf[51]=C_h_intern(&lf[51],12,"contractable");
lf[52]=C_h_intern(&lf[52],9,"removable");
lf[53]=C_h_intern(&lf[53],11,"\004corelambda");
lf[54]=C_h_intern(&lf[54],6,"unused");
lf[55]=C_h_intern(&lf[55],9,"partition");
lf[56]=C_h_intern(&lf[56],26,"\010compilerbuild-lambda-list");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[58]=C_h_intern(&lf[58],13,"explicit-rest");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[60]=C_h_intern(&lf[60],30,"\010compilerdecompose-lambda-list");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[62]=C_h_intern(&lf[62],21,"has-unused-parameters");
lf[63]=C_h_intern(&lf[63],31,"\010compilerinline-lambda-bindings");
lf[64]=C_h_intern(&lf[64],13,"\010compilerput!");
lf[65]=C_h_intern(&lf[65],13,"inline-target");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[67]=C_h_intern(&lf[67],24,"\010compilercheck-signature");
lf[68]=C_h_intern(&lf[68],30,"\010compilerconstant-declarations");
lf[69]=C_h_intern(&lf[69],14,"\004coreundefined");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[71]=C_h_intern(&lf[71],1,"x");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[73]=C_h_intern(&lf[73],37,"\010compilerexpression-has-side-effects\077");
lf[74]=C_h_intern(&lf[74],8,"assigned");
lf[75]=C_h_intern(&lf[75],10,"references");
lf[76]=C_h_intern(&lf[76],7,"unknown");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\017global inlining");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\010inlining");
lf[80]=C_h_intern(&lf[80],1,"i");
lf[81]=C_h_intern(&lf[81],22,"\010compilerinline-global");
lf[82]=C_h_intern(&lf[82],14,"append-reverse");
lf[83]=C_h_intern(&lf[83],6,"gensym");
lf[84]=C_h_intern(&lf[84],1,"t");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[86]=C_h_intern(&lf[86],8,"split-at");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[88]=C_h_intern(&lf[88],20,"\004coreinline_allocate");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[90]=C_h_intern(&lf[90],21,"\010compilerllist-length");
lf[91]=C_h_intern(&lf[91],23,"\010compilerinline-locally");
lf[92]=C_h_intern(&lf[92],3,"yes");
lf[93]=C_h_intern(&lf[93],2,"no");
lf[94]=C_h_intern(&lf[94],24,"\010compilerinline-max-size");
lf[95]=C_h_intern(&lf[95],15,"\010compilerinline");
lf[96]=C_h_intern(&lf[96],9,"inlinable");
lf[97]=C_h_intern(&lf[97],11,"local-value");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[99]=C_h_intern(&lf[99],16,"inline-transient");
lf[100]=C_h_intern(&lf[100],26,"\010compilervariable-visible\077");
lf[101]=C_h_intern(&lf[101],6,"global");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[105]=C_h_intern(&lf[105],5,"print");
lf[106]=C_h_intern(&lf[106],7,"newline");
lf[107]=C_h_intern(&lf[107],6,"print*");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[111]=C_h_intern(&lf[111],34,"\010compilerperform-pre-optimization!");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[113]=C_h_intern(&lf[113],24,"node-subexpressions-set!");
lf[114]=C_h_intern(&lf[114],7,"reverse");
lf[115]=C_h_intern(&lf[115],20,"node-parameters-set!");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[117]=C_h_intern(&lf[117],17,"\010compilerget-list");
lf[118]=C_h_intern(&lf[118],3,"not");
lf[119]=C_h_intern(&lf[119],10,"call-sites");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[121]=C_h_intern(&lf[121],24,"register-simplifications");
lf[122]=C_h_intern(&lf[122],19,"\003syshash-table-set!");
lf[123]=C_h_intern(&lf[123],38,"\010compilerreorganize-recursive-bindings");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\026eliminated assignments");
lf[125]=C_h_intern(&lf[125],10,"fold-right");
lf[126]=C_h_intern(&lf[126],4,"fold");
lf[127]=C_h_intern(&lf[127],16,"topological-sort");
lf[128]=C_h_intern(&lf[128],6,"lset<=");
lf[129]=C_h_intern(&lf[129],10,"filter-map");
lf[130]=C_h_intern(&lf[130],6,"filter");
lf[131]=C_h_intern(&lf[131],10,"append-map");
lf[132]=C_h_intern(&lf[132],28,"\010compilerscan-used-variables");
lf[133]=C_h_intern(&lf[133],8,"for-each");
lf[134]=C_h_intern(&lf[134],3,"map");
lf[135]=C_h_intern(&lf[135],4,"cons");
lf[136]=C_h_intern(&lf[136],27,"\010compilersubstitution-table");
lf[137]=C_h_intern(&lf[137],16,"\010compilerrewrite");
lf[138]=C_h_intern(&lf[138],28,"\010compilersimplify-named-call");
lf[139]=C_h_intern(&lf[139],37,"\010compilerinline-substitutions-enabled");
lf[140]=C_h_intern(&lf[140],11,"\004coreinline");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[142]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[143]=C_h_intern(&lf[143],6,"unsafe");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[146]=C_h_intern(&lf[146],6,"vector");
lf[147]=C_h_intern(&lf[147],14,"rest-parameter");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[149]=C_h_intern(&lf[149],11,"number-type");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[151]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[154]=C_h_intern(&lf[154],6,"fixnum");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[156]=C_h_intern(&lf[156],21,"\010compilerfold-boolean");
lf[157]=C_h_intern(&lf[157],6,"flonum");
lf[158]=C_h_intern(&lf[158],7,"generic");
lf[159]=C_h_intern(&lf[159],5,"cons*");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[161]=C_h_intern(&lf[161],9,"\004coreproc");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[164]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[170]=C_h_intern(&lf[170],19,"\010compilerfold-inner");
lf[171]=C_h_intern(&lf[171],6,"remove");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[176]=C_h_intern(&lf[176],5,"fifth");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[178]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[179]=C_h_intern(&lf[179],13,"\010compilerbomb");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[181]=C_h_intern(&lf[181],34,"\010compilertransform-direct-lambdas!");
lf[182]=C_h_intern(&lf[182],19,"\010compilercopy-node!");
lf[183]=C_h_intern(&lf[183],16,"\004coredirect_call");
lf[184]=C_h_intern(&lf[184],4,"quit");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[186]=C_h_intern(&lf[186],15,"lset-difference");
lf[187]=C_h_intern(&lf[187],15,"node-class-set!");
lf[188]=C_h_intern(&lf[188],12,"\004corerecurse");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[190]=C_h_intern(&lf[190],4,"take");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[193]=C_h_intern(&lf[193],11,"\004corereturn");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[195]=C_h_intern(&lf[195],18,"\004coredirect_lambda");
lf[196]=C_h_intern(&lf[196],6,"cdaddr");
lf[197]=C_h_intern(&lf[197],6,"caaddr");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[200]=C_h_intern(&lf[200],6,"unzip1");
lf[201]=C_h_intern(&lf[201],16,"\003sysmake-promise");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[203]=C_h_intern(&lf[203],5,"boxed");
lf[204]=C_h_intern(&lf[204],15,"\004coreinline_ref");
lf[205]=C_h_intern(&lf[205],37,"\010compilerestimate-foreign-result-size");
lf[206]=C_h_intern(&lf[206],19,"\004coreinline_loc_ref");
lf[207]=C_h_intern(&lf[207],5,"lset=");
lf[208]=C_h_intern(&lf[208],6,"delete");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[210]=C_h_intern(&lf[210],32,"\010compilerperform-lambda-lifting!");
lf[211]=C_h_intern(&lf[211],23,"\003syshash-table-for-each");
lf[212]=C_h_intern(&lf[212],1,"+");
lf[213]=C_h_intern(&lf[213],17,"delete-duplicates");
lf[214]=C_h_intern(&lf[214],14,"\004coreprimitive");
lf[215]=C_h_intern(&lf[215],7,"delete!");
lf[216]=C_h_intern(&lf[216],11,"concatenate");
lf[217]=C_h_intern(&lf[217],5,"count");
lf[218]=C_h_intern(&lf[218],22,"\010compilerhide-variable");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[222]=C_h_intern(&lf[222],12,"pretty-print");
lf[223]=C_h_intern(&lf[223],1,"l");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[234]=C_h_intern(&lf[234],11,"make-vector");
lf[235]=C_h_intern(&lf[235],3,"var");
lf[236]=C_h_intern(&lf[236],1,"y");
lf[237]=C_h_intern(&lf[237],2,"d2");
lf[238]=C_h_intern(&lf[238],1,"z");
lf[239]=C_h_intern(&lf[239],2,"d3");
lf[240]=C_h_intern(&lf[240],2,"d1");
lf[241]=C_h_intern(&lf[241],2,"op");
lf[242]=C_h_intern(&lf[242],5,"clist");
lf[243]=C_h_intern(&lf[243],34,"\010compilermembership-test-operators");
lf[244]=C_h_intern(&lf[244],32,"\010compilermembership-unfold-limit");
lf[245]=C_h_intern(&lf[245],4,"var1");
lf[246]=C_h_intern(&lf[246],4,"var0");
lf[247]=C_h_intern(&lf[247],6,"const1");
lf[248]=C_h_intern(&lf[248],4,"var2");
lf[249]=C_h_intern(&lf[249],6,"const2");
lf[250]=C_h_intern(&lf[250],4,"rest");
lf[251]=C_h_intern(&lf[251],5,"body2");
lf[252]=C_h_intern(&lf[252],5,"body1");
lf[253]=C_h_intern(&lf[253],27,"\010compilereq-inline-operator");
lf[254]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[255]=C_h_intern(&lf[255],19,"\010compilerimmediate\077");
lf[256]=C_h_intern(&lf[256],5,"const");
lf[257]=C_h_intern(&lf[257],1,"n");
lf[258]=C_h_intern(&lf[258],7,"clauses");
lf[259]=C_h_intern(&lf[259],4,"body");
lf[260]=C_h_intern(&lf[260],1,"d");
lf[261]=C_h_intern(&lf[261],4,"more");
lf[262]=C_h_intern(&lf[262],4,"args");
lf[263]=C_h_intern(&lf[263],1,"a");
lf[264]=C_h_intern(&lf[264],1,"b");
lf[265]=C_h_intern(&lf[265],1,"c");
lf[266]=C_h_intern(&lf[266],4,"cdar");
C_register_lf2(lf,267,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2709,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2707 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2712,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2710 in k2707 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2715,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2713 in k2710 in k2707 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2724,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2724,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2726,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 105  make-vector");
((C_proc4)C_retrieve_proc(*((C_word*)lf[234]+1)))(4,*((C_word*)lf[234]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2993,2,t0,t1);}
t2=C_mutate((C_word*)lf[21]+1 /* (set! simplifications ...) */,t1);
t3=C_set_block_item(lf[22] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[23]+1 /* (set! perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2996,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[111]+1 /* (set! perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4601,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[121]+1 /* (set! register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4858,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4865,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_cons(&a,2,lf[263],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[8],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[264],lf[265]);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[260],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[14],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[260],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[265],t15);
t17=(C_word)C_a_i_cons(&a,2,lf[264],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[263],t17);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11669,tmp=(C_word)a,a+=2,tmp);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t18,t20);
t22=(C_word)C_a_i_cons(&a,2,t14,t21);
t23=(C_word)C_a_i_list(&a,1,t22);
C_trace("optimizer.scm: 475  ##sys#hash-table-set!");
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t7,*((C_word*)lf[21]+1),lf[14],t23);}

/* a11668 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_11669,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11677,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 484  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t7,C_retrieve(lf[136]),t3);}

/* k11675 in a11668 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11677,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11682,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_11682(t6,((C_word*)t0)[2],t2);}

/* loop in k11675 in a11668 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_11682(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11682,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11692,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11727,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 486  caar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[27]+1)))(3,*((C_word*)lf[27]+1),t4,t2);}}

/* k11725 in loop in k11675 in a11668 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11731,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 486  cdar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[266]+1)))(3,*((C_word*)lf[266]+1),t2,((C_word*)t0)[2]);}

/* k11729 in k11725 in loop in k11675 in a11668 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 486  simplify-named-call");
((C_proc9)C_retrieve_symbol_proc(lf[138]))(9,*((C_word*)lf[138]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11690 in loop in k11675 in a11668 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11692,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[22]));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_fixnum_increase(t3);
t5=(C_word)C_i_set_cdr(t2,t4);
t6=t1;
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11716,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 491  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t3,((C_word*)t0)[5],C_fix(1),C_retrieve(lf[22]));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 493  loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_11682(t3,((C_word*)t0)[4],t2);}}

/* k11714 in k11690 in loop in k11675 in a11668 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate((C_word*)lf[22]+1 /* (set! simplified-ops ...) */,t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word ab[446],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[245],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[8],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[247],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[25],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,t4,t12);
t14=(C_word)C_a_i_cons(&a,2,lf[140],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[245],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[8],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[248],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[8],t21);
t23=(C_word)C_a_i_cons(&a,2,lf[249],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[25],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t22,t26);
t28=(C_word)C_a_i_cons(&a,2,t19,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[140],t28);
t30=(C_word)C_a_i_cons(&a,2,lf[248],C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t30,C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[8],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[250],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[251],t33);
t35=(C_word)C_a_i_cons(&a,2,t32,t34);
t36=(C_word)C_a_i_cons(&a,2,lf[237],t35);
t37=(C_word)C_a_i_cons(&a,2,lf[9],t36);
t38=(C_word)C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t29,t38);
t40=(C_word)C_a_i_cons(&a,2,t18,t39);
t41=(C_word)C_a_i_cons(&a,2,lf[10],t40);
t42=(C_word)C_a_i_cons(&a,2,t41,C_SCHEME_END_OF_LIST);
t43=(C_word)C_a_i_cons(&a,2,lf[252],t42);
t44=(C_word)C_a_i_cons(&a,2,t17,t43);
t45=(C_word)C_a_i_cons(&a,2,lf[240],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[9],t45);
t47=(C_word)C_a_i_cons(&a,2,t46,C_SCHEME_END_OF_LIST);
t48=(C_word)C_a_i_cons(&a,2,t14,t47);
t49=(C_word)C_a_i_cons(&a,2,t3,t48);
t50=(C_word)C_a_i_cons(&a,2,lf[10],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[250],C_SCHEME_END_OF_LIST);
t52=(C_word)C_a_i_cons(&a,2,lf[237],t51);
t53=(C_word)C_a_i_cons(&a,2,lf[240],t52);
t54=(C_word)C_a_i_cons(&a,2,lf[251],t53);
t55=(C_word)C_a_i_cons(&a,2,lf[252],t54);
t56=(C_word)C_a_i_cons(&a,2,lf[249],t55);
t57=(C_word)C_a_i_cons(&a,2,lf[247],t56);
t58=(C_word)C_a_i_cons(&a,2,lf[241],t57);
t59=(C_word)C_a_i_cons(&a,2,lf[248],t58);
t60=(C_word)C_a_i_cons(&a,2,lf[245],t59);
t61=(C_word)C_a_i_cons(&a,2,lf[246],t60);
t62=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11354,tmp=(C_word)a,a+=2,tmp);
t63=(C_word)C_a_i_cons(&a,2,t62,C_SCHEME_END_OF_LIST);
t64=(C_word)C_a_i_cons(&a,2,t61,t63);
t65=(C_word)C_a_i_cons(&a,2,t50,t64);
t66=(C_word)C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t67=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t68=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t69=(C_word)C_a_i_cons(&a,2,t68,C_SCHEME_END_OF_LIST);
t70=(C_word)C_a_i_cons(&a,2,lf[8],t69);
t71=(C_word)C_a_i_cons(&a,2,lf[256],C_SCHEME_END_OF_LIST);
t72=(C_word)C_a_i_cons(&a,2,t71,C_SCHEME_END_OF_LIST);
t73=(C_word)C_a_i_cons(&a,2,lf[25],t72);
t74=(C_word)C_a_i_cons(&a,2,t73,C_SCHEME_END_OF_LIST);
t75=(C_word)C_a_i_cons(&a,2,t70,t74);
t76=(C_word)C_a_i_cons(&a,2,t67,t75);
t77=(C_word)C_a_i_cons(&a,2,lf[140],t76);
t78=(C_word)C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t79=(C_word)C_a_i_cons(&a,2,t78,C_SCHEME_END_OF_LIST);
t80=(C_word)C_a_i_cons(&a,2,lf[8],t79);
t81=(C_word)C_a_i_cons(&a,2,lf[257],C_SCHEME_END_OF_LIST);
t82=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t83=(C_word)C_a_i_cons(&a,2,t82,C_SCHEME_END_OF_LIST);
t84=(C_word)C_a_i_cons(&a,2,lf[8],t83);
t85=(C_word)C_a_i_cons(&a,2,t84,lf[258]);
t86=(C_word)C_a_i_cons(&a,2,t81,t85);
t87=(C_word)C_a_i_cons(&a,2,lf[17],t86);
t88=(C_word)C_a_i_cons(&a,2,t87,C_SCHEME_END_OF_LIST);
t89=(C_word)C_a_i_cons(&a,2,lf[259],t88);
t90=(C_word)C_a_i_cons(&a,2,t80,t89);
t91=(C_word)C_a_i_cons(&a,2,lf[260],t90);
t92=(C_word)C_a_i_cons(&a,2,lf[9],t91);
t93=(C_word)C_a_i_cons(&a,2,t92,C_SCHEME_END_OF_LIST);
t94=(C_word)C_a_i_cons(&a,2,t77,t93);
t95=(C_word)C_a_i_cons(&a,2,t66,t94);
t96=(C_word)C_a_i_cons(&a,2,lf[10],t95);
t97=(C_word)C_a_i_cons(&a,2,lf[258],C_SCHEME_END_OF_LIST);
t98=(C_word)C_a_i_cons(&a,2,lf[257],t97);
t99=(C_word)C_a_i_cons(&a,2,lf[259],t98);
t100=(C_word)C_a_i_cons(&a,2,lf[260],t99);
t101=(C_word)C_a_i_cons(&a,2,lf[256],t100);
t102=(C_word)C_a_i_cons(&a,2,lf[246],t101);
t103=(C_word)C_a_i_cons(&a,2,lf[241],t102);
t104=(C_word)C_a_i_cons(&a,2,lf[235],t103);
t105=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11140,tmp=(C_word)a,a+=2,tmp);
t106=(C_word)C_a_i_cons(&a,2,t105,C_SCHEME_END_OF_LIST);
t107=(C_word)C_a_i_cons(&a,2,t104,t106);
t108=(C_word)C_a_i_cons(&a,2,t96,t107);
t109=(C_word)C_a_i_cons(&a,2,lf[245],C_SCHEME_END_OF_LIST);
t110=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t111=(C_word)C_a_i_cons(&a,2,lf[69],t110);
t112=(C_word)C_a_i_cons(&a,2,lf[261],C_SCHEME_END_OF_LIST);
t113=(C_word)C_a_i_cons(&a,2,t111,t112);
t114=(C_word)C_a_i_cons(&a,2,t109,t113);
t115=(C_word)C_a_i_cons(&a,2,lf[10],t114);
t116=(C_word)C_a_i_cons(&a,2,lf[261],C_SCHEME_END_OF_LIST);
t117=(C_word)C_a_i_cons(&a,2,lf[245],t116);
t118=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10830,tmp=(C_word)a,a+=2,tmp);
t119=(C_word)C_a_i_cons(&a,2,t118,C_SCHEME_END_OF_LIST);
t120=(C_word)C_a_i_cons(&a,2,t117,t119);
t121=(C_word)C_a_i_cons(&a,2,t115,t120);
t122=(C_word)C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t123=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t124=(C_word)C_a_i_cons(&a,2,t123,lf[262]);
t125=(C_word)C_a_i_cons(&a,2,lf[140],t124);
t126=(C_word)C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t127=(C_word)C_a_i_cons(&a,2,t126,C_SCHEME_END_OF_LIST);
t128=(C_word)C_a_i_cons(&a,2,lf[8],t127);
t129=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t130=(C_word)C_a_i_cons(&a,2,lf[71],t129);
t131=(C_word)C_a_i_cons(&a,2,t128,t130);
t132=(C_word)C_a_i_cons(&a,2,lf[260],t131);
t133=(C_word)C_a_i_cons(&a,2,lf[9],t132);
t134=(C_word)C_a_i_cons(&a,2,t133,C_SCHEME_END_OF_LIST);
t135=(C_word)C_a_i_cons(&a,2,t125,t134);
t136=(C_word)C_a_i_cons(&a,2,t122,t135);
t137=(C_word)C_a_i_cons(&a,2,lf[10],t136);
t138=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t139=(C_word)C_a_i_cons(&a,2,lf[71],t138);
t140=(C_word)C_a_i_cons(&a,2,lf[260],t139);
t141=(C_word)C_a_i_cons(&a,2,lf[262],t140);
t142=(C_word)C_a_i_cons(&a,2,lf[241],t141);
t143=(C_word)C_a_i_cons(&a,2,lf[235],t142);
t144=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10694,tmp=(C_word)a,a+=2,tmp);
t145=(C_word)C_a_i_cons(&a,2,t144,C_SCHEME_END_OF_LIST);
t146=(C_word)C_a_i_cons(&a,2,t143,t145);
t147=(C_word)C_a_i_cons(&a,2,t137,t146);
t148=(C_word)C_a_i_list(&a,4,t65,t108,t121,t147);
C_trace("optimizer.scm: 475  ##sys#hash-table-set!");
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t2,*((C_word*)lf[21]+1),lf[10],t148);}

/* a10693 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_10694,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[253])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10728,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 632  get-list");
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t9,t2,t3,lf[75]);}}

/* k10726 in a10693 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10728,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t6=((C_word*)t0)[5];
t7=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t5,t6);
t8=(C_word)C_a_i_list(&a,3,t7,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[35],lf[9],t4,t8));}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a10829 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10830,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10840,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_10840(t9,t1,t5,t4);}

/* loop1 in a10829 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_10840(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10840,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_car(t9);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_slot(t12,C_fix(3));
t15=(C_word)C_slot(t12,C_fix(1));
t16=(C_word)C_eqp(t15,lf[69]);
if(C_truep(t16)){
t17=(C_word)C_i_car(t7);
t18=(C_word)C_a_i_cons(&a,2,t17,t2);
t19=(C_word)C_i_cadr(t9);
C_trace("optimizer.scm: 577  loop1");
t23=t1;
t24=t18;
t25=t19;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t17=(C_word)C_eqp(t15,lf[15]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10904,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t14,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 579  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t18,t2);}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k10902 in loop1 in a10829 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10904,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10933,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_10933(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k10902 in loop1 in a10829 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_10933(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10933,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t4;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t4;
t10=(C_word)C_slot(t9,C_fix(3));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10949,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_eqp(t6,lf[10]);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11070,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t10,a[5]=t3,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
t15=(C_word)C_i_car(t8);
C_trace("optimizer.scm: 590  get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t14,((C_word*)t0)[2],t15,lf[99]);}
else{
t14=t11;
f_10949(t14,C_SCHEME_FALSE);}}
else{
t13=t11;
f_10949(t13,C_SCHEME_FALSE);}}

/* k11068 in loop2 in k10902 in loop1 in a10829 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11070,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_10949(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11062,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 591  get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2],t3,lf[75]);}}

/* k11060 in k11068 in loop2 in k10902 in loop1 in a10829 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10949(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(lf[15],t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=((C_word*)t0)[4];
f_10949(t9,(C_word)C_eqp(t5,t8));}
else{
t5=((C_word*)t0)[4];
f_10949(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
f_10949(t2,C_SCHEME_FALSE);}}}

/* k10947 in loop2 in k10902 in loop1 in a10829 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_10949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10949,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
C_trace("optimizer.scm: 595  loop2");
t8=((C_word*)((C_word*)t0)[5])[1];
f_10933(t8,((C_word*)t0)[4],t5,t6,t7);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10986,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10996,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a10995 in k10947 in loop2 in k10902 in loop1 in a10829 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10996,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a10985 in k10947 in loop2 in k10902 in loop1 in a10829 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 600  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2]);}

/* k10992 in a10985 in k10947 in loop2 in k10902 in loop1 in a10829 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 600  reorganize-recursive-bindings");
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a11139 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_11140,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[253])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11153,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 543  immediate?");
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k11151 in a11139 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11153,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11188,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 544  get-list");
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[75]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11186 in k11151 in a11139 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11188,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11165,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 548  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k11170 in k11186 in k11151 in a11139 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 549  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}

/* k11174 in k11170 in k11186 in k11151 in a11139 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 548  cons*");
((C_proc6)C_retrieve_symbol_proc(lf[159]))(6,*((C_word*)lf[159]+1),((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11163 in k11186 in k11151 in a11139 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11165,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[17],((C_word*)t0)[2],t1));}

/* a11353 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_11354,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[253])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11367,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 516  immediate?");
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k11365 in a11353 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11367,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 517  immediate?");
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11371 in k11365 in a11353 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11373,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11419,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 518  get-list");
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[75]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11417 in k11371 in k11365 in a11353 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11419,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11411,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 519  get-list");
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[75]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k11409 in k11417 in k11371 in k11365 in a11353 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11411,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 523  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k11393 in k11409 in k11417 in k11371 in k11365 in a11353 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 524  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}

/* k11397 in k11393 in k11409 in k11417 in k11371 in k11365 in a11353 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11403,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 526  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}

/* k11401 in k11397 in k11393 in k11409 in k11417 in k11371 in k11365 in a11353 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_11403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11403,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[17],lf[254],t2));}

/* k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word ab[166],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[8],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[237],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[14],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[8],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[238],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t12,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[239],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[14],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,t9,t17);
t19=(C_word)C_a_i_cons(&a,2,lf[71],t18);
t20=(C_word)C_a_i_cons(&a,2,lf[240],t19);
t21=(C_word)C_a_i_cons(&a,2,lf[9],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[238],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[236],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[71],t24);
t26=(C_word)C_a_i_cons(&a,2,lf[239],t25);
t27=(C_word)C_a_i_cons(&a,2,lf[237],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[240],t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10543,tmp=(C_word)a,a+=2,tmp);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t28,t30);
t32=(C_word)C_a_i_cons(&a,2,t21,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[242],C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t34,C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,lf[25],t35);
t37=(C_word)C_a_i_cons(&a,2,t36,C_SCHEME_END_OF_LIST);
t38=(C_word)C_a_i_cons(&a,2,lf[71],t37);
t39=(C_word)C_a_i_cons(&a,2,t33,t38);
t40=(C_word)C_a_i_cons(&a,2,lf[140],t39);
t41=(C_word)C_a_i_cons(&a,2,lf[238],C_SCHEME_END_OF_LIST);
t42=(C_word)C_a_i_cons(&a,2,lf[236],t41);
t43=(C_word)C_a_i_cons(&a,2,t40,t42);
t44=(C_word)C_a_i_cons(&a,2,lf[240],t43);
t45=(C_word)C_a_i_cons(&a,2,lf[9],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[238],C_SCHEME_END_OF_LIST);
t47=(C_word)C_a_i_cons(&a,2,lf[236],t46);
t48=(C_word)C_a_i_cons(&a,2,lf[242],t47);
t49=(C_word)C_a_i_cons(&a,2,lf[71],t48);
t50=(C_word)C_a_i_cons(&a,2,lf[241],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[240],t50);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10372,tmp=(C_word)a,a+=2,tmp);
t53=(C_word)C_a_i_cons(&a,2,t52,C_SCHEME_END_OF_LIST);
t54=(C_word)C_a_i_cons(&a,2,t51,t53);
t55=(C_word)C_a_i_cons(&a,2,t45,t54);
t56=(C_word)C_a_i_list(&a,2,t32,t55);
C_trace("optimizer.scm: 475  ##sys#hash-table-set!");
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t2,*((C_word*)lf[21]+1),lf[9],t56);}

/* a10371 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_10372,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[243]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[244]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10394,a[2]=t6,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,a[7]=t3,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 670  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k10392 in a10371 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10394,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=((C_word*)t0)[7];
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10417,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10419,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10449,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 687  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t8,C_SCHEME_FALSE);}

/* k10447 in k10392 in a10371 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 679  fold-right");
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a10418 in k10392 in a10371 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10419,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10441,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 684  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t4,((C_word*)t0)[2]);}

/* k10439 in a10418 in k10392 in a10371 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 684  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[2]);}

/* k10443 in k10439 in a10418 in k10392 in a10371 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10445,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[140],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 685  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t4,C_SCHEME_TRUE);}

/* k10435 in k10443 in k10439 in a10418 in k10392 in a10371 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10437,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[16],C_SCHEME_END_OF_LIST,t2));}

/* k10415 in k10392 in a10371 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10417,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[9],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[10],((C_word*)t0)[2],t4));}

/* a10542 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_10543,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[139]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10557,a[2]=t4,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 655  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k10555 in a10542 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10557,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[16],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t4));}

/* k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1 /* (set! reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4873,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5231,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 782  make-vector");
((C_proc4)C_retrieve_proc(*((C_word*)lf[234]+1)))(4,*((C_word*)lf[234]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5231,2,t0,t1);}
t2=C_mutate((C_word*)lf[136]+1 /* (set! substitution-table ...) */,t1);
t3=C_mutate((C_word*)lf[137]+1 /* (set! rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5233,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[138]+1 /* (set! simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5253,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[181]+1 /* (set! transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7125,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[210]+1 /* (set! perform-lambda-lifting! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8317,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[44],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8317,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8320,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8420,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8665,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8764,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9024,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9298,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9584,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9902,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10035,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10251,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 1758 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t15,lf[19],lf[233]);}

/* k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10254,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1759 find-lifting-candidates");
t3=((C_word*)t0)[2];
f_8320(t3,t2);}

/* k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10257,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 1760 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[232]);}

/* k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1761 build-call-graph");
t3=((C_word*)t0)[2];
f_8420(t3,t2,((C_word*)t0)[3]);}

/* k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10263,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 1762 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[231]);}

/* k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10266,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 1763 eliminate");
t3=((C_word*)t0)[4];
f_8665(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10269,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10343,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1764 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,lf[223],lf[230]);}

/* k10341 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("optimizer.scm: 1764 pretty-print");
((C_proc3)C_retrieve_symbol_proc(lf[222]))(3,*((C_word*)lf[222]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10269(2,t2,C_SCHEME_UNDEFINED);}}

/* k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 1765 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[229]);}

/* k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 1766 collect-accessibles");
t3=((C_word*)t0)[2];
f_8764(t3,t2,((C_word*)t0)[3]);}

/* k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10337,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1767 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,lf[223],lf[228]);}

/* k10335 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("optimizer.scm: 1767 pretty-print");
((C_proc3)C_retrieve_symbol_proc(lf[222]))(3,*((C_word*)lf[222]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10278(2,t2,C_SCHEME_UNDEFINED);}}

/* k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 1768 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[227]);}

/* k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10284,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10334,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1769 eliminate4");
t4=((C_word*)t0)[3];
f_9024(t4,t3,((C_word*)t0)[2]);}

/* k10332 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10334,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8990,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8990(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k10332 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8990(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8990,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8994,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9008,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1563 filter");
((C_proc4)C_retrieve_symbol_proc(lf[130]))(4,*((C_word*)lf[130]+1),t4,t5,t2);}

/* a9007 in loop in k10332 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9008(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9008,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9014,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(t2);
C_trace("optimizer.scm: 1563 every");
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),t1,t3,t4);}

/* a9013 in a9007 in loop in k10332 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9014,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k8992 in loop in k10332 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
C_trace("optimizer.scm: 1567 loop");
t5=((C_word*)((C_word*)t0)[2])[1];
f_8990(t5,((C_word*)t0)[3],t1,t2);}}

/* k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10324,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10326,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#make-promise");
t5=*((C_word*)lf[201]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a10325 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10326,2,t0,t1);}
C_trace("optimizer.scm: 1770 unzip1");
((C_proc3)C_retrieve_symbol_proc(lf[200]))(3,*((C_word*)lf[200]+1),t1,((C_word*)t0)[2]);}

/* k10322 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1770 debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),((C_word*)t0)[2],lf[6],lf[226],t1);}

/* k10285 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1771 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[225]);}

/* k10288 in k10285 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1772 compute-extra-variables");
t3=((C_word*)t0)[2];
f_9298(t3,t2,((C_word*)t0)[5]);}

/* k10291 in k10288 in k10285 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10317,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1773 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,lf[223],lf[224]);}

/* k10315 in k10291 in k10288 in k10285 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("optimizer.scm: 1773 pretty-print");
((C_proc3)C_retrieve_symbol_proc(lf[222]))(3,*((C_word*)lf[222]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10296(2,t2,C_SCHEME_UNDEFINED);}}

/* k10294 in k10291 in k10288 in k10285 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 1774 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[221]);}

/* k10297 in k10294 in k10291 in k10288 in k10285 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1775 extend-call-sites!");
t3=((C_word*)t0)[2];
f_9902(t3,t2,((C_word*)t0)[4]);}

/* k10300 in k10297 in k10294 in k10291 in k10288 in k10285 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1776 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[220]);}

/* k10303 in k10300 in k10297 in k10294 in k10291 in k10288 in k10285 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1777 remove-local-bindings!");
t3=((C_word*)t0)[2];
f_10035(t3,t2,((C_word*)t0)[4]);}

/* k10306 in k10303 in k10300 in k10297 in k10294 in k10291 in k10288 in k10285 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1778 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[219]);}

/* k10309 in k10306 in k10303 in k10300 in k10297 in k10294 in k10291 in k10288 in k10285 in k10282 in k10279 in k10276 in k10273 in k10270 in k10267 in k10264 in k10261 in k10258 in k10255 in k10252 in k10249 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1779 reconstruct!");
t2=((C_word*)t0)[5];
f_9584(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_10035(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10035,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10041,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10041(t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_10041(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10041,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10060,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=(C_word)C_slot(t11,C_fix(3));
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10146,a[2]=((C_word*)t0)[2],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_10146(t16,t10,t12);}
else{
t10=(C_word)C_eqp(t4,lf[15]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10176,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=t2;
t13=(C_word)C_slot(t12,C_fix(3));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10201,a[2]=((C_word*)t0)[2],a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_10201(t17,t11,t13);}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10227,a[2]=((C_word*)t0)[2],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_10227(t14,t1,t8);}}}

/* loop2633 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_10227(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10227,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10237,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2572");
t5=((C_word*)((C_word*)t0)[2])[1];
f_10041(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10235 in loop2633 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10227(t3,((C_word*)t0)[2],t2);}

/* loop2618 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_10201(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10201,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10211,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2572");
t5=((C_word*)((C_word*)t0)[2])[1];
f_10041(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10209 in loop2618 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10201(t3,((C_word*)t0)[2],t2);}

/* k10174 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10176,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1753 node-class-set!");
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t3,((C_word*)t0)[2],lf[69]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10183 in k10174 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1754 node-parameters-set!");
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10186 in k10183 in k10174 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1755 node-subexpressions-set!");
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop2587 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_10146(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10146,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10156,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2572");
t5=((C_word*)((C_word*)t0)[2])[1];
f_10041(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10154 in loop2587 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10146(t3,((C_word*)t0)[2],t2);}

/* k10058 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10060,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10065,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_10065(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop2597 in k10058 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_10065(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10065,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
C_trace("optimizer.scm: 1743 copy-node!");
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10088,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10103,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1745 reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t4,((C_word*)t0)[3]))){
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_i_cdr(t3);
t19=t1;
t20=t5;
t21=t6;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[6])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[6])+1,t6);
t8=(C_word)C_i_car(t3);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)((C_word*)t0)[4])[1]);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t11=(C_word)C_i_cdr(t2);
t12=(C_word)C_i_cdr(t3);
t19=t1;
t20=t11;
t21=t12;
t1=t19;
t2=t20;
t3=t21;
goto loop;}}}

/* k10101 in doloop2597 in k10058 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1745 node-parameters-set!");
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10086 in doloop2597 in k10058 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10095,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10099,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1746 reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k10097 in k10086 in doloop2597 in k10058 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1746 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10093 in k10086 in doloop2597 in k10058 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1746 node-subexpressions-set!");
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9902(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9902,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9908,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9908(t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9908(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9908,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9930,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t10,C_fix(1));
t13=(C_word)C_eqp(lf[8],t12);
if(C_truep(t13)){
t14=(C_word)C_slot(t10,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
if(C_truep(t16)){
t17=(C_word)C_i_set_car(t6,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9983,a[2]=t2,a[3]=t11,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9987,a[2]=t18,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cdr(t16);
C_trace("map");
t21=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,C_retrieve(lf[47]),t20);}
else{
t17=C_SCHEME_UNDEFINED;
t18=t11;
f_9930(2,t18,t17);}}
else{
t14=t11;
f_9930(2,t14,C_SCHEME_UNDEFINED);}}
else{
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10012,a[2]=((C_word*)t0)[3],a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_10012(t13,t1,t8);}}

/* loop2563 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_10012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10012,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10022,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2528");
t5=((C_word*)((C_word*)t0)[2])[1];
f_9908(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10020 in loop2563 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_10022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10012(t3,((C_word*)t0)[2],t2);}

/* k9985 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1725 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],t1,t2);}

/* k9981 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9983,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("optimizer.scm: 1723 node-subexpressions-set!");
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9928 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9930,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)C_slot(t2,C_fix(3));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9939,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_9939(t7,((C_word*)t0)[2],t3);}

/* loop2552 in k9928 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9939(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9939,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9949,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2528");
t5=((C_word*)((C_word*)t0)[2])[1];
f_9908(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9947 in loop2552 in k9928 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9939(t3,((C_word*)t0)[2],t2);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9584(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9584,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9596,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9598,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
C_trace("optimizer.scm: 1659 fold-right");
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),t4,t5,t8,t2);}

/* a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9598,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9605,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1662 get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t5,((C_word*)t0)[2],t4,lf[45]);}

/* k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1663 hide-variable");
((C_proc3)C_retrieve_symbol_proc(lf[218]))(3,*((C_word*)lf[218]+1),t2,((C_word*)t0)[5]);}

/* k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9608,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9617,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1664 decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[2],t3,t4);}

/* a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9617,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9624,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
C_trace("map");
t8=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[83]),t6);}

/* k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9627,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1669 map");
((C_proc5)C_retrieve_proc(*((C_word*)lf[134]+1)))(5,*((C_word*)lf[134]+1),t2,*((C_word*)lf[135]+1),((C_word*)t0)[5],t1);}

/* k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9708,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9723,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_9723(t9,t2,t4);}

/* walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9723,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9742,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9772,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t12=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],t6);}
else{
t10=(C_word)C_eqp(t4,lf[8]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9789,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_car(t6);
C_trace("optimizer.scm: 1698 rename");
t13=((C_word*)t0)[2];
f_9708(3,t13,t11,t12);}
else{
t11=(C_word)C_eqp(t4,lf[15]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9802,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9836,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_car(t6);
C_trace("optimizer.scm: 1700 rename");
t15=((C_word*)t0)[2];
f_9708(3,t15,t13,t14);}
else{
t12=(C_word)C_eqp(t4,lf[12]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1703 decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t1,t13,t14);}
else{
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9879,a[2]=((C_word*)t0)[3],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_9879(t16,t1,t8);}}}}}

/* loop2518 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9879(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9879,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9889,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2479");
t5=((C_word*)((C_word*)t0)[2])[1];
f_9723(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9887 in loop2518 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9879(t3,((C_word*)t0)[2],t2);}

/* a9854 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9855,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9870,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9874,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k9872 in a9854 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1706 build-lambda-list");
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9868 in a9854 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1707 walk");
t4=((C_word*)((C_word*)t0)[3])[1];
f_9723(t4,((C_word*)t0)[2],t3);}

/* k9834 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9836,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 1700 node-parameters-set!");
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9800 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9802,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9807,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_9807(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2504 in k9800 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9807,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9817,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2479");
t5=((C_word*)((C_word*)t0)[2])[1];
f_9723(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9815 in loop2504 in k9800 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9807(t3,((C_word*)t0)[2],t2);}

/* k9787 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9789,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 1698 node-parameters-set!");
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9770 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1695 node-parameters-set!");
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9740 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9742,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9747,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_9747(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2494 in k9740 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9747(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9747,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9757,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2479");
t5=((C_word*)((C_word*)t0)[2])[1];
f_9723(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9755 in loop2494 in k9740 in walk in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9747(t3,((C_word*)t0)[2],t2);}

/* rename in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9708,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k9628 in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1672 gensym");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[84]);}

/* k9677 in k9628 in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9679,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9663,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9667,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1678 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9665 in k9677 in k9628 in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
C_trace("optimizer.scm: 1678 build-lambda-list");
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k9661 in k9677 in k9628 in k9625 in k9622 in a9616 in k9606 in k9603 in a9597 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9663,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_a_i_record(&a,4,lf[35],lf[12],t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_record(&a,4,lf[35],lf[15],((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[4]);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[35],lf[10],((C_word*)t0)[2],t7));}

/* k9594 in reconstruct! in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9596,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 1656 node-subexpressions-set!");
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9298(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9298,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9409,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9570,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a9569 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9570(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9570,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9409,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9411,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9502,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9547,a[2]=t5,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_9547(t11,t7,((C_word*)t0)[4]);}

/* loop2398 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9547(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9547,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9557,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2401");
t5=((C_word*)((C_word*)t0)[2])[1];
f_9411(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9555 in loop2398 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9547(t3,((C_word*)t0)[2],t2);}

/* k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9507,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9507,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9545,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1645 get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t4,((C_word*)t0)[2],t3,lf[45]);}

/* k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9545,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9307,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9307(t8,t4,t1);}

/* walk in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9307,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9327,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1621 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t10,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(t4,lf[12]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9368,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1624 decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t1,t11,t12);}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9385,a[2]=((C_word*)t0)[2],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_9385(t14,t1,t8);}}}

/* loop2384 in walk in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9385(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9385,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9395,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2355");
t5=((C_word*)((C_word*)t0)[2])[1];
f_9307(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9393 in loop2384 in walk in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9385(t3,((C_word*)t0)[2],t2);}

/* a9367 in walk in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9368,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9373,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1627 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k9371 in a9367 in walk in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1628 walk");
t4=((C_word*)((C_word*)t0)[3])[1];
f_9307(t4,((C_word*)t0)[2],t3);}

/* k9325 in walk in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9327,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9332,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9332(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2370 in k9325 in walk in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9332(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9332,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9342,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("walk2355");
t5=((C_word*)((C_word*)t0)[2])[1];
f_9307(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9340 in loop2370 in k9325 in walk in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9332(t3,((C_word*)t0)[2],t2);}

/* k9303 in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9305,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9521,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9523,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9537,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1651 delete-duplicates");
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t5,t6,*((C_word*)lf[34]+1));}

/* k9535 in k9303 in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1647 remove");
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9522 in k9303 in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9523(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9523,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k9519 in k9303 in k9543 in a9506 in k9500 in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9521,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9411,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9495,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1636 count");
((C_proc4)C_retrieve_symbol_proc(lf[217]))(4,*((C_word*)lf[217]+1),t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a9494 in walk in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9495(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9495,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k9491 in walk in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9493,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9431,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_9465(t9,t5,t4);}}

/* loop2416 in k9491 in walk in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9465(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9465,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9478,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_assq(t3,((C_word*)t0)[3]);
C_trace("optimizer.scm: 1639 walk");
t6=((C_word*)((C_word*)t0)[2])[1];
f_9411(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9476 in loop2416 in k9491 in walk in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9465(t3,((C_word*)t0)[2],t2);}

/* k9429 in k9491 in walk in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9431,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9441,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9449,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9453,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9455,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t8=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a9454 in k9429 in k9491 in walk in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9455,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k9451 in k9429 in k9491 in walk in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1641 concatenate");
((C_proc3)C_retrieve_symbol_proc(lf[216]))(3,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1);}

/* k9447 in k9429 in k9491 in walk in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1641 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9439 in k9429 in k9491 in walk in k9407 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9024(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9024,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9028,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9030,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9030(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9030(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9030,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9049,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9049(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[25]);
if(C_truep(t12)){
t13=t11;
f_9049(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[69]);
if(C_truep(t13)){
t14=t11;
f_9049(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[214]);
t15=t11;
f_9049(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[161])));}}}}

/* k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9049(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9049,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[10]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9060,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9060(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9111,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1586 decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[14]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9162,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1592 call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t6,t7);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9255,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_9255(t8,((C_word*)t0)[8],((C_word*)t0)[3]);}}}}}

/* loop2341 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9255,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9268,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1607 walk");
t5=((C_word*)((C_word*)t0)[3])[1];
f_9030(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9266 in loop2341 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9255(t3,((C_word*)t0)[2],t2);}

/* a9161 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9162,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_eqp(lf[8],t3);
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t8=(C_word)C_i_car(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9178,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_9178(t12,t1,t8);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* loop in a9161 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9178(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9178,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9198,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9231,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
C_trace("optimizer.scm: 1601 lset<=");
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t7,*((C_word*)lf[34]+1),t8,((C_word*)t0)[2]);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k9229 in loop in a9161 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9231,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_9198(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9235,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1603 delete!");
((C_proc5)C_retrieve_symbol_proc(lf[215]))(5,*((C_word*)lf[215]+1),t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[34]+1));}}

/* k9233 in k9229 in loop in a9161 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
C_trace("optimizer.scm: 1604 return");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9196 in loop in a9161 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9198,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9207,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9207(t6,((C_word*)t0)[2],t2);}

/* loop2317 in k9196 in loop in a9161 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9207(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9207,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9217,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("loop2305");
t5=((C_word*)((C_word*)t0)[2])[1];
f_9178(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9215 in loop2317 in k9196 in loop in a9161 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9207(t3,((C_word*)t0)[2],t2);}

/* k9133 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9135,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9140,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_9140(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2330 in k9133 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9140(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9140,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9153,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1606 walk");
t5=((C_word*)((C_word*)t0)[3])[1];
f_9030(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9151 in loop2330 in k9133 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9140(t3,((C_word*)t0)[2],t2);}

/* a9110 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9111,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9123,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1589 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t6,t2,((C_word*)t0)[2]);}

/* k9121 in a9110 in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1589 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_9030(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_9060(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9060,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9078,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1581 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9081,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
C_trace("optimizer.scm: 1583 walk");
t6=((C_word*)((C_word*)t0)[5])[1];
f_9030(t6,t4,t5,((C_word*)t0)[3]);}}

/* k9079 in loop in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1584 loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_9060(t4,((C_word*)t0)[2],t2,t3);}

/* k9076 in loop in k9047 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1581 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_9030(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9026 in eliminate4 in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_9028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8764(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8764,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8768,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8770,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_8770(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8770(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8770,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t3,a[8]=t7,a[9]=((C_word*)t0)[5],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t10)){
t12=t11;
f_8789(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[25]);
if(C_truep(t12)){
t13=t11;
f_8789(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[69]);
if(C_truep(t13)){
t14=t11;
f_8789(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[214]);
t15=t11;
f_8789(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[161])));}}}}

/* k8787 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8789,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[10]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8800,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_8800(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[12]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8848,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8882,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
C_trace("optimizer.scm: 1538 alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t5;
f_8848(t8,t7);}}
else{
t6=t5;
f_8848(t6,C_SCHEME_UNDEFINED);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8891,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8891(t7,((C_word*)t0)[11],((C_word*)t0)[6]);}}}}

/* loop2227 in k8787 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8891(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8891,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8904,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1544 walk");
t5=((C_word*)((C_word*)t0)[3])[1];
f_8770(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8902 in loop2227 in k8787 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8891(t3,((C_word*)t0)[2],t2);}

/* k8880 in k8787 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_8848(t3,t2);}

/* k8846 in k8787 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8848(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8848,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1539 decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[2],t2,t3);}

/* a8856 in k8846 in k8787 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8857,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8869,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1542 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t6,t2,((C_word*)t0)[2]);}

/* k8867 in a8856 in k8846 in k8787 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1542 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_8770(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k8787 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8800(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8800,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8818,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1529 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8821,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
C_trace("optimizer.scm: 1531 walk");
t6=((C_word*)((C_word*)t0)[5])[1];
f_8770(t6,t4,t5,((C_word*)t0)[3]);}}

/* k8819 in loop in k8787 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1532 loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_8800(t4,((C_word*)t0)[2],t2,t3);}

/* k8816 in loop in k8787 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1529 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_8770(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8766 in collect-accessibles in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8665(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8665,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8671,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1499 remove");
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),t1,t4,t3);}

/* a8670 in eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8671,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8705,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8715,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1509 unzip1");
((C_proc3)C_retrieve_symbol_proc(lf[200]))(3,*((C_word*)lf[200]+1),t6,t5);}

/* k8713 in a8670 in eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8715,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8720,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8720(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k8713 in a8670 in eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8720(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8720,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8727,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
C_trace("optimizer.scm: 1512 lset-difference");
((C_proc6)C_retrieve_symbol_proc(lf[186]))(6,*((C_word*)lf[186]+1),t5,*((C_word*)lf[34]+1),t6,t3,((C_word*)t0)[2]);}

/* k8725 in count in k8713 in a8670 in eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8754,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1513 delete-duplicates");
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t2,t3,*((C_word*)lf[34]+1));}

/* k8752 in k8725 in count in k8713 in a8670 in eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8754,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8750,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1514 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8748 in k8752 in k8725 in count in k8713 in a8670 in eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8750,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8740,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8742,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a8741 in k8748 in k8752 in k8725 in count in k8713 in a8670 in eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8742,3,t0,t1,t2);}
C_trace("optimizer.scm: 1515 count");
t3=((C_word*)((C_word*)t0)[3])[1];
f_8720(t3,t1,t2,((C_word*)t0)[2]);}

/* k8738 in k8748 in k8752 in k8725 in count in k8713 in a8670 in eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1515 fold");
((C_proc5)C_retrieve_symbol_proc(lf[126]))(5,*((C_word*)lf[126]+1),((C_word*)t0)[3],*((C_word*)lf[212]+1),((C_word*)t0)[2],t1);}

/* k8703 in a8670 in eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8705,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1502 any");
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),((C_word*)t0)[5],t3,t4);}}

/* a8682 in k8703 in a8670 in eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8683,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8690,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1503 get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t3,((C_word*)t0)[2],t2,lf[74]);}

/* k8688 in a8682 in k8703 in a8670 in eliminate in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8420(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8420,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8423,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8604,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8606,a[2]=t10,a[3]=t14,a[4]=t4,a[5]=t8,a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_8606(t16,t12,t2);}

/* loop2068 in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8606(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8606,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_END_OF_LIST);
t9=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8630,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8647,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1488 decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t10,t7,t11);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a8646 in loop2068 in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8647,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t6=(C_word)C_i_car(t5);
C_trace("optimizer.scm: 1491 walk");
t7=((C_word*)((C_word*)t0)[2])[1];
f_8423(t7,t1,t6,t2);}

/* k8628 in loop2068 in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8634,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
C_trace("optimizer.scm: 1492 alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[8])[1]);}

/* k8632 in k8628 in loop2068 in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8606(t4,((C_word*)t0)[2],t3);}

/* k8602 in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8423(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8423,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[15]));
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8448,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t12,a[5]=t9,a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_i_memq(t12,t3);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8489,a[2]=((C_word*)t0)[3],a[3]=t12,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t14)){
t16=t15;
f_8489(2,t16,t14);}
else{
C_trace("optimizer.scm: 1464 get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t15,((C_word*)t0)[2],t12,lf[101]);}}
else{
t12=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8507,a[2]=t14,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_8507(t16,t1,t7,t9);}
else{
t13=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8561,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1476 decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t1,t14,t15);}
else{
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8578,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t15,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_8578(t17,t1,t9);}}}}

/* loop2123 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8578(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8578,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8591,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1479 walk");
t5=((C_word*)((C_word*)t0)[3])[1];
f_8423(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8589 in loop2123 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8578(t3,((C_word*)t0)[2],t2);}

/* a8560 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8561(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8561,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8573,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1478 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t6,t2,((C_word*)t0)[2]);}

/* k8571 in a8560 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1478 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_8423(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8507(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8507,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8525,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1471 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8531,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
C_trace("optimizer.scm: 1473 walk");
t7=((C_word*)((C_word*)t0)[5])[1];
f_8423(t7,t5,t6,((C_word*)t0)[3]);}}

/* k8529 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1474 loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_8507(t4,((C_word*)t0)[2],t2,t3);}

/* k8523 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1471 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_8423(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8487 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8489,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8448(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_8448(t4,t3);}}

/* k8446 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8448,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8451,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_8451(t5,t4);}
else{
t3=t2;
f_8451(t3,C_SCHEME_UNDEFINED);}}

/* k8449 in k8446 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8451,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8456,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8456(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2102 in k8449 in k8446 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8456(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8456,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8469,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1467 walk");
t5=((C_word*)((C_word*)t0)[3])[1];
f_8423(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8467 in loop2102 in k8449 in k8446 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8456(t3,((C_word*)t0)[2],t2);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8320,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8324,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8326,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1435 ##sys#hash-table-for-each");
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t4,t5,((C_word*)t0)[2]);}

/* a8325 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8326,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[45],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[75],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[119],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8357,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[76],t3))){
t10=t9;
f_8357(t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t4);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[12],t11);
if(C_truep(t12)){
if(C_truep((C_word)C_i_assq(lf[101],t3))){
t13=t9;
f_8357(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_cdr(t6);
t14=(C_word)C_i_length(t13);
t15=t9;
f_8357(t15,(C_word)C_eqp(t8,t14));}}
else{
t13=t9;
f_8357(t13,C_SCHEME_FALSE);}}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k8355 in a8325 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8357(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8357,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1446 alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k8359 in k8355 in a8325 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8361,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8365,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1447 alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k8363 in k8359 in k8355 in a8325 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8322 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7125,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7725,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7306,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7128,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8312,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1414 debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t17,lf[19],lf[209]);}

/* k8310 in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8315,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1415 walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_7128(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8313 in k8310 in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7128(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7128,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t3;
t8=(C_word)C_slot(t7,C_fix(3));
t9=t3;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[53]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7153,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
if(C_truep((C_word)C_i_cadr(t6))){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7238,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t8,a[7]=t3,a[8]=t12,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 1206 get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t14,((C_word*)t0)[2],t2,lf[76]);}
else{
t14=t13;
f_7153(2,t14,C_SCHEME_FALSE);}}
else{
t14=t13;
f_7153(2,t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t10,lf[15]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(C_word)C_i_car(t8);
C_trace("optimizer.scm: 1216 walk");
t26=t1;
t27=t13;
t28=t14;
t29=C_SCHEME_FALSE;
t1=t26;
t2=t27;
t3=t28;
t4=t29;
goto loop;}
else{
t13=(C_word)C_eqp(t10,lf[10]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7264,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t6);
t16=(C_word)C_i_car(t8);
C_trace("optimizer.scm: 1218 walk");
t26=t14;
t27=t15;
t28=t16;
t29=t3;
t1=t26;
t2=t27;
t3=t28;
t4=t29;
goto loop;}
else{
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7284,a[2]=((C_word*)t0)[4],a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_7284(t17,t1,t8);}}}}

/* loop1708 in walk in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7284(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7284,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7297,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1220 walk");
t5=((C_word*)((C_word*)t0)[2])[1];
f_7128(t5,t4,C_SCHEME_FALSE,t3,C_SCHEME_FALSE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7295 in loop1708 in walk in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7284(t3,((C_word*)t0)[2],t2);}

/* k7262 in walk in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1219 walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_7128(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k7236 in walk in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7238,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_7153(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 1208 get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[45]);}
else{
t2=((C_word*)t0)[9];
f_7153(2,t2,C_SCHEME_FALSE);}}}

/* k7182 in k7236 in walk in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7184,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1209 get-list");
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[75]);}
else{
t2=((C_word*)t0)[4];
f_7153(2,t2,C_SCHEME_FALSE);}}

/* k7188 in k7182 in k7236 in walk in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7190,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 1210 get-list");
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[119]);}
else{
t2=((C_word*)t0)[4];
f_7153(2,t2,C_SCHEME_FALSE);}}

/* k7194 in k7188 in k7182 in k7236 in walk in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7196,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
C_trace("optimizer.scm: 1213 scan");
t9=((C_word*)t0)[4];
f_7306(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_7153(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_7153(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_7153(2,t2,C_SCHEME_FALSE);}}

/* k7151 in walk in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("optimizer.scm: 1214 transform");
t2=((C_word*)t0)[11];
f_7725(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1215 walk");
t3=((C_word*)((C_word*)t0)[2])[1];
f_7128(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7306(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7306,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7309,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7716,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1299 rec");
t18=((C_word*)t12)[1];
f_7309(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k7714 in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7716,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7723,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1300 delete");
((C_proc5)C_retrieve_symbol_proc(lf[208]))(5,*((C_word*)lf[208]+1),t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[34]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7721 in k7714 in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1300 lset=");
((C_proc5)C_retrieve_symbol_proc(lf[207]))(5,*((C_word*)lf[207]+1),((C_word*)t0)[3],*((C_word*)lf[34]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7309,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[8]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7358,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t13,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1231 get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t14,((C_word*)t0)[9],t13,lf[203]);}
else{
t13=(C_word)C_eqp(t11,lf[53]);
if(C_truep(t13)){
if(C_truep(t3)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7376,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1239 decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t1,t14,t15);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(t11,lf[88]);
if(C_truep(t14)){
t15=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=(C_word)C_i_cadr(t7);
t17=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t16);
t18=C_mutate(((C_word *)((C_word*)t0)[10])+1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7413,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1248 every");
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),t1,t19,t9);}}
else{
t15=(C_word)C_eqp(t11,lf[195]);
if(C_truep(t15)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[6])){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7447,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_car(t9);
C_trace("optimizer.scm: 1251 scan-used-variables");
((C_proc4)C_retrieve_symbol_proc(lf[132]))(4,*((C_word*)lf[132]+1),t16,t17,t5);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_eqp(t11,lf[204]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7463,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t18=(C_word)C_i_cadr(t7);
C_trace("optimizer.scm: 1256 estimate-foreign-result-size");
((C_proc3)C_retrieve_symbol_proc(lf[205]))(3,*((C_word*)lf[205]+1),t17,t18);}
else{
t17=(C_word)C_eqp(t11,lf[206]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7504,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t19=(C_word)C_i_car(t7);
C_trace("optimizer.scm: 1264 estimate-foreign-result-size");
((C_proc3)C_retrieve_symbol_proc(lf[205]))(3,*((C_word*)lf[205]+1),t18,t19);}
else{
t18=(C_word)C_eqp(t11,lf[14]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
t20=(C_word)C_slot(t19,C_fix(1));
t21=(C_word)C_eqp(lf[8],t20);
if(C_truep(t21)){
t22=(C_word)C_slot(t19,C_fix(2));
t23=(C_word)C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7557,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_eqp(t23,((C_word*)t0)[4]);
if(C_truep(t25)){
t26=(C_word)C_eqp(((C_word*)((C_word*)t0)[10])[1],C_fix(0));
if(C_truep(t26)){
t27=(C_word)C_i_cadr(t9);
t28=(C_word)C_slot(t27,C_fix(1));
t29=(C_word)C_eqp(lf[8],t28);
if(C_truep(t29)){
t30=(C_word)C_slot(t27,C_fix(2));
t31=(C_word)C_i_car(t30);
t32=(C_word)C_a_i_cons(&a,2,t31,((C_word*)((C_word*)t0)[3])[1]);
t33=C_mutate(((C_word *)((C_word*)t0)[3])+1,t32);
t34=C_set_block_item(((C_word*)t0)[11],0,C_SCHEME_TRUE);
t35=t24;
f_7557(t35,C_SCHEME_TRUE);}
else{
t30=C_set_block_item(((C_word*)t0)[11],0,C_SCHEME_TRUE);
t31=t24;
f_7557(t31,C_SCHEME_TRUE);}}
else{
t27=t24;
f_7557(t27,C_SCHEME_FALSE);}}
else{
t26=t24;
f_7557(t26,(C_word)C_eqp(t23,((C_word*)t0)[2]));}}
else{
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_eqp(t11,lf[183]);
if(C_truep(t19)){
t20=(C_word)C_i_cadddr(t7);
t21=(C_word)C_eqp(t20,C_fix(0));
if(C_truep(t21)){
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t22=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t22)){
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_FALSE);}
else{
t23=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t20);
t24=C_mutate(((C_word *)((C_word*)t0)[10])+1,t23);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7646,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1290 every");
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),t1,t25,t9);}}}
else{
t20=(C_word)C_eqp(t11,lf[15]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_i_car(t7);
C_trace("optimizer.scm: 1291 rec");
t67=t1;
t68=t21;
t69=t22;
t70=C_SCHEME_FALSE;
t71=t5;
t1=t67;
t2=t68;
t3=t69;
t4=t70;
t5=t71;
goto loop;}
else{
t21=(C_word)C_eqp(t11,lf[10]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7679,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_car(t9);
t24=(C_word)C_i_car(t7);
C_trace("optimizer.scm: 1293 rec");
t67=t22;
t68=t23;
t69=t24;
t70=t2;
t71=t5;
t1=t67;
t2=t68;
t3=t69;
t4=t70;
t5=t71;
goto loop;}
else{
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7703,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1295 every");
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),t1,t22,t9);}}}}}}}}}}}

/* a7702 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7703,3,t0,t1,t2);}
C_trace("optimizer.scm: 1295 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_7309(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7677 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7679,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7690,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1294 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7688 in k7677 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1294 rec");
t2=((C_word*)((C_word*)t0)[4])[1];
f_7309(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a7645 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7646,3,t0,t1,t2);}
C_trace("optimizer.scm: 1290 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_7309(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7555 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7557(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7557,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7562,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1283 every");
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7561 in k7555 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7562,3,t0,t1,t2);}
C_trace("optimizer.scm: 1283 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_7309(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7502 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7504,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7510,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7510(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_7510(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_7510(t7,C_SCHEME_TRUE);}}}

/* k7508 in k7502 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7510(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7510,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7515,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1270 every");
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7514 in k7508 in k7502 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7515,3,t0,t1,t2);}
C_trace("optimizer.scm: 1270 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_7309(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7461 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7463,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7469,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7469(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_7469(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_7469(t7,C_SCHEME_TRUE);}}}

/* k7467 in k7461 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7469,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7474,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1262 every");
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7473 in k7467 in k7461 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7474,3,t0,t1,t2);}
C_trace("optimizer.scm: 1262 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_7309(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7445 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7447,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7443,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1253 alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7441 in k7445 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a7412 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7413(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7413,3,t0,t1,t2);}
C_trace("optimizer.scm: 1248 rec");
t3=((C_word*)((C_word*)t0)[3])[1];
f_7309(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a7375 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7376,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7392,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1243 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t8,t2,((C_word*)t0)[2]);}

/* k7390 in a7375 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1243 rec");
t2=((C_word*)((C_word*)t0)[4])[1];
f_7309(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k7356 in rec in scan in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7725(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7725,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7729,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t6,a[9]=t2,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8300,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8302,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#make-promise");
t11=*((C_word*)lf[201]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
C_trace("optimizer.scm: 1305 debugging");
((C_proc6)C_retrieve_symbol_proc(lf[5]))(6,*((C_word*)lf[5]+1),t8,lf[6],lf[202],t3,t7);}}

/* a8301 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8302,2,t0,t1);}
C_trace("optimizer.scm: 1304 unzip1");
((C_proc3)C_retrieve_symbol_proc(lf[200]))(3,*((C_word*)lf[200]+1),t1,((C_word*)t0)[2]);}

/* k8298 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1304 debugging");
((C_proc7)C_retrieve_symbol_proc(lf[5]))(7,*((C_word*)lf[5]+1),((C_word*)t0)[4],lf[6],lf[199],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7729,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_length(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7739,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 1310 get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t9,((C_word*)t0)[2],((C_word*)t0)[4],lf[119]);}

/* k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7739,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[11]))){
t6=(C_word)C_i_length(((C_word*)t0)[11]);
t7=(C_word)C_eqp(t6,C_fix(4));
if(C_truep(t7)){
t8=(C_word)C_i_caddr(((C_word*)t0)[11]);
t9=t5;
f_7748(t9,(C_word)C_i_listp(t8));}
else{
t8=t5;
f_7748(t8,C_SCHEME_FALSE);}}
else{
t6=t5;
f_7748(t6,C_SCHEME_FALSE);}}

/* k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7748,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
C_trace("optimizer.scm: 1314 caaddr");
((C_proc3)C_retrieve_proc(*((C_word*)lf[197]+1)))(3,*((C_word*)lf[197]+1),t3,((C_word*)t0)[13]);}
else{
C_trace("optimizer.scm: 1412 bomb");
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),((C_word*)t0)[10],lf[198],((C_word*)t0)[13]);}}

/* k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
C_trace("optimizer.scm: 1315 cdaddr");
((C_proc3)C_retrieve_proc(*((C_word*)lf[196]+1)))(3,*((C_word*)lf[196]+1),t2,((C_word*)t0)[14]);}

/* k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7757,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
C_trace("optimizer.scm: 1319 node-class-set!");
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t4,((C_word*)t0)[5],lf[195]);}

/* k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7766,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[5];
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7971,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_7971(t9,t2,t5);}

/* rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7971(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7971,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[14]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=(C_word)C_i_cadr(t6);
t12=(C_word)C_slot(t10,C_fix(2));
t13=(C_word)C_slot(t11,C_fix(2));
t14=(C_word)C_slot(t10,C_fix(1));
t15=(C_word)C_eqp(lf[8],t14);
if(C_truep(t15)){
t16=(C_word)C_i_car(t12);
t17=(C_word)C_eqp(((C_word*)t0)[9],t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t13,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
C_trace("optimizer.scm: 1333 alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t18,C_SCHEME_FALSE,t2,((C_word*)((C_word*)t0)[8])[1]);}
else{
t18=(C_word)C_i_car(t12);
t19=(C_word)C_eqp(((C_word*)t0)[7],t18);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8146,a[2]=t2,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1358 node-class-set!");
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t20,t2,lf[193]);}
else{
C_trace("optimizer.scm: 1361 bomb");
((C_proc3)C_retrieve_symbol_proc(lf[179]))(3,*((C_word*)lf[179]+1),t1,lf[194]);}}}
else{
t16=C_SCHEME_UNDEFINED;
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t16);}}
else{
t10=(C_word)C_eqp(t8,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t4);
t12=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8193,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1366 alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t13,t11,t12,((C_word*)((C_word*)t0)[4])[1]);}
else{
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8208,a[2]=((C_word*)t0)[3],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_8208(t16,t1,t6);}}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8234,a[2]=((C_word*)t0)[3],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_8234(t14,t1,t6);}}}

/* loop1941 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8234(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8234,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8244,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("rec1861");
t5=((C_word*)((C_word*)t0)[2])[1];
f_7971(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8242 in loop1941 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8234(t3,((C_word*)t0)[2],t2);}

/* loop1932 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_8208(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8208,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8218,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("rec1861");
t5=((C_word*)((C_word*)t0)[2])[1];
f_7971(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8216 in loop1932 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8208(t3,((C_word*)t0)[2],t2);}

/* k8191 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8193,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1367 copy-node!");
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t3,t4,((C_word*)t0)[3]);}

/* k8194 in k8191 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1368 rec");
t2=((C_word*)((C_word*)t0)[4])[1];
f_7971(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8144 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1359 node-parameters-set!");
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8147 in k8144 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1360 node-subexpressions-set!");
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8013 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8015,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8024,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_8024(2,t9,C_SCHEME_UNDEFINED);}
else{
C_trace("optimizer.scm: 1336 quit");
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t5,lf[189],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8070,a[2]=t7,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=t9,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
t12=(C_word)C_i_length(t11);
t13=(C_word)C_eqp(((C_word*)t0)[5],t12);
if(C_truep(t13)){
t14=t10;
f_8070(2,t14,C_SCHEME_UNDEFINED);}
else{
C_trace("optimizer.scm: 1347 quit");
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t10,lf[191],((C_word*)t0)[4]);}}
else{
C_trace("optimizer.scm: 1356 bomb");
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),((C_word*)t0)[8],lf[192],((C_word*)t0)[11]);}}}

/* k8068 in k8013 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 1350 node-class-set!");
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t2,((C_word*)t0)[3],lf[10]);}

/* k8071 in k8068 in k8013 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8100,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t5=(C_word)C_i_caddr(t4);
C_trace("optimizer.scm: 1351 take");
((C_proc4)C_retrieve_symbol_proc(lf[190]))(4,*((C_word*)lf[190]+1),t3,t5,C_fix(1));}

/* k8098 in k8071 in k8068 in k8013 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1351 node-parameters-set!");
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8074 in k8071 in k8068 in k8013 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8079,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_record(&a,4,lf[35],lf[188],t3,t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[5]);
C_trace("optimizer.scm: 1352 node-subexpressions-set!");
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],t6);}

/* k8077 in k8074 in k8071 in k8068 in k8013 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1355 rec");
t2=((C_word*)((C_word*)t0)[4])[1];
f_7971(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8022 in k8013 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1339 node-class-set!");
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t2,((C_word*)t0)[3],lf[188]);}

/* k8025 in k8022 in k8013 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
C_trace("optimizer.scm: 1340 node-parameters-set!");
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[3],t3);}

/* k8028 in k8025 in k8022 in k8013 in rec in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_8030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 1341 node-subexpressions-set!");
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7769,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7880,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7953,tmp=(C_word)a,a+=2,tmp);
C_trace("optimizer.scm: 1389 lset-difference");
((C_proc5)C_retrieve_symbol_proc(lf[186]))(5,*((C_word*)lf[186]+1),t3,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a7952 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7953,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k7878 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7880,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_7882(t5,((C_word*)t0)[2],t1);}

/* loop1952 in k7878 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7882(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7882,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_slot(t4,C_fix(3));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7901,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
t9=(C_word)C_eqp(((C_word*)t0)[3],t8);
if(C_truep(t9)){
t10=t6;
f_7901(2,t10,C_SCHEME_UNDEFINED);}
else{
C_trace("optimizer.scm: 1379 quit");
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t6,lf[185],((C_word*)t0)[2]);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7899 in loop1952 in k7878 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7904,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3]);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_i_cddr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_record(&a,4,lf[35],lf[183],t4,t7);
t9=(C_word)C_a_i_list(&a,2,t3,t8);
C_trace("optimizer.scm: 1382 node-subexpressions-set!");
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],t9);}

/* k7902 in k7899 in loop1952 in k7878 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7882(t3,((C_word*)t0)[2],t2);}

/* k7767 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7769,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_record(&a,4,lf[35],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7781,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 1394 copy-node!");
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t4,((C_word*)t0)[4],t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7779 in k7767 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7784,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7836,tmp=(C_word)a,a+=2,tmp);
C_trace("optimizer.scm: 1396 fold-right");
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a7835 in k7779 in k7767 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7836,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(2));
t11=(C_word)C_slot(t8,C_fix(3));
t12=(C_word)C_a_i_record(&a,4,lf[35],t9,t10,t11);
t13=(C_word)C_a_i_list(&a,2,t12,t3);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_record(&a,4,lf[35],lf[10],t5,t13));}

/* k7782 in k7779 in k7767 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1405 copy-node!");
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t2,t1,((C_word*)t0)[2]);}

/* k7785 in k7782 in k7779 in k7767 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7787,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7792,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7792(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1996 in k7785 in k7782 in k7779 in k7767 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7792(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7792,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_cdr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7808,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7834,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1409 gensym");
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t6);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7832 in loop1996 in k7785 in k7782 in k7779 in k7767 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7834,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 1409 node-parameters-set!");
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7806 in loop1996 in k7785 in k7782 in k7779 in k7767 in k7764 in k7761 in k7755 in k7752 in k7746 in k7737 in k7727 in transform in ##compiler#transform-direct-lambdas! in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7808,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=(C_word)C_i_set_car(t2,t3);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=((C_word*)((C_word*)t0)[3])[1];
f_7792(t6,((C_word*)t0)[2],t5);}

/* ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5253,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
switch(t6){
case C_fix(1):
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5310,a[2]=t5,a[3]=t8,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);
case C_fix(2):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5418,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t13,t12,lf[44]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[139]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5516,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[139]))){
if(C_truep(C_retrieve(lf[143]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5554,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t12,t11,lf[44]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5610,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(6):
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[139]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(C_fix(1),t11);
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5697,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t14,t13,lf[44]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(7):
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[139]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t11,t12);
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5762,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t15,t14,lf[44]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5817,a[2]=t8,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5838,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5982,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t12,t11,lf[44]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6069,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t12,t11,lf[44]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6128,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6198,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_cadr(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6257,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t13,t12,lf[44]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(1),t9);
if(C_truep(t10)){
t11=C_retrieve(lf[143]);
t12=(C_truep(t11)?t11:(C_word)C_i_cadddr(t7));
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6334,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t14,t13,lf[44]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(16):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[139]))){
t12=(C_word)C_i_not(t9);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t10,t9));
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6421,a[2]=t10,a[3]=t11,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t15,t14,lf[44]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6494,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t13,t12,lf[44]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[139]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6556,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6585,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(20):
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[143]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[139]))){
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t9,t12);
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6727,a[2]=t8,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t15,t14,lf[44]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6794,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(22):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[139]))){
t12=(C_word)C_eqp(t10,t9);
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6942,a[2]=t11,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t14,t13,lf[44]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[139]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6999,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t10,t9,lf[44]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
default:
C_trace("optimizer.scm: 1181 bomb");
((C_proc3)C_retrieve_symbol_proc(lf[179]))(3,*((C_word*)lf[179]+1),t1,lf[180]);}}

/* k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6999,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7014,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7021,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cadr(((C_word*)t0)[5]);
C_trace("optimizer.scm: 1167 varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7019 in k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7025,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7033,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t2,t3,t4);}

/* a7032 in k7019 in k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7033,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7041,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7047,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_7047(t9,t4,t3,t5);}

/* loop in a7032 in k7019 in k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_7047(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7047,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7067,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_symbolp(t5))){
C_trace("optimizer.scm: 791  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5278,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_5278(t8,(C_word)C_eqp(lf[25],t7));}
else{
t7=t6;
f_5278(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7096,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
C_trace("optimizer.scm: 1179 loop");
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k7094 in loop in a7032 in k7019 in k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7096,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5276 in loop in a7032 in k7019 in k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_5278(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 792  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],t2);}
else{
C_trace("optimizer.scm: 793  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k7065 in loop in a7032 in k7019 in k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7071,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1177 loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_7047(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k7069 in k7065 in loop in a7032 in k7019 in k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7071,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7039 in a7032 in k7019 in k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1170 append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7026 in k7019 in k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7027,2,t0,t1);}
C_trace("optimizer.scm: 1169 split-at");
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7023 in k7019 in k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1166 cons*");
((C_proc5)C_retrieve_symbol_proc(lf[159]))(5,*((C_word*)lf[159]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7012 in k6997 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_7014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7014,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k6940 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6942,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_retrieve(lf[149]),lf[154]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1148 fifth");
((C_proc3)C_retrieve_symbol_proc(lf[176]))(3,*((C_word*)lf[176]+1),t5,((C_word*)t0)[6]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[2]);
t7=((C_word*)t0)[5];
t8=(C_word)C_a_i_record(&a,4,lf[35],lf[88],t6,t7);
t9=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[178],t9));}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6972 in k6940 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6974,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t2,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[177],t5));}

/* k6792 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6794,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6800,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 1108 fifth");
((C_proc3)C_retrieve_symbol_proc(lf[176]))(3,*((C_word*)lf[176]+1),t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6798 in k6792 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6800,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[143]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6809,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6884,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1112 remove");
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),t4,t5,((C_word*)t0)[2]);}

/* a6883 in k6798 in k6792 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6884,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[25],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k6807 in k6798 in k6792 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6809,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6825,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1117 qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[174],t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6851,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 1125 fold-inner");
((C_proc4)C_retrieve_symbol_proc(lf[170]))(4,*((C_word*)lf[170]+1),t3,t4,t1);}}}

/* a6852 in k6807 in k6798 in k6792 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6853,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[149]),lf[154]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[140],t5,t6));}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[88],t5,t6));}}

/* k6849 in k6807 in k6798 in k6792 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6851,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[175],t2));}

/* k6823 in k6807 in k6798 in k6792 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6825,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[173],t2));}

/* k6725 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6727,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6740,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6755,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t4,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6754 in k6725 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6755,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6767,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1096 qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t4,t5);}

/* k6765 in a6754 in k6725 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6767,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 1095 append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[11]+1)))(5,*((C_word*)lf[11]+1),((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6744 in k6725 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6745,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
C_trace("optimizer.scm: 1094 split-at");
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[2],t2);}

/* k6738 in k6725 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6740,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[35],lf[140],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[172],t3));}

/* k6583 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6585,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[143]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6594,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6666,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1063 remove");
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6665 in k6583 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6666,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[25],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k6592 in k6583 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6594,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6610,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 1068 qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[168],t4));}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[149]),lf[154]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6645,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6647,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 1076 fold-inner");
((C_proc4)C_retrieve_symbol_proc(lf[170]))(4,*((C_word*)lf[170]+1),t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a6646 in k6592 in k6583 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6647,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[35],lf[140],t4,t5));}

/* k6643 in k6592 in k6583 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6645,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[169],t2));}

/* k6608 in k6592 in k6583 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6610,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[167],t2));}

/* k6554 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6556,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("optimizer.scm: 1050 qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6564 in k6554 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6566,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[166],t2));}

/* k6492 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6494,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6511,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[143]))){
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_6511(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[2]):(C_word)C_i_cadr(((C_word*)t0)[2])));}
else{
t3=t2;
f_6511(t3,(C_word)C_i_cadr(((C_word*)t0)[2]));}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6509 in k6492 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_6511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6511,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t2,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[165],t5));}

/* k6419 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6421,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6440,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[7]);
t6=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=(C_word)C_fixnum_increase(((C_word*)t0)[2]);
t8=t4;
f_6440(t8,(C_word)C_a_i_list(&a,2,t5,t7));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_fixnum_times(((C_word*)t0)[2],t7);
t9=t4;
f_6440(t9,(C_word)C_a_i_list(&a,2,t5,t8));}
else{
t7=t4;
f_6440(t7,(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[3]));}}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6438 in k6419 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_6440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6440,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[88],t1,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[164],t4));}

/* k6332 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6334,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[149]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6346,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
C_trace("optimizer.scm: 1001 varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[149]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[163],t6));}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6351 in k6332 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 1001 cons*");
((C_proc5)C_retrieve_symbol_proc(lf[159]))(5,*((C_word*)lf[159]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6344 in k6332 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6346,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k6255 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6257,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[149]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[143]));
if(C_truep(t5)){
t6=(C_truep(C_retrieve(lf[143]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t7=(C_word)C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[4];
t9=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t7,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[162],t10));}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6196 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6198,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6213,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_6213(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_6213(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6211 in k6196 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_6213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6213,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6216,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],C_SCHEME_TRUE);
t4=(C_word)C_a_i_record(&a,4,lf[35],lf[161],t3,C_SCHEME_END_OF_LIST);
C_trace("optimizer.scm: 974  cons*");
((C_proc5)C_retrieve_symbol_proc(lf[159]))(5,*((C_word*)lf[159]+1),t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6214 in k6211 in k6196 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6216,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k6126 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6128,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[160],t7));}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6164,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6171,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("optimizer.scm: 964  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6169 in k6126 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 964  cons*");
((C_proc5)C_retrieve_symbol_proc(lf[159]))(5,*((C_word*)lf[159]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6162 in k6126 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6164,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k6067 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6069,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_6081(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_6081(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6079 in k6067 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_6081(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6081,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6087,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
C_trace("optimizer.scm: 949  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6092 in k6079 in k6067 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 949  cons*");
((C_proc5)C_retrieve_symbol_proc(lf[159]))(5,*((C_word*)lf[159]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6085 in k6079 in k6067 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6087,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k5980 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5982,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6004,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("optimizer.scm: 931  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6002 in k5980 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6004,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 934  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t3,t4);}

/* k6010 in k6002 in k5980 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6016,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 936  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t2,t4);}
else{
t4=t2;
f_6016(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k6014 in k6010 in k6002 in k5980 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_6016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6016,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t2));}

/* k5836 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5838,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 902  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5860,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[143]))){
t4=(C_word)C_eqp(C_retrieve(lf[149]),lf[158]);
t5=t3;
f_5860(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5860(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5858 in k5836 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_5860(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5860,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5863(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[149]),lf[154]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_5863(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[149]),lf[157]);
t6=t2;
f_5863(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* k5861 in k5858 in k5836 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_5863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5863,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5922,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5921 in k5861 in k5858 in k5836 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5922,3,t0,t1,t2);}
C_trace("optimizer.scm: 906  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t1);}

/* k5864 in k5861 in k5858 in k5836 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5869,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("map");
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[47]),t1);}

/* k5867 in k5864 in k5861 in k5858 in k5836 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5874,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_eqp(C_retrieve(lf[149]),lf[154]);
t4=(C_truep(t3)?(C_word)C_i_car(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5900,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 918  fold-boolean");
((C_proc4)C_retrieve_symbol_proc(lf[156]))(4,*((C_word*)lf[156]+1),t6,t7,t1);}

/* a5899 in k5867 in k5864 in k5861 in k5858 in k5836 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5900,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[140],((C_word*)t0)[2],t4));}

/* k5896 in k5867 in k5864 in k5861 in k5858 in k5836 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5898,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[155],t2);
C_trace("optimizer.scm: 908  fold-right");
((C_proc6)C_retrieve_symbol_proc(lf[125]))(6,*((C_word*)lf[125]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5873 in k5867 in k5864 in k5861 in k5858 in k5836 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5874,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[10],t5,t6));}

/* k5852 in k5836 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5854,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[153],t2));}

/* k5815 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5760 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5762,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5775,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5786,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_caddr(((C_word*)t0)[5]);
C_trace("optimizer.scm: 888  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5784 in k5760 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5786,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 887  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5773 in k5760 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5775,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[35],lf[140],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[152],t3));}

/* k5695 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5697,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t5,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t3,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[151],t10));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5608 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5610,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[149])));
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 864  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t10,t11);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5650 in k5608 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5652,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[35],lf[140],((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[150],t4));}

/* k5552 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5567,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("optimizer.scm: 846  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5565 in k5552 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5567,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 849  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t3,t4);}

/* k5573 in k5565 in k5552 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5575,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t3));}

/* k5514 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5516,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5526,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("optimizer.scm: 837  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5524 in k5514 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5526,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[148],t2));}

/* k5416 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5418,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5446,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=(C_word)C_slot(t4,C_fix(1));
t8=(C_word)C_eqp(lf[8],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5475,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_slot(t4,C_fix(2));
t11=(C_word)C_i_car(t10);
C_trace("optimizer.scm: 828  get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t9,((C_word*)t0)[2],t11,lf[147]);}
else{
t9=t6;
f_5446(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_5446(t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5473 in k5416 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5446(t2,(C_word)C_eqp(lf[146],t1));}

/* k5444 in k5416 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_5446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5446,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t2,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[144],t5));}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[5];
t5=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[145],t6));}}

/* k5308 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5310,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t7,C_fix(1));
t11=(C_word)C_eqp(lf[8],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t6,C_fix(2));
t13=(C_word)C_slot(t7,C_fix(2));
if(C_truep((C_word)C_i_equalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5373,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 807  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t14,C_SCHEME_TRUE);}
else{
t14=t2;
f_5313(t14,C_SCHEME_FALSE);}}
else{
t12=t2;
f_5313(t12,C_SCHEME_FALSE);}}
else{
t10=t2;
f_5313(t10,C_SCHEME_FALSE);}}
else{
t6=t2;
f_5313(t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5371 in k5308 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5373,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_5313(t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[142],t2));}

/* k5311 in k5308 in ##compiler#simplify-named-call in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_5313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5313,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_retrieve(lf[139]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[35],lf[140],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[141],t6));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* ##compiler#rewrite in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5233(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5233r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5233r(t0,t1,t2,t3);}}

static void C_ccall f_5233r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5237,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 785  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t4,C_retrieve(lf[136]),t2);}

/* k5235 in ##compiler#rewrite in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5237,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("optimizer.scm: 786  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,t2,t4);}

/* k5245 in k5235 in ##compiler#rewrite in k5229 in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 786  ##sys#hash-table-set!");
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[3],C_retrieve(lf[136]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4873,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4877,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 697  map");
((C_proc5)C_retrieve_proc(*((C_word*)lf[134]+1)))(5,*((C_word*)lf[134]+1),t7,*((C_word*)lf[135]+1),t2,t3);}

/* k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5218,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 708  for-each");
((C_proc5)C_retrieve_proc(*((C_word*)lf[133]+1)))(5,*((C_word*)lf[133]+1),t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5217 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5218,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5223,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5227,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 709  scan-used-variables");
((C_proc4)C_retrieve_symbol_proc(lf[132]))(4,*((C_word*)lf[132]+1),t5,t3,((C_word*)t0)[2]);}

/* k5225 in a5217 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 709  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5221 in a5217 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4924,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_5144(t10,t6,((C_word*)t0)[2]);}

/* loop977 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_5144(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5144,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_memq(t3,((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_slot(t2,C_fix(1));
t9=t1;
t10=t4;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5170,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5192,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 718  filter");
((C_proc4)C_retrieve_symbol_proc(lf[130]))(4,*((C_word*)lf[130]+1),t4,t5,((C_word*)t0)[2]);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a5191 in loop977 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5192,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5205,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 719  find-path");
t5=((C_word*)t0)[2];
f_4879(t5,t4,((C_word*)t0)[3],t2);}}

/* k5203 in a5191 in loop977 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("optimizer.scm: 719  find-path");
t2=((C_word*)t0)[5];
f_4879(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5168 in loop977 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5174,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5186,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 721  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t3);}

/* k5184 in k5168 in loop977 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5186,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
C_trace("optimizer.scm: 721  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k5172 in k5168 in loop977 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5174,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5178,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
C_trace("optimizer.scm: 722  append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[11]+1)))(5,*((C_word*)lf[11]+1),t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);}

/* k5176 in k5172 in k5168 in loop977 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5144(t4,((C_word*)t0)[2],t3);}

/* k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4930,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t6,a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5069(t8,t4,((C_word*)((C_word*)t0)[7])[1]);}

/* loop997 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_5069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5069,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5085,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t3);
C_trace("optimizer.scm: 731  append-map");
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),t5,t6,t7);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a5127 in loop997 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5128,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5134,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 732  filter");
((C_proc4)C_retrieve_symbol_proc(lf[130]))(4,*((C_word*)lf[130]+1),t1,t3,((C_word*)t0)[2]);}

/* a5133 in a5127 in loop997 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5134,3,t0,t1,t2);}
C_trace("optimizer.scm: 732  find-path");
t3=((C_word*)t0)[3];
f_4879(t3,t1,((C_word*)t0)[2],t2);}

/* k5083 in loop997 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5089,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5102,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 737  filter-map");
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a5101 in k5083 in loop997 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5102,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5115,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
C_trace("optimizer.scm: 738  lset<=");
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t4,*((C_word*)lf[34]+1),t5,((C_word*)t0)[2]);}}

/* k5113 in a5101 in k5083 in loop997 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k5098 in k5083 in loop997 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 735  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5087 in k5083 in loop997 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5069(t4,((C_word*)t0)[2],t3);}

/* k4928 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4933,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 744  topological-sort");
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[34]+1));}

/* k4931 in k4928 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4933,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4936,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4953,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 749  fold");
((C_proc5)C_retrieve_symbol_proc(lf[126]))(5,*((C_word*)lf[126]+1),t4,t5,((C_word*)t0)[2],t1);}

/* a4952 in k4931 in k4928 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4953,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4966,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_4966(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_4966(t9,C_SCHEME_FALSE);}}

/* k4964 in a4952 in k4931 in k4928 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4966(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4966,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[10],((C_word*)t0)[2],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4989,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5007,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 763  fold-right");
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a5008 in k4964 in a4952 in k4931 in k4928 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5009,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5041,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 766  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t4);}

/* k5039 in a5008 in k4964 in a4952 in k4931 in k4928 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5041,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_record(&a,4,lf[35],lf[15],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[35],lf[10],t2,t8));}

/* k5005 in k4964 in a4952 in k4931 in k4928 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 758  fold-right");
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a4988 in k4964 in a4952 in k4931 in k4928 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4989,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_record(&a,4,lf[35],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_list(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[35],lf[10],t4,t6));}

/* k4934 in k4931 in k4928 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4936,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4945,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 775  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[124],((C_word*)((C_word*)t0)[3])[1]);}
else{
C_trace("optimizer.scm: 777  values");
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k4943 in k4934 in k4931 in k4928 in k4925 in k4922 in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 776  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4879(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4879,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4885,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4885(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4885(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4885,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4909,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 705  any");
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t1,t8,t5);}}}

/* a4908 in find in find-path in k4875 in ##compiler#reorganize-recursive-bindings in k4869 in k4866 in k4863 in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4909,3,t0,t1,t2);}
C_trace("optimizer.scm: 705  find");
t3=((C_word*)((C_word*)t0)[3])[1];
f_4885(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_4858r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4858r(t0,t1,t2,t3);}}

static void C_ccall f_4858r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_trace("optimizer.scm: 475  ##sys#hash-table-set!");
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t1,*((C_word*)lf[21]+1),t2,t3);}

/* ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4601,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4604,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4608,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4615,a[2]=t9,a[3]=t3,a[4]=t8,a[5]=t7,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 427  debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t10,lf[19],lf[120]);}

/* k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4630,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t3,lf[118],lf[44]);}

/* k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4630,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 466  test");
t3=((C_word*)t0)[3];
f_4608(t3,t2,lf[118],lf[119]);}
else{
t2=((C_word*)t0)[2];
f_4618(2,t2,C_SCHEME_UNDEFINED);}}

/* k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_4642(t6,((C_word*)t0)[2],t2);}

/* loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4642(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4642,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_slot(t4,C_fix(3));
t6=(C_word)C_i_cadr(t5);
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4664,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4849,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 436  test");
t11=((C_word*)t0)[2];
f_4608(t11,t10,t8,lf[76]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4847 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4664(2,t2,C_SCHEME_FALSE);}
else{
C_trace("optimizer.scm: 436  test");
t2=((C_word*)t0)[3];
f_4608(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[45]);}}

/* k4662 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4667,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 437  get-list");
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[75]);}

/* k4665 in k4662 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[10])){
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[4]);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
t8=t2;
f_4680(t8,(C_word)C_eqp(lf[53],t7));}
else{
t7=t2;
f_4680(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_4680(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4680(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4680(t3,C_SCHEME_FALSE);}}

/* k4678 in k4665 in k4662 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4680,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[10],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(t5,C_fix(3));
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t5,a[12]=t3,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t8=(C_word)C_i_cdr(t3);
t9=t7;
f_4695(t9,(C_word)C_i_nullp(t8));}
else{
t8=t7;
f_4695(t8,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=((C_word*)((C_word*)t0)[6])[1];
f_4642(t3,((C_word*)t0)[5],t2);}}

/* k4693 in k4678 in k4665 in k4662 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4695(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4695,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4701,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 448  get-list");
((C_proc5)C_retrieve_symbol_proc(lf[117]))(5,*((C_word*)lf[117]+1),t3,((C_word*)t0)[2],t2,lf[75]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=((C_word*)((C_word*)t0)[7])[1];
f_4642(t3,((C_word*)t0)[6],t2);}}

/* k4699 in k4693 in k4678 in k4665 in k4662 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t6=t2;
f_4707(t6,(C_word)C_eqp(lf[9],t5));}
else{
t5=t2;
f_4707(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4707(t3,C_SCHEME_FALSE);}}

/* k4705 in k4699 in k4693 in k4678 in k4665 in k4662 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4707,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_eqp(lf[8],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t4;
f_4716(t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t7=t4;
f_4716(t7,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=((C_word*)((C_word*)t0)[7])[1];
f_4642(t3,((C_word*)t0)[6],t2);}}

/* k4714 in k4705 in k4699 in k4693 in k4678 in k4665 in k4662 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4716(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4716,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 460  node-parameters-set!");
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t4,((C_word*)t0)[2],lf[116]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=((C_word*)((C_word*)t0)[7])[1];
f_4642(t3,((C_word*)t0)[6],t2);}}

/* k4721 in k4714 in k4705 in k4699 in k4693 in k4678 in k4665 in k4662 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4726,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 461  node-subexpressions-set!");
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],t3);}

/* k4724 in k4721 in k4714 in k4705 in k4699 in k4693 in k4678 in k4665 in k4662 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("optimizer.scm: 464  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t4,t5);}

/* k4742 in k4724 in k4721 in k4714 in k4705 in k4699 in k4693 in k4678 in k4665 in k4662 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("optimizer.scm: 462  node-subexpressions-set!");
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4727 in k4724 in k4721 in k4714 in k4705 in k4699 in k4693 in k4678 in k4665 in k4662 in loop640 in k4635 in k4628 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=f_4604(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4642(t4,((C_word*)t0)[2],t3);}

/* k4616 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
C_trace("optimizer.scm: 468  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[112],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)((C_word*)t0)[3])[1]);}}

/* k4619 in k4616 in k4613 in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4608(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4608,NULL,4,t0,t1,t2,t3);}
C_trace("optimizer.scm: 425  get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static C_word C_fcall f_4604(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[66],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2996,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2999,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3005,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3029,a[2]=t3,a[3]=t20,a[4]=t18,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3121,a[2]=t25,a[3]=t17,a[4]=t23,a[5]=t18,a[6]=t7,a[7]=t20,a[8]=t15,tmp=(C_word)a,a+=9,tmp));
t29=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3335,a[2]=t11,a[3]=t3,a[4]=t27,a[5]=t23,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t18,tmp=(C_word)a,a+=10,tmp));
t30=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4464,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t31=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4489,a[2]=t23,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 393  perform-pre-optimization!");
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),t31,t2,t3);}

/* k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4489,2,t0,t1);}
if(C_truep(t1)){
C_trace("optimizer.scm: 394  values");
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4495,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 396  debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,lf[19],lf[110]);}}

/* k4493 in k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4495,2,t0,t1);}
t2=C_set_block_item(lf[22] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4499,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 398  walk");
t4=((C_word*)((C_word*)t0)[3])[1];
f_3121(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4497 in k4493 in k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
C_trace("optimizer.scm: 399  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[109],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_4502(2,t3,C_SCHEME_UNDEFINED);}}

/* k4500 in k4497 in k4493 in k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4538,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[22])))){
C_trace("optimizer.scm: 400  debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,lf[6],lf[108]);}
else{
t4=t3;
f_4538(2,t4,C_SCHEME_FALSE);}}

/* k4536 in k4500 in k4497 in k4493 in k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4538,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4543,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4543(t5,((C_word*)t0)[2],C_retrieve(lf[22]));}
else{
t2=((C_word*)t0)[2];
f_4505(2,t2,C_SCHEME_UNDEFINED);}}

/* loop597 in k4536 in k4500 in k4497 in k4493 in k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4543(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4543,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4556,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
C_trace("optimizer.scm: 403  print*");
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t4,C_make_character(9),t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4554 in loop597 in k4536 in k4500 in k4497 in k4493 in k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 405  print");
((C_proc4)C_retrieve_proc(*((C_word*)lf[105]+1)))(4,*((C_word*)lf[105]+1),t2,C_make_character(9),t4);}
else{
C_trace("optimizer.scm: 406  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[106]+1)))(2,*((C_word*)lf[106]+1),t2);}}

/* k4557 in k4554 in loop597 in k4536 in k4500 in k4497 in k4493 in k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4543(t3,((C_word*)t0)[2],t2);}

/* k4503 in k4500 in k4497 in k4493 in k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
C_trace("optimizer.scm: 408  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[104],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_4508(2,t4,C_SCHEME_UNDEFINED);}}

/* k4506 in k4503 in k4500 in k4497 in k4493 in k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4511,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
C_trace("optimizer.scm: 409  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[103],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_4511(2,t4,C_SCHEME_UNDEFINED);}}

/* k4509 in k4506 in k4503 in k4500 in k4497 in k4493 in k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
C_trace("optimizer.scm: 410  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[102],((C_word*)((C_word*)t0)[2])[1]);}
else{
C_trace("optimizer.scm: 411  values");
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k4512 in k4509 in k4506 in k4503 in k4500 in k4497 in k4493 in k4487 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 411  values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4464(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4464,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4468,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4479,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t9=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t5);}

/* a4478 in walk-generic in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4479,3,t0,t1,t2);}
C_trace("walk137");
t3=((C_word*)((C_word*)t0)[3])[1];
f_3121(t3,t1,t2,((C_word*)t0)[2]);}

/* k4466 in walk-generic in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4474,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 389  every");
((C_proc5)C_retrieve_symbol_proc(lf[41]))(5,*((C_word*)lf[41]+1),t2,*((C_word*)lf[34]+1),((C_word*)t0)[2],t1);}

/* k4472 in k4466 in walk-generic in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4474,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[35],t2,t3,((C_word*)t0)[2]));}}

/* walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3335(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3335,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[8]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3360,a[2]=((C_word*)t0)[7],a[3]=t7,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t13,tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_3360(t15,t1,t11);}
else{
t11=(C_word)C_eqp(t9,lf[10]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3435,a[2]=t12,a[3]=((C_word*)t0)[8],a[4]=t7,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 204  test");
t14=((C_word*)t0)[8];
f_2999(t14,t13,t12,lf[49]);}
else{
t12=(C_word)C_eqp(t9,lf[53]);
if(C_truep(t12)){
t13=(C_word)C_i_caddr(t7);
t14=(C_word)C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3501,a[2]=t9,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t13,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=t14,a[10]=t5,a[11]=t7,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
C_trace("optimizer.scm: 215  test");
t16=((C_word*)t0)[8];
f_2999(t16,t15,t14,lf[62]);}
else{
t13=(C_word)C_eqp(t9,lf[14]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t5);
t15=(C_word)C_slot(t14,C_fix(1));
t16=(C_word)C_eqp(t15,lf[8]);
if(C_truep(t16)){
t17=(C_word)C_slot(t14,C_fix(2));
t18=(C_word)C_i_car(t17);
t19=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3677,a[2]=((C_word*)t0)[2],a[3]=t14,a[4]=((C_word*)t0)[8],a[5]=t7,a[6]=t9,a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=t18,a[10]=((C_word*)t0)[3],a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],a[14]=((C_word*)t0)[9],a[15]=t5,tmp=(C_word)a,a+=16,tmp);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4314,a[2]=t18,a[3]=((C_word*)t0)[8],a[4]=t19,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 253  test");
t21=((C_word*)t0)[8];
f_2999(t21,t20,t18,lf[76]);}
else{
t17=(C_word)C_eqp(t15,lf[53]);
if(C_truep(t17)){
if(C_truep((C_word)C_i_car(t7))){
C_trace("optimizer.scm: 366  walk-generic");
t18=((C_word*)((C_word*)t0)[4])[1];
f_4464(t18,t1,t2,t9,t7,t5,t3);}
else{
t18=(C_word)C_i_cdr(t7);
t19=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4339,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4344,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t22=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,t21,t5);}}
else{
C_trace("optimizer.scm: 368  walk-generic");
t18=((C_word*)((C_word*)t0)[4])[1];
f_4464(t18,t1,t2,t9,t7,t5,t3);}}}
else{
t14=(C_word)C_eqp(t9,lf[15]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t15,a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 372  test");
t17=((C_word*)t0)[8];
f_2999(t17,t16,t15,lf[51]);}
else{
C_trace("optimizer.scm: 385  walk-generic");
t15=((C_word*)((C_word*)t0)[4])[1];
f_4464(t15,t1,t2,t9,t7,t5,t3);}}}}}}

/* k4368 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t1)){
t3=t2;
f_4373(2,t3,t1);}
else{
C_trace("optimizer.scm: 372  test");
t3=((C_word*)t0)[2];
f_2999(t3,t2,((C_word*)t0)[8],lf[49]);}}

/* k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4373,2,t0,t1);}
if(C_truep(t1)){
t2=f_3025(((C_word*)t0)[10]);
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4385,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4456,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 375  test");
t4=((C_word*)t0)[2];
f_2999(t4,t3,((C_word*)t0)[8],lf[101]);}}

/* k4454 in k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4456,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_4414(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4452,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 376  variable-visible?");
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t4,((C_word*)t0)[2]);}}

/* k4450 in k4454 in k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4414(t2,(C_word)C_i_not(t1));}

/* k4412 in k4454 in k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4414(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4414,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 377  test");
t3=((C_word*)t0)[3];
f_2999(t3,t2,((C_word*)t0)[2],lf[99]);}
else{
t2=((C_word*)t0)[6];
f_4385(t2,C_SCHEME_FALSE);}}

/* k4443 in k4412 in k4454 in k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_4385(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4441,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 378  test");
t3=((C_word*)t0)[3];
f_2999(t3,t2,((C_word*)t0)[2],lf[75]);}}

/* k4439 in k4443 in k4412 in k4454 in k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4441,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4385(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 379  expression-has-side-effects?");
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t2,t3,((C_word*)t0)[2]);}}

/* k4431 in k4439 in k4443 in k4412 in k4454 in k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4385(t2,(C_word)C_i_not(t1));}

/* k4383 in k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4385(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4385,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3025(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 381  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t3,lf[6],lf[98],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4404,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("optimizer.scm: 383  walk");
t4=((C_word*)((C_word*)t0)[3])[1];
f_3121(t4,t2,t3,((C_word*)t0)[2]);}}

/* k4402 in k4383 in k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4404,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[15],((C_word*)t0)[2],t2));}

/* k4389 in k4383 in k4371 in k4368 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4391,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* a4343 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4344,3,t0,t1,t2);}
C_trace("walk137");
t3=((C_word*)((C_word*)t0)[3])[1];
f_3121(t3,t1,t2,((C_word*)t0)[2]);}

/* k4337 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4339,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k4312 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4314,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3677(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 254  test");
t3=((C_word*)t0)[3];
f_2999(t3,t2,((C_word*)t0)[2],lf[45]);}}

/* k4302 in k4312 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
f_3677(2,t3,t2);}
else{
C_trace("optimizer.scm: 255  test");
t2=((C_word*)t0)[3];
f_2999(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[97]);}}

/* k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3677,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=t1,tmp=(C_word)a,a+=18,tmp);
C_trace("optimizer.scm: 257  test");
t4=((C_word*)t0)[4];
f_2999(t4,t3,((C_word*)t0)[9],lf[51]);}

/* k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[17],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3695,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t3,a[6]=((C_word*)t0)[17],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 260  check-signature");
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t4,((C_word*)t0)[10],((C_word*)t0)[12],t3);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[10],C_retrieve(lf[68])))){
t2=(C_word)C_i_car(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(lf[8],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_i_car(t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3774,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3878,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 271  test");
t10=((C_word*)t0)[4];
f_2999(t10,t9,t7,lf[76]);}
else{
t8=t3;
f_3753(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_3753(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3753(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3892,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[17])){
t3=(C_word)C_slot(((C_word*)t0)[17],C_fix(1));
t4=t2;
f_3892(t4,(C_word)C_eqp(lf[53],t3));}
else{
t3=t2;
f_3892(t3,C_SCHEME_FALSE);}}}}

/* k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3892,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[17],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
C_trace("optimizer.scm: 287  decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[2],t3,t4);}
else{
C_trace("optimizer.scm: 363  walk-generic");
t2=((C_word*)((C_word*)t0)[10])[1];
f_4464(t2,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[14]);}}

/* a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3903,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3913,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t5,a[13]=((C_word*)t0)[18],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=((C_word*)t0)[15],a[20]=t1,a[21]=((C_word*)t0)[16],a[22]=((C_word*)t0)[17],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[91]))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[18],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 292  test");
t8=((C_word*)t0)[3];
f_2999(t8,t7,((C_word*)t0)[10],lf[96]);}
else{
t7=t6;
f_3913(t7,C_SCHEME_FALSE);}}

/* k4250 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4252,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4284,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("optimizer.scm: 293  test");
t4=((C_word*)t0)[2];
f_2999(t4,t2,t3,lf[65]);}
else{
t2=((C_word*)t0)[5];
f_3913(t2,C_SCHEME_FALSE);}}

/* k4282 in k4250 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4284,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3913(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2],lf[95]);}}

/* k4259 in k4282 in k4250 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_eqp(t1,lf[92]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3913(t3,C_SCHEME_TRUE);}
else{
t3=(C_word)C_eqp(t1,lf[93]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_3913(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t5=C_retrieve(lf[94]);
t6=((C_word*)t0)[3];
f_3913(t6,(C_word)C_fixnum_lessp(t4,t5));}}}

/* k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3913,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[18],a[7]=((C_word*)t0)[19],a[8]=((C_word*)t0)[20],a[9]=((C_word*)t0)[21],a[10]=((C_word*)t0)[22],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3976,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[14],a[4]=t2,a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t3,((C_word*)t0)[14],lf[81]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[21],a[11]=((C_word*)t0)[22],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[6],a[14]=((C_word*)t0)[7],a[15]=((C_word*)t0)[8],a[16]=((C_word*)t0)[9],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[10],a[19]=((C_word*)t0)[11],a[20]=((C_word*)t0)[16],tmp=(C_word)a,a+=21,tmp);
C_trace("optimizer.scm: 312  test");
t3=((C_word*)t0)[4];
f_2999(t3,t2,((C_word*)t0)[12],lf[62]);}}

/* k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[20]);
t3=((C_word*)t0)[19];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
C_trace("optimizer.scm: 314  walk-generic");
t4=((C_word*)((C_word*)t0)[18])[1];
f_4464(t4,((C_word*)t0)[17],((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3999,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3999(t7,((C_word*)t0)[17],((C_word*)t0)[5],((C_word*)t0)[19],((C_word*)t0)[20],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4150,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[18],a[14]=((C_word*)t0)[20],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4239,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[16],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 338  test");
t4=((C_word*)t0)[6];
f_2999(t4,t3,((C_word*)t0)[2],lf[58]);}}

/* k4237 in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_4150(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_4150(t2,C_SCHEME_FALSE);}}

/* k4148 in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_4150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4150,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
C_trace("optimizer.scm: 340  llist-length");
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),t2,((C_word*)t0)[3]);}
else{
C_trace("optimizer.scm: 362  walk-generic");
t2=((C_word*)((C_word*)t0)[13])[1];
f_4464(t2,((C_word*)t0)[12],((C_word*)t0)[2],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k4151 in k4148 in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4153,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[12]);
t3=t1;
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
C_trace("optimizer.scm: 342  walk-generic");
t4=((C_word*)((C_word*)t0)[11])[1];
f_4464(t4,((C_word*)t0)[10],t1,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 344  debugging");
((C_proc6)C_retrieve_symbol_proc(lf[5]))(6,*((C_word*)lf[5]+1),t4,lf[6],lf[89],((C_word*)t0)[2],t1);}}

/* k4163 in k4151 in k4148 in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4170,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4175 in k4163 in k4151 in k4148 in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[32],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4176,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4180,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4189,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4201,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4209,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("optimizer.scm: 355  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t7,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_i_length(t3);
t9=(C_word)C_fixnum_times(C_fix(3),t8);
t10=(C_word)C_a_i_list(&a,2,lf[87],t9);
t11=(C_word)C_a_i_record(&a,4,lf[35],lf[88],t10,t3);
t12=(C_word)C_a_i_list(&a,1,t11);
C_trace("optimizer.scm: 351  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t6,t2,t12);}}

/* k4207 in a4175 in k4163 in k4151 in k4148 in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4209,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("optimizer.scm: 351  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4199 in a4175 in k4163 in k4151 in k4148 in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("map");
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4188 in a4175 in k4163 in k4151 in k4148 in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4189,3,t0,t1,t2);}
C_trace("walk137");
t3=((C_word*)((C_word*)t0)[3])[1];
f_3121(t3,t1,t2,((C_word*)t0)[2]);}

/* k4178 in a4175 in k4163 in k4151 in k4148 in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a4169 in k4163 in k4151 in k4148 in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4170,2,t0,t1);}
C_trace("optimizer.scm: 345  split-at");
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3999(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3999,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_3025(((C_word*)t0)[10]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4020,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4032,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 321  append-reverse");
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),t11,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t5,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t9=(C_word)C_i_car(t2);
C_trace("optimizer.scm: 322  test");
t10=((C_word*)t0)[2];
f_2999(t10,t8,t9,lf[54]);}}

/* k4036 in loop in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
if(C_truep(t1)){
t2=f_3025(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("optimizer.scm: 324  debugging");
((C_proc6)C_retrieve_symbol_proc(lf[5]))(6,*((C_word*)lf[5]+1),t3,lf[6],lf[85],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[10]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[9]);
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
t5=(C_word)C_i_car(((C_word*)t0)[8]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[6]);
C_trace("optimizer.scm: 334  loop");
t7=((C_word*)((C_word*)t0)[7])[1];
f_3999(t7,((C_word*)t0)[11],t2,t3,t4,t6);}}

/* k4042 in k4036 in loop in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
C_trace("optimizer.scm: 327  expression-has-side-effects?");
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t2,t3,((C_word*)t0)[2]);}

/* k4048 in k4042 in k4036 in loop in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 330  gensym");
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[84]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[7]);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
C_trace("optimizer.scm: 333  loop");
t5=((C_word*)((C_word*)t0)[5])[1];
f_3999(t5,((C_word*)t0)[9],t2,t3,t4,((C_word*)t0)[4]);}}

/* k4085 in k4048 in k4042 in k4036 in loop in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4087,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
C_trace("optimizer.scm: 331  walk");
t5=((C_word*)((C_word*)t0)[3])[1];
f_3121(t5,t3,t4,((C_word*)t0)[2]);}

/* k4061 in k4085 in k4048 in k4042 in k4036 in loop in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 332  loop");
t6=((C_word*)((C_word*)t0)[3])[1];
f_3999(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k4065 in k4061 in k4085 in k4048 in k4042 in k4036 in loop in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4067,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[10],((C_word*)t0)[2],t2));}

/* k4030 in loop in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4032,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("map");
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4019 in loop in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4020,3,t0,t1,t2);}
C_trace("walk137");
t3=((C_word*)((C_word*)t0)[3])[1];
f_3121(t3,t1,t2,((C_word*)t0)[2]);}

/* k4013 in loop in k3983 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4015,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[14],((C_word*)t0)[2],t1));}

/* k3974 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_structurep(t1,lf[35]);
t3=(C_truep(t2)?lf[78]:lf[79]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
C_trace("optimizer.scm: 299  debugging");
((C_proc7)C_retrieve_symbol_proc(lf[5]))(7,*((C_word*)lf[5]+1),((C_word*)t0)[4],lf[80],t3,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k3914 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3945(t6,t2,((C_word*)t0)[7]);}

/* loop445 in k3914 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3945(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3945,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3958,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##compiler#put!");
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],t3,lf[65],C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3956 in loop445 in k3914 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3945(t3,((C_word*)t0)[2],t2);}

/* k3917 in k3914 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 306  check-signature");
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3920 in k3917 in k3914 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 307  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[77],((C_word*)t0)[2]);}

/* k3923 in k3920 in k3917 in k3914 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3925,2,t0,t1);}
t2=f_3025(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_i_car(t4);
C_trace("optimizer.scm: 310  inline-lambda-bindings");
((C_proc7)C_retrieve_symbol_proc(lf[63]))(7,*((C_word*)lf[63]+1),t3,((C_word*)t0)[4],((C_word*)t0)[3],t5,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k3933 in k3923 in k3920 in k3917 in k3914 in k3911 in a3902 in k3890 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 309  walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_3121(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3876 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3774(2,t2,C_SCHEME_FALSE);}
else{
C_trace("optimizer.scm: 271  test");
t2=((C_word*)t0)[3];
f_2999(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[45]);}}

/* k3772 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3774,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_eqp(lf[53],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(2));
t5=(C_word)C_i_caddr(t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3795,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(t5);
C_trace("optimizer.scm: 274  test");
t8=((C_word*)t0)[2];
f_2999(t8,t6,t7,lf[54]);}
else{
t6=((C_word*)t0)[7];
f_3753(t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[7];
f_3753(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
f_3753(t2,C_SCHEME_FALSE);}}

/* k3793 in k3772 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_3798(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 275  test");
t5=((C_word*)t0)[2];
f_2999(t5,t3,t4,lf[75]);}}

/* k3850 in k3793 in k3772 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3852,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3798(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3844,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("optimizer.scm: 276  test");
t4=((C_word*)t0)[2];
f_2999(t4,t2,t3,lf[74]);}}

/* k3842 in k3850 in k3793 in k3772 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3798(t2,(C_word)C_i_not(t1));}

/* k3796 in k3793 in k3772 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3798,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3821,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3823,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("optimizer.scm: 277  any");
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_3753(t2,C_SCHEME_FALSE);}}

/* a3822 in k3796 in k3793 in k3772 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3823,3,t0,t1,t2);}
C_trace("##compiler#expression-has-side-effects?");
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t1,t2,((C_word*)t0)[2]);}

/* k3819 in k3796 in k3793 in k3772 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3821,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3753(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3807,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 278  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[71],lf[72],((C_word*)t0)[2]);}}

/* k3805 in k3819 in k3796 in k3793 in k3772 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3807,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[35],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_3753(t4,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[70],t3));}

/* k3751 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
C_trace("optimizer.scm: 282  walk-generic");
t2=((C_word*)((C_word*)t0)[7])[1];
f_4464(t2,((C_word*)t0)[8],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3693 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3698,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 261  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[66],((C_word*)t0)[2]);}

/* k3696 in k3693 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3698,2,t0,t1);}
t2=f_3025(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3721(t7,t3,((C_word*)t0)[6]);}

/* loop352 in k3696 in k3693 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3721(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3721,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3734,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##compiler#put!");
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],t3,lf[65],C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3732 in loop352 in k3696 in k3693 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3721(t3,((C_word*)t0)[2],t2);}

/* k3702 in k3696 in k3693 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3711,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_i_car(t3);
C_trace("optimizer.scm: 265  inline-lambda-bindings");
((C_proc7)C_retrieve_symbol_proc(lf[63]))(7,*((C_word*)lf[63]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3],t4,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k3709 in k3702 in k3696 in k3693 in k3684 in k3675 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 264  walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_3121(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3501,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3506,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 216  decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
C_trace("optimizer.scm: 231  test");
t3=((C_word*)t0)[13];
f_2999(t3,t2,((C_word*)t0)[9],lf[58]);}}

/* k3591 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3593,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 232  decompose-lambda-list");
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
C_trace("optimizer.scm: 244  walk-generic");
t3=((C_word*)((C_word*)t0)[4])[1];
f_4464(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[11],((C_word*)t0)[10],t2);}}

/* a3597 in k3591 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3598,5,t0,t1,t2,t3,t4);}
t5=f_3025(((C_word*)t0)[7]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3605,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
C_trace("optimizer.scm: 236  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t6,lf[6],lf[61],t4);}

/* k3603 in a3597 in k3591 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3605,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3638,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t3,a[8]=t2,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
C_trace("optimizer.scm: 241  build-lambda-list");
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k3636 in k3603 in a3597 in k3591 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3638,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[8],((C_word*)t0)[7],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3618,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
C_trace("optimizer.scm: 243  walk");
t7=((C_word*)((C_word*)t0)[2])[1];
f_3121(t7,t4,t5,t6);}

/* k3616 in k3636 in k3603 in a3597 in k3591 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[53],((C_word*)t0)[2],t2));}

/* a3505 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3506,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3512,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3524,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t5,t6);}

/* a3523 in a3505 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3524,4,t0,t1,t2,t3);}
t4=f_3025(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
C_trace("optimizer.scm: 221  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t5,lf[6],lf[59],t2);}

/* k3529 in a3523 in a3505 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,a[8]=t2,a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("optimizer.scm: 225  test");
t6=((C_word*)t0)[2];
f_2999(t6,t5,((C_word*)t0)[8],lf[58]);}
else{
t6=t5;
f_3571(2,t6,C_SCHEME_FALSE);}}

/* k3569 in k3529 in a3523 in a3505 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3571,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 226  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[57],((C_word*)t0)[2]);}
else{
C_trace("optimizer.scm: 228  build-lambda-list");
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k3572 in k3569 in k3529 in a3523 in a3505 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
C_trace("optimizer.scm: 227  build-lambda-list");
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k3562 in k3529 in a3523 in a3505 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3564,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[8],((C_word*)t0)[7],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3544,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
C_trace("optimizer.scm: 230  walk");
t7=((C_word*)((C_word*)t0)[2])[1];
f_3121(t7,t4,t5,t6);}

/* k3542 in k3562 in k3529 in a3523 in a3505 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[53],((C_word*)t0)[2],t2));}

/* a3511 in a3505 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3518,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 219  partition");
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t1,t2,((C_word*)t0)[2]);}

/* a3517 in a3511 in a3505 in k3499 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3518,3,t0,t1,t2);}
C_trace("optimizer.scm: 219  test");
t3=((C_word*)t0)[2];
f_2999(t3,t1,t2,lf[54]);}

/* k3433 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3438,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_3438(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 205  test");
t4=((C_word*)t0)[3];
f_2999(t4,t3,((C_word*)t0)[2],lf[52]);}}

/* k3465 in k3433 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3467,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
f_3438(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 206  test");
t3=((C_word*)t0)[3];
f_2999(t3,t2,((C_word*)t0)[2],lf[51]);}}

/* k3474 in k3465 in k3433 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3476,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3483,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 206  test");
t3=((C_word*)t0)[3];
f_2999(t3,t2,((C_word*)t0)[2],lf[50]);}
else{
t2=((C_word*)t0)[4];
f_3438(t2,C_SCHEME_FALSE);}}

/* k3481 in k3474 in k3465 in k3433 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3438(t2,(C_word)C_i_not(t1));}

/* k3436 in k3433 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3438,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3025(((C_word*)t0)[8]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[7])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[6]);
C_trace("optimizer.scm: 209  walk");
t6=((C_word*)((C_word*)t0)[5])[1];
f_3121(t6,((C_word*)t0)[4],t5,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t4=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[6]);}}

/* a3459 in k3436 in k3433 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3460,3,t0,t1,t2);}
C_trace("walk137");
t3=((C_word*)((C_word*)t0)[3])[1];
f_3121(t3,t1,t2,((C_word*)t0)[2]);}

/* k3453 in k3436 in k3433 in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[35],lf[10],((C_word*)t0)[2],t1));}

/* replace in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3360(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3360,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
C_trace("optimizer.scm: 190  test");
t4=((C_word*)t0)[4];
f_2999(t4,t3,t2,lf[49]);}

/* k3362 in replace in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3364,2,t0,t1);}
if(C_truep(t1)){
C_trace("replace234");
t2=((C_word*)((C_word*)t0)[8])[1];
f_3360(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("optimizer.scm: 191  test");
t3=((C_word*)t0)[5];
f_2999(t3,t2,((C_word*)t0)[4],lf[48]);}}

/* k3374 in k3362 in replace in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
if(C_truep(t1)){
t2=f_3025(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 193  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t3,lf[6],lf[46],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t3)){
C_trace("optimizer.scm: 200  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t4=f_3025(((C_word*)t0)[7]);
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
C_trace("optimizer.scm: 200  varnode");
((C_proc3)C_retrieve_symbol_proc(lf[47]))(3,*((C_word*)lf[47]+1),((C_word*)t0)[6],((C_word*)t0)[4]);}}}

/* k3380 in k3374 in k3362 in replace in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3393,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("optimizer.scm: 194  test");
t3=((C_word*)t0)[3];
f_2999(t3,t2,((C_word*)t0)[2],lf[45]);}

/* k3391 in k3380 in k3374 in k3362 in replace in walk1 in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_car(t2);
C_trace("optimizer.scm: 194  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],t3);}

/* walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3121(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3121,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[32])))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)((C_word*)t0)[8])[1];
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
C_trace("optimizer.scm: 143  walk1");
t6=((C_word*)((C_word*)t0)[2])[1];
f_3335(t6,t5,t2,t3);}}

/* k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(3));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,lf[9]);
if(C_truep(t5)){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[25],t7);
if(C_truep(t8)){
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t10=C_mutate(((C_word *)((C_word*)t0)[8])+1,t9);
t11=f_3025(((C_word*)t0)[7]);
t12=(C_word)C_i_car(t2);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=(C_truep(t14)?(C_word)C_i_cadr(t2):(C_word)C_i_caddr(t2));
C_trace("optimizer.scm: 151  walk");
t16=((C_word*)((C_word*)t0)[6])[1];
f_3121(t16,t4,t15,((C_word*)t0)[5]);}
else{
t9=t1;
C_trace("optimizer.scm: 141  simplify");
t10=((C_word*)((C_word*)t0)[10])[1];
f_3029(t10,((C_word*)t0)[9],t9);}}
else{
t6=(C_word)C_eqp(t3,lf[14]);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_slot(t10,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3205,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t1,a[9]=t4,a[10]=t12,tmp=(C_word)a,a+=11,tmp);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3306,a[2]=t12,a[3]=((C_word*)t0)[2],a[4]=t13,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#get");
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t14,t12,lf[44]);}
else{
t10=t1;
C_trace("optimizer.scm: 141  simplify");
t11=((C_word*)((C_word*)t0)[10])[1];
f_3029(t11,((C_word*)t0)[9],t10);}}
else{
t7=t1;
C_trace("optimizer.scm: 141  simplify");
t8=((C_word*)((C_word*)t0)[10])[1];
f_3029(t8,((C_word*)t0)[9],t7);}}}

/* k3304 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3306,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3312,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 161  foldable?");
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3205(2,t2,C_SCHEME_FALSE);}}

/* k3310 in k3304 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
C_trace("optimizer.scm: 162  every");
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_3205(2,t2,C_SCHEME_FALSE);}}

/* k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3205,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3287,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
C_trace("map");
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[8];
C_trace("optimizer.scm: 141  simplify");
t3=((C_word*)((C_word*)t0)[3])[1];
f_3029(t3,((C_word*)t0)[2],t2);}}

/* a3286 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3287,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[25],t5));}

/* k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3285,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3216,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t3,t4);}

/* a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3216,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3222,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3239,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("with-exception-handler");
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),t1,t3,t4);}

/* a3238 in a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a3270 in a3238 in a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3271r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3271r(t0,t1,t2);}}

static void C_ccall f_3271r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("k205208");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3276 in a3270 in a3238 in a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3277,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3244 in a3238 in a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 170  eval");
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k3247 in a3244 in a3238 in a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3252,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 171  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[38],((C_word*)t0)[2]);}

/* k3250 in k3247 in a3244 in a3238 in a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3252,2,t0,t1);}
t2=f_3025(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 176  qnode");
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),t4,((C_word*)t0)[2]);}

/* k3267 in k3250 in k3247 in a3244 in a3238 in a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3269,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[35],lf[14],lf[36],t2));}

/* a3221 in a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3222,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3228,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("k205208");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3227 in a3221 in a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3232,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3232(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_3232(t4,t3);}}

/* k3230 in a3227 in a3221 in a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3232(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3232,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 168  lset-adjoin");
((C_proc5)C_retrieve_symbol_proc(lf[33]))(5,*((C_word*)lf[33]+1),t2,*((C_word*)lf[34]+1),C_retrieve(lf[32]),((C_word*)t0)[2]);}

/* k3234 in k3230 in a3227 in a3221 in a3215 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[32]+1 /* (set! broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k3212 in k3283 in k3203 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3142 in k3133 in walk in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 141  simplify");
t2=((C_word*)((C_word*)t0)[3])[1];
f_3029(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_3029(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3029,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
C_trace("optimizer.scm: 122  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t3,*((C_word*)lf[21]+1),t5);}

/* k3031 in simplify in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 123  any");
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t2,t3,t1);}
else{
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a3043 in k3031 in simplify in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3044,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3054,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
C_trace("optimizer.scm: 125  match-node");
((C_proc5)C_retrieve_symbol_proc(lf[29]))(5,*((C_word*)lf[29]+1),t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3052 in a3043 in k3031 in simplify in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3054,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3060,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3101,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3103,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t6=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3102 in k3052 in a3043 in k3031 in simplify in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3103,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k3099 in k3052 in a3043 in k3031 in simplify in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3058 in k3052 in a3043 in k3031 in simplify in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3060,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3066,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 128  caar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[27]+1)))(3,*((C_word*)lf[27]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3064 in k3058 in k3052 in a3043 in k3031 in simplify in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3066,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_fixnum_increase(t3);
t5=(C_word)C_i_set_cdr(t2,t4);
t6=f_3025(((C_word*)t0)[5]);
C_trace("optimizer.scm: 134  simplify");
t7=((C_word*)((C_word*)t0)[4])[1];
f_3029(t7,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 132  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t3,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k3091 in k3064 in k3058 in k3052 in a3043 in k3031 in simplify in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=f_3025(((C_word*)t0)[5]);
C_trace("optimizer.scm: 134  simplify");
t4=((C_word*)((C_word*)t0)[4])[1];
f_3029(t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3034 in k3031 in simplify in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* touch in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static C_word C_fcall f_3025(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* constant-node? in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3005,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[25],t3));}

/* test in ##compiler#perform-high-level-optimizations in k2991 in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_2999(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2999,NULL,4,t0,t1,t2,t3);}
C_trace("optimizer.scm: 116  get");
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2726,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2729,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2747,a[2]=t2,a[3]=t7,a[4]=t6,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("optimizer.scm: 48   debugging");
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t8,lf[19],lf[20]);}

/* k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2750,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("optimizer.scm: 49   call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t2,t3);}

/* a2806 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2807,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2810,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2838,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
C_trace("optimizer.scm: 84   scan");
t9=((C_word*)t6)[1];
f_2838(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a2806 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_2838(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2838,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(2));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[8]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t5);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2863,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,t3))){
t13=t12;
f_2863(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[6])[1]);
t14=t12;
f_2863(t14,(C_word)C_i_not(t13));}}
else{
t11=(C_word)C_eqp(t9,lf[9]);
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t9,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t7,a[9]=t1,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t11)){
t13=t12;
f_2890(t13,t11);}
else{
t13=(C_word)C_eqp(t9,lf[16]);
t14=t12;
f_2890(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[17])));}}}

/* k2888 in scan in a2806 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_2890(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2890,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
C_trace("optimizer.scm: 66   scan");
t4=((C_word*)((C_word*)t0)[7])[1];
f_2838(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[10]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
C_trace("optimizer.scm: 70   scan");
t5=((C_word*)((C_word*)t0)[7])[1];
f_2838(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[12]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[13]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[14]);
if(C_truep(t5)){
C_trace("optimizer.scm: 75   return");
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[15]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))){
t8=(C_word)C_i_car(((C_word*)t0)[8]);
C_trace("optimizer.scm: 80   scan");
t9=((C_word*)((C_word*)t0)[7])[1];
f_2838(t9,((C_word*)t0)[9],t8,((C_word*)t0)[6]);}
else{
t8=f_2729(C_a_i(&a,3),((C_word*)t0)[3],t7);
t9=(C_word)C_i_car(((C_word*)t0)[8]);
C_trace("optimizer.scm: 80   scan");
t10=((C_word*)((C_word*)t0)[7])[1];
f_2838(t10,((C_word*)t0)[9],t9,((C_word*)t0)[6]);}}
else{
C_trace("optimizer.scm: 82   scan-each");
t7=((C_word*)((C_word*)t0)[2])[1];
f_2810(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k2907 in k2888 in scan in a2806 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2909,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2920,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 71   append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2918 in k2907 in k2888 in scan in a2806 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 71   scan");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2838(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2891 in k2888 in scan in a2806 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("optimizer.scm: 67   return");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k2861 in scan in a2806 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_2863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2863,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* scan-each in a2806 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_2810(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2810,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2816,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2816(t7,t1,t2);}

/* loop43 in scan-each in a2806 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_2816(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2816,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2829,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("optimizer.scm: 53   scan");
t5=((C_word*)((C_word*)t0)[3])[1];
f_2838(t5,t4,t3,((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2827 in loop43 in scan-each in a2806 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2816(t3,((C_word*)t0)[2],t2);}

/* k2748 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("optimizer.scm: 85   debugging");
((C_proc5)C_retrieve_symbol_proc(lf[5]))(5,*((C_word*)lf[5]+1),t2,lf[6],lf[7],((C_word*)((C_word*)t0)[2])[1]);}

/* k2751 in k2748 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2753,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2758,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2758(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* loop89 in k2751 in k2748 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_fcall f_2758(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2758,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2798,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2773,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t4,t3,lf[2],C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_car(t5);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t4,t3,lf[2],t8);}
else{
C_trace("##sys#error");
t8=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[4],t5);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2771 in loop89 in k2751 in k2748 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[2],t1);}

/* k2796 in loop89 in k2751 in k2748 in k2745 in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2758(t3,((C_word*)t0)[2],t2);}

/* mark in ##compiler#scan-toplevel-assignments in k2722 in k2719 in k2716 in k2713 in k2710 in k2707 */
static C_word C_fcall f_2729(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
if(C_truep((C_word)C_i_memq(t1,((C_word*)((C_word*)t0)[3])[1]))){
t2=C_SCHEME_UNDEFINED;
return(t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[628] = {
{"toplevel:optimizer_scm",(void*)C_optimizer_toplevel},
{"f_2709:optimizer_scm",(void*)f_2709},
{"f_2712:optimizer_scm",(void*)f_2712},
{"f_2715:optimizer_scm",(void*)f_2715},
{"f_2718:optimizer_scm",(void*)f_2718},
{"f_2721:optimizer_scm",(void*)f_2721},
{"f_2724:optimizer_scm",(void*)f_2724},
{"f_2993:optimizer_scm",(void*)f_2993},
{"f_11669:optimizer_scm",(void*)f_11669},
{"f_11677:optimizer_scm",(void*)f_11677},
{"f_11682:optimizer_scm",(void*)f_11682},
{"f_11727:optimizer_scm",(void*)f_11727},
{"f_11731:optimizer_scm",(void*)f_11731},
{"f_11692:optimizer_scm",(void*)f_11692},
{"f_11716:optimizer_scm",(void*)f_11716},
{"f_4865:optimizer_scm",(void*)f_4865},
{"f_10694:optimizer_scm",(void*)f_10694},
{"f_10728:optimizer_scm",(void*)f_10728},
{"f_10830:optimizer_scm",(void*)f_10830},
{"f_10840:optimizer_scm",(void*)f_10840},
{"f_10904:optimizer_scm",(void*)f_10904},
{"f_10933:optimizer_scm",(void*)f_10933},
{"f_11070:optimizer_scm",(void*)f_11070},
{"f_11062:optimizer_scm",(void*)f_11062},
{"f_10949:optimizer_scm",(void*)f_10949},
{"f_10996:optimizer_scm",(void*)f_10996},
{"f_10986:optimizer_scm",(void*)f_10986},
{"f_10994:optimizer_scm",(void*)f_10994},
{"f_11140:optimizer_scm",(void*)f_11140},
{"f_11153:optimizer_scm",(void*)f_11153},
{"f_11188:optimizer_scm",(void*)f_11188},
{"f_11172:optimizer_scm",(void*)f_11172},
{"f_11176:optimizer_scm",(void*)f_11176},
{"f_11165:optimizer_scm",(void*)f_11165},
{"f_11354:optimizer_scm",(void*)f_11354},
{"f_11367:optimizer_scm",(void*)f_11367},
{"f_11373:optimizer_scm",(void*)f_11373},
{"f_11419:optimizer_scm",(void*)f_11419},
{"f_11411:optimizer_scm",(void*)f_11411},
{"f_11395:optimizer_scm",(void*)f_11395},
{"f_11399:optimizer_scm",(void*)f_11399},
{"f_11403:optimizer_scm",(void*)f_11403},
{"f_4868:optimizer_scm",(void*)f_4868},
{"f_10372:optimizer_scm",(void*)f_10372},
{"f_10394:optimizer_scm",(void*)f_10394},
{"f_10449:optimizer_scm",(void*)f_10449},
{"f_10419:optimizer_scm",(void*)f_10419},
{"f_10441:optimizer_scm",(void*)f_10441},
{"f_10445:optimizer_scm",(void*)f_10445},
{"f_10437:optimizer_scm",(void*)f_10437},
{"f_10417:optimizer_scm",(void*)f_10417},
{"f_10543:optimizer_scm",(void*)f_10543},
{"f_10557:optimizer_scm",(void*)f_10557},
{"f_4871:optimizer_scm",(void*)f_4871},
{"f_5231:optimizer_scm",(void*)f_5231},
{"f_8317:optimizer_scm",(void*)f_8317},
{"f_10251:optimizer_scm",(void*)f_10251},
{"f_10254:optimizer_scm",(void*)f_10254},
{"f_10257:optimizer_scm",(void*)f_10257},
{"f_10260:optimizer_scm",(void*)f_10260},
{"f_10263:optimizer_scm",(void*)f_10263},
{"f_10266:optimizer_scm",(void*)f_10266},
{"f_10343:optimizer_scm",(void*)f_10343},
{"f_10269:optimizer_scm",(void*)f_10269},
{"f_10272:optimizer_scm",(void*)f_10272},
{"f_10275:optimizer_scm",(void*)f_10275},
{"f_10337:optimizer_scm",(void*)f_10337},
{"f_10278:optimizer_scm",(void*)f_10278},
{"f_10281:optimizer_scm",(void*)f_10281},
{"f_10334:optimizer_scm",(void*)f_10334},
{"f_8990:optimizer_scm",(void*)f_8990},
{"f_9008:optimizer_scm",(void*)f_9008},
{"f_9014:optimizer_scm",(void*)f_9014},
{"f_8994:optimizer_scm",(void*)f_8994},
{"f_10284:optimizer_scm",(void*)f_10284},
{"f_10326:optimizer_scm",(void*)f_10326},
{"f_10324:optimizer_scm",(void*)f_10324},
{"f_10287:optimizer_scm",(void*)f_10287},
{"f_10290:optimizer_scm",(void*)f_10290},
{"f_10293:optimizer_scm",(void*)f_10293},
{"f_10317:optimizer_scm",(void*)f_10317},
{"f_10296:optimizer_scm",(void*)f_10296},
{"f_10299:optimizer_scm",(void*)f_10299},
{"f_10302:optimizer_scm",(void*)f_10302},
{"f_10305:optimizer_scm",(void*)f_10305},
{"f_10308:optimizer_scm",(void*)f_10308},
{"f_10311:optimizer_scm",(void*)f_10311},
{"f_10035:optimizer_scm",(void*)f_10035},
{"f_10041:optimizer_scm",(void*)f_10041},
{"f_10227:optimizer_scm",(void*)f_10227},
{"f_10237:optimizer_scm",(void*)f_10237},
{"f_10201:optimizer_scm",(void*)f_10201},
{"f_10211:optimizer_scm",(void*)f_10211},
{"f_10176:optimizer_scm",(void*)f_10176},
{"f_10185:optimizer_scm",(void*)f_10185},
{"f_10188:optimizer_scm",(void*)f_10188},
{"f_10146:optimizer_scm",(void*)f_10146},
{"f_10156:optimizer_scm",(void*)f_10156},
{"f_10060:optimizer_scm",(void*)f_10060},
{"f_10065:optimizer_scm",(void*)f_10065},
{"f_10103:optimizer_scm",(void*)f_10103},
{"f_10088:optimizer_scm",(void*)f_10088},
{"f_10099:optimizer_scm",(void*)f_10099},
{"f_10095:optimizer_scm",(void*)f_10095},
{"f_9902:optimizer_scm",(void*)f_9902},
{"f_9908:optimizer_scm",(void*)f_9908},
{"f_10012:optimizer_scm",(void*)f_10012},
{"f_10022:optimizer_scm",(void*)f_10022},
{"f_9987:optimizer_scm",(void*)f_9987},
{"f_9983:optimizer_scm",(void*)f_9983},
{"f_9930:optimizer_scm",(void*)f_9930},
{"f_9939:optimizer_scm",(void*)f_9939},
{"f_9949:optimizer_scm",(void*)f_9949},
{"f_9584:optimizer_scm",(void*)f_9584},
{"f_9598:optimizer_scm",(void*)f_9598},
{"f_9605:optimizer_scm",(void*)f_9605},
{"f_9608:optimizer_scm",(void*)f_9608},
{"f_9617:optimizer_scm",(void*)f_9617},
{"f_9624:optimizer_scm",(void*)f_9624},
{"f_9627:optimizer_scm",(void*)f_9627},
{"f_9723:optimizer_scm",(void*)f_9723},
{"f_9879:optimizer_scm",(void*)f_9879},
{"f_9889:optimizer_scm",(void*)f_9889},
{"f_9855:optimizer_scm",(void*)f_9855},
{"f_9874:optimizer_scm",(void*)f_9874},
{"f_9870:optimizer_scm",(void*)f_9870},
{"f_9836:optimizer_scm",(void*)f_9836},
{"f_9802:optimizer_scm",(void*)f_9802},
{"f_9807:optimizer_scm",(void*)f_9807},
{"f_9817:optimizer_scm",(void*)f_9817},
{"f_9789:optimizer_scm",(void*)f_9789},
{"f_9772:optimizer_scm",(void*)f_9772},
{"f_9742:optimizer_scm",(void*)f_9742},
{"f_9747:optimizer_scm",(void*)f_9747},
{"f_9757:optimizer_scm",(void*)f_9757},
{"f_9708:optimizer_scm",(void*)f_9708},
{"f_9630:optimizer_scm",(void*)f_9630},
{"f_9679:optimizer_scm",(void*)f_9679},
{"f_9667:optimizer_scm",(void*)f_9667},
{"f_9663:optimizer_scm",(void*)f_9663},
{"f_9596:optimizer_scm",(void*)f_9596},
{"f_9298:optimizer_scm",(void*)f_9298},
{"f_9570:optimizer_scm",(void*)f_9570},
{"f_9409:optimizer_scm",(void*)f_9409},
{"f_9547:optimizer_scm",(void*)f_9547},
{"f_9557:optimizer_scm",(void*)f_9557},
{"f_9502:optimizer_scm",(void*)f_9502},
{"f_9507:optimizer_scm",(void*)f_9507},
{"f_9545:optimizer_scm",(void*)f_9545},
{"f_9307:optimizer_scm",(void*)f_9307},
{"f_9385:optimizer_scm",(void*)f_9385},
{"f_9395:optimizer_scm",(void*)f_9395},
{"f_9368:optimizer_scm",(void*)f_9368},
{"f_9373:optimizer_scm",(void*)f_9373},
{"f_9327:optimizer_scm",(void*)f_9327},
{"f_9332:optimizer_scm",(void*)f_9332},
{"f_9342:optimizer_scm",(void*)f_9342},
{"f_9305:optimizer_scm",(void*)f_9305},
{"f_9537:optimizer_scm",(void*)f_9537},
{"f_9523:optimizer_scm",(void*)f_9523},
{"f_9521:optimizer_scm",(void*)f_9521},
{"f_9411:optimizer_scm",(void*)f_9411},
{"f_9495:optimizer_scm",(void*)f_9495},
{"f_9493:optimizer_scm",(void*)f_9493},
{"f_9465:optimizer_scm",(void*)f_9465},
{"f_9478:optimizer_scm",(void*)f_9478},
{"f_9431:optimizer_scm",(void*)f_9431},
{"f_9455:optimizer_scm",(void*)f_9455},
{"f_9453:optimizer_scm",(void*)f_9453},
{"f_9449:optimizer_scm",(void*)f_9449},
{"f_9441:optimizer_scm",(void*)f_9441},
{"f_9024:optimizer_scm",(void*)f_9024},
{"f_9030:optimizer_scm",(void*)f_9030},
{"f_9049:optimizer_scm",(void*)f_9049},
{"f_9255:optimizer_scm",(void*)f_9255},
{"f_9268:optimizer_scm",(void*)f_9268},
{"f_9162:optimizer_scm",(void*)f_9162},
{"f_9178:optimizer_scm",(void*)f_9178},
{"f_9231:optimizer_scm",(void*)f_9231},
{"f_9235:optimizer_scm",(void*)f_9235},
{"f_9198:optimizer_scm",(void*)f_9198},
{"f_9207:optimizer_scm",(void*)f_9207},
{"f_9217:optimizer_scm",(void*)f_9217},
{"f_9135:optimizer_scm",(void*)f_9135},
{"f_9140:optimizer_scm",(void*)f_9140},
{"f_9153:optimizer_scm",(void*)f_9153},
{"f_9111:optimizer_scm",(void*)f_9111},
{"f_9123:optimizer_scm",(void*)f_9123},
{"f_9060:optimizer_scm",(void*)f_9060},
{"f_9081:optimizer_scm",(void*)f_9081},
{"f_9078:optimizer_scm",(void*)f_9078},
{"f_9028:optimizer_scm",(void*)f_9028},
{"f_8764:optimizer_scm",(void*)f_8764},
{"f_8770:optimizer_scm",(void*)f_8770},
{"f_8789:optimizer_scm",(void*)f_8789},
{"f_8891:optimizer_scm",(void*)f_8891},
{"f_8904:optimizer_scm",(void*)f_8904},
{"f_8882:optimizer_scm",(void*)f_8882},
{"f_8848:optimizer_scm",(void*)f_8848},
{"f_8857:optimizer_scm",(void*)f_8857},
{"f_8869:optimizer_scm",(void*)f_8869},
{"f_8800:optimizer_scm",(void*)f_8800},
{"f_8821:optimizer_scm",(void*)f_8821},
{"f_8818:optimizer_scm",(void*)f_8818},
{"f_8768:optimizer_scm",(void*)f_8768},
{"f_8665:optimizer_scm",(void*)f_8665},
{"f_8671:optimizer_scm",(void*)f_8671},
{"f_8715:optimizer_scm",(void*)f_8715},
{"f_8720:optimizer_scm",(void*)f_8720},
{"f_8727:optimizer_scm",(void*)f_8727},
{"f_8754:optimizer_scm",(void*)f_8754},
{"f_8750:optimizer_scm",(void*)f_8750},
{"f_8742:optimizer_scm",(void*)f_8742},
{"f_8740:optimizer_scm",(void*)f_8740},
{"f_8705:optimizer_scm",(void*)f_8705},
{"f_8683:optimizer_scm",(void*)f_8683},
{"f_8690:optimizer_scm",(void*)f_8690},
{"f_8420:optimizer_scm",(void*)f_8420},
{"f_8606:optimizer_scm",(void*)f_8606},
{"f_8647:optimizer_scm",(void*)f_8647},
{"f_8630:optimizer_scm",(void*)f_8630},
{"f_8634:optimizer_scm",(void*)f_8634},
{"f_8604:optimizer_scm",(void*)f_8604},
{"f_8423:optimizer_scm",(void*)f_8423},
{"f_8578:optimizer_scm",(void*)f_8578},
{"f_8591:optimizer_scm",(void*)f_8591},
{"f_8561:optimizer_scm",(void*)f_8561},
{"f_8573:optimizer_scm",(void*)f_8573},
{"f_8507:optimizer_scm",(void*)f_8507},
{"f_8531:optimizer_scm",(void*)f_8531},
{"f_8525:optimizer_scm",(void*)f_8525},
{"f_8489:optimizer_scm",(void*)f_8489},
{"f_8448:optimizer_scm",(void*)f_8448},
{"f_8451:optimizer_scm",(void*)f_8451},
{"f_8456:optimizer_scm",(void*)f_8456},
{"f_8469:optimizer_scm",(void*)f_8469},
{"f_8320:optimizer_scm",(void*)f_8320},
{"f_8326:optimizer_scm",(void*)f_8326},
{"f_8357:optimizer_scm",(void*)f_8357},
{"f_8361:optimizer_scm",(void*)f_8361},
{"f_8365:optimizer_scm",(void*)f_8365},
{"f_8324:optimizer_scm",(void*)f_8324},
{"f_7125:optimizer_scm",(void*)f_7125},
{"f_8312:optimizer_scm",(void*)f_8312},
{"f_8315:optimizer_scm",(void*)f_8315},
{"f_7128:optimizer_scm",(void*)f_7128},
{"f_7284:optimizer_scm",(void*)f_7284},
{"f_7297:optimizer_scm",(void*)f_7297},
{"f_7264:optimizer_scm",(void*)f_7264},
{"f_7238:optimizer_scm",(void*)f_7238},
{"f_7184:optimizer_scm",(void*)f_7184},
{"f_7190:optimizer_scm",(void*)f_7190},
{"f_7196:optimizer_scm",(void*)f_7196},
{"f_7153:optimizer_scm",(void*)f_7153},
{"f_7306:optimizer_scm",(void*)f_7306},
{"f_7716:optimizer_scm",(void*)f_7716},
{"f_7723:optimizer_scm",(void*)f_7723},
{"f_7309:optimizer_scm",(void*)f_7309},
{"f_7703:optimizer_scm",(void*)f_7703},
{"f_7679:optimizer_scm",(void*)f_7679},
{"f_7690:optimizer_scm",(void*)f_7690},
{"f_7646:optimizer_scm",(void*)f_7646},
{"f_7557:optimizer_scm",(void*)f_7557},
{"f_7562:optimizer_scm",(void*)f_7562},
{"f_7504:optimizer_scm",(void*)f_7504},
{"f_7510:optimizer_scm",(void*)f_7510},
{"f_7515:optimizer_scm",(void*)f_7515},
{"f_7463:optimizer_scm",(void*)f_7463},
{"f_7469:optimizer_scm",(void*)f_7469},
{"f_7474:optimizer_scm",(void*)f_7474},
{"f_7447:optimizer_scm",(void*)f_7447},
{"f_7443:optimizer_scm",(void*)f_7443},
{"f_7413:optimizer_scm",(void*)f_7413},
{"f_7376:optimizer_scm",(void*)f_7376},
{"f_7392:optimizer_scm",(void*)f_7392},
{"f_7358:optimizer_scm",(void*)f_7358},
{"f_7725:optimizer_scm",(void*)f_7725},
{"f_8302:optimizer_scm",(void*)f_8302},
{"f_8300:optimizer_scm",(void*)f_8300},
{"f_7729:optimizer_scm",(void*)f_7729},
{"f_7739:optimizer_scm",(void*)f_7739},
{"f_7748:optimizer_scm",(void*)f_7748},
{"f_7754:optimizer_scm",(void*)f_7754},
{"f_7757:optimizer_scm",(void*)f_7757},
{"f_7763:optimizer_scm",(void*)f_7763},
{"f_7971:optimizer_scm",(void*)f_7971},
{"f_8234:optimizer_scm",(void*)f_8234},
{"f_8244:optimizer_scm",(void*)f_8244},
{"f_8208:optimizer_scm",(void*)f_8208},
{"f_8218:optimizer_scm",(void*)f_8218},
{"f_8193:optimizer_scm",(void*)f_8193},
{"f_8196:optimizer_scm",(void*)f_8196},
{"f_8146:optimizer_scm",(void*)f_8146},
{"f_8149:optimizer_scm",(void*)f_8149},
{"f_8015:optimizer_scm",(void*)f_8015},
{"f_8070:optimizer_scm",(void*)f_8070},
{"f_8073:optimizer_scm",(void*)f_8073},
{"f_8100:optimizer_scm",(void*)f_8100},
{"f_8076:optimizer_scm",(void*)f_8076},
{"f_8079:optimizer_scm",(void*)f_8079},
{"f_8024:optimizer_scm",(void*)f_8024},
{"f_8027:optimizer_scm",(void*)f_8027},
{"f_8030:optimizer_scm",(void*)f_8030},
{"f_7766:optimizer_scm",(void*)f_7766},
{"f_7953:optimizer_scm",(void*)f_7953},
{"f_7880:optimizer_scm",(void*)f_7880},
{"f_7882:optimizer_scm",(void*)f_7882},
{"f_7901:optimizer_scm",(void*)f_7901},
{"f_7904:optimizer_scm",(void*)f_7904},
{"f_7769:optimizer_scm",(void*)f_7769},
{"f_7781:optimizer_scm",(void*)f_7781},
{"f_7836:optimizer_scm",(void*)f_7836},
{"f_7784:optimizer_scm",(void*)f_7784},
{"f_7787:optimizer_scm",(void*)f_7787},
{"f_7792:optimizer_scm",(void*)f_7792},
{"f_7834:optimizer_scm",(void*)f_7834},
{"f_7808:optimizer_scm",(void*)f_7808},
{"f_5253:optimizer_scm",(void*)f_5253},
{"f_6999:optimizer_scm",(void*)f_6999},
{"f_7021:optimizer_scm",(void*)f_7021},
{"f_7033:optimizer_scm",(void*)f_7033},
{"f_7047:optimizer_scm",(void*)f_7047},
{"f_7096:optimizer_scm",(void*)f_7096},
{"f_5278:optimizer_scm",(void*)f_5278},
{"f_7067:optimizer_scm",(void*)f_7067},
{"f_7071:optimizer_scm",(void*)f_7071},
{"f_7041:optimizer_scm",(void*)f_7041},
{"f_7027:optimizer_scm",(void*)f_7027},
{"f_7025:optimizer_scm",(void*)f_7025},
{"f_7014:optimizer_scm",(void*)f_7014},
{"f_6942:optimizer_scm",(void*)f_6942},
{"f_6974:optimizer_scm",(void*)f_6974},
{"f_6794:optimizer_scm",(void*)f_6794},
{"f_6800:optimizer_scm",(void*)f_6800},
{"f_6884:optimizer_scm",(void*)f_6884},
{"f_6809:optimizer_scm",(void*)f_6809},
{"f_6853:optimizer_scm",(void*)f_6853},
{"f_6851:optimizer_scm",(void*)f_6851},
{"f_6825:optimizer_scm",(void*)f_6825},
{"f_6727:optimizer_scm",(void*)f_6727},
{"f_6755:optimizer_scm",(void*)f_6755},
{"f_6767:optimizer_scm",(void*)f_6767},
{"f_6745:optimizer_scm",(void*)f_6745},
{"f_6740:optimizer_scm",(void*)f_6740},
{"f_6585:optimizer_scm",(void*)f_6585},
{"f_6666:optimizer_scm",(void*)f_6666},
{"f_6594:optimizer_scm",(void*)f_6594},
{"f_6647:optimizer_scm",(void*)f_6647},
{"f_6645:optimizer_scm",(void*)f_6645},
{"f_6610:optimizer_scm",(void*)f_6610},
{"f_6556:optimizer_scm",(void*)f_6556},
{"f_6566:optimizer_scm",(void*)f_6566},
{"f_6494:optimizer_scm",(void*)f_6494},
{"f_6511:optimizer_scm",(void*)f_6511},
{"f_6421:optimizer_scm",(void*)f_6421},
{"f_6440:optimizer_scm",(void*)f_6440},
{"f_6334:optimizer_scm",(void*)f_6334},
{"f_6353:optimizer_scm",(void*)f_6353},
{"f_6346:optimizer_scm",(void*)f_6346},
{"f_6257:optimizer_scm",(void*)f_6257},
{"f_6198:optimizer_scm",(void*)f_6198},
{"f_6213:optimizer_scm",(void*)f_6213},
{"f_6216:optimizer_scm",(void*)f_6216},
{"f_6128:optimizer_scm",(void*)f_6128},
{"f_6171:optimizer_scm",(void*)f_6171},
{"f_6164:optimizer_scm",(void*)f_6164},
{"f_6069:optimizer_scm",(void*)f_6069},
{"f_6081:optimizer_scm",(void*)f_6081},
{"f_6094:optimizer_scm",(void*)f_6094},
{"f_6087:optimizer_scm",(void*)f_6087},
{"f_5982:optimizer_scm",(void*)f_5982},
{"f_6004:optimizer_scm",(void*)f_6004},
{"f_6012:optimizer_scm",(void*)f_6012},
{"f_6016:optimizer_scm",(void*)f_6016},
{"f_5838:optimizer_scm",(void*)f_5838},
{"f_5860:optimizer_scm",(void*)f_5860},
{"f_5863:optimizer_scm",(void*)f_5863},
{"f_5922:optimizer_scm",(void*)f_5922},
{"f_5866:optimizer_scm",(void*)f_5866},
{"f_5869:optimizer_scm",(void*)f_5869},
{"f_5900:optimizer_scm",(void*)f_5900},
{"f_5898:optimizer_scm",(void*)f_5898},
{"f_5874:optimizer_scm",(void*)f_5874},
{"f_5854:optimizer_scm",(void*)f_5854},
{"f_5817:optimizer_scm",(void*)f_5817},
{"f_5762:optimizer_scm",(void*)f_5762},
{"f_5786:optimizer_scm",(void*)f_5786},
{"f_5775:optimizer_scm",(void*)f_5775},
{"f_5697:optimizer_scm",(void*)f_5697},
{"f_5610:optimizer_scm",(void*)f_5610},
{"f_5652:optimizer_scm",(void*)f_5652},
{"f_5554:optimizer_scm",(void*)f_5554},
{"f_5567:optimizer_scm",(void*)f_5567},
{"f_5575:optimizer_scm",(void*)f_5575},
{"f_5516:optimizer_scm",(void*)f_5516},
{"f_5526:optimizer_scm",(void*)f_5526},
{"f_5418:optimizer_scm",(void*)f_5418},
{"f_5475:optimizer_scm",(void*)f_5475},
{"f_5446:optimizer_scm",(void*)f_5446},
{"f_5310:optimizer_scm",(void*)f_5310},
{"f_5373:optimizer_scm",(void*)f_5373},
{"f_5313:optimizer_scm",(void*)f_5313},
{"f_5233:optimizer_scm",(void*)f_5233},
{"f_5237:optimizer_scm",(void*)f_5237},
{"f_5247:optimizer_scm",(void*)f_5247},
{"f_4873:optimizer_scm",(void*)f_4873},
{"f_4877:optimizer_scm",(void*)f_4877},
{"f_5218:optimizer_scm",(void*)f_5218},
{"f_5227:optimizer_scm",(void*)f_5227},
{"f_5223:optimizer_scm",(void*)f_5223},
{"f_4924:optimizer_scm",(void*)f_4924},
{"f_5144:optimizer_scm",(void*)f_5144},
{"f_5192:optimizer_scm",(void*)f_5192},
{"f_5205:optimizer_scm",(void*)f_5205},
{"f_5170:optimizer_scm",(void*)f_5170},
{"f_5186:optimizer_scm",(void*)f_5186},
{"f_5174:optimizer_scm",(void*)f_5174},
{"f_5178:optimizer_scm",(void*)f_5178},
{"f_4927:optimizer_scm",(void*)f_4927},
{"f_5069:optimizer_scm",(void*)f_5069},
{"f_5128:optimizer_scm",(void*)f_5128},
{"f_5134:optimizer_scm",(void*)f_5134},
{"f_5085:optimizer_scm",(void*)f_5085},
{"f_5102:optimizer_scm",(void*)f_5102},
{"f_5115:optimizer_scm",(void*)f_5115},
{"f_5100:optimizer_scm",(void*)f_5100},
{"f_5089:optimizer_scm",(void*)f_5089},
{"f_4930:optimizer_scm",(void*)f_4930},
{"f_4933:optimizer_scm",(void*)f_4933},
{"f_4953:optimizer_scm",(void*)f_4953},
{"f_4966:optimizer_scm",(void*)f_4966},
{"f_5009:optimizer_scm",(void*)f_5009},
{"f_5041:optimizer_scm",(void*)f_5041},
{"f_5007:optimizer_scm",(void*)f_5007},
{"f_4989:optimizer_scm",(void*)f_4989},
{"f_4936:optimizer_scm",(void*)f_4936},
{"f_4945:optimizer_scm",(void*)f_4945},
{"f_4879:optimizer_scm",(void*)f_4879},
{"f_4885:optimizer_scm",(void*)f_4885},
{"f_4909:optimizer_scm",(void*)f_4909},
{"f_4858:optimizer_scm",(void*)f_4858},
{"f_4601:optimizer_scm",(void*)f_4601},
{"f_4615:optimizer_scm",(void*)f_4615},
{"f_4630:optimizer_scm",(void*)f_4630},
{"f_4637:optimizer_scm",(void*)f_4637},
{"f_4642:optimizer_scm",(void*)f_4642},
{"f_4849:optimizer_scm",(void*)f_4849},
{"f_4664:optimizer_scm",(void*)f_4664},
{"f_4667:optimizer_scm",(void*)f_4667},
{"f_4680:optimizer_scm",(void*)f_4680},
{"f_4695:optimizer_scm",(void*)f_4695},
{"f_4701:optimizer_scm",(void*)f_4701},
{"f_4707:optimizer_scm",(void*)f_4707},
{"f_4716:optimizer_scm",(void*)f_4716},
{"f_4723:optimizer_scm",(void*)f_4723},
{"f_4726:optimizer_scm",(void*)f_4726},
{"f_4744:optimizer_scm",(void*)f_4744},
{"f_4729:optimizer_scm",(void*)f_4729},
{"f_4618:optimizer_scm",(void*)f_4618},
{"f_4621:optimizer_scm",(void*)f_4621},
{"f_4608:optimizer_scm",(void*)f_4608},
{"f_4604:optimizer_scm",(void*)f_4604},
{"f_2996:optimizer_scm",(void*)f_2996},
{"f_4489:optimizer_scm",(void*)f_4489},
{"f_4495:optimizer_scm",(void*)f_4495},
{"f_4499:optimizer_scm",(void*)f_4499},
{"f_4502:optimizer_scm",(void*)f_4502},
{"f_4538:optimizer_scm",(void*)f_4538},
{"f_4543:optimizer_scm",(void*)f_4543},
{"f_4556:optimizer_scm",(void*)f_4556},
{"f_4559:optimizer_scm",(void*)f_4559},
{"f_4505:optimizer_scm",(void*)f_4505},
{"f_4508:optimizer_scm",(void*)f_4508},
{"f_4511:optimizer_scm",(void*)f_4511},
{"f_4514:optimizer_scm",(void*)f_4514},
{"f_4464:optimizer_scm",(void*)f_4464},
{"f_4479:optimizer_scm",(void*)f_4479},
{"f_4468:optimizer_scm",(void*)f_4468},
{"f_4474:optimizer_scm",(void*)f_4474},
{"f_3335:optimizer_scm",(void*)f_3335},
{"f_4370:optimizer_scm",(void*)f_4370},
{"f_4373:optimizer_scm",(void*)f_4373},
{"f_4456:optimizer_scm",(void*)f_4456},
{"f_4452:optimizer_scm",(void*)f_4452},
{"f_4414:optimizer_scm",(void*)f_4414},
{"f_4445:optimizer_scm",(void*)f_4445},
{"f_4441:optimizer_scm",(void*)f_4441},
{"f_4433:optimizer_scm",(void*)f_4433},
{"f_4385:optimizer_scm",(void*)f_4385},
{"f_4404:optimizer_scm",(void*)f_4404},
{"f_4391:optimizer_scm",(void*)f_4391},
{"f_4344:optimizer_scm",(void*)f_4344},
{"f_4339:optimizer_scm",(void*)f_4339},
{"f_4314:optimizer_scm",(void*)f_4314},
{"f_4304:optimizer_scm",(void*)f_4304},
{"f_3677:optimizer_scm",(void*)f_3677},
{"f_3686:optimizer_scm",(void*)f_3686},
{"f_3892:optimizer_scm",(void*)f_3892},
{"f_3903:optimizer_scm",(void*)f_3903},
{"f_4252:optimizer_scm",(void*)f_4252},
{"f_4284:optimizer_scm",(void*)f_4284},
{"f_4261:optimizer_scm",(void*)f_4261},
{"f_3913:optimizer_scm",(void*)f_3913},
{"f_3985:optimizer_scm",(void*)f_3985},
{"f_4239:optimizer_scm",(void*)f_4239},
{"f_4150:optimizer_scm",(void*)f_4150},
{"f_4153:optimizer_scm",(void*)f_4153},
{"f_4165:optimizer_scm",(void*)f_4165},
{"f_4176:optimizer_scm",(void*)f_4176},
{"f_4209:optimizer_scm",(void*)f_4209},
{"f_4201:optimizer_scm",(void*)f_4201},
{"f_4189:optimizer_scm",(void*)f_4189},
{"f_4180:optimizer_scm",(void*)f_4180},
{"f_4170:optimizer_scm",(void*)f_4170},
{"f_3999:optimizer_scm",(void*)f_3999},
{"f_4038:optimizer_scm",(void*)f_4038},
{"f_4044:optimizer_scm",(void*)f_4044},
{"f_4050:optimizer_scm",(void*)f_4050},
{"f_4087:optimizer_scm",(void*)f_4087},
{"f_4063:optimizer_scm",(void*)f_4063},
{"f_4067:optimizer_scm",(void*)f_4067},
{"f_4032:optimizer_scm",(void*)f_4032},
{"f_4020:optimizer_scm",(void*)f_4020},
{"f_4015:optimizer_scm",(void*)f_4015},
{"f_3976:optimizer_scm",(void*)f_3976},
{"f_3916:optimizer_scm",(void*)f_3916},
{"f_3945:optimizer_scm",(void*)f_3945},
{"f_3958:optimizer_scm",(void*)f_3958},
{"f_3919:optimizer_scm",(void*)f_3919},
{"f_3922:optimizer_scm",(void*)f_3922},
{"f_3925:optimizer_scm",(void*)f_3925},
{"f_3935:optimizer_scm",(void*)f_3935},
{"f_3878:optimizer_scm",(void*)f_3878},
{"f_3774:optimizer_scm",(void*)f_3774},
{"f_3795:optimizer_scm",(void*)f_3795},
{"f_3852:optimizer_scm",(void*)f_3852},
{"f_3844:optimizer_scm",(void*)f_3844},
{"f_3798:optimizer_scm",(void*)f_3798},
{"f_3823:optimizer_scm",(void*)f_3823},
{"f_3821:optimizer_scm",(void*)f_3821},
{"f_3807:optimizer_scm",(void*)f_3807},
{"f_3753:optimizer_scm",(void*)f_3753},
{"f_3695:optimizer_scm",(void*)f_3695},
{"f_3698:optimizer_scm",(void*)f_3698},
{"f_3721:optimizer_scm",(void*)f_3721},
{"f_3734:optimizer_scm",(void*)f_3734},
{"f_3704:optimizer_scm",(void*)f_3704},
{"f_3711:optimizer_scm",(void*)f_3711},
{"f_3501:optimizer_scm",(void*)f_3501},
{"f_3593:optimizer_scm",(void*)f_3593},
{"f_3598:optimizer_scm",(void*)f_3598},
{"f_3605:optimizer_scm",(void*)f_3605},
{"f_3638:optimizer_scm",(void*)f_3638},
{"f_3618:optimizer_scm",(void*)f_3618},
{"f_3506:optimizer_scm",(void*)f_3506},
{"f_3524:optimizer_scm",(void*)f_3524},
{"f_3531:optimizer_scm",(void*)f_3531},
{"f_3571:optimizer_scm",(void*)f_3571},
{"f_3574:optimizer_scm",(void*)f_3574},
{"f_3564:optimizer_scm",(void*)f_3564},
{"f_3544:optimizer_scm",(void*)f_3544},
{"f_3512:optimizer_scm",(void*)f_3512},
{"f_3518:optimizer_scm",(void*)f_3518},
{"f_3435:optimizer_scm",(void*)f_3435},
{"f_3467:optimizer_scm",(void*)f_3467},
{"f_3476:optimizer_scm",(void*)f_3476},
{"f_3483:optimizer_scm",(void*)f_3483},
{"f_3438:optimizer_scm",(void*)f_3438},
{"f_3460:optimizer_scm",(void*)f_3460},
{"f_3455:optimizer_scm",(void*)f_3455},
{"f_3360:optimizer_scm",(void*)f_3360},
{"f_3364:optimizer_scm",(void*)f_3364},
{"f_3376:optimizer_scm",(void*)f_3376},
{"f_3382:optimizer_scm",(void*)f_3382},
{"f_3393:optimizer_scm",(void*)f_3393},
{"f_3121:optimizer_scm",(void*)f_3121},
{"f_3135:optimizer_scm",(void*)f_3135},
{"f_3306:optimizer_scm",(void*)f_3306},
{"f_3312:optimizer_scm",(void*)f_3312},
{"f_3205:optimizer_scm",(void*)f_3205},
{"f_3287:optimizer_scm",(void*)f_3287},
{"f_3285:optimizer_scm",(void*)f_3285},
{"f_3216:optimizer_scm",(void*)f_3216},
{"f_3239:optimizer_scm",(void*)f_3239},
{"f_3271:optimizer_scm",(void*)f_3271},
{"f_3277:optimizer_scm",(void*)f_3277},
{"f_3245:optimizer_scm",(void*)f_3245},
{"f_3249:optimizer_scm",(void*)f_3249},
{"f_3252:optimizer_scm",(void*)f_3252},
{"f_3269:optimizer_scm",(void*)f_3269},
{"f_3222:optimizer_scm",(void*)f_3222},
{"f_3228:optimizer_scm",(void*)f_3228},
{"f_3232:optimizer_scm",(void*)f_3232},
{"f_3236:optimizer_scm",(void*)f_3236},
{"f_3214:optimizer_scm",(void*)f_3214},
{"f_3144:optimizer_scm",(void*)f_3144},
{"f_3029:optimizer_scm",(void*)f_3029},
{"f_3033:optimizer_scm",(void*)f_3033},
{"f_3044:optimizer_scm",(void*)f_3044},
{"f_3054:optimizer_scm",(void*)f_3054},
{"f_3103:optimizer_scm",(void*)f_3103},
{"f_3101:optimizer_scm",(void*)f_3101},
{"f_3060:optimizer_scm",(void*)f_3060},
{"f_3066:optimizer_scm",(void*)f_3066},
{"f_3093:optimizer_scm",(void*)f_3093},
{"f_3036:optimizer_scm",(void*)f_3036},
{"f_3025:optimizer_scm",(void*)f_3025},
{"f_3005:optimizer_scm",(void*)f_3005},
{"f_2999:optimizer_scm",(void*)f_2999},
{"f_2726:optimizer_scm",(void*)f_2726},
{"f_2747:optimizer_scm",(void*)f_2747},
{"f_2807:optimizer_scm",(void*)f_2807},
{"f_2838:optimizer_scm",(void*)f_2838},
{"f_2890:optimizer_scm",(void*)f_2890},
{"f_2909:optimizer_scm",(void*)f_2909},
{"f_2920:optimizer_scm",(void*)f_2920},
{"f_2893:optimizer_scm",(void*)f_2893},
{"f_2863:optimizer_scm",(void*)f_2863},
{"f_2810:optimizer_scm",(void*)f_2810},
{"f_2816:optimizer_scm",(void*)f_2816},
{"f_2829:optimizer_scm",(void*)f_2829},
{"f_2750:optimizer_scm",(void*)f_2750},
{"f_2753:optimizer_scm",(void*)f_2753},
{"f_2758:optimizer_scm",(void*)f_2758},
{"f_2773:optimizer_scm",(void*)f_2773},
{"f_2798:optimizer_scm",(void*)f_2798},
{"f_2729:optimizer_scm",(void*)f_2729},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
