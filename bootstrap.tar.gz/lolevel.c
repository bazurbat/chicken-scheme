/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-28 22:52
   Version 4.1.4 - SVN rev. 15427
   linux-unix-gnu-x86 [ ptables applyhook ]
   compiled 2009-08-13 on x (Linux)
   command line: lolevel.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature debugbuild -scrutinize -types ./types.db -explicit-use -no-trace -output-file lolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[135];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,99,104,101,99,107,45,98,108,111,99,107,32,120,49,53,32,108,111,99,49,54,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,99,104,101,99,107,45,103,101,110,101,114,105,99,45,115,116,114,117,99,116,117,114,101,32,120,52,55,32,108,111,99,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,99,104,101,99,107,45,112,111,105,110,116,101,114,32,120,55,50,32,46,32,108,111,99,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,10),40,110,111,115,105,122,101,114,114,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,16),40,115,105,122,101,114,114,32,97,114,103,115,49,57,52,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,29),40,99,104,101,99,107,110,49,32,110,49,57,53,32,110,109,97,120,49,57,54,32,111,102,102,49,57,55,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,47),40,99,104,101,99,107,110,50,32,110,50,48,50,32,110,109,97,120,50,48,51,32,110,109,97,120,50,50,48,52,32,111,102,102,49,50,48,53,32,111,102,102,50,50,48,54,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,20),40,109,111,118,101,32,102,114,111,109,50,49,52,32,116,111,50,49,53,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,49,55,55,32,110,49,56,55,32,102,111,102,102,115,101,116,49,56,56,32,116,111,102,102,115,101,116,49,56,57,41,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,116,111,102,102,115,101,116,49,56,49,32,37,110,49,55,52,51,48,53,32,37,102,111,102,102,115,101,116,49,55,53,51,48,54,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,102,111,102,102,115,101,116,49,56,48,32,37,110,49,55,52,51,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,49,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,40),40,109,111,118,101,45,109,101,109,111,114,121,33,32,102,114,111,109,49,54,56,32,116,111,49,54,57,32,46,32,116,109,112,49,54,55,49,55,48,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,51,51,56,32,105,51,52,50,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,51,50,48,41,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,99,111,112,121,32,120,51,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,18),40,97,108,108,111,99,97,116,101,32,97,51,52,55,51,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,14),40,102,114,101,101,32,97,51,53,50,51,53,54,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,15),40,112,111,105,110,116,101,114,63,32,120,51,53,57,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,20),40,112,111,105,110,116,101,114,45,108,105,107,101,63,32,120,51,54,52,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,26),40,97,100,100,114,101,115,115,45,62,112,111,105,110,116,101,114,32,97,100,100,114,51,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,25),40,112,111,105,110,116,101,114,45,62,97,100,100,114,101,115,115,32,112,116,114,51,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,22),40,110,117,108,108,45,112,111,105,110,116,101,114,63,32,112,116,114,51,55,53,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,62,112,111,105,110,116,101,114,32,120,51,55,56,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,24),40,112,111,105,110,116,101,114,45,62,111,98,106,101,99,116,32,112,116,114,51,56,55,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,23),40,112,111,105,110,116,101,114,61,63,32,112,49,51,57,48,32,112,50,51,57,49,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,32),40,112,111,105,110,116,101,114,45,111,102,102,115,101,116,32,97,51,57,53,51,57,57,32,97,51,57,52,52,48,48,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,20),40,97,108,105,103,110,45,116,111,45,119,111,114,100,32,120,52,48,57,41,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,27),40,116,97,103,45,112,111,105,110,116,101,114,32,112,116,114,52,50,48,32,116,97,103,52,50,49,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,34),40,116,97,103,103,101,100,45,112,111,105,110,116,101,114,63,32,120,52,51,55,32,46,32,116,109,112,52,51,54,52,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,18),40,112,111,105,110,116,101,114,45,116,97,103,32,120,52,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,108,111,99,97,116,105,118,101,32,111,98,106,52,54,52,32,46,32,105,110,100,101,120,52,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,38),40,109,97,107,101,45,119,101,97,107,45,108,111,99,97,116,105,118,101,32,111,98,106,52,55,49,32,46,32,105,110,100,101,120,52,55,50,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,25),40,108,111,99,97,116,105,118,101,45,115,101,116,33,32,120,52,55,56,32,121,52,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,23),40,108,111,99,97,116,105,118,101,45,62,111,98,106,101,99,116,32,120,52,56,49,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,16),40,108,111,99,97,116,105,118,101,63,32,120,52,56,51,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,117,56,45,115,101,116,33,32,97,52,56,55,52,57,49,32,97,52,56,54,52,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,115,56,45,115,101,116,33,32,97,52,57,53,52,57,57,32,97,52,57,52,53,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,49,54,45,115,101,116,33,32,97,53,48,51,53,48,55,32,97,53,48,50,53,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,49,54,45,115,101,116,33,32,97,53,49,49,53,49,53,32,97,53,49,48,53,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,51,50,45,115,101,116,33,32,97,53,49,57,53,50,51,32,97,53,49,56,53,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,51,50,45,115,101,116,33,32,97,53,50,55,53,51,49,32,97,53,50,54,53,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,51,50,45,115,101,116,33,32,97,53,51,53,53,51,57,32,97,53,51,52,53,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,54,52,45,115,101,116,33,32,97,53,52,51,53,52,55,32,97,53,52,50,53,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,12),40,97,50,49,56,49,32,120,54,48,53,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,17),40,97,50,49,57,55,32,120,54,48,56,32,105,54,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,34),40,101,120,116,101,110,100,45,112,114,111,99,101,100,117,114,101,32,112,114,111,99,54,48,51,32,100,97,116,97,54,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,12),40,97,50,50,50,50,32,120,54,50,50,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,26),40,101,120,116,101,110,100,101,100,45,112,114,111,99,101,100,117,114,101,63,32,120,54,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,97,50,50,53,54,32,120,54,51,54,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,100,117,114,101,45,100,97,116,97,32,120,54,50,54,41,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,34),40,115,101,116,45,112,114,111,99,101,100,117,114,101,45,100,97,116,97,33,32,112,114,111,99,54,52,48,32,120,54,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,19),40,118,101,99,116,111,114,45,108,105,107,101,63,32,120,54,52,52,41,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,115,108,111,116,115,32,120,54,53,52,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,98,121,116,101,115,32,120,54,53,55,41,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,32,116,121,112,101,54,54,53,32,46,32,97,114,103,115,54,54,54,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,35),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,63,32,120,54,55,53,32,46,32,116,109,112,54,55,52,54,55,54,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,27),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,116,121,112,101,32,120,54,57,51,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,29),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,108,101,110,103,116,104,32,120,54,57,54,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,42),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,115,108,111,116,45,115,101,116,33,32,120,54,57,57,32,105,55,48,48,32,121,55,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,55,49,51,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,21),40,114,101,99,111,114,100,45,62,118,101,99,116,111,114,32,120,55,48,57,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,101,118,105,99,116,101,100,63,32,120,55,50,50,41,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,16),40,102,95,50,53,57,50,32,97,55,50,56,55,51,49,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,53,52,32,105,55,53,56,41};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,55,51,52,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,34),40,111,98,106,101,99,116,45,101,118,105,99,116,32,120,55,50,52,32,46,32,97,108,108,111,99,97,116,111,114,55,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,49,52,32,105,56,49,56,41};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,55,56,57,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,49),40,111,98,106,101,99,116,45,101,118,105,99,116,45,116,111,45,108,111,99,97,116,105,111,110,32,120,55,55,50,32,112,116,114,55,55,51,32,46,32,108,105,109,105,116,55,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,16),40,102,95,50,56,52,53,32,97,56,51,56,56,52,50,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,53,53,32,105,56,53,57,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,14),40,114,101,108,101,97,115,101,32,120,56,52,53,41,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,35),40,111,98,106,101,99,116,45,114,101,108,101,97,115,101,32,120,56,51,52,32,46,32,114,101,108,101,97,115,101,114,56,51,53,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,56,49,32,105,56,56,53,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,56,54,57,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,115,105,122,101,32,120,56,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,57,51,49,32,105,57,51,53,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,57,49,50,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,33),40,111,98,106,101,99,116,45,117,110,101,118,105,99,116,32,120,57,48,51,32,46,32,116,109,112,57,48,50,57,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,50,56,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,24),40,111,98,106,101,99,116,45,98,101,99,111,109,101,33,32,97,108,115,116,57,52,50,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,33),40,109,117,116,97,116,101,45,112,114,111,99,101,100,117,114,101,32,111,108,100,57,52,57,32,112,114,111,99,57,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,111,111,107,32,46,32,97,114,103,115,57,54,48,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,45),40,115,101,116,45,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,97,110,100,108,101,114,33,32,112,114,111,99,57,53,57,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,33),40,117,110,98,111,117,110,100,45,118,97,114,105,97,98,108,101,45,118,97,108,117,101,32,46,32,118,97,108,57,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,103,108,111,98,97,108,45,114,101,102,32,115,121,109,57,54,56,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,25),40,103,108,111,98,97,108,45,115,101,116,33,32,115,121,109,57,55,49,32,120,57,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,22),40,103,108,111,98,97,108,45,98,111,117,110,100,63,32,115,121,109,57,55,53,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,29),40,103,108,111,98,97,108,45,109,97,107,101,45,117,110,98,111,117,110,100,33,32,115,121,109,57,55,56,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,17),40,97,51,49,55,53,32,120,55,48,52,32,105,55,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,15),40,97,51,49,57,57,32,97,53,57,53,53,57,57,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,15),40,97,51,50,48,57,32,97,53,56,56,53,57,50,41,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,15),40,97,51,50,49,57,32,97,53,56,49,53,56,53,41,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,15),40,97,51,50,50,57,32,97,53,55,52,53,55,56,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,15),40,97,51,50,51,57,32,97,53,54,56,53,55,50,41,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,15),40,97,51,50,52,57,32,97,53,54,50,53,54,54,41,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,15),40,97,51,50,53,57,32,97,53,53,54,53,54,48,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,15),40,97,51,50,54,57,32,97,53,53,48,53,53,52,41,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,14),67,95,108,111,99,97,116,105,118,101,95,114,101,102,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k2848 */
static C_word C_fcall stub839(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub839(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k2595 */
static C_word C_fcall stub729(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub729(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k3203 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub596(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub596(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_ret:
#undef return

return C_r;}

/* from k3213 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub589(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub589(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_ret:
#undef return

return C_r;}

/* from k3223 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub582(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub582(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3233 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub575(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub575(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3243 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub569(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub569(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_ret:
#undef return

return C_r;}

/* from k3253 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub563(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub563(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_ret:
#undef return

return C_r;}

/* from k3263 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub557(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub557(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((signed char *)p));
C_ret:
#undef return

return C_r;}

/* from k3273 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub551(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub551(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_ret:
#undef return

return C_r;}

/* from k2130 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub544(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub544(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2116 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub536(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub536(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2102 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub528(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub528(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2088 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub520(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub520(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2074 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub512(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub512(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2060 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub504(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub504(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2046 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub496(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub496(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2032 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub488(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub488(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1839 */
static C_word C_fcall stub405(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub405(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k1829 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub396(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub396(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

/* from object->pointer in k1068 in k1065 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub382(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub382(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k1750 */
static C_word C_fcall stub353(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub353(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k1743 */
static C_word C_fcall stub348(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub348(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1321 */
static C_word C_fcall stub147(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub147(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1293 */
static C_word C_fcall stub131(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub131(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1265 */
static C_word C_fcall stub115(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub115(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1237 */
static C_word C_fcall stub99(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub99(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1100)
static void C_fcall f_1100(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_fcall f_2951(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_fcall f_3022(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_fcall f_2864(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_fcall f_2883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_fcall f_2896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_fcall f_2898(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2772)
static void C_fcall f_2772(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2817)
static void C_fcall f_2817(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f3599)
static void C_ccall f3599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_fcall f_2606(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2752)
static void C_ccall f_2752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2620)
static void C_fcall f_2620(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_fcall f_2639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_fcall f_2645(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_fcall f_2661(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_fcall f_2663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_fcall f_2496(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_fcall f_2522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_fcall f_2535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_fcall f_2537(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static C_word C_fcall f_2455(C_word t0,C_word t1);
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1174)
static void C_fcall f_1174(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1757)
static void C_ccall f_1757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1665)
static void C_fcall f_1665(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_fcall f_1710(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1596)
static void C_fcall f_1596(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_fcall f_1591(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1586)
static void C_fcall f_1586(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1337)
static void C_fcall f_1337(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1398)
static void C_ccall f_1398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_fcall f_1403(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1368)
static void C_fcall f_1368(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1375)
static void C_fcall f_1375(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_fcall f_1352(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1346)
static void C_fcall f_1346(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1340)
static void C_fcall f_1340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1145)
static void C_fcall f_1145(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1072)
static void C_fcall f_1072(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_1100)
static void C_fcall trf_1100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1100(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1100(t0,t1,t2);}

C_noret_decl(trf_2951)
static void C_fcall trf_2951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2951(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2951(t0,t1,t2);}

C_noret_decl(trf_3022)
static void C_fcall trf_3022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3022(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3022(t0,t1,t2);}

C_noret_decl(trf_2864)
static void C_fcall trf_2864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2864(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2864(t0,t1,t2);}

C_noret_decl(trf_2883)
static void C_fcall trf_2883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2883(t0,t1);}

C_noret_decl(trf_2896)
static void C_fcall trf_2896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2896(t0,t1);}

C_noret_decl(trf_2898)
static void C_fcall trf_2898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2898(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2898(t0,t1,t2);}

C_noret_decl(trf_2772)
static void C_fcall trf_2772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2772(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2772(t0,t1,t2);}

C_noret_decl(trf_2817)
static void C_fcall trf_2817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2817(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2817(t0,t1,t2);}

C_noret_decl(trf_2606)
static void C_fcall trf_2606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2606(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2606(t0,t1);}

C_noret_decl(trf_2620)
static void C_fcall trf_2620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2620(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2620(t0,t1,t2);}

C_noret_decl(trf_2639)
static void C_fcall trf_2639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2639(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2639(t0,t1);}

C_noret_decl(trf_2645)
static void C_fcall trf_2645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2645(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2645(t0,t1);}

C_noret_decl(trf_2661)
static void C_fcall trf_2661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2661(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2661(t0,t1);}

C_noret_decl(trf_2663)
static void C_fcall trf_2663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2663(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2663(t0,t1,t2);}

C_noret_decl(trf_2496)
static void C_fcall trf_2496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2496(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2496(t0,t1,t2);}

C_noret_decl(trf_2522)
static void C_fcall trf_2522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2522(t0,t1);}

C_noret_decl(trf_2535)
static void C_fcall trf_2535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2535(t0,t1);}

C_noret_decl(trf_2537)
static void C_fcall trf_2537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2537(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2537(t0,t1,t2);}

C_noret_decl(trf_1174)
static void C_fcall trf_1174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1174(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1174(t0,t1);}

C_noret_decl(trf_1665)
static void C_fcall trf_1665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1665(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1665(t0,t1,t2);}

C_noret_decl(trf_1710)
static void C_fcall trf_1710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1710(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1710(t0,t1,t2);}

C_noret_decl(trf_1596)
static void C_fcall trf_1596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1596(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1596(t0,t1);}

C_noret_decl(trf_1591)
static void C_fcall trf_1591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1591(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1591(t0,t1,t2);}

C_noret_decl(trf_1586)
static void C_fcall trf_1586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1586(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1586(t0,t1,t2,t3);}

C_noret_decl(trf_1337)
static void C_fcall trf_1337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1337(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1337(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1403)
static void C_fcall trf_1403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1403(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1403(t0,t1,t2,t3);}

C_noret_decl(trf_1368)
static void C_fcall trf_1368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1368(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1368(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1375)
static void C_fcall trf_1375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1375(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1375(t0,t1);}

C_noret_decl(trf_1352)
static void C_fcall trf_1352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1352(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1352(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1346)
static void C_fcall trf_1346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1346(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1346(t0,t1,t2);}

C_noret_decl(trf_1340)
static void C_fcall trf_1340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1340(t0,t1);}

C_noret_decl(trf_1145)
static void C_fcall trf_1145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1145(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1145(t0,t1,t2);}

C_noret_decl(trf_1072)
static void C_fcall trf_1072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1072(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1072(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1297)){
C_save(t1);
C_rereclaim2(1297*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,135);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_h_intern(&lf[3],14,"\003syserror-hook");
lf[5]=C_h_intern(&lf[5],15,"\003syssignal-hook");
lf[6]=C_h_intern(&lf[6],11,"\000type-error");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a structure");
lf[8]=C_h_intern(&lf[8],17,"\003syscheck-pointer");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[10]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[11]=C_h_intern(&lf[11],12,"move-memory!");
lf[12]=C_h_intern(&lf[12],9,"\003syserror");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[15]=C_h_intern(&lf[15],15,"\003sysbytevector\077");
lf[16]=C_h_intern(&lf[16],11,"object-copy");
lf[17]=C_h_intern(&lf[17],15,"\003sysmake-vector");
lf[18]=C_h_intern(&lf[18],8,"allocate");
lf[19]=C_h_intern(&lf[19],4,"free");
lf[20]=C_h_intern(&lf[20],8,"pointer\077");
lf[21]=C_h_intern(&lf[21],13,"pointer-like\077");
lf[22]=C_h_intern(&lf[22],16,"address->pointer");
lf[23]=C_h_intern(&lf[23],20,"\003sysaddress->pointer");
lf[24]=C_h_intern(&lf[24],17,"\003syscheck-integer");
lf[25]=C_h_intern(&lf[25],16,"pointer->address");
lf[26]=C_h_intern(&lf[26],20,"\003syspointer->address");
lf[27]=C_h_intern(&lf[27],17,"\003syscheck-special");
lf[28]=C_h_intern(&lf[28],12,"null-pointer");
lf[29]=C_h_intern(&lf[29],16,"\003sysnull-pointer");
lf[30]=C_h_intern(&lf[30],13,"null-pointer\077");
lf[31]=C_h_intern(&lf[31],15,"object->pointer");
lf[32]=C_h_intern(&lf[32],15,"pointer->object");
lf[33]=C_h_intern(&lf[33],9,"pointer=\077");
lf[34]=C_h_intern(&lf[34],14,"pointer-offset");
lf[35]=C_h_intern(&lf[35],13,"align-to-word");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a pointer or integer");
lf[37]=C_h_intern(&lf[37],11,"tag-pointer");
lf[38]=C_h_intern(&lf[38],23,"\003sysmake-tagged-pointer");
lf[39]=C_h_intern(&lf[39],15,"tagged-pointer\077");
lf[40]=C_h_intern(&lf[40],11,"pointer-tag");
lf[41]=C_h_intern(&lf[41],13,"make-locative");
lf[42]=C_h_intern(&lf[42],17,"\003sysmake-locative");
lf[43]=C_h_intern(&lf[43],18,"make-weak-locative");
lf[44]=C_h_intern(&lf[44],13,"locative-set!");
lf[45]=C_h_intern(&lf[45],12,"locative-ref");
lf[46]=C_h_intern(&lf[46],16,"locative->object");
lf[47]=C_h_intern(&lf[47],9,"locative\077");
lf[48]=C_h_intern(&lf[48],15,"pointer-u8-set!");
lf[49]=C_h_intern(&lf[49],15,"pointer-s8-set!");
lf[50]=C_h_intern(&lf[50],16,"pointer-u16-set!");
lf[51]=C_h_intern(&lf[51],16,"pointer-s16-set!");
lf[52]=C_h_intern(&lf[52],16,"pointer-u32-set!");
lf[53]=C_h_intern(&lf[53],16,"pointer-s32-set!");
lf[54]=C_h_intern(&lf[54],16,"pointer-f32-set!");
lf[55]=C_h_intern(&lf[55],16,"pointer-f64-set!");
lf[56]=C_h_intern(&lf[56],14,"pointer-u8-ref");
lf[57]=C_h_intern(&lf[57],14,"pointer-s8-ref");
lf[58]=C_h_intern(&lf[58],15,"pointer-u16-ref");
lf[59]=C_h_intern(&lf[59],15,"pointer-s16-ref");
lf[60]=C_h_intern(&lf[60],15,"pointer-u32-ref");
lf[61]=C_h_intern(&lf[61],15,"pointer-s32-ref");
lf[62]=C_h_intern(&lf[62],15,"pointer-f32-ref");
lf[63]=C_h_intern(&lf[63],15,"pointer-f64-ref");
lf[64]=C_h_intern(&lf[64],8,"extended");
lf[66]=C_h_intern(&lf[66],16,"extend-procedure");
lf[67]=C_h_intern(&lf[67],19,"\003sysdecorate-lambda");
lf[68]=C_h_intern(&lf[68],17,"\003syscheck-closure");
lf[69]=C_h_intern(&lf[69],19,"extended-procedure\077");
lf[70]=C_h_intern(&lf[70],21,"\003syslambda-decoration");
lf[71]=C_h_intern(&lf[71],14,"procedure-data");
lf[72]=C_h_intern(&lf[72],19,"set-procedure-data!");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[74]=C_h_intern(&lf[74],10,"block-set!");
lf[75]=C_h_intern(&lf[75],14,"\003sysblock-set!");
lf[76]=C_h_intern(&lf[76],9,"block-ref");
lf[77]=C_h_intern(&lf[77],12,"vector-like\077");
lf[78]=C_h_intern(&lf[78],15,"number-of-slots");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a vector-like object");
lf[80]=C_h_intern(&lf[80],15,"number-of-bytes");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\0002cannot compute number of bytes of immediate object");
lf[82]=C_h_intern(&lf[82],20,"make-record-instance");
lf[83]=C_h_intern(&lf[83],18,"\003sysmake-structure");
lf[84]=C_h_intern(&lf[84],16,"record-instance\077");
lf[85]=C_h_intern(&lf[85],20,"record-instance-type");
lf[86]=C_h_intern(&lf[86],22,"record-instance-length");
lf[87]=C_h_intern(&lf[87],25,"record-instance-slot-set!");
lf[88]=C_h_intern(&lf[88],15,"\003syscheck-range");
lf[89]=C_h_intern(&lf[89],20,"record-instance-slot");
lf[90]=C_h_intern(&lf[90],14,"record->vector");
lf[91]=C_h_intern(&lf[91],15,"object-evicted\077");
lf[92]=C_h_intern(&lf[92],12,"object-evict");
lf[93]=C_h_intern(&lf[93],15,"hash-table-set!");
lf[94]=C_h_intern(&lf[94],19,"\003sysundefined-value");
lf[95]=C_h_intern(&lf[95],22,"hash-table-ref/default");
lf[96]=C_h_intern(&lf[96],15,"make-hash-table");
lf[97]=C_h_intern(&lf[97],3,"eq\077");
lf[98]=C_h_intern(&lf[98],24,"object-evict-to-location");
lf[99]=C_h_intern(&lf[99],24,"\003sysset-pointer-address!");
lf[100]=C_h_intern(&lf[100],6,"signal");
lf[101]=C_h_intern(&lf[101],24,"make-composite-condition");
lf[102]=C_h_intern(&lf[102],23,"make-property-condition");
lf[103]=C_h_intern(&lf[103],5,"evict");
lf[104]=C_h_intern(&lf[104],5,"limit");
lf[105]=C_h_intern(&lf[105],3,"exn");
lf[106]=C_h_intern(&lf[106],8,"location");
lf[107]=C_h_intern(&lf[107],7,"message");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000$cannot evict object - limit exceeded");
lf[109]=C_h_intern(&lf[109],9,"arguments");
lf[110]=C_h_intern(&lf[110],14,"object-release");
lf[111]=C_h_intern(&lf[111],11,"object-size");
lf[112]=C_h_intern(&lf[112],14,"object-unevict");
lf[113]=C_h_intern(&lf[113],15,"\003sysmake-string");
lf[114]=C_h_intern(&lf[114],14,"object-become!");
lf[115]=C_h_intern(&lf[115],11,"\003sysbecome!");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000:bad argument type - not an a-list of non-immediate objects");
lf[117]=C_h_intern(&lf[117],16,"mutate-procedure");
lf[119]=C_h_intern(&lf[119],35,"set-invalid-procedure-call-handler!");
lf[120]=C_h_intern(&lf[120],31,"\003sysinvalid-procedure-call-hook");
lf[121]=C_h_intern(&lf[121],26,"\003syslast-invalid-procedure");
lf[122]=C_h_intern(&lf[122],22,"unbound-variable-value");
lf[123]=C_h_intern(&lf[123],31,"\003sysunbound-variable-value-hook");
lf[124]=C_h_intern(&lf[124],10,"global-ref");
lf[125]=C_h_intern(&lf[125],11,"global-set!");
lf[126]=C_h_intern(&lf[126],13,"global-bound\077");
lf[127]=C_h_intern(&lf[127],32,"\003syssymbol-has-toplevel-binding\077");
lf[128]=C_h_intern(&lf[128],20,"global-make-unbound!");
lf[129]=C_h_intern(&lf[129],28,"\003sysarbitrary-unbound-symbol");
lf[130]=C_h_intern(&lf[130],18,"getter-with-setter");
lf[131]=C_h_intern(&lf[131],13,"\003sysblock-ref");
lf[132]=C_h_intern(&lf[132],15,"pointer-s6-set!");
lf[133]=C_h_intern(&lf[133],17,"register-feature!");
lf[134]=C_h_intern(&lf[134],7,"lolevel");
C_register_lf2(lf,135,create_ptable());
t2=C_mutate(&lf[0] /* (set! c316 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1065 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 75   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[133]+1)))(3,*((C_word*)lf[133]+1),t2,lf[134]);}

/* k1068 in k1065 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[76],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1070,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! check-block ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1072,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[4] /* (set! check-generic-structure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1145,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! check-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1196,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=lf[10];
t6=C_mutate((C_word*)lf[11]+1 /* (set! move-memory! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1335,a[2]=t5,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[16]+1 /* (set! object-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1659,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[18]+1 /* (set! allocate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[19]+1 /* (set! free ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1747,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[20]+1 /* (set! pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1757,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[21]+1 /* (set! pointer-like? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1763,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[22]+1 /* (set! address->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1769,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[25]+1 /* (set! pointer->address ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1778,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[28]+1 /* (set! null-pointer ...) */,*((C_word*)lf[29]+1));
t15=C_mutate((C_word*)lf[30]+1 /* (set! null-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[31]+1 /* (set! object->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1801,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[32]+1 /* (set! pointer->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1807,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[33]+1 /* (set! pointer=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1813,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[34]+1 /* (set! pointer-offset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1822,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[35]+1 /* (set! align-to-word ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1842,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[37]+1 /* (set! tag-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1874,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[39]+1 /* (set! tagged-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1889,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[40]+1 /* (set! pointer-tag ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[41]+1 /* (set! make-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1951,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[43]+1 /* (set! make-weak-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1980,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[44]+1 /* (set! locative-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2009,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)C_locative_ref,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 345  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t27,t28,*((C_word*)lf[44]+1));}

/* k2012 in k1068 in k1065 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! locative-ref ...) */,t1);
t3=C_mutate((C_word*)lf[46]+1 /* (set! locative->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2016,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[47]+1 /* (set! locative? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2019,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[48]+1 /* (set! pointer-u8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2025,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[49]+1 /* (set! pointer-s8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2039,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[50]+1 /* (set! pointer-u16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2053,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[51]+1 /* (set! pointer-s16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2067,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[52]+1 /* (set! pointer-u32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2081,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[53]+1 /* (set! pointer-s32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2095,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[54]+1 /* (set! pointer-f32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2109,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[55]+1 /* (set! pointer-f64-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2123,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3270,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 362  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t13,t14,*((C_word*)lf[48]+1));}

/* a3269 in k2012 in k1068 in k1065 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3270,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub551(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub551(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2139,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1 /* (set! pointer-u8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3260,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 367  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[49]+1));}

/* a3259 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3260,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub557(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub557(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! pointer-s8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3250,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 372  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[50]+1));}

/* a3249 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3250,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub563(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub563(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2147,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! pointer-u16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3240,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 377  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[132]+1));}

/* a3239 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3240,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub569(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub569(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1 /* (set! pointer-s16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2155,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3230,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 382  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[52]+1));}

/* a3229 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3230,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub575(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub575(t3,C_SCHEME_FALSE));}}

/* k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2155,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* (set! pointer-u32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2159,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3220,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 387  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[53]+1));}

/* a3219 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3220,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub582(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub582(t3,C_SCHEME_FALSE));}}

/* k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2159,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! pointer-s32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3210,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 392  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[54]+1));}

/* a3209 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3210,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub589(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub589(t3,C_SCHEME_FALSE));}}

/* k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2163,2,t0,t1);}
t2=C_mutate((C_word*)lf[62]+1 /* (set! pointer-f32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2167,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3200,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 397  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[55]+1));}

/* a3199 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3200,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub596(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub596(t3,C_SCHEME_FALSE));}}

/* k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2167,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! pointer-f64-ref ...) */,t1);
t3=(C_word)C_a_i_vector(&a,1,lf[64]);
t4=C_mutate(&lf[65] /* (set! xproc-tag ...) */,t3);
t5=C_mutate((C_word*)lf[66]+1 /* (set! extend-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2173,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[69]+1 /* (set! extended-procedure? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2208,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[71]+1 /* (set! procedure-data ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[66]+1);
t9=C_mutate((C_word*)lf[72]+1 /* (set! set-procedure-data! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2273,a[2]=t8,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[74]+1 /* (set! block-set! ...) */,*((C_word*)lf[75]+1));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 441  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t11,*((C_word*)lf[131]+1),*((C_word*)lf[75]+1));}

/* k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! block-ref ...) */,t1);
t3=C_mutate((C_word*)lf[77]+1 /* (set! vector-like? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2293,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[78]+1 /* (set! number-of-slots ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2306,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[80]+1 /* (set! number-of-bytes ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[82]+1 /* (set! make-record-instance ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2337,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[84]+1 /* (set! record-instance? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2346,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[85]+1 /* (set! record-instance-type ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2390,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[86]+1 /* (set! record-instance-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2399,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[87]+1 /* (set! record-instance-slot-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2412,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2438,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3176,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 491  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t11,t12,*((C_word*)lf[87]+1));}

/* a3175 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3176,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3180,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 493  ##sys#check-generic-structure */
f_1145(t4,t2,(C_word)C_a_i_list(&a,1,lf[89]));}

/* k3178 in a3175 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 494  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[88]+1)))(6,*((C_word*)lf[88]+1),t2,((C_word*)t0)[4],C_fix(0),t4,lf[89]);}

/* k3181 in k3178 in a3175 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2438,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! record-instance-slot ...) */,t1);
t3=C_mutate((C_word*)lf[90]+1 /* (set! record->vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2440,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[91]+1 /* (set! object-evicted? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2478,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[92]+1 /* (set! object-evict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2481,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[98]+1 /* (set! object-evict-to-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[110]+1 /* (set! object-release ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2763,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[111]+1 /* (set! object-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2855,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[112]+1 /* (set! object-unevict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2939,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[114]+1 /* (set! object-become! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3068,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[117]+1 /* (set! mutate-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3077,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t12=lf[118] /* ipc-hook-0 */ =C_SCHEME_FALSE;;
t13=C_mutate((C_word*)lf[119]+1 /* (set! set-invalid-procedure-call-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3109,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[122]+1 /* (set! unbound-variable-value ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3122,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[124]+1 /* (set! global-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3139,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[125]+1 /* (set! global-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3145,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[126]+1 /* (set! global-bound? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3154,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[128]+1 /* (set! global-make-unbound! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3163,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t19=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3163,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[128]);
t4=(C_word)C_slot(lf[129],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3154,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[126]);
/* lolevel.scm: 679  ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t1,t2);}

/* global-set! in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3145,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[125]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3139,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[124]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* unbound-variable-value in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3122r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3122r(t0,t1,t2);}}

static void C_ccall f_3122r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(2);
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
t4=(C_word)C_a_i_vector(&a,1,t3);
t5=C_mutate((C_word*)lf[123]+1 /* (set! unbound-variable-value-hook ...) */,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=C_set_block_item(lf[123] /* unbound-variable-value-hook */,0,C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* set-invalid-procedure-call-handler! in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3109,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3113,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 655  ##sys#check-closure */
t4=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[119]);}

/* k3111 in set-invalid-procedure-call-handler! in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3113,2,t0,t1);}
t2=C_mutate(&lf[118] /* (set! ipc-hook-0 ...) */,((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[120]+1 /* (set! invalid-procedure-call-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3116,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#invalid-procedure-call-hook in k3111 in set-invalid-procedure-call-handler! in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3116r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3116r(t0,t1,t2);}}

static void C_ccall f_3116r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* lolevel.scm: 659  ipc-hook-0 */
((C_proc4)C_retrieve_proc(lf[118]))(4,lf[118],t1,*((C_word*)lf[121]+1),t2);}

/* mutate-procedure in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3077,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3081,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 641  ##sys#check-closure */
t5=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[117]);}

/* k3079 in mutate-procedure in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 642  ##sys#check-closure */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[117]);}

/* k3082 in k3079 in mutate-procedure in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3084,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 645  ##sys#make-vector */
t5=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3089 in k3082 in k3079 in mutate-procedure in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3091,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3094,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3106,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 646  proc */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3104 in k3089 in k3082 in k3079 in mutate-procedure in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* lolevel.scm: 646  ##sys#become! */
t4=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k3092 in k3089 in k3082 in k3079 in mutate-procedure in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3068,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3072,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_i_check_list_2(t4,lf[114]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1100,a[2]=t4,a[3]=t7,a[4]=((C_word)li80),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1100(t9,t3,t4);}

/* loop in object-become! in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_1100(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1100,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_pair_2(t4,lf[114]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1122,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* lolevel.scm: 116  ##sys#check-block */
f_1072(t6,t7,(C_word)C_a_i_list(&a,1,lf[114]));}
else{
/* lolevel.scm: 120  ##sys#signal-hook */
t4=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[6],lf[114],lf[116],((C_word*)t0)[2]);}}}

/* k1120 in loop in object-become! in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* lolevel.scm: 117  ##sys#check-block */
f_1072(t2,t3,(C_word)C_a_i_list(&a,1,lf[114]));}

/* k1123 in k1120 in loop in object-become! in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_1125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* lolevel.scm: 118  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1100(t3,((C_word*)t0)[2],t2);}

/* k3070 in object-become! in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 638  ##sys#become! */
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2939r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2939r(t0,t1,t2,t3);}}

static void C_ccall f_2939r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2943,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2943(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2943(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 609  make-hash-table */
t3=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[97]+1));}

/* k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2946,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2951,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li78),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2951(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2951(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2951,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 613  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2965 in copy in k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 616  ##sys#make-string */
t4=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2996,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm: 621  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 626  ##sys#make-vector */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k3008 in k2965 in copy in k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3010,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 627  hash-table-set! */
t4=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k3011 in k3008 in k2965 in copy in k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word)li77),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3022(t7,t2,t3);}

/* doloop931 in k3011 in k3008 in k2965 in copy in k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_3022(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3022,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3043,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 630  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2951(t5,t3,t4);}}

/* k3041 in doloop931 in k3011 in k3008 in k2965 in copy in k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3022(t4,((C_word*)t0)[2],t3);}

/* k3014 in k3011 in k3008 in k2965 in copy in k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2994 in k2965 in copy in k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2999,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 622  hash-table-set! */
t3=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2997 in k2994 in k2965 in copy in k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2978 in k2965 in copy in k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2980,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2983,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 617  hash-table-set! */
t4=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k2981 in k2978 in k2965 in copy in k2944 in k2941 in object-unevict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2855,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2859,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 592  make-hash-table */
t4=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[97]+1));}

/* k2857 in object-size in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2859,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2864,a[2]=t1,a[3]=t3,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2864(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2857 in object-size in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2864(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2864,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 595  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2875 in evict in k2857 in object-size in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2934,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm: 599  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t4,t2);}
else{
t5=(C_word)C_bytes(t2);
t6=t3;
f_2883(t6,(C_word)C_fixnum_plus(t5,(C_word)C_bytes(C_fix(1))));}}}

/* k2932 in k2875 in evict in k2857 in object-size in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2883(t2,(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1))));}

/* k2881 in k2875 in evict in k2857 in object-size in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2883,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 601  hash-table-set! */
t5=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k2884 in k2881 in k2875 in evict in k2857 in object-size in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2889,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)((C_word*)t0)[6])[1];
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2896,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2896(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=(C_word)C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2896(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2894 in k2884 in k2881 in k2875 in evict in k2857 in object-size in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2896,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2898,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li74),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2898(t5,((C_word*)t0)[2],t1);}

/* doloop881 in k2894 in k2884 in k2881 in k2875 in evict in k2857 in object-size in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2898(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2898,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2920,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 605  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2864(t5,t3,t4);}}

/* k2918 in doloop881 in k2894 in k2884 in k2881 in k2875 in evict in k2857 in object-size in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2898(t5,((C_word*)t0)[2],t4);}

/* k2887 in k2884 in k2881 in k2875 in evict in k2857 in object-size in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* object-release in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2763r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2763r(t0,t1,t2,t3);}}

static void C_ccall f_2763r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2845,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2772,a[2]=t9,a[3]=t5,a[4]=t7,a[5]=((C_word)li72),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2772(t11,t1,t2);}

/* release in object-release in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2772(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2772,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2801,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3599,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 589  ##sys#address->pointer */
t8=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,(C_word)C_block_address(&a,1,t2));}
else{
t7=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2817,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,a[6]=((C_word)li71),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_2817(t11,t6,t7);}}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* doloop855 in release in object-release in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2817(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2817,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2827,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 588  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2772(t5,t3,t4);}}

/* k2825 in doloop855 in release in object-release in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2817(t3,((C_word*)t0)[2],t2);}

/* f3599 in release in object-release in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f3599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 589  free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2799 in release in object-release in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 589  ##sys#address->pointer */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2806 in k2799 in release in object-release in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 589  free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_2845 in object-release in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2845,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub839(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub839(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2599r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2599r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2599r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2603,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 536  ##sys#check-special */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[98]);}

/* k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[98]);
t5=t2;
f_2606(t5,t3);}
else{
t3=t2;
f_2606(t3,C_SCHEME_FALSE);}}

/* k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2606,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2609,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2752,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 541  ##sys#pointer->address */
t6=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2750 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 541  ##sys#address->pointer */
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 542  make-hash-table */
t3=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[97]+1));}

/* k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2615,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2620,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li68),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2620(t6,t2,((C_word*)t0)[2]);}

/* evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2620(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2620,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 546  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2745,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 550  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t4,t2);}
else{
t5=(C_word)C_bytes(t2);
t6=t3;
f_2639(t6,(C_word)C_fixnum_plus(t5,(C_word)C_bytes(C_fix(1))));}}}

/* k2743 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2639(t2,(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1))));}

/* k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2639,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2642,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t1);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2729,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm: 557  make-property-condition */
t8=*((C_word*)lf[102]+1);
((C_proc9)(void*)(*((C_word*)t8+1)))(9,t8,t6,lf[105],lf[106],lf[98],lf[107],lf[108],lf[109],t7);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t2;
f_2642(2,t6,t5);}}
else{
t3=t2;
f_2642(2,t3,C_SCHEME_UNDEFINED);}}

/* k2731 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2737,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 561  make-property-condition */
t3=*((C_word*)lf[102]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[103],lf[104],((C_word*)((C_word*)t0)[2])[1]);}

/* k2735 in k2731 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 556  make-composite-condition */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2727 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 555  signal */
t2=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2640 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2645,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[8]))){
t4=*((C_word*)lf[94]+1);
t5=t3;
f_2645(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2645(t4,C_SCHEME_UNDEFINED);}}

/* k2643 in k2640 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2645(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2645,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2648,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2702,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 564  ##sys#pointer->address */
t4=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2700 in k2643 in k2640 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2702,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 564  ##sys#set-pointer-address! */
t3=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2646 in k2643 in k2640 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 565  hash-table-set! */
t3=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2649 in k2646 in k2643 in k2640 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2661,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2661(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=(C_word)C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2661(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2659 in k2649 in k2646 in k2643 in k2640 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2661(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2661,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li67),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2663(t5,((C_word*)t0)[2],t1);}

/* doloop814 in k2659 in k2649 in k2646 in k2643 in k2640 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2663(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2663,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2684,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 569  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2620(t5,t3,t4);}}

/* k2682 in doloop814 in k2659 in k2649 in k2646 in k2643 in k2640 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2663(t4,((C_word*)t0)[2],t3);}

/* k2652 in k2649 in k2646 in k2643 in k2640 in k2637 in k2628 in evict in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2613 in k2610 in k2607 in k2604 in k2601 in object-evict-to-location in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 571  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2481r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2481r(t0,t1,t2,t3);}}

static void C_ccall f_2481r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2592,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2488,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 517  make-hash-table */
t7=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[97]+1));}

/* k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 518  ##sys#check-closure */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[92]);}

/* k2489 in k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2491,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word)li65),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2496(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2489 in k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2496(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2496,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 521  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2504 in evict in k2489 in k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm: 524  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t3,t2);}
else{
t4=t3;
f_2515(2,t4,(C_word)C_bytes(t2));}}}

/* k2513 in k2504 in evict in k2489 in k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 525  allocator */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2517 in k2513 in k2504 in evict in k2489 in k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
t4=*((C_word*)lf[94]+1);
t5=t3;
f_2522(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2522(t4,C_SCHEME_UNDEFINED);}}

/* k2520 in k2517 in k2513 in k2504 in evict in k2489 in k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2522,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 527  hash-table-set! */
t3=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2523 in k2520 in k2517 in k2513 in k2504 in evict in k2489 in k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2535,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2535(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=(C_word)C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2535(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2533 in k2523 in k2520 in k2517 in k2513 in k2504 in evict in k2489 in k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2535,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li64),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2537(t5,((C_word*)t0)[2],t1);}

/* doloop754 in k2533 in k2523 in k2520 in k2517 in k2513 in k2504 in evict in k2489 in k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_2537(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2537,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2558,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 532  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2496(t5,t3,t4);}}

/* k2556 in doloop754 in k2533 in k2523 in k2520 in k2517 in k2513 in k2504 in evict in k2489 in k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2537(t4,((C_word*)t0)[2],t3);}

/* k2526 in k2523 in k2520 in k2517 in k2513 in k2504 in evict in k2489 in k2486 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2592 in object-evict in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2592,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub729(t3,t4));}

/* object-evicted? in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2478,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* record->vector in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2444,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 499  ##sys#check-generic-structure */
f_1145(t3,t2,(C_word)C_a_i_list(&a,1,lf[90]));}

/* k2442 in record->vector in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 501  ##sys#make-vector */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2448 in k2442 in record->vector in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2455(t2,C_fix(0)));}

/* doloop713 in k2448 in k2442 in record->vector in k2436 in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static C_word C_fcall f_2455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
return(t2);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t7=t4;
t1=t7;
goto loop;}}

/* record-instance-slot-set! in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2412,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2416,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 486  ##sys#check-generic-structure */
f_1145(t5,t2,(C_word)C_a_i_list(&a,1,lf[87]));}

/* k2414 in record-instance-slot-set! in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 487  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[88]+1)))(6,*((C_word*)lf[88]+1),t2,((C_word*)t0)[5],C_fix(0),t4,lf[87]);}

/* k2417 in k2414 in record-instance-slot-set! in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],t2,((C_word*)t0)[2]));}

/* record-instance-length in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2399,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2403,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 482  ##sys#check-generic-structure */
f_1145(t3,t2,(C_word)C_a_i_list(&a,1,lf[86]));}

/* k2401 in record-instance-length in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_difference(t2,C_fix(1)));}

/* record-instance-type in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2390,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2394,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 478  ##sys#check-generic-structure */
f_1145(t3,t2,(C_word)C_a_i_list(&a,1,lf[85]));}

/* k2392 in record-instance-type in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* record-instance? in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2346r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2346r(t0,t1,t2,t3);}}

static void C_ccall f_2346r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2350,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2350(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2350(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2348 in record-instance? in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_structurep(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t1,t5));}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* make-record-instance in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2337r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2337r(t0,t1,t2,t3);}}

static void C_ccall f_2337r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[82]);
C_apply(5,0,t1,*((C_word*)lf[83]+1),t2,t3);}

/* number-of-bytes in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2315,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_w2b(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
/* lolevel.scm: 452  ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[6],lf[80],lf[81],t2);}}

/* number-of-slots in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2306,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2310,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_list(&a,1,lf[78]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1174,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_blockp(t4))){
t7=(C_word)C_specialp(t4);
if(C_truep(t7)){
t8=t6;
f_1174(t8,(C_word)C_i_not(t7));}
else{
t8=(C_word)C_byteblockp(t4);
t9=t6;
f_1174(t9,(C_word)C_i_not(t8));}}
else{
t7=t6;
f_1174(t7,C_SCHEME_FALSE);}}

/* k1172 in number-of-slots in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_fcall f_1174(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[5]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
/* lolevel.scm: 134  ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[6],t2,lf[79],((C_word*)t0)[2]);}
else{
/* lolevel.scm: 134  ##sys#signal-hook */
t2=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[6],C_SCHEME_FALSE,lf[79],((C_word*)t0)[2]);}}}

/* k2308 in number-of-slots in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* vector-like? in k2289 in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2293,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_specialp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t4=(C_word)C_byteblockp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_not(t4));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* set-procedure-data! in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2273,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2277,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 430  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k2275 in set-procedure-data! in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* lolevel.scm: 433  ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[6],lf[72],lf[73],((C_word*)t0)[3]);}}

/* procedure-data in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2239,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2249,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2257,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 415  ##sys#lambda-decoration */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t3,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2256 in procedure-data in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2257,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[65],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2247 in procedure-data in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2208,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2221,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2223,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 415  ##sys#lambda-decoration */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t3,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2222 in extended-procedure? in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2223,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[65],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2219 in extended-procedure? in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2173,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2177,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 408  ##sys#check-closure */
t5=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[66]);}

/* k2175 in extend-procedure in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[4],a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 409  ##sys#decorate-lambda */
t4=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2197 in k2175 in extend-procedure in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2198,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[65],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a2181 in k2175 in extend-procedure in k2165 in k2161 in k2157 in k2153 in k2149 in k2145 in k2141 in k2137 in k2012 in k1068 in k1065 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2182,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[65],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-f64-set! in k2012 in k1068 in k1065 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2123,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub544(C_SCHEME_UNDEFINED,t4,t5));}
else{
t4=(C_word)C_i_foreign_flonum_argumentp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub544(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t4));}}

/* pointer-f32-set! in k2012 in k1068 in k1065 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2109,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub536(C_SCHEME_UNDEFINED,t4,t5));}
else{
t4=(C_word)C_i_foreign_flonum_argumentp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub536(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t4));}}

/* pointer-s32-set! in k2012 in k1068 in k1065 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2095,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub528(C_SCHEME_UNDEFINED,t4,t5));}
else{
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub528(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t4));}}

/* pointer-u32-set! in k2012 in k1068 in k1065 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2081,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub520(C_SCHEME_UNDEFINED,t4,t5));}
else{
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub520(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t4));}}

/* pointer-s16-set! in k2012 in k1068 in k1065 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2067,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub512(C_SCHEME_UNDEFINED,t4,t5));}
else{
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub512(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t4));}}

/* pointer-u16-set! in k2012 in k1068 in k1065 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2053,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub504(C_SCHEME_UNDEFINED,t4,t5));}
else{
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub504(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t4));}}

/* pointer-s8-set! in k2012 in k1068 in k1065 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2039,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub496(C_SCHEME_UNDEFINED,t4,t5));}
else{
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub496(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t4));}}

/* pointer-u8-set! in k2012 in k1068 in k1065 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2025,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub488(C_SCHEME_UNDEFINED,t4,t5));}
else{
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub488(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t4));}}

/* locative? in k2012 in k1068 in k1065 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2019,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_locativep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* locative->object in k2012 in k1068 in k1065 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2016,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k1068 in k1065 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2009,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k1068 in k1065 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1980r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1980r(t0,t1,t2,t3);}}

static void C_ccall f_1980r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1988,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* lolevel.scm: 342  ##sys#make-locative */
t5=*((C_word*)lf[42]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,t2,C_fix(0),C_SCHEME_TRUE,lf[43]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
/* lolevel.scm: 342  ##sys#make-locative */
t7=*((C_word*)lf[42]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t6,C_SCHEME_TRUE,lf[43]);}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1986 in make-weak-locative in k1068 in k1065 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 342  ##sys#make-locative */
t2=*((C_word*)lf[42]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[43]);}

/* make-locative in k1068 in k1065 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1951r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1951r(t0,t1,t2,t3);}}

static void C_ccall f_1951r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1959,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* lolevel.scm: 339  ##sys#make-locative */
t5=*((C_word*)lf[42]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,t2,C_fix(0),C_SCHEME_FALSE,lf[41]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
/* lolevel.scm: 339  ##sys#make-locative */
t7=*((C_word*)lf[42]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t6,C_SCHEME_FALSE,lf[41]);}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1957 in make-locative in k1068 in k1065 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 339  ##sys#make-locative */
t2=*((C_word*)lf[42]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[41]);}

/* pointer-tag in k1068 in k1065 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1933,3,t0,t1,t2);}
t3=t2;
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 316  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[40],t2);}}

/* tagged-pointer? in k1068 in k1065 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1889r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1889r(t0,t1,t2,t3);}}

static void C_ccall f_1889r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1893,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1893(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1893(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1891 in tagged-pointer? in k1068 in k1065 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_blockp(((C_word*)t0)[3]))){
if(C_truep((C_word)C_taggedpointerp(((C_word*)t0)[3]))){
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_equalp(t1,t3));}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* tag-pointer in k1068 in k1065 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1874,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1878,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 301  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1876 in tag-pointer in k1068 in k1065 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1881,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_copy_pointer(((C_word*)t0)[2],t1);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}
else{
/* lolevel.scm: 304  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t2,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[37],((C_word*)t0)[2]);}}

/* k1879 in k1876 in tag-pointer in k1068 in k1065 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* align-to-word in k1068 in k1065 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1842,3,t0,t1,t2);}
if(C_truep((C_word)C_i_integerp(t2))){
t3=t1;
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=t3;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub405(t5,t6));}
else{
t3=t2;
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1869,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 291  ##sys#pointer->address */
t6=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* lolevel.scm: 293  ##sys#signal-hook */
t5=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[6],lf[35],lf[36],t2);}}}

/* k1867 in align-to-word in k1068 in k1065 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1869,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t3=(C_word)C_i_foreign_integer_argumentp(t1);
t4=(C_word)stub405(t2,t3);
/* lolevel.scm: 291  ##sys#address->pointer */
t5=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[2],t4);}

/* pointer-offset in k1068 in k1065 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1822,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_integer_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub396(t4,t5,t6));}

/* pointer=? in k1068 in k1065 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1813,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1817,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 277  ##sys#check-special */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[33]);}

/* k1815 in pointer=? in k1068 in k1065 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 278  ##sys#check-special */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[33]);}

/* k1818 in k1815 in pointer=? in k1068 in k1065 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k1068 in k1065 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1807,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1811,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 273  ##sys#check-pointer */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[32]);}

/* k1809 in pointer->object in k1068 in k1065 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k1068 in k1065 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1801,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=t2;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)stub382(t4,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* null-pointer? in k1068 in k1065 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1788,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1792,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 265  ##sys#check-special */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[30]);}

/* k1790 in null-pointer? in k1068 in k1065 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 266  ##sys#pointer->address */
t3=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1797 in k1790 in null-pointer? in k1068 in k1065 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k1068 in k1065 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1778,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1782,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 259  ##sys#check-special */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[25]);}

/* k1780 in pointer->address in k1068 in k1065 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 260  ##sys#pointer->address */
t2=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k1068 in k1065 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1769,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1773,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 255  ##sys#check-integer */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[22]);}

/* k1771 in address->pointer in k1068 in k1065 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 256  ##sys#address->pointer */
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer-like? in k1068 in k1065 */
static void C_ccall f_1763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1763,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_specialp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer? in k1068 in k1065 */
static void C_ccall f_1757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1757,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_anypointerp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* free in k1068 in k1065 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1747,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub353(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub353(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* allocate in k1068 in k1065 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1740,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub348(t3,t4));}

/* object-copy in k1068 in k1065 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1659,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1665,a[2]=t4,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1665(t6,t1,t2);}

/* copy in object-copy in k1068 in k1065 */
static void C_fcall f_1665(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1665,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 233  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1695,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 237  ##sys#make-vector */
t6=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1693 in copy in object-copy in k1068 in k1065 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1695,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1698,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1710,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li13),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1710(t10,t3,t6);}}

/* doloop338 in k1693 in copy in object-copy in k1068 in k1065 */
static void C_fcall f_1710(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1710,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1731,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 241  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1665(t5,t3,t4);}}

/* k1729 in doloop338 in k1693 in copy in object-copy in k1068 in k1065 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1710(t4,((C_word*)t0)[2],t3);}

/* k1696 in k1693 in copy in object-copy in k1068 in k1065 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* move-memory! in k1068 in k1065 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_1335r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1335r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1335r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1337,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word)li8),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1586,a[2]=t5,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1591,a[2]=t6,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1596,a[2]=t7,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-n179309 */
t9=t8;
f_1596(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-foffset180307 */
t11=t7;
f_1591(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-toffset181304 */
t13=t6;
f_1586(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body177186 */
t15=t5;
f_1337(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-n179 in move-memory! in k1068 in k1065 */
static void C_fcall f_1596(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1596,NULL,2,t0,t1);}
/* def-foffset180307 */
t2=((C_word*)t0)[2];
f_1591(t2,t1,C_SCHEME_FALSE);}

/* def-foffset180 in move-memory! in k1068 in k1065 */
static void C_fcall f_1591(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1591,NULL,3,t0,t1,t2);}
/* def-toffset181304 */
t3=((C_word*)t0)[2];
f_1586(t3,t1,t2,C_fix(0));}

/* def-toffset181 in move-memory! in k1068 in k1065 */
static void C_fcall f_1586(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1586,NULL,4,t0,t1,t2,t3);}
/* body177186 */
t4=((C_word*)t0)[2];
f_1337(t4,t1,t2,t3,C_fix(0));}

/* body177 in move-memory! in k1068 in k1065 */
static void C_fcall f_1337(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1337,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1340,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1352,a[2]=t6,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1368,a[2]=t6,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t8,a[6]=t7,a[7]=t5,a[8]=t3,a[9]=t4,a[10]=t2,a[11]=((C_word*)t0)[2],tmp=(C_word)a,a+=12,tmp);
/* lolevel.scm: 197  ##sys#check-block */
f_1072(t9,((C_word*)t0)[4],(C_word)C_a_i_list(&a,1,lf[11]));}

/* k1393 in body177 in move-memory! in k1068 in k1065 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* lolevel.scm: 198  ##sys#check-block */
f_1072(t2,((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,lf[11]));}

/* k1396 in k1393 in body177 in move-memory! in k1068 in k1065 */
static void C_ccall f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1398,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=((C_word*)t0)[11],a[10]=((C_word)li7),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_1403(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* move in k1396 in k1393 in body177 in move-memory! in k1068 in k1065 */
static void C_fcall f_1403(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1403,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[9]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 202  move */
t23=t1;
t24=t5;
t25=t3;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t5=t1;
t6=t2;
/* lolevel.scm: 173  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t5,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t6);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[9]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 206  move */
t23=t1;
t24=t2;
t25=t5;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t5=t1;
t6=t3;
/* lolevel.scm: 173  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t5,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t6);}}
else{
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:(C_word)C_locativep(t4));
if(C_truep(t6)){
t7=t3;
t8=(C_truep((C_word)C_blockp(t7))?(C_word)C_anypointerp(t7):C_SCHEME_FALSE);
t9=(C_truep(t8)?t8:(C_word)C_locativep(t7));
if(C_truep(t9)){
t10=((C_word*)t0)[7];
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t10)){
t12=t11;
f_1481(2,t12,t10);}
else{
/* lolevel.scm: 210  nosizerr */
t12=((C_word*)t0)[4];
f_1340(t12,t11);}}
else{
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1490,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm: 211  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t10,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm: 215  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t7,t2);}}}}

/* k1521 in move in k1396 in k1393 in body177 in move-memory! in k1068 in k1065 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1523,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[9]);
t4=((C_word*)t0)[8];
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:(C_word)C_locativep(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[4];
if(C_truep(t8)){
/* lolevel.scm: 218  checkn1 */
t9=((C_word*)t0)[3];
f_1352(t9,t7,t8,t3,((C_word*)t0)[5]);}
else{
/* lolevel.scm: 218  checkn1 */
t9=((C_word*)t0)[3];
f_1352(t9,t7,t3,t3,((C_word*)t0)[5]);}}
else{
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm: 219  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t7,((C_word*)t0)[8]);}}
else{
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[9];
/* lolevel.scm: 173  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t4);}}

/* k1553 in k1521 in move in k1396 in k1393 in body177 in move-memory! in k1068 in k1065 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1565,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[4];
t5=(C_truep(t4)?t4:((C_word*)t0)[3]);
t6=(C_word)C_block_size(((C_word*)t0)[9]);
/* lolevel.scm: 220  checkn2 */
t7=((C_word*)t0)[2];
f_1368(t7,t3,t5,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
/* lolevel.scm: 173  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t4);}}

/* k1563 in k1553 in k1521 in move in k1396 in k1393 in body177 in move-memory! in k1068 in k1065 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub147(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1543 in k1521 in move in k1396 in k1393 in body177 in move-memory! in k1068 in k1065 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub115(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1488 in move in k1396 in k1393 in body177 in move-memory! in k1068 in k1065 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1490,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1500,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1504,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=(C_word)C_block_size(((C_word*)t0)[9]);
/* lolevel.scm: 212  checkn1 */
t7=((C_word*)t0)[3];
f_1352(t7,t3,t4,t6,((C_word*)t0)[6]);}
else{
/* lolevel.scm: 212  nosizerr */
t6=((C_word*)t0)[2];
f_1340(t6,t5);}}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
/* lolevel.scm: 173  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t4);}}

/* k1502 in k1488 in move in k1396 in k1393 in body177 in move-memory! in k1068 in k1065 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 212  checkn1 */
t3=((C_word*)t0)[4];
f_1352(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k1498 in k1488 in move in k1396 in k1393 in body177 in move-memory! in k1068 in k1065 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub131(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1479 in move in k1396 in k1393 in body177 in move-memory! in k1068 in k1065 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub99(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* checkn2 in body177 in move-memory! in k1068 in k1065 */
static void C_fcall f_1368(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1368,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1375,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_fixnum_difference(t3,t5);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t8))){
t9=(C_word)C_fixnum_difference(t4,t6);
t10=t7;
f_1375(t10,(C_word)C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_1375(t9,C_SCHEME_FALSE);}}

/* k1373 in checkn2 in body177 in move-memory! in k1068 in k1065 */
static void C_fcall f_1375(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1375,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* lolevel.scm: 195  sizerr */
t2=((C_word*)t0)[4];
f_1346(t2,((C_word*)t0)[5],(C_word)C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* checkn1 in body177 in move-memory! in k1068 in k1065 */
static void C_fcall f_1352(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1352,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t3,t4);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t5))){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* lolevel.scm: 190  sizerr */
t6=((C_word*)t0)[2];
f_1346(t6,t1,(C_word)C_a_i_list(&a,2,t2,t3));}}

/* sizerr in body177 in move-memory! in k1068 in k1065 */
static void C_fcall f_1346(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1346,NULL,3,t0,t1,t2);}
C_apply(8,0,t1,*((C_word*)lf[12]+1),lf[11],lf[14],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* nosizerr in body177 in move-memory! in k1068 in k1065 */
static void C_fcall f_1340(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1340,NULL,2,t0,t1);}
/* lolevel.scm: 182  ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[11],lf[13],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#check-pointer in k1068 in k1065 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1196r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1196r(t0,t1,t2,t3);}}

static void C_ccall f_1196r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_notvemptyp(t3))){
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
/* lolevel.scm: 140  ##sys#error-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[3]+1)))(6,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),t6,lf[9],t2);}
else{
/* lolevel.scm: 140  ##sys#error-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[3]+1)))(6,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),C_SCHEME_FALSE,lf[9],t2);}}}

/* ##sys#check-generic-structure in k1068 in k1065 */
static void C_fcall f_1145(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1145,NULL,3,t1,t2,t3);}
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_structurep(t4):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t6=(C_word)C_i_car(t3);
/* lolevel.scm: 126  ##sys#signal-hook */
t7=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,lf[6],t6,lf[7],t2);}
else{
/* lolevel.scm: 126  ##sys#signal-hook */
t6=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,lf[6],C_SCHEME_FALSE,lf[7],t2);}}}

/* ##sys#check-block in k1068 in k1065 */
static void C_fcall f_1072(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1072,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
/* lolevel.scm: 105  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),t4,t2);}
else{
/* lolevel.scm: 105  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),C_SCHEME_FALSE,t2);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[218] = {
{"toplevel:lolevel_scm",(void*)C_lolevel_toplevel},
{"f_1067:lolevel_scm",(void*)f_1067},
{"f_1070:lolevel_scm",(void*)f_1070},
{"f_2014:lolevel_scm",(void*)f_2014},
{"f_3270:lolevel_scm",(void*)f_3270},
{"f_2139:lolevel_scm",(void*)f_2139},
{"f_3260:lolevel_scm",(void*)f_3260},
{"f_2143:lolevel_scm",(void*)f_2143},
{"f_3250:lolevel_scm",(void*)f_3250},
{"f_2147:lolevel_scm",(void*)f_2147},
{"f_3240:lolevel_scm",(void*)f_3240},
{"f_2151:lolevel_scm",(void*)f_2151},
{"f_3230:lolevel_scm",(void*)f_3230},
{"f_2155:lolevel_scm",(void*)f_2155},
{"f_3220:lolevel_scm",(void*)f_3220},
{"f_2159:lolevel_scm",(void*)f_2159},
{"f_3210:lolevel_scm",(void*)f_3210},
{"f_2163:lolevel_scm",(void*)f_2163},
{"f_3200:lolevel_scm",(void*)f_3200},
{"f_2167:lolevel_scm",(void*)f_2167},
{"f_2291:lolevel_scm",(void*)f_2291},
{"f_3176:lolevel_scm",(void*)f_3176},
{"f_3180:lolevel_scm",(void*)f_3180},
{"f_3183:lolevel_scm",(void*)f_3183},
{"f_2438:lolevel_scm",(void*)f_2438},
{"f_3163:lolevel_scm",(void*)f_3163},
{"f_3154:lolevel_scm",(void*)f_3154},
{"f_3145:lolevel_scm",(void*)f_3145},
{"f_3139:lolevel_scm",(void*)f_3139},
{"f_3122:lolevel_scm",(void*)f_3122},
{"f_3109:lolevel_scm",(void*)f_3109},
{"f_3113:lolevel_scm",(void*)f_3113},
{"f_3116:lolevel_scm",(void*)f_3116},
{"f_3077:lolevel_scm",(void*)f_3077},
{"f_3081:lolevel_scm",(void*)f_3081},
{"f_3084:lolevel_scm",(void*)f_3084},
{"f_3091:lolevel_scm",(void*)f_3091},
{"f_3106:lolevel_scm",(void*)f_3106},
{"f_3094:lolevel_scm",(void*)f_3094},
{"f_3068:lolevel_scm",(void*)f_3068},
{"f_1100:lolevel_scm",(void*)f_1100},
{"f_1122:lolevel_scm",(void*)f_1122},
{"f_1125:lolevel_scm",(void*)f_1125},
{"f_3072:lolevel_scm",(void*)f_3072},
{"f_2939:lolevel_scm",(void*)f_2939},
{"f_2943:lolevel_scm",(void*)f_2943},
{"f_2946:lolevel_scm",(void*)f_2946},
{"f_2951:lolevel_scm",(void*)f_2951},
{"f_2967:lolevel_scm",(void*)f_2967},
{"f_3010:lolevel_scm",(void*)f_3010},
{"f_3013:lolevel_scm",(void*)f_3013},
{"f_3022:lolevel_scm",(void*)f_3022},
{"f_3043:lolevel_scm",(void*)f_3043},
{"f_3016:lolevel_scm",(void*)f_3016},
{"f_2996:lolevel_scm",(void*)f_2996},
{"f_2999:lolevel_scm",(void*)f_2999},
{"f_2980:lolevel_scm",(void*)f_2980},
{"f_2983:lolevel_scm",(void*)f_2983},
{"f_2855:lolevel_scm",(void*)f_2855},
{"f_2859:lolevel_scm",(void*)f_2859},
{"f_2864:lolevel_scm",(void*)f_2864},
{"f_2877:lolevel_scm",(void*)f_2877},
{"f_2934:lolevel_scm",(void*)f_2934},
{"f_2883:lolevel_scm",(void*)f_2883},
{"f_2886:lolevel_scm",(void*)f_2886},
{"f_2896:lolevel_scm",(void*)f_2896},
{"f_2898:lolevel_scm",(void*)f_2898},
{"f_2920:lolevel_scm",(void*)f_2920},
{"f_2889:lolevel_scm",(void*)f_2889},
{"f_2763:lolevel_scm",(void*)f_2763},
{"f_2772:lolevel_scm",(void*)f_2772},
{"f_2817:lolevel_scm",(void*)f_2817},
{"f_2827:lolevel_scm",(void*)f_2827},
{"f3599:lolevel_scm",(void*)f3599},
{"f_2801:lolevel_scm",(void*)f_2801},
{"f_2808:lolevel_scm",(void*)f_2808},
{"f_2845:lolevel_scm",(void*)f_2845},
{"f_2599:lolevel_scm",(void*)f_2599},
{"f_2603:lolevel_scm",(void*)f_2603},
{"f_2606:lolevel_scm",(void*)f_2606},
{"f_2752:lolevel_scm",(void*)f_2752},
{"f_2609:lolevel_scm",(void*)f_2609},
{"f_2612:lolevel_scm",(void*)f_2612},
{"f_2620:lolevel_scm",(void*)f_2620},
{"f_2630:lolevel_scm",(void*)f_2630},
{"f_2745:lolevel_scm",(void*)f_2745},
{"f_2639:lolevel_scm",(void*)f_2639},
{"f_2733:lolevel_scm",(void*)f_2733},
{"f_2737:lolevel_scm",(void*)f_2737},
{"f_2729:lolevel_scm",(void*)f_2729},
{"f_2642:lolevel_scm",(void*)f_2642},
{"f_2645:lolevel_scm",(void*)f_2645},
{"f_2702:lolevel_scm",(void*)f_2702},
{"f_2648:lolevel_scm",(void*)f_2648},
{"f_2651:lolevel_scm",(void*)f_2651},
{"f_2661:lolevel_scm",(void*)f_2661},
{"f_2663:lolevel_scm",(void*)f_2663},
{"f_2684:lolevel_scm",(void*)f_2684},
{"f_2654:lolevel_scm",(void*)f_2654},
{"f_2615:lolevel_scm",(void*)f_2615},
{"f_2481:lolevel_scm",(void*)f_2481},
{"f_2488:lolevel_scm",(void*)f_2488},
{"f_2491:lolevel_scm",(void*)f_2491},
{"f_2496:lolevel_scm",(void*)f_2496},
{"f_2506:lolevel_scm",(void*)f_2506},
{"f_2515:lolevel_scm",(void*)f_2515},
{"f_2519:lolevel_scm",(void*)f_2519},
{"f_2522:lolevel_scm",(void*)f_2522},
{"f_2525:lolevel_scm",(void*)f_2525},
{"f_2535:lolevel_scm",(void*)f_2535},
{"f_2537:lolevel_scm",(void*)f_2537},
{"f_2558:lolevel_scm",(void*)f_2558},
{"f_2528:lolevel_scm",(void*)f_2528},
{"f_2592:lolevel_scm",(void*)f_2592},
{"f_2478:lolevel_scm",(void*)f_2478},
{"f_2440:lolevel_scm",(void*)f_2440},
{"f_2444:lolevel_scm",(void*)f_2444},
{"f_2450:lolevel_scm",(void*)f_2450},
{"f_2455:lolevel_scm",(void*)f_2455},
{"f_2412:lolevel_scm",(void*)f_2412},
{"f_2416:lolevel_scm",(void*)f_2416},
{"f_2419:lolevel_scm",(void*)f_2419},
{"f_2399:lolevel_scm",(void*)f_2399},
{"f_2403:lolevel_scm",(void*)f_2403},
{"f_2390:lolevel_scm",(void*)f_2390},
{"f_2394:lolevel_scm",(void*)f_2394},
{"f_2346:lolevel_scm",(void*)f_2346},
{"f_2350:lolevel_scm",(void*)f_2350},
{"f_2337:lolevel_scm",(void*)f_2337},
{"f_2315:lolevel_scm",(void*)f_2315},
{"f_2306:lolevel_scm",(void*)f_2306},
{"f_1174:lolevel_scm",(void*)f_1174},
{"f_2310:lolevel_scm",(void*)f_2310},
{"f_2293:lolevel_scm",(void*)f_2293},
{"f_2273:lolevel_scm",(void*)f_2273},
{"f_2277:lolevel_scm",(void*)f_2277},
{"f_2239:lolevel_scm",(void*)f_2239},
{"f_2257:lolevel_scm",(void*)f_2257},
{"f_2249:lolevel_scm",(void*)f_2249},
{"f_2208:lolevel_scm",(void*)f_2208},
{"f_2223:lolevel_scm",(void*)f_2223},
{"f_2221:lolevel_scm",(void*)f_2221},
{"f_2173:lolevel_scm",(void*)f_2173},
{"f_2177:lolevel_scm",(void*)f_2177},
{"f_2198:lolevel_scm",(void*)f_2198},
{"f_2182:lolevel_scm",(void*)f_2182},
{"f_2123:lolevel_scm",(void*)f_2123},
{"f_2109:lolevel_scm",(void*)f_2109},
{"f_2095:lolevel_scm",(void*)f_2095},
{"f_2081:lolevel_scm",(void*)f_2081},
{"f_2067:lolevel_scm",(void*)f_2067},
{"f_2053:lolevel_scm",(void*)f_2053},
{"f_2039:lolevel_scm",(void*)f_2039},
{"f_2025:lolevel_scm",(void*)f_2025},
{"f_2019:lolevel_scm",(void*)f_2019},
{"f_2016:lolevel_scm",(void*)f_2016},
{"f_2009:lolevel_scm",(void*)f_2009},
{"f_1980:lolevel_scm",(void*)f_1980},
{"f_1988:lolevel_scm",(void*)f_1988},
{"f_1951:lolevel_scm",(void*)f_1951},
{"f_1959:lolevel_scm",(void*)f_1959},
{"f_1933:lolevel_scm",(void*)f_1933},
{"f_1889:lolevel_scm",(void*)f_1889},
{"f_1893:lolevel_scm",(void*)f_1893},
{"f_1874:lolevel_scm",(void*)f_1874},
{"f_1878:lolevel_scm",(void*)f_1878},
{"f_1881:lolevel_scm",(void*)f_1881},
{"f_1842:lolevel_scm",(void*)f_1842},
{"f_1869:lolevel_scm",(void*)f_1869},
{"f_1822:lolevel_scm",(void*)f_1822},
{"f_1813:lolevel_scm",(void*)f_1813},
{"f_1817:lolevel_scm",(void*)f_1817},
{"f_1820:lolevel_scm",(void*)f_1820},
{"f_1807:lolevel_scm",(void*)f_1807},
{"f_1811:lolevel_scm",(void*)f_1811},
{"f_1801:lolevel_scm",(void*)f_1801},
{"f_1788:lolevel_scm",(void*)f_1788},
{"f_1792:lolevel_scm",(void*)f_1792},
{"f_1799:lolevel_scm",(void*)f_1799},
{"f_1778:lolevel_scm",(void*)f_1778},
{"f_1782:lolevel_scm",(void*)f_1782},
{"f_1769:lolevel_scm",(void*)f_1769},
{"f_1773:lolevel_scm",(void*)f_1773},
{"f_1763:lolevel_scm",(void*)f_1763},
{"f_1757:lolevel_scm",(void*)f_1757},
{"f_1747:lolevel_scm",(void*)f_1747},
{"f_1740:lolevel_scm",(void*)f_1740},
{"f_1659:lolevel_scm",(void*)f_1659},
{"f_1665:lolevel_scm",(void*)f_1665},
{"f_1695:lolevel_scm",(void*)f_1695},
{"f_1710:lolevel_scm",(void*)f_1710},
{"f_1731:lolevel_scm",(void*)f_1731},
{"f_1698:lolevel_scm",(void*)f_1698},
{"f_1335:lolevel_scm",(void*)f_1335},
{"f_1596:lolevel_scm",(void*)f_1596},
{"f_1591:lolevel_scm",(void*)f_1591},
{"f_1586:lolevel_scm",(void*)f_1586},
{"f_1337:lolevel_scm",(void*)f_1337},
{"f_1395:lolevel_scm",(void*)f_1395},
{"f_1398:lolevel_scm",(void*)f_1398},
{"f_1403:lolevel_scm",(void*)f_1403},
{"f_1523:lolevel_scm",(void*)f_1523},
{"f_1555:lolevel_scm",(void*)f_1555},
{"f_1565:lolevel_scm",(void*)f_1565},
{"f_1545:lolevel_scm",(void*)f_1545},
{"f_1490:lolevel_scm",(void*)f_1490},
{"f_1504:lolevel_scm",(void*)f_1504},
{"f_1500:lolevel_scm",(void*)f_1500},
{"f_1481:lolevel_scm",(void*)f_1481},
{"f_1368:lolevel_scm",(void*)f_1368},
{"f_1375:lolevel_scm",(void*)f_1375},
{"f_1352:lolevel_scm",(void*)f_1352},
{"f_1346:lolevel_scm",(void*)f_1346},
{"f_1340:lolevel_scm",(void*)f_1340},
{"f_1196:lolevel_scm",(void*)f_1196},
{"f_1145:lolevel_scm",(void*)f_1145},
{"f_1072:lolevel_scm",(void*)f_1072},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
