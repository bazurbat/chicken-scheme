/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-28 22:52
   Version 4.1.4 - SVN rev. 15427
   linux-unix-gnu-x86 [ ptables applyhook ]
   compiled 2009-08-13 on x (Linux)
   command line: srfi-69.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature debugbuild -scrutinize -types ./types.db -explicit-use -no-trace -output-file srfi-69.c -extend ./private-namespace.scm
   unit: srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[115];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,110,117,109,98,101,114,45,104,97,115,104,45,104,111,111,107,32,111,98,106,54,52,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,29),40,110,117,109,98,101,114,45,104,97,115,104,32,111,98,106,55,52,32,46,32,116,109,112,55,51,55,53,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,36),40,111,98,106,101,99,116,45,117,105,100,45,104,97,115,104,32,111,98,106,49,51,54,32,46,32,116,109,112,49,51,53,49,51,55,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,32),40,115,121,109,98,111,108,45,104,97,115,104,32,111,98,106,49,53,57,32,46,32,116,109,112,49,53,56,49,54,48,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,99,104,101,99,107,45,107,101,121,119,111,114,100,32,120,49,55,55,32,46,32,121,49,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,33),40,107,101,121,119,111,114,100,45,104,97,115,104,32,111,98,106,49,57,49,32,46,32,116,109,112,49,57,48,49,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,101,113,63,45,104,97,115,104,32,111,98,106,50,50,56,32,46,32,116,109,112,50,50,55,50,50,57,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,30),40,101,113,118,63,45,104,97,115,104,32,111,98,106,50,57,49,32,46,32,116,109,112,50,57,48,50,57,50,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,104,115,104,51,50,49,32,105,51,50,50,32,108,101,110,51,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,46),40,118,101,99,116,111,114,45,104,97,115,104,32,111,98,106,51,49,53,32,115,101,101,100,51,49,54,32,100,101,112,116,104,51,49,55,32,115,116,97,114,116,51,49,56,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,39),40,114,101,99,117,114,115,105,118,101,45,97,116,111,109,105,99,45,104,97,115,104,32,111,98,106,51,50,53,32,100,101,112,116,104,51,50,54,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,32),40,114,101,99,117,114,115,105,118,101,45,104,97,115,104,32,111,98,106,51,52,54,32,100,101,112,116,104,51,52,55,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,21),40,42,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,51,49,49,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,32),40,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,52,48,53,32,46,32,116,109,112,52,48,52,52,48,54,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,52,52,52,32,115,116,97,114,116,52,53,51,32,101,110,100,52,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,110,100,52,52,55,32,37,115,116,97,114,116,52,52,50,52,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,115,116,97,114,116,52,52,54,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,104,97,115,104,32,115,116,114,52,50,54,32,46,32,116,109,112,52,50,53,52,50,55,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,52,57,56,32,115,116,97,114,116,53,48,55,32,101,110,100,53,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,110,100,53,48,49,32,37,115,116,97,114,116,52,57,54,53,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,115,116,97,114,116,53,48,48,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,35),40,115,116,114,105,110,103,45,99,105,45,104,97,115,104,32,115,116,114,52,56,48,32,46,32,116,109,112,52,55,57,52,56,49,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,43),40,104,97,115,104,45,116,97,98,108,101,45,99,97,110,111,110,105,99,97,108,45,108,101,110,103,116,104,32,116,97,98,53,52,49,32,114,101,113,53,52,50,41,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,86),40,42,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,116,101,115,116,53,54,48,32,104,97,115,104,53,54,49,32,108,101,110,53,54,50,32,109,105,110,45,108,111,97,100,53,54,51,32,109,97,120,45,108,111,97,100,53,54,52,32,105,110,105,116,105,97,108,53,54,55,32,116,109,112,53,53,57,53,54,56,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,19),40,105,110,118,97,114,103,45,101,114,114,32,109,115,103,54,53,55,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,8),40,102,95,50,56,52,49,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,97,114,103,115,54,53,50,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,46,32,97,114,103,117,109,101,110,116,115,48,53,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,20),40,104,97,115,104,45,116,97,98,108,101,63,32,111,98,106,55,48,52,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,115,105,122,101,32,104,116,55,48,54,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,39),40,104,97,115,104,45,116,97,98,108,101,45,101,113,117,105,118,97,108,101,110,99,101,45,102,117,110,99,116,105,111,110,32,104,116,55,48,57,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,104,45,102,117,110,99,116,105,111,110,32,104,116,55,49,50,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,105,110,45,108,111,97,100,32,104,116,55,49,53,41,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,97,120,45,108,111,97,100,32,104,116,55,49,56,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,28),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,107,101,121,115,32,104,116,55,50,49,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,30),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,118,97,108,117,101,115,32,104,116,55,50,52,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,31),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,45,105,110,105,116,105,97,108,63,32,104,116,55,50,55,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,105,110,105,116,105,97,108,32,104,116,55,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,55,53,48,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,52,52,32,105,55,52,56,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,40),40,104,97,115,104,45,116,97,98,108,101,45,114,101,115,105,122,101,33,32,104,116,55,54,50,32,118,101,99,55,54,51,32,108,101,110,55,54,52,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,21),40,99,111,112,121,45,108,111,111,112,32,98,117,99,107,101,116,55,56,51,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,55,55,32,105,55,56,49,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,24),40,42,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,55,55,50,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,55,56,57,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,56,51,56,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,56,52,55,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,56,48,54,32,102,117,110,99,56,49,53,32,116,104,117,110,107,56,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,8),40,102,95,51,53,54,48,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,116,104,117,110,107,56,48,57,32,37,102,117,110,99,56,48,52,56,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,102,117,110,99,56,48,56,41,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,45),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,32,104,116,55,57,56,32,107,101,121,55,57,57,32,46,32,116,109,112,55,57,55,56,48,48,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,56,57,56,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,48,55,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,57),40,42,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,56,55,51,32,107,101,121,56,55,52,32,102,117,110,99,56,55,53,32,100,101,102,56,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,56),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,57,49,55,32,107,101,121,57,49,56,32,102,117,110,99,57,49,57,32,100,101,102,57,50,48,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,52,56,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,53,51,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,37),40,104,97,115,104,45,116,97,98,108,101,45,115,101,116,33,32,104,116,57,50,52,32,107,101,121,57,50,53,32,118,97,108,57,50,54,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,44),40,104,97,115,104,45,116,97,98,108,101,45,114,101,102,47,100,101,102,97,117,108,116,32,104,116,57,57,49,32,107,101,121,57,57,50,32,100,101,102,57,57,51,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,101,120,105,115,116,115,63,32,104,116,49,48,48,57,32,107,101,121,49,48,49,48,41,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,48,54,49,32,98,117,99,107,101,116,49,48,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,100,101,108,101,116,101,33,32,104,116,49,48,52,48,32,107,101,121,49,48,52,49,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,48,56,52,32,98,117,99,107,101,116,49,48,56,53,41,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,48,55,56,32,105,49,48,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,36),40,104,97,115,104,45,116,97,98,108,101,45,114,101,109,111,118,101,33,32,104,116,49,48,55,50,32,102,117,110,99,49,48,55,51,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,99,108,101,97,114,33,32,104,116,49,48,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,20),40,100,111,108,111,111,112,49,49,49,50,32,108,115,116,49,49,49,54,41,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,49,48,55,32,105,49,49,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,36),40,42,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,49,48,50,32,104,116,50,49,49,48,51,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,49,50,51,32,104,116,50,49,49,50,52,41,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,34),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,32,104,116,49,49,49,50,56,32,104,116,50,49,49,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,49,52,49,32,108,115,116,49,49,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,49,51,56,32,108,115,116,49,49,51,57,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,62,97,108,105,115,116,32,104,116,49,49,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,49,49,53,51,32,108,115,116,49,49,53,52,49,49,53,55,41,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,40),40,97,108,105,115,116,45,62,104,97,115,104,45,116,97,98,108,101,32,97,108,105,115,116,49,49,52,56,32,46,32,114,101,115,116,49,49,52,57,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,49,55,51,32,108,115,116,49,49,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,49,55,48,32,108,115,116,49,49,55,49,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,24),40,104,97,115,104,45,116,97,98,108,101,45,107,101,121,115,32,104,116,49,49,54,53,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,49,56,56,32,108,115,116,49,49,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,49,56,53,32,108,115,116,49,49,56,54,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,118,97,108,117,101,115,32,104,116,49,49,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,49,50,48,55,32,108,115,116,49,50,48,56,49,50,49,49,41,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,50,48,48,32,105,49,50,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,38),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,49,57,53,32,112,114,111,99,49,49,57,54,41,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,26),40,102,111,108,100,50,32,98,117,99,107,101,116,49,50,50,56,32,97,99,99,49,50,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,50,50,53,32,97,99,99,49,50,50,54,41,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,43),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,50,49,56,32,102,117,110,99,49,50,49,57,32,105,110,105,116,49,50,50,48,41,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,42),40,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,50,51,52,32,102,117,110,99,49,50,51,53,32,105,110,105,116,49,50,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,37),40,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,50,52,48,32,112,114,111,99,49,50,52,49,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,33),40,104,97,115,104,45,116,97,98,108,101,45,119,97,108,107,32,104,116,49,50,52,53,32,112,114,111,99,49,50,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,25),40,97,53,48,48,53,32,107,49,50,53,50,32,118,49,50,53,51,32,97,49,50,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,109,97,112,32,104,116,49,50,53,48,32,102,117,110,99,49,50,53,49,41};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,56,49,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,56,53,41};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,8),40,102,95,53,49,51,54,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,32),40,97,53,48,49,53,32,104,116,57,54,55,32,107,101,121,57,54,56,32,46,32,116,109,112,57,54,54,57,54,57,41};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_69_toplevel)
C_externexport void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_fcall f_5053(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_fcall f_4892(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4904)
static void C_fcall f_4904(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4920)
static void C_fcall f_4920(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_fcall f_4827(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4839)
static void C_fcall f_4839(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4862)
static void C_fcall f_4862(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4777)
static void C_fcall f_4777(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4793)
static void C_fcall f_4793(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4712)
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4728)
static void C_fcall f_4728(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4664)
static void C_fcall f_4664(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4594)
static void C_fcall f_4594(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4610)
static void C_fcall f_4610(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4486)
static void C_fcall f_4486(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4498)
static void C_fcall f_4498(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4521)
static void C_fcall f_4521(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4374)
static void C_ccall f_4374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4381)
static void C_ccall f_4381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_fcall f_4395(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4421)
static void C_fcall f_4421(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_fcall f_4326(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static C_word C_fcall f_4279(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4206)
static void C_fcall f_4206(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4166)
static C_word C_fcall f_4166(C_word t0,C_word t1);
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_fcall f_4099(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static C_word C_fcall f_4060(C_word t0,C_word t1);
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_fcall f_3941(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3892)
static void C_fcall f_3892(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_fcall f_3613(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3810)
static void C_ccall f_3810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_fcall f_3726(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3736)
static void C_ccall f_3736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_fcall f_3667(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3565)
static void C_fcall f_3565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3548)
static void C_fcall f_3548(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_fcall f_3325(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_fcall f_3451(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_fcall f_3388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3202)
static void C_fcall f_3202(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_fcall f_3217(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3279)
static void C_fcall f_3279(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3300)
static void C_ccall f_3300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_fcall f_3109(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3132)
static void C_fcall f_3132(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_fcall f_2716(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_fcall f_2719(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_fcall f_2722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_fcall f_2757(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_fcall f_2768(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static C_word C_fcall f_2640(C_word t0);
C_noret_decl(f_2607)
static void C_fcall f_2607(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2583)
static C_word C_fcall f_2583(C_word t0,C_word t1);
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2515)
static void C_fcall f_2515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_fcall f_2506(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2487)
static void C_fcall f_2487(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2390)
static void C_fcall f_2390(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_fcall f_2381(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2362)
static void C_fcall f_2362(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_fcall f_1942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_fcall f_2010(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2026)
static void C_fcall f_2026(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_fcall f_1945(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1962)
static void C_fcall f_1962(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1703)
static void C_ccall f_1703r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1344)
static void C_fcall f_1344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_5095)
static void C_fcall trf_5095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5095(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5095(t0,t1,t2);}

C_noret_decl(trf_5053)
static void C_fcall trf_5053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5053(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5053(t0,t1,t2);}

C_noret_decl(trf_4892)
static void C_fcall trf_4892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4892(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4892(t0,t1,t2,t3);}

C_noret_decl(trf_4904)
static void C_fcall trf_4904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4904(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4904(t0,t1,t2,t3);}

C_noret_decl(trf_4920)
static void C_fcall trf_4920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4920(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4920(t0,t1,t2,t3);}

C_noret_decl(trf_4827)
static void C_fcall trf_4827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4827(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4827(t0,t1,t2);}

C_noret_decl(trf_4839)
static void C_fcall trf_4839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4839(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4839(t0,t1,t2);}

C_noret_decl(trf_4862)
static void C_fcall trf_4862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4862(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4862(t0,t1,t2);}

C_noret_decl(trf_4777)
static void C_fcall trf_4777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4777(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4777(t0,t1,t2,t3);}

C_noret_decl(trf_4793)
static void C_fcall trf_4793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4793(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4793(t0,t1,t2,t3);}

C_noret_decl(trf_4712)
static void C_fcall trf_4712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4712(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4712(t0,t1,t2,t3);}

C_noret_decl(trf_4728)
static void C_fcall trf_4728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4728(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4728(t0,t1,t2,t3);}

C_noret_decl(trf_4664)
static void C_fcall trf_4664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4664(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4664(t0,t1,t2);}

C_noret_decl(trf_4594)
static void C_fcall trf_4594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4594(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4594(t0,t1,t2,t3);}

C_noret_decl(trf_4610)
static void C_fcall trf_4610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4610(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4610(t0,t1,t2,t3);}

C_noret_decl(trf_4486)
static void C_fcall trf_4486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4486(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4486(t0,t1,t2);}

C_noret_decl(trf_4498)
static void C_fcall trf_4498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4498(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4498(t0,t1,t2);}

C_noret_decl(trf_4521)
static void C_fcall trf_4521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4521(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4521(t0,t1,t2);}

C_noret_decl(trf_4395)
static void C_fcall trf_4395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4395(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4395(t0,t1,t2);}

C_noret_decl(trf_4421)
static void C_fcall trf_4421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4421(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4421(t0,t1,t2,t3);}

C_noret_decl(trf_4326)
static void C_fcall trf_4326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4326(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4326(t0,t1,t2,t3);}

C_noret_decl(trf_4206)
static void C_fcall trf_4206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4206(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4206(t0,t1,t2);}

C_noret_decl(trf_4099)
static void C_fcall trf_4099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4099(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4099(t0,t1,t2);}

C_noret_decl(trf_3941)
static void C_fcall trf_3941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3941(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3941(t0,t1,t2);}

C_noret_decl(trf_3892)
static void C_fcall trf_3892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3892(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3892(t0,t1,t2);}

C_noret_decl(trf_3613)
static void C_fcall trf_3613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3613(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3613(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3726)
static void C_fcall trf_3726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3726(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3726(t0,t1,t2);}

C_noret_decl(trf_3667)
static void C_fcall trf_3667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3667(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3667(t0,t1,t2);}

C_noret_decl(trf_3565)
static void C_fcall trf_3565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3565(t0,t1);}

C_noret_decl(trf_3548)
static void C_fcall trf_3548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3548(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3548(t0,t1,t2);}

C_noret_decl(trf_3325)
static void C_fcall trf_3325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3325(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3325(t0,t1,t2,t3);}

C_noret_decl(trf_3451)
static void C_fcall trf_3451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3451(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3451(t0,t1,t2);}

C_noret_decl(trf_3388)
static void C_fcall trf_3388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3388(t0,t1,t2);}

C_noret_decl(trf_3202)
static void C_fcall trf_3202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3202(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3202(t0,t1,t2);}

C_noret_decl(trf_3217)
static void C_fcall trf_3217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3217(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3217(t0,t1,t2);}

C_noret_decl(trf_3279)
static void C_fcall trf_3279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3279(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3279(t0,t1,t2);}

C_noret_decl(trf_3109)
static void C_fcall trf_3109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3109(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3109(t0,t1,t2);}

C_noret_decl(trf_3132)
static void C_fcall trf_3132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3132(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3132(t0,t1,t2);}

C_noret_decl(trf_2716)
static void C_fcall trf_2716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2716(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2716(t0,t1);}

C_noret_decl(trf_2719)
static void C_fcall trf_2719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2719(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2719(t0,t1);}

C_noret_decl(trf_2722)
static void C_fcall trf_2722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2722(t0,t1);}

C_noret_decl(trf_2757)
static void C_fcall trf_2757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2757(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2757(t0,t1,t2);}

C_noret_decl(trf_2768)
static void C_fcall trf_2768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2768(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2768(t0,t1,t2);}

C_noret_decl(trf_2607)
static void C_fcall trf_2607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2607(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_2607(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_2577)
static void C_fcall trf_2577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2577(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2577(t0,t1,t2);}

C_noret_decl(trf_2515)
static void C_fcall trf_2515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2515(t0,t1);}

C_noret_decl(trf_2506)
static void C_fcall trf_2506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2506(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2506(t0,t1,t2);}

C_noret_decl(trf_2487)
static void C_fcall trf_2487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2487(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2487(t0,t1,t2,t3);}

C_noret_decl(trf_2390)
static void C_fcall trf_2390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2390(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2390(t0,t1);}

C_noret_decl(trf_2381)
static void C_fcall trf_2381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2381(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2381(t0,t1,t2);}

C_noret_decl(trf_2362)
static void C_fcall trf_2362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2362(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2362(t0,t1,t2,t3);}

C_noret_decl(trf_1942)
static void C_fcall trf_1942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1942(t0,t1);}

C_noret_decl(trf_2041)
static void C_fcall trf_2041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2041(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2041(t0,t1,t2,t3);}

C_noret_decl(trf_2010)
static void C_fcall trf_2010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2010(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2010(t0,t1,t2,t3);}

C_noret_decl(trf_2026)
static void C_fcall trf_2026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2026(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2026(t0,t1);}

C_noret_decl(trf_1945)
static void C_fcall trf_1945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1945(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1945(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1962)
static void C_fcall trf_1962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1962(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1962(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1344)
static void C_fcall trf_1344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1344(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(933)){
C_save(t1);
C_rereclaim2(933*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,115);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],20,"\003sysnumber-hash-hook");
lf[4]=C_h_intern(&lf[4],11,"number-hash");
lf[5]=C_h_intern(&lf[5],5,"fxmod");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_h_intern(&lf[7],5,"\000type");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_h_intern(&lf[10],15,"object-uid-hash");
lf[11]=C_h_intern(&lf[11],11,"symbol-hash");
lf[12]=C_h_intern(&lf[12],17,"\003syscheck-keyword");
lf[13]=C_h_intern(&lf[13],11,"\000type-error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[15]=C_h_intern(&lf[15],8,"keyword\077");
lf[16]=C_h_intern(&lf[16],12,"keyword-hash");
lf[17]=C_h_intern(&lf[17],8,"eq\077-hash");
lf[18]=C_h_intern(&lf[18],16,"hash-by-identity");
lf[19]=C_h_intern(&lf[19],9,"eqv\077-hash");
lf[20]=C_h_intern(&lf[20],11,"input-port\077");
lf[21]=C_h_intern(&lf[21],11,"equal\077-hash");
lf[22]=C_h_intern(&lf[22],4,"hash");
lf[23]=C_h_intern(&lf[23],11,"string-hash");
lf[24]=C_h_intern(&lf[24],13,"\003syssubstring");
lf[25]=C_h_intern(&lf[25],15,"\003syscheck-range");
lf[26]=C_h_intern(&lf[26],14,"string-ci-hash");
lf[27]=C_h_intern(&lf[27],14,"string-hash-ci");
lf[29]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[31]=C_h_intern(&lf[31],11,"make-vector");
lf[33]=C_h_intern(&lf[33],10,"hash-table");
lf[34]=C_h_intern(&lf[34],3,"eq\077");
lf[35]=C_h_intern(&lf[35],4,"eqv\077");
lf[36]=C_h_intern(&lf[36],6,"equal\077");
lf[37]=C_h_intern(&lf[37],8,"string=\077");
lf[38]=C_h_intern(&lf[38],11,"string-ci=\077");
lf[39]=C_h_intern(&lf[39],1,"=");
lf[40]=C_h_intern(&lf[40],15,"make-hash-table");
lf[41]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[42]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[43]=C_h_intern(&lf[43],7,"warning");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[45]=C_h_intern(&lf[45],5,"error");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[47]=C_h_intern(&lf[47],5,"\000test");
lf[48]=C_h_intern(&lf[48],17,"\003syscheck-closure");
lf[49]=C_h_intern(&lf[49],5,"\000hash");
lf[50]=C_h_intern(&lf[50],5,"\000size");
lf[51]=C_h_intern(&lf[51],19,"hash-table-max-size");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[53]=C_h_intern(&lf[53],8,"\000initial");
lf[54]=C_h_intern(&lf[54],9,"\000min-load");
lf[55]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[56]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[58]=C_h_intern(&lf[58],17,"\003syscheck-inexact");
lf[59]=C_h_intern(&lf[59],9,"\000max-load");
lf[60]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[61]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[63]=C_h_intern(&lf[63],10,"\000weak-keys");
lf[64]=C_h_intern(&lf[64],12,"\000weak-values");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[69]=C_h_intern(&lf[69],11,"hash-table\077");
lf[70]=C_h_intern(&lf[70],15,"hash-table-size");
lf[71]=C_h_intern(&lf[71],31,"hash-table-equivalence-function");
lf[72]=C_h_intern(&lf[72],24,"hash-table-hash-function");
lf[73]=C_h_intern(&lf[73],19,"hash-table-min-load");
lf[74]=C_h_intern(&lf[74],19,"hash-table-max-load");
lf[75]=C_h_intern(&lf[75],20,"hash-table-weak-keys");
lf[76]=C_h_intern(&lf[76],22,"hash-table-weak-values");
lf[77]=C_h_intern(&lf[77],23,"hash-table-has-initial\077");
lf[78]=C_h_intern(&lf[78],18,"hash-table-initial");
lf[79]=C_h_intern(&lf[79],18,"hash-table-resize!");
lf[81]=C_h_intern(&lf[81],15,"hash-table-copy");
lf[82]=C_h_intern(&lf[82],18,"hash-table-update!");
lf[83]=C_h_intern(&lf[83],5,"floor");
lf[84]=C_h_intern(&lf[84],13,"\000access-error");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[86]=C_h_intern(&lf[86],8,"identity");
lf[88]=C_h_intern(&lf[88],26,"hash-table-update!/default");
lf[89]=C_h_intern(&lf[89],15,"hash-table-set!");
lf[90]=C_h_intern(&lf[90],19,"\003sysundefined-value");
lf[91]=C_h_intern(&lf[91],14,"hash-table-ref");
lf[92]=C_h_intern(&lf[92],22,"hash-table-ref/default");
lf[93]=C_h_intern(&lf[93],18,"hash-table-exists\077");
lf[94]=C_h_intern(&lf[94],18,"hash-table-delete!");
lf[95]=C_h_intern(&lf[95],18,"hash-table-remove!");
lf[96]=C_h_intern(&lf[96],17,"hash-table-clear!");
lf[97]=C_h_intern(&lf[97],12,"vector-fill!");
lf[99]=C_h_intern(&lf[99],17,"hash-table-merge!");
lf[100]=C_h_intern(&lf[100],16,"hash-table-merge");
lf[101]=C_h_intern(&lf[101],17,"hash-table->alist");
lf[102]=C_h_intern(&lf[102],17,"alist->hash-table");
lf[103]=C_h_intern(&lf[103],15,"hash-table-keys");
lf[104]=C_h_intern(&lf[104],17,"hash-table-values");
lf[107]=C_h_intern(&lf[107],15,"hash-table-fold");
lf[108]=C_h_intern(&lf[108],19,"hash-table-for-each");
lf[109]=C_h_intern(&lf[109],15,"hash-table-walk");
lf[110]=C_h_intern(&lf[110],14,"hash-table-map");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[112]=C_h_intern(&lf[112],18,"getter-with-setter");
lf[113]=C_h_intern(&lf[113],17,"register-feature!");
lf[114]=C_h_intern(&lf[114],7,"srfi-69");
C_register_lf2(lf,115,create_ptable());
t2=C_mutate(&lf[0] /* (set! c81 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1323,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 65   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),t3,lf[114]);}

/* k1321 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[114],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! number-hash-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1325,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[4]+1 /* (set! number-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[10]+1 /* (set! object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1467,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[11]+1 /* (set! symbol-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1515,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[12]+1 /* (set! check-keyword ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1566,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[16]+1 /* (set! keyword-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1592,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[17]+1 /* (set! eq?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1703,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[18]+1 /* (set! hash-by-identity ...) */,*((C_word*)lf[17]+1));
t10=C_mutate((C_word*)lf[19]+1 /* (set! eqv?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[3] /* (set! *equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1942,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[21]+1 /* (set! equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[22]+1 /* (set! hash ...) */,*((C_word*)lf[21]+1));
t14=C_mutate((C_word*)lf[23]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2325,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[26]+1 /* (set! string-ci-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2450,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[27]+1 /* (set! string-hash-ci ...) */,*((C_word*)lf[26]+1));
t17=C_mutate(&lf[28] /* (set! constant539 ...) */,lf[29]);
t18=C_mutate(&lf[30] /* (set! hash-table-canonical-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2577,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t19=*((C_word*)lf[31]+1);
t20=C_mutate(&lf[32] /* (set! *make-hash-table ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2607,a[2]=t19,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp));
t21=*((C_word*)lf[34]+1);
t22=*((C_word*)lf[35]+1);
t23=*((C_word*)lf[36]+1);
t24=*((C_word*)lf[37]+1);
t25=*((C_word*)lf[38]+1);
t26=*((C_word*)lf[39]+1);
t27=C_mutate((C_word*)lf[40]+1 /* (set! make-hash-table ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2638,a[2]=t26,a[3]=t25,a[4]=t24,a[5]=t23,a[6]=t22,a[7]=t21,a[8]=((C_word)li28),tmp=(C_word)a,a+=9,tmp));
t28=C_mutate((C_word*)lf[69]+1 /* (set! hash-table? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3001,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[70]+1 /* (set! hash-table-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3007,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[71]+1 /* (set! hash-table-equivalence-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3016,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[72]+1 /* (set! hash-table-hash-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[73]+1 /* (set! hash-table-min-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3034,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[74]+1 /* (set! hash-table-max-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3043,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[75]+1 /* (set! hash-table-weak-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[76]+1 /* (set! hash-table-weak-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3061,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[77]+1 /* (set! hash-table-has-initial? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3070,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[78]+1 /* (set! hash-table-initial ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[79]+1 /* (set! hash-table-resize! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3176,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t39=*((C_word*)lf[31]+1);
t40=C_mutate(&lf[80] /* (set! *hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3202,a[2]=t39,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t41=C_mutate((C_word*)lf[81]+1 /* (set! hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3314,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t42=*((C_word*)lf[34]+1);
t43=C_mutate((C_word*)lf[82]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3323,a[2]=t42,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp));
t44=*((C_word*)lf[34]+1);
t45=C_mutate(&lf[87] /* (set! *hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3613,a[2]=t44,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[88]+1 /* (set! hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3820,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t47=*((C_word*)lf[34]+1);
t48=C_mutate((C_word*)lf[89]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3832,a[2]=t47,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp));
t49=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t50=*((C_word*)lf[34]+1);
t51=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5016,a[2]=t50,a[3]=((C_word)li103),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 808  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t49,t51,*((C_word*)lf[89]+1));}

/* a5015 in k1321 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_5016r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5016r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5016r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5020,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5020(2,t6,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5136,a[2]=t2,a[3]=t3,a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5020(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* f_5136 in a5015 in k1321 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5136,2,t0,t1);}
/* srfi-69.scm: 811  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[84],lf[91],lf[111],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5018 in a5015 in k1321 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5020,2,t0,t1);}
t2=(C_word)C_i_check_structure_2(((C_word*)t0)[5],lf[33],lf[91]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 815  ##sys#check-closure */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[91]);}

/* k5024 in k5018 in a5015 in k1321 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5026,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(4));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_block_size(t2);
/* srfi-69.scm: 819  hash */
t7=t4;
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[3],t6);}

/* k5036 in k5024 in k5018 in a5015 in k1321 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5038,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5053,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5053(t7,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5095,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word)li101),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_5095(t7,((C_word*)t0)[2],t3);}}

/* loop in k5036 in k5024 in k5018 in a5015 in k1321 */
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5095,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 832  def */
t3=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5114,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 834  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k5112 in loop in k5036 in k5024 in k5018 in a5015 in k1321 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 836  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5095(t3,((C_word*)t0)[5],t2);}}

/* loop in k5036 in k5024 in k5018 in a5015 in k1321 */
static void C_fcall f_5053(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5053,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 824  def */
t3=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 828  loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4025 in k1321 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[58],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4027,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! hash-table-ref ...) */,t1);
t3=*((C_word*)lf[34]+1);
t4=C_mutate((C_word*)lf[92]+1 /* (set! hash-table-ref/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4029,a[2]=t3,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[34]+1);
t6=C_mutate((C_word*)lf[93]+1 /* (set! hash-table-exists? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4135,a[2]=t5,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[34]+1);
t8=C_mutate((C_word*)lf[94]+1 /* (set! hash-table-delete! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4243,a[2]=t7,a[3]=((C_word)li68),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[95]+1 /* (set! hash-table-remove! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4374,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[96]+1 /* (set! hash-table-clear! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4470,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[98] /* (set! *hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4486,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[99]+1 /* (set! hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4551,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[100]+1 /* (set! hash-table-merge ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4563,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[101]+1 /* (set! hash-table->alist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4579,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[40]+1);
t16=C_mutate((C_word*)lf[102]+1 /* (set! alist->hash-table ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4652,a[2]=t15,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[103]+1 /* (set! hash-table-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4697,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[104]+1 /* (set! hash-table-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4762,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[105] /* (set! *hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4827,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[106] /* (set! *hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4892,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[107]+1 /* (set! hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4958,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[108]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4970,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[109]+1 /* (set! hash-table-walk ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4982,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[110]+1 /* (set! hash-table-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4994,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t25=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,C_SCHEME_UNDEFINED);}

/* hash-table-map in k4025 in k1321 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4994,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[110]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5001,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1088 ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[110]);}

/* k4999 in hash-table-map in k4025 in k1321 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5006,a[2]=((C_word*)t0)[4],a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1089 *hash-table-fold */
f_4892(((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a5005 in k4999 in hash-table-map in k4025 in k1321 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5006,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5014,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1089 func */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k5012 in a5005 in k4999 in hash-table-map in k4025 in k1321 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5014,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k4025 in k1321 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4982,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[109]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4989,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1083 ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[109]);}

/* k4987 in hash-table-walk in k4025 in k1321 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1084 *hash-table-for-each */
f_4827(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k4025 in k1321 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4970,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[108]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4977,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1078 ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[108]);}

/* k4975 in hash-table-for-each in k4025 in k1321 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1079 *hash-table-for-each */
f_4827(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k4025 in k1321 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4958,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[33],lf[107]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4965,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 1073 ##sys#check-closure */
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[107]);}

/* k4963 in hash-table-fold in k4025 in k1321 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1074 *hash-table-fold */
f_4892(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-fold in k4025 in k1321 */
static void C_fcall f_4892(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4892,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4904,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,a[6]=((C_word)li93),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_4904(t10,t1,C_fix(0),t4);}

/* loop in *hash-table-fold in k4025 in k1321 */
static void C_fcall f_4904(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4904,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4920,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word)li92),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_4920(t8,t1,t4,t3);}}

/* fold2 in loop in *hash-table-fold in k4025 in k1321 */
static void C_fcall f_4920(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4920,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 1066 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4904(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4948,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 1069 func */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t6,t7,t8,t3);}}

/* k4946 in fold2 in loop in *hash-table-fold in k4025 in k1321 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1068 fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4920(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* *hash-table-for-each in k4025 in k1321 */
static void C_fcall f_4827(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4827,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4839,a[2]=t3,a[3]=t4,a[4]=t7,a[5]=t5,a[6]=((C_word)li90),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_4839(t9,t1,C_fix(0));}

/* doloop1200 in *hash-table-for-each in k4025 in k1321 */
static void C_fcall f_4839(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4839,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4849,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4862,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word)li89),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4862(t8,t3,t4);}}

/* loop1207 in doloop1200 in *hash-table-for-each in k4025 in k1321 */
static void C_fcall f_4862(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4862,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4875,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 1054 proc */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4873 in loop1207 in doloop1200 in *hash-table-for-each in k4025 in k1321 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4862(t3,((C_word*)t0)[2],t2);}

/* k4847 in doloop1200 in *hash-table-for-each in k4025 in k1321 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4839(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k4025 in k1321 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4762,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[104]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4777,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li87),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4777(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k4025 in k1321 */
static void C_fcall f_4777(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4777,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4793,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li86),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4793(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k4025 in k1321 */
static void C_fcall f_4793(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4793,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1036 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4777(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1037 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k4025 in k1321 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4697,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[103]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4712,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4712(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k4025 in k1321 */
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4712,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4728,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4728(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k4025 in k1321 */
static void C_fcall f_4728(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4728,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1021 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4712(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1022 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k4025 in k1321 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4652r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4652r(t0,t1,t2,t3);}}

static void C_ccall f_4652r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_list_2(t2,lf[102]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4659,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,((C_word*)t0)[2],t3);}

/* k4657 in alist->hash-table in k4025 in k1321 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4662,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4664,a[2]=t1,a[3]=t4,a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4664(t6,t2,((C_word*)t0)[2]);}

/* loop1153 in k4657 in alist->hash-table in k4025 in k1321 */
static void C_fcall f_4664(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4664,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_check_pair_2(t3,lf[102]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4680,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 1005 *hash-table-update!/default */
t8=lf[87];
f_3613(t8,t5,((C_word*)t0)[2],t6,*((C_word*)lf[86]+1),t7);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4678 in loop1153 in k4657 in alist->hash-table in k4025 in k1321 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4664(t3,((C_word*)t0)[2],t2);}

/* k4660 in k4657 in alist->hash-table in k4025 in k1321 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k4025 in k1321 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4579,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[101]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4594,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li79),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4594(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k4025 in k1321 */
static void C_fcall f_4594(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4594,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4610,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li78),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4610(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k4025 in k1321 */
static void C_fcall f_4610(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4610,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 992  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4594(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm: 993  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k4025 in k1321 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4563,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[100]);
t5=(C_word)C_i_check_structure_2(t3,lf[33],lf[100]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4577,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 978  *hash-table-copy */
t7=lf[80];
f_3202(t7,t6,t2);}

/* k4575 in hash-table-merge in k4025 in k1321 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 978  *hash-table-merge! */
f_4486(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k4025 in k1321 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4551,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[99]);
t5=(C_word)C_i_check_structure_2(t3,lf[33],lf[99]);
/* srfi-69.scm: 973  *hash-table-merge! */
f_4486(t1,t2,t3);}

/* *hash-table-merge! in k4025 in k1321 */
static void C_fcall f_4486(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4486,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4498,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=((C_word)li74),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_4498(t9,t1,C_fix(0));}

/* doloop1107 in *hash-table-merge! in k4025 in k1321 */
static void C_fcall f_4498(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4498,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=((C_word*)t0)[4];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4508,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4521(t8,t3,t4);}}

/* doloop1112 in doloop1107 in *hash-table-merge! in k4025 in k1321 */
static void C_fcall f_4521(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4521,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4534,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 968  *hash-table-update!/default */
t7=lf[87];
f_3613(t7,t4,((C_word*)t0)[2],t5,*((C_word*)lf[86]+1),t6);}}

/* k4532 in doloop1112 in doloop1107 in *hash-table-merge! in k4025 in k1321 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4521(t3,((C_word*)t0)[2],t2);}

/* k4506 in doloop1107 in *hash-table-merge! in k4025 in k1321 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4498(t3,((C_word*)t0)[2],t2);}

/* hash-table-clear! in k4025 in k1321 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4470,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[96]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4477,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 955  vector-fill! */
t6=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k4475 in hash-table-clear! in k4025 in k1321 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_fix(0)));}

/* hash-table-remove! in k4025 in k1321 */
static void C_ccall f_4374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4374,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[95]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4381,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 932  ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[95]);}

/* k4379 in hash-table-remove! in k4025 in k1321 */
static void C_ccall f_4381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4381,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word)li70),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_4395(t10,((C_word*)t0)[2],C_fix(0));}

/* doloop1078 in k4379 in hash-table-remove! in k4025 in k1321 */
static void C_fcall f_4395(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4395,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4408,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4421,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word)li69),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_4421(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in doloop1078 in k4379 in hash-table-remove! in k4025 in k1321 */
static void C_fcall f_4421(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4421,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4440,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 942  func */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t6,t7,t8);}}

/* k4438 in loop in doloop1078 in k4379 in hash-table-remove! in k4025 in k1321 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 949  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4421(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k4406 in doloop1078 in k4379 in hash-table-remove! in k4025 in k1321 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4395(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k4025 in k1321 */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4243,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[94]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4259,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 896  hash */
t9=t7;
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t3,t6);}

/* k4257 in hash-table-delete! in k4025 in k1321 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4259,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[5],t1);
t6=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4279,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li66),tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_4279(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word)li67),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_4326(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k4257 in hash-table-delete! in k4025 in k1321 */
static void C_fcall f_4326(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4326,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4345,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
/* srfi-69.scm: 919  test */
t8=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k4343 in loop in k4257 in hash-table-delete! in k4025 in k1321 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):(C_word)C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 926  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4326(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k4257 in hash-table-delete! in k4025 in k1321 */
static C_word C_fcall f_4279(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?(C_word)C_i_setslot(t1,C_fix(1),t4):(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k4025 in k1321 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4135,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[93]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(3));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4151,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_block_size(t5);
/* srfi-69.scm: 872  hash */
t10=t7;
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t3,t9);}

/* k4149 in hash-table-exists? in k4025 in k1321 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4166,a[2]=((C_word*)t0)[3],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4166(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4206(t7,((C_word*)t0)[2],t3);}}

/* loop in k4149 in hash-table-exists? in k4025 in k1321 */
static void C_fcall f_4206(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4206,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4219,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 884  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4217 in loop in k4149 in hash-table-exists? in k4025 in k1321 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 885  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4206(t3,((C_word*)t0)[4],t2);}}

/* loop in k4149 in hash-table-exists? in k4025 in k1321 */
static C_word C_fcall f_4166(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-ref/default in k4025 in k1321 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4029,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[33],lf[92]);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(3));
t8=(C_word)C_slot(t2,C_fix(4));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4045,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t6,a[6]=t7,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_block_size(t6);
/* srfi-69.scm: 846  hash */
t11=t8;
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t3,t10);}

/* k4043 in hash-table-ref/default in k4025 in k1321 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4045,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4060(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word)li61),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_4099(t7,((C_word*)t0)[2],t3);}}

/* loop in k4043 in hash-table-ref/default in k4025 in k1321 */
static void C_fcall f_4099(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4099,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[5];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 861  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4113 in loop in k4043 in hash-table-ref/default in k4025 in k1321 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 863  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4099(t3,((C_word*)t0)[5],t2);}}

/* loop in k4043 in hash-table-ref/default in k4025 in k1321 */
static C_word C_fcall f_4060(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[3];
return(t2);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return((C_word)C_slot(t2,C_fix(1)));}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t8=t5;
t1=t8;
goto loop;}}}

/* hash-table-set! in k1321 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3832,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[33],lf[89]);
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_fixnum_plus(t6,C_fix(1));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(5));
t11=(C_word)C_slot(t8,C_fix(6));
t12=(C_word)C_block_size(t9);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4015,a[2]=t11,a[3]=t9,a[4]=t8,a[5]=t12,a[6]=t7,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[2],a[10]=t1,a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_a_i_times(&a,2,t12,t10);
/* srfi-69.scm: 636  floor */
t15=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}

/* k4013 in hash-table-set! in k1321 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4015,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4005 in k4013 in hash-table-set! in k1321 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3860,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[5],C_fix(1073741823)))){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],((C_word*)t0)[6]))){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[6],t2))){
/* srfi-69.scm: 640  hash-table-resize! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[79]+1)))(5,*((C_word*)lf[79]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t4=t3;
f_3860(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_3860(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_3860(2,t4,C_SCHEME_UNDEFINED);}}

/* k3858 in k4005 in k4013 in hash-table-set! in k1321 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3860,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 780  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[4],t5);}

/* k3873 in k3858 in k4005 in k4013 in hash-table-set! in k1321 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3875,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3881,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3892,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word)li57),tmp=(C_word)a,a+=11,tmp));
t8=((C_word*)t6)[1];
f_3892(t8,t3,t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word)li58),tmp=(C_word)a,a+=12,tmp));
t8=((C_word*)t6)[1];
f_3941(t8,t3,t2);}}

/* loop in k3873 in k3858 in k4005 in k4013 in hash-table-set! in k1321 */
static void C_fcall f_3941(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3941,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 800  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[10],t5);}}

/* k3969 in loop in k3873 in k3858 in k4005 in k4013 in hash-table-set! in k1321 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 802  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3941(t3,((C_word*)t0)[6],t2);}}

/* loop in k3873 in k3858 in k4005 in k4013 in hash-table-set! in k1321 */
static void C_fcall f_3892(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3892,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[7]);
t5=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[9],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(t3,C_fix(1),((C_word*)t0)[8]));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 792  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k3879 in k3873 in k3858 in k4005 in k4013 in hash-table-set! in k1321 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[90]+1));}

/* hash-table-update!/default in k1321 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3820,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_structure_2(t2,lf[33],lf[88]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3827,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 767  ##sys#check-closure */
t8=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[88]);}

/* k3825 in hash-table-update!/default in k1321 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 768  *hash-table-update!/default */
t2=lf[87];
f_3613(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-update!/default in k1321 */
static void C_fcall f_3613(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3613,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_fixnum_plus(t6,C_fix(1));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(5));
t11=(C_word)C_slot(t8,C_fix(6));
t12=(C_word)C_block_size(t9);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3810,a[2]=t11,a[3]=t9,a[4]=t8,a[5]=t12,a[6]=t1,a[7]=t5,a[8]=t4,a[9]=t7,a[10]=t3,a[11]=((C_word*)t0)[2],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t14=(C_word)C_a_i_times(&a,2,t12,t10);
/* srfi-69.scm: 636  floor */
t15=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}

/* k3808 in *hash-table-update!/default in k1321 */
static void C_ccall f_3810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3810,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3800 in k3808 in *hash-table-update!/default in k1321 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3802,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3638,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[5],C_fix(1073741823)))){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],((C_word*)t0)[9]))){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[9],t2))){
/* srfi-69.scm: 640  hash-table-resize! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[79]+1)))(5,*((C_word*)lf[79]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t4=t3;
f_3638(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_3638(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_3638(2,t4,C_SCHEME_UNDEFINED);}}

/* k3636 in k3800 in k3808 in *hash-table-update!/default in k1321 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3638,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 735  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k3651 in k3636 in k3800 in k3808 in *hash-table-update!/default in k1321 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3667,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word)li53),tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_3667(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3726,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],a[12]=((C_word)li54),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_3726(t7,((C_word*)t0)[2],t2);}}

/* loop in k3651 in k3636 in k3800 in k3808 in *hash-table-update!/default in k1321 */
static void C_fcall f_3726(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3726,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3736,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 754  func */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3759,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 759  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k3757 in loop in k3651 in k3636 in k3800 in k3808 in *hash-table-update!/default in k1321 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3759,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3762,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 760  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 763  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3726(t3,((C_word*)t0)[5],t2);}}

/* k3760 in k3757 in loop in k3651 in k3636 in k3800 in k3808 in *hash-table-update!/default in k1321 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3734 in loop in k3651 in k3636 in k3800 in k3808 in *hash-table-update!/default in k1321 */
static void C_ccall f_3736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3736,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* loop in k3651 in k3636 in k3800 in k3808 in *hash-table-update!/default in k1321 */
static void C_fcall f_3667(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3667,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3677,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 741  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3703,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 747  func */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 750  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k3701 in loop in k3651 in k3636 in k3800 in k3808 in *hash-table-update!/default in k1321 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3675 in loop in k3651 in k3636 in k3800 in k3808 in *hash-table-update!/default in k1321 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3677,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* hash-table-update! in k1321 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_3323r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3323r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3323r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(16);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3325,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li48),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3548,a[2]=t3,a[3]=t5,a[4]=t2,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3565,a[2]=t6,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-func808867 */
t8=t7;
f_3565(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-thunk809859 */
t10=t6;
f_3548(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body806814 */
t12=t5;
f_3325(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-func808 in hash-table-update! in k1321 */
static void C_fcall f_3565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3565,NULL,2,t0,t1);}
/* def-thunk809859 */
t2=((C_word*)t0)[2];
f_3548(t2,t1,*((C_word*)lf[86]+1));}

/* def-thunk809 in hash-table-update! in k1321 */
static void C_fcall f_3548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3548,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(9));
if(C_truep(t3)){
/* body806814 */
t4=((C_word*)t0)[3];
f_3325(t4,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
/* body806814 */
t5=((C_word*)t0)[3];
f_3325(t5,t1,t2,t4);}}

/* f_3560 in def-thunk809 in hash-table-update! in k1321 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3560,2,t0,t1);}
/* srfi-69.scm: 684  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[84],lf[82],lf[85],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body806 in hash-table-update! in k1321 */
static void C_fcall f_3325(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3325,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[4],lf[33],lf[82]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3332,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 688  ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[82]);}

/* k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 689  ##sys#check-closure */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[82]);}

/* k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(2));
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
t4=((C_word*)t0)[7];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t4,C_fix(5));
t7=(C_word)C_slot(t4,C_fix(6));
t8=(C_word)C_block_size(t5);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3539,a[2]=t7,a[3]=t5,a[4]=t4,a[5]=t8,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t3,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
t10=(C_word)C_a_i_times(&a,2,t8,t6);
/* srfi-69.scm: 636  floor */
t11=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}

/* k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3539,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3359,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[5],C_fix(1073741823)))){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],((C_word*)t0)[9]))){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[9],t2))){
/* srfi-69.scm: 640  hash-table-resize! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[79]+1)))(5,*((C_word*)lf[79]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t4=t3;
f_3359(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_3359(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_3359(2,t4,C_SCHEME_UNDEFINED);}}

/* k3357 in k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3359,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 696  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k3372 in k3357 in k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3374,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3388,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word)li46),tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_3388(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],a[12]=((C_word)li47),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_3451(t7,((C_word*)t0)[2],t2);}}

/* loop in k3372 in k3357 in k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_fcall f_3451(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3451,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3461,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3479,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 715  thunk */
t5=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3488,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 720  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k3486 in loop in k3372 in k3357 in k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3491,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 721  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 724  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3451(t3,((C_word*)t0)[5],t2);}}

/* k3489 in k3486 in loop in k3372 in k3357 in k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3477 in loop in k3372 in k3357 in k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 715  func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3459 in loop in k3372 in k3357 in k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3461,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* loop in k3372 in k3357 in k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_fcall f_3388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3388,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3398,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3416,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 702  thunk */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3428,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 708  func */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 711  loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k3426 in loop in k3372 in k3357 in k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3414 in loop in k3372 in k3357 in k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 702  func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3396 in loop in k3372 in k3357 in k3529 in k3537 in k3333 in k3330 in body806 in hash-table-update! in k1321 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* hash-table-copy in k1321 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3314,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[81]);
/* srfi-69.scm: 669  *hash-table-copy */
t4=lf[80];
f_3202(t4,t1,t2);}

/* *hash-table-copy in k1321 */
static void C_fcall f_3202(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3202,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3212,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 649  make-vector */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k3210 in *hash-table-copy in k1321 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3217,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li43),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3217(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop777 in k3210 in *hash-table-copy in k1321 */
static void C_fcall f_3217(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3217,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(6));
t8=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t9=(C_word)C_slot(((C_word*)t0)[5],C_fix(8));
t10=(C_word)C_slot(((C_word*)t0)[5],C_fix(9));
/* srfi-69.scm: 652  *make-hash-table */
t11=lf[32];
f_2607(t11,t1,t3,t4,t5,t6,t7,t10,(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3273,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3279,a[2]=t6,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3279(t8,t3,t4);}}

/* copy-loop in doloop777 in k3210 in *hash-table-copy in k1321 */
static void C_fcall f_3279(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3279,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3300,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 665  copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k3298 in copy-loop in doloop777 in k3210 in *hash-table-copy in k1321 */
static void C_ccall f_3300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3300,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3271 in doloop777 in k3210 in *hash-table-copy in k1321 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3217(t4,((C_word*)t0)[2],t3);}

/* hash-table-resize! in k1321 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3176,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_times(t4,C_fix(2));
t6=(C_word)C_i_fixnum_min(C_fix(1073741823),t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3183,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 624  hash-table-canonical-length */
f_2577(t7,lf[28],t6);}

/* k3181 in hash-table-resize! in k1321 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 625  make-vector */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_SCHEME_END_OF_LIST);}

/* k3184 in k3181 in hash-table-resize! in k1321 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3189,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t5);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3109,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t9,a[7]=t6,a[8]=((C_word)li40),tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_3109(t11,t2,C_fix(0));}

/* doloop744 in k3184 in k3181 in hash-table-resize! in k1321 */
static void C_fcall f_3109(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3109,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3119,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3132(t8,t3,t4);}}

/* loop in doloop744 in k3184 in k3181 in hash-table-resize! in k1321 */
static void C_fcall f_3132(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3132,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3148,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 615  hash */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k3146 in loop in doloop744 in k3184 in k3181 in hash-table-resize! in k1321 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3148,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 618  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3132(t8,((C_word*)t0)[2],t7);}

/* k3117 in doloop744 in k3184 in k3181 in hash-table-resize! in k1321 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3109(t3,((C_word*)t0)[2],t2);}

/* k3187 in k3184 in k3181 in hash-table-resize! in k1321 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]));}

/* hash-table-initial in k1321 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3082,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[78]);
t4=(C_word)C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm: 602  thunk */
t5=t4;
((C_proc2)C_retrieve_proc(t5))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k1321 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3070,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[77]);
t4=(C_word)C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k1321 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3061,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[76]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k1321 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3052,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k1321 */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3043,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[74]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k1321 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3034,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[73]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k1321 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3025,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[72]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k1321 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3016,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-size in k1321 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3007,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[70]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* hash-table? in k1321 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3001,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[33]));}

/* make-hash-table in k1321 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+41)){
C_save_and_reclaim((void*)tr2r,(void*)f_2638r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2638r(t0,t1,t2);}}

static void C_ccall f_2638r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(41);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[36]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[41];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[42];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2716,a[2]=t4,a[3]=t2,a[4]=t17,a[5]=t12,a[6]=t16,a[7]=t14,a[8]=t6,a[9]=t1,a[10]=t8,a[11]=t10,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t4)[1]))){
t19=t18;
f_2716(t19,C_SCHEME_UNDEFINED);}
else{
t19=(C_word)C_i_car(((C_word*)t4)[1]);
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2991,a[2]=t4,a[3]=t19,a[4]=t6,a[5]=t18,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 481  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t20,t19);}}

/* k2989 in make-hash-table in k1321 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_2716(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 482  ##sys#check-closure */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[40]);}}

/* k2992 in k2989 in make-hash-table in k1321 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_2716(t5,t4);}

/* k2714 in make-hash-table in k1321 */
static void C_fcall f_2716(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2716,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_2719(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 487  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t3);}}

/* k2969 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2971,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_2719(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 488  ##sys#check-closure */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[40]);}}

/* k2972 in k2969 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_2719(t5,t4);}

/* k2717 in k2714 in make-hash-table in k1321 */
static void C_fcall f_2719(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2719,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_2722(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 493  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t3);}}

/* k2937 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2939,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_2722(t3,t2);}
else{
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[40]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_2945(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 496  error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[40],lf[68],((C_word*)t0)[4]);}}}

/* k2943 in k2937 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[51]+1),((C_word*)t0)[5]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_2722(t6,t5);}

/* k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_fcall f_2722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2722,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2757,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[8],a[8]=t4,a[9]=((C_word*)t0)[3],a[10]=((C_word)li27),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2757(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_fcall f_2757(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2757,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[9],a[3]=t3,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2778,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* srfi-69.scm: 506  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t5,t3);}}

/* k2776 in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2778,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=t3;
f_2784(2,t4,(C_word)C_i_car(t2));}
else{
/* srfi-69.scm: 510  invarg-err */
t4=((C_word*)t0)[2];
f_2768(t4,t3,lf[66]);}}
else{
/* srfi-69.scm: 542  invarg-err */
t2=((C_word*)t0)[2];
f_2768(t2,((C_word*)t0)[10],lf[67]);}}

/* k2782 in k2776 in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2787,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[47]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 513  ##sys#check-closure */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,lf[40]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[49]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2810,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 516  ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[40]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[50]);
if(C_truep(t5)){
t6=(C_word)C_i_check_exact_2(t1,lf[40]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_2823(2,t8,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 521  error */
t8=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[40],lf[52],t1);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[53]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2841,a[2]=t1,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp));
t8=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm: 541  loop */
t9=((C_word*)((C_word*)t0)[11])[1];
f_2757(t9,((C_word*)t0)[10],t8);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[54]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 526  ##sys#check-inexact */
((C_proc4)C_retrieve_proc(*((C_word*)lf[58]+1)))(4,*((C_word*)lf[58]+1),t8,t1,lf[40]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[59]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2876,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 531  ##sys#check-inexact */
((C_proc4)C_retrieve_proc(*((C_word*)lf[58]+1)))(4,*((C_word*)lf[58]+1),t9,t1,lf[40]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[63]);
if(C_truep(t9)){
if(C_truep(t1)){
t10=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm: 541  loop */
t11=((C_word*)((C_word*)t0)[11])[1];
f_2757(t11,((C_word*)t0)[10],t10);}
else{
t10=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm: 541  loop */
t11=((C_word*)((C_word*)t0)[11])[1];
f_2757(t11,((C_word*)t0)[10],t10);}}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[64]);
if(C_truep(t10)){
if(C_truep(t1)){
t11=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm: 541  loop */
t12=((C_word*)((C_word*)t0)[11])[1];
f_2757(t12,((C_word*)t0)[10],t11);}
else{
t11=(C_word)C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm: 541  loop */
t12=((C_word*)((C_word*)t0)[11])[1];
f_2757(t12,((C_word*)t0)[10],t11);}}
else{
/* srfi-69.scm: 540  invarg-err */
t11=((C_word*)t0)[2];
f_2768(t11,t2,lf[65]);}}}}}}}}}

/* k2874 in k2782 in k2776 in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_flonum_lessp(lf[60],((C_word*)t0)[5]))){
if(C_truep((C_word)C_flonum_lessp(((C_word*)t0)[5],lf[61]))){
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 541  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2757(t5,((C_word*)t0)[2],t4);}
else{
/* srfi-69.scm: 533  error */
t3=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[40],lf[62],((C_word*)t0)[5]);}}
else{
/* srfi-69.scm: 533  error */
t3=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[40],lf[62],((C_word*)t0)[5]);}}

/* k2877 in k2874 in k2782 in k2776 in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 541  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2757(t4,((C_word*)t0)[2],t3);}

/* k2849 in k2782 in k2776 in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_flonum_lessp(lf[55],((C_word*)t0)[5]))){
if(C_truep((C_word)C_flonum_lessp(((C_word*)t0)[5],lf[56]))){
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 541  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2757(t5,((C_word*)t0)[2],t4);}
else{
/* srfi-69.scm: 528  error */
t3=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[40],lf[57],((C_word*)t0)[5]);}}
else{
/* srfi-69.scm: 528  error */
t3=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[40],lf[57],((C_word*)t0)[5]);}}

/* k2852 in k2849 in k2782 in k2776 in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 541  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2757(t4,((C_word*)t0)[2],t3);}

/* f_2841 in k2782 in k2776 in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2841,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2821 in k2782 in k2776 in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[51]+1),((C_word*)t0)[6]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 541  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2757(t5,((C_word*)t0)[2],t4);}

/* k2808 in k2782 in k2776 in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 541  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2757(t4,((C_word*)t0)[2],t3);}

/* k2798 in k2782 in k2776 in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 541  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2757(t4,((C_word*)t0)[2],t3);}

/* k2785 in k2782 in k2776 in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 541  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2757(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_fcall f_2768(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2768,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 505  error */
t3=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[40],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2723 in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_flonum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* srfi-69.scm: 545  error */
t3=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[40],lf[46],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_2728(2,t3,C_SCHEME_UNDEFINED);}}

/* k2726 in k2723 in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 547  hash-table-canonical-length */
f_2577(t2,lf[28],((C_word*)((C_word*)t0)[9])[1]);}

/* k2730 in k2726 in k2723 in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2732,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
/* srfi-69.scm: 557  *make-hash-table */
t3=lf[32];
f_2607(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);}
else{
t3=f_2640(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=C_mutate(((C_word *)((C_word*)t0)[8])+1,t3);
/* srfi-69.scm: 557  *make-hash-table */
t5=lf[32];
f_2607(t5,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 554  warning */
((C_proc4)C_retrieve_proc(*((C_word*)lf[43]+1)))(4,*((C_word*)lf[43]+1),t4,lf[40],lf[44]);}}}

/* k2746 in k2730 in k2726 in k2723 in k2720 in k2717 in k2714 in make-hash-table in k1321 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[21]+1));
/* srfi-69.scm: 557  *make-hash-table */
t3=lf[32];
f_2607(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* hash-for-test in make-hash-table in k1321 */
static C_word C_fcall f_2640(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_stack_check;
t1=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:(C_word)C_eqp(*((C_word*)lf[34]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
t3=*((C_word*)lf[17]+1);
return(t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(*((C_word*)lf[35]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
t5=*((C_word*)lf[19]+1);
return(t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(*((C_word*)lf[36]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
t7=*((C_word*)lf[21]+1);
return(t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(*((C_word*)lf[37]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
t9=*((C_word*)lf[23]+1);
return(t9);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(*((C_word*)lf[38]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
t11=*((C_word*)lf[27]+1);
return(t11);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t11)){
if(C_truep(t11)){
t12=*((C_word*)lf[4]+1);
return(t12);}
else{
return(C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(*((C_word*)lf[39]+1),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t12)){
t13=*((C_word*)lf[4]+1);
return(t13);}
else{
return(C_SCHEME_FALSE);}}}}}}}}

/* *make-hash-table in k1321 */
static void C_fcall f_2607(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2607,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2611,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
/* srfi-69.scm: 429  make-vector */
t10=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t4,C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_2611(2,t11,(C_word)C_i_car(t8));}
else{
/* ##sys#error */
t11=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[0],t8);}}}

/* k2609 in *make-hash-table in k1321 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,10,lf[33],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* hash-table-canonical-length in k1321 */
static void C_fcall f_2577(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2577,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2583,a[2]=t3,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2583(t4,t2));}

/* loop in hash-table-canonical-length in k1321 */
static C_word C_fcall f_2583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
if(C_truep(t4)){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}}

/* string-ci-hash in k1321 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_2450r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2450r(t0,t1,t2,t3);}}

static void C_ccall f_2450r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(17);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(C_word)C_i_check_string_2(t2,lf[26]);
t9=(C_word)C_i_check_exact_2(t5,lf[26]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2466,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2487,a[2]=t2,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2506,a[2]=t11,a[3]=t2,a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2515,a[2]=t12,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-start500513 */
t14=t13;
f_2515(t14,t10);}
else{
t14=(C_word)C_i_car(t7);
t15=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t15))){
/* def-end501511 */
t16=t12;
f_2506(t16,t10,t14);}
else{
t16=(C_word)C_i_car(t15);
t17=(C_word)C_i_cdr(t15);
if(C_truep((C_word)C_i_nullp(t17))){
/* body498506 */
t18=t11;
f_2487(t18,t10,t14,t16);}
else{
/* ##sys#error */
t18=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t10,lf[0],t17);}}}}
else{
t11=t10;
f_2466(2,t11,t2);}}

/* def-start500 in string-ci-hash in k1321 */
static void C_fcall f_2515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2515,NULL,2,t0,t1);}
/* def-end501511 */
t2=((C_word*)t0)[2];
f_2506(t2,t1,C_fix(0));}

/* def-end501 in string-ci-hash in k1321 */
static void C_fcall f_2506(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2506,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(((C_word*)t0)[3]);
/* body498506 */
t4=((C_word*)t0)[2];
f_2487(t4,t1,t2,t3);}

/* body498 in string-ci-hash in k1321 */
static void C_fcall f_2487(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2487,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2491,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 377  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[25]+1)))(6,*((C_word*)lf[25]+1),t4,t2,C_fix(0),t5,lf[27]);}

/* k2489 in body498 in string-ci-hash in k1321 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 378  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[25]+1)))(6,*((C_word*)lf[25]+1),t2,((C_word*)t0)[2],C_fix(0),t3,lf[27]);}

/* k2492 in k2489 in body498 in string-ci-hash in k1321 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 379  ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[24]+1)))(5,*((C_word*)lf[24]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2464 in string-ci-hash in k1321 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_hash_string_ci(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(C_word)C_fixnum_negate(t2);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 137  fxmod */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}
else{
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}}

/* string-hash in k1321 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_2325r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2325r(t0,t1,t2,t3);}}

static void C_ccall f_2325r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(17);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(C_word)C_i_check_string_2(t2,lf[23]);
t9=(C_word)C_i_check_exact_2(t5,lf[23]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2341,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2362,a[2]=t2,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2381,a[2]=t11,a[3]=t2,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2390,a[2]=t12,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-start446459 */
t14=t13;
f_2390(t14,t10);}
else{
t14=(C_word)C_i_car(t7);
t15=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t15))){
/* def-end447457 */
t16=t12;
f_2381(t16,t10,t14);}
else{
t16=(C_word)C_i_car(t15);
t17=(C_word)C_i_cdr(t15);
if(C_truep((C_word)C_i_nullp(t17))){
/* body444452 */
t18=t11;
f_2362(t18,t10,t14,t16);}
else{
/* ##sys#error */
t18=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t10,lf[0],t17);}}}}
else{
t11=t10;
f_2341(2,t11,t2);}}

/* def-start446 in string-hash in k1321 */
static void C_fcall f_2390(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2390,NULL,2,t0,t1);}
/* def-end447457 */
t2=((C_word*)t0)[2];
f_2381(t2,t1,C_fix(0));}

/* def-end447 in string-hash in k1321 */
static void C_fcall f_2381(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2381,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(((C_word*)t0)[3]);
/* body444452 */
t4=((C_word*)t0)[2];
f_2362(t4,t1,t2,t3);}

/* body444 in string-hash in k1321 */
static void C_fcall f_2362(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2362,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2366,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 365  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[25]+1)))(6,*((C_word*)lf[25]+1),t4,t2,C_fix(0),t5,lf[23]);}

/* k2364 in body444 in string-hash in k1321 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 366  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[25]+1)))(6,*((C_word*)lf[25]+1),t2,((C_word*)t0)[2],C_fix(0),t3,lf[23]);}

/* k2367 in k2364 in body444 in string-hash in k1321 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 367  ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[24]+1)))(5,*((C_word*)lf[24]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2339 in string-hash in k1321 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_hash_string(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(C_word)C_fixnum_negate(t2);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 137  fxmod */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}
else{
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}}

/* equal?-hash in k1321 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2276r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2276r(t0,t1,t2,t3);}}

static void C_ccall f_2276r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2280,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2280(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2280(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2278 in equal?-hash in k1321 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[22]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2286,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 353  *equal?-hash */
f_1942(t3,((C_word*)t0)[2]);}

/* k2284 in k2278 in equal?-hash in k1321 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(C_word)C_fixnum_negate(t1);
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}
else{
t2=t1;
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}}

/* *equal?-hash in k1321 */
static void C_fcall f_1942(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1942,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1945,a[2]=t8,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2010,a[2]=t8,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2041,a[2]=t4,a[3]=t6,a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp));
/* srfi-69.scm: 349  recursive-hash */
t12=((C_word*)t8)[1];
f_2041(t12,t1,t2,C_fix(0));}

/* recursive-hash in *equal?-hash in k1321 */
static void C_fcall f_2041(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2041,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t4=t2;
if(C_truep((C_word)C_i_flonump(t4))){
t5=(C_word)C_subbyte(t4,C_fix(7));
t6=(C_word)C_subbyte(t4,C_fix(6));
t7=(C_word)C_subbyte(t4,C_fix(5));
t8=(C_word)C_subbyte(t4,C_fix(4));
t9=(C_word)C_subbyte(t4,C_fix(3));
t10=(C_word)C_subbyte(t4,C_fix(2));
t11=(C_word)C_subbyte(t4,C_fix(1));
t12=(C_word)C_subbyte(t4,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_fixnum_plus(t5,t25);
t27=t1;
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2178,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t5,t4);}}
else{
t4=t2;
if(C_truep((C_word)C_blockp(t4))){
t5=t2;
if(C_truep((C_word)C_byteblockp(t5))){
t6=t2;
t7=(C_word)C_hash_string(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t6=t2;
t7=(C_word)C_i_length(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2204,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(t6,C_fix(0));
/* srfi-69.scm: 285  recursive-atomic-hash */
t10=((C_word*)((C_word*)t0)[3])[1];
f_2010(t10,t8,t9,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=t2;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2233,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t6,C_fix(0));
/* srfi-69.scm: 288  recursive-atomic-hash */
t9=((C_word*)((C_word*)t0)[3])[1];
f_2010(t9,t7,t8,t3);}
else{
t6=t2;
if(C_truep((C_word)C_portp(t6))){
t7=t2;
t8=(C_word)C_peek_fixnum(t7,C_fix(0));
t9=(C_word)C_fixnum_shift_left(t8,C_fix(4));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2254,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 293  input-port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t10,t7);}
else{
t7=t2;
if(C_truep((C_word)C_specialp(t7))){
t8=t2;
t9=(C_word)C_peek_fixnum(t8,C_fix(0));
/* srfi-69.scm: 298  vector-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_1945(t10,t1,t8,t9,t3,C_fix(1));}
else{
t8=t2;
/* srfi-69.scm: 301  vector-hash */
t9=((C_word*)((C_word*)t0)[2])[1];
f_1945(t9,t1,t8,C_fix(0),t3,C_fix(0));}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(262));}}}}}}}}}}

/* k2252 in recursive-hash in *equal?-hash in k1321 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(260)):(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(261))));}

/* k2231 in recursive-hash in *equal?-hash in k1321 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=(C_word)C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2225,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 289  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2010(t5,t3,t4,((C_word*)t0)[2]);}

/* k2223 in k2231 in recursive-hash in *equal?-hash in k1321 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2202 in recursive-hash in *equal?-hash in k1321 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2176 in recursive-hash in *equal?-hash in k1321 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* recursive-atomic-hash in *equal?-hash in k1321 */
static void C_fcall f_2010(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2010,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_symbolp(t4));
t7=(C_truep(t6)?t6:(C_word)C_i_numberp(t4));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2026,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t7)){
t9=t8;
f_2026(t9,t7);}
else{
t9=t2;
t10=t8;
f_2026(t10,(C_word)C_byteblockp(t9));}}

/* k2024 in recursive-atomic-hash in *equal?-hash in k1321 */
static void C_fcall f_2026(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 323  recursive-hash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2041(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* vector-hash in *equal?-hash in k1321 */
static void C_fcall f_1945(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1945,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t2);
t7=(C_word)C_fixnum_plus(t6,t3);
t8=(C_word)C_i_fixnum_min(C_fix(4),t6);
t9=(C_word)C_fixnum_difference(t8,t5);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t11,a[6]=((C_word)li8),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_1962(t13,t1,t7,t5,t9);}

/* loop in vector-hash in *equal?-hash in k1321 */
static void C_fcall f_1962(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1962,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1996,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 315  recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2041(t10,t7,t8,t9);}}

/* k1994 in loop in vector-hash in *equal?-hash in k1321 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[7],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 313  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1962(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k1321 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1894r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1894r(t0,t1,t2,t3);}}

static void C_ccall f_1894r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1898,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1898(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1898(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1896 in eqv?-hash in k1321 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[19]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1904,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
f_1904(2,t5,t4);}
else{
if(C_truep((C_word)C_charp(t4))){
t5=t3;
f_1904(2,t5,(C_word)C_fix((C_word)C_character_code(t4)));}
else{
switch(t4){
case C_SCHEME_TRUE:
t5=t3;
f_1904(2,t5,C_fix(256));
case C_SCHEME_FALSE:
t5=t3;
f_1904(2,t5,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_1904(2,t5,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t4))){
t5=t3;
f_1904(2,t5,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=t3;
f_1904(2,t7,t6);}
else{
if(C_truep((C_word)C_i_numberp(t4))){
if(C_truep((C_word)C_i_flonump(t4))){
t5=(C_word)C_subbyte(t4,C_fix(7));
t6=(C_word)C_subbyte(t4,C_fix(6));
t7=(C_word)C_subbyte(t4,C_fix(5));
t8=(C_word)C_subbyte(t4,C_fix(4));
t9=(C_word)C_subbyte(t4,C_fix(3));
t10=(C_word)C_subbyte(t4,C_fix(2));
t11=(C_word)C_subbyte(t4,C_fix(1));
t12=(C_word)C_subbyte(t4,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_fixnum_plus(t5,t25);
t27=t3;
f_1904(2,t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1883,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t5,t4);}}
else{
if(C_truep((C_word)C_blockp(t4))){
/* srfi-69.scm: 184  *equal?-hash */
f_1942(t3,t4);}
else{
t5=t3;
f_1904(2,t5,C_fix(262));}}}}}}}}}

/* k1881 in k1896 in eqv?-hash in k1321 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix(t1);
t3=((C_word*)t0)[2];
f_1904(2,t3,t2);}

/* k1902 in k1896 in eqv?-hash in k1321 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(C_word)C_fixnum_negate(t1);
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}
else{
t2=t1;
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}}

/* eq?-hash in k1321 */
static void C_ccall f_1703(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1703r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1703r(t0,t1,t2,t3);}}

static void C_ccall f_1703r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1707,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1707(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1707(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1705 in eq?-hash in k1321 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1707,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[17]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1713,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
f_1713(2,t5,t4);}
else{
if(C_truep((C_word)C_charp(t4))){
t5=t3;
f_1713(2,t5,(C_word)C_fix((C_word)C_character_code(t4)));}
else{
switch(t4){
case C_SCHEME_TRUE:
t5=t3;
f_1713(2,t5,C_fix(256));
case C_SCHEME_FALSE:
t5=t3;
f_1713(2,t5,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_1713(2,t5,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t4))){
t5=t3;
f_1713(2,t5,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=t3;
f_1713(2,t7,t6);}
else{
if(C_truep((C_word)C_blockp(t4))){
/* srfi-69.scm: 184  *equal?-hash */
f_1942(t3,t4);}
else{
t5=t3;
f_1713(2,t5,C_fix(262));}}}}}}}}

/* k1711 in k1705 in eq?-hash in k1321 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(C_word)C_fixnum_negate(t1);
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}
else{
t2=t1;
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}}

/* keyword-hash in k1321 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1592r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1592r(t0,t1,t2,t3);}}

static void C_ccall f_1592r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1596,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1596(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1596(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1594 in keyword-hash in k1321 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 220  ##sys#check-keyword */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,((C_word*)t0)[3],lf[16]);}

/* k1597 in k1594 in keyword-hash in k1321 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[16]);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_hash_string(t4);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
t6=(C_word)C_fixnum_negate(t5);
t7=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t6);
/* srfi-69.scm: 137  fxmod */
t8=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t7,((C_word*)t0)[4]);}
else{
t6=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t5);
/* srfi-69.scm: 137  fxmod */
t7=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t6,((C_word*)t0)[4]);}}

/* ##sys#check-keyword in k1321 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1566r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1566r(t0,t1,t2,t3);}}

static void C_ccall f_1566r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1573,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 207  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t2);}

/* k1571 in ##sys#check-keyword in k1321 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_vemptyp(((C_word*)t0)[3]))){
/* srfi-69.scm: 208  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[13],C_SCHEME_FALSE,lf[14],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
/* srfi-69.scm: 208  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[13],t2,lf[14],((C_word*)t0)[2]);}}}

/* symbol-hash in k1321 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1515r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1515r(t0,t1,t2,t3);}}

static void C_ccall f_1515r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1519,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1519(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1519(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1517 in symbol-hash in k1321 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[3],lf[11]);
t3=(C_word)C_i_check_exact_2(t1,lf[11]);
t4=((C_word*)t0)[3];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_hash_string(t5);
if(C_truep((C_word)C_fixnum_lessp(t6,C_fix(0)))){
t7=(C_word)C_fixnum_negate(t6);
t8=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t7);
/* srfi-69.scm: 137  fxmod */
t9=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[2],t8,t1);}
else{
t7=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t6);
/* srfi-69.scm: 137  fxmod */
t8=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t7,t1);}}

/* object-uid-hash in k1321 */
static void C_ccall f_1467(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1467r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1467r(t0,t1,t2,t3);}}

static void C_ccall f_1467r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1471,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1471(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1471(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1469 in object-uid-hash in k1321 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[10]);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1477,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 184  *equal?-hash */
f_1942(t4,t3);}

/* k1475 in k1469 in object-uid-hash in k1321 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(C_word)C_fixnum_negate(t1);
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}
else{
t2=t1;
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}}

/* number-hash in k1321 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1331r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1331r(t0,t1,t2,t3);}}

static void C_ccall f_1331r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1335,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1335(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1335(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1333 in number-hash in k1321 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t3=t2;
f_1338(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 173  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[7],lf[4],lf[8],((C_word*)t0)[3]);}}

/* k1336 in k1333 in number-hash in k1321 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1338,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[4]);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1344,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t3))){
t5=t4;
f_1344(t5,t3);}
else{
if(C_truep((C_word)C_i_flonump(t3))){
t5=(C_word)C_subbyte(t3,C_fix(7));
t6=(C_word)C_subbyte(t3,C_fix(6));
t7=(C_word)C_subbyte(t3,C_fix(5));
t8=(C_word)C_subbyte(t3,C_fix(4));
t9=(C_word)C_subbyte(t3,C_fix(3));
t10=(C_word)C_subbyte(t3,C_fix(2));
t11=(C_word)C_subbyte(t3,C_fix(1));
t12=(C_word)C_subbyte(t3,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_fixnum_plus(t5,t25);
t27=t4;
f_1344(t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t5,t3);}}}

/* k1438 in k1336 in k1333 in number-hash in k1321 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix(t1);
t3=((C_word*)t0)[2];
f_1344(t3,t2);}

/* k1342 in k1336 in k1333 in number-hash in k1321 */
static void C_fcall f_1344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(C_word)C_fixnum_negate(t1);
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}
else{
t2=t1;
t3=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t2);
/* srfi-69.scm: 137  fxmod */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}}

/* ##sys#number-hash-hook in k1321 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1325,3,t0,t1,t2);}
/* srfi-69.scm: 161  *equal?-hash */
f_1942(t1,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[228] = {
{"toplevel:srfi_69_scm",(void*)C_srfi_69_toplevel},
{"f_1323:srfi_69_scm",(void*)f_1323},
{"f_5016:srfi_69_scm",(void*)f_5016},
{"f_5136:srfi_69_scm",(void*)f_5136},
{"f_5020:srfi_69_scm",(void*)f_5020},
{"f_5026:srfi_69_scm",(void*)f_5026},
{"f_5038:srfi_69_scm",(void*)f_5038},
{"f_5095:srfi_69_scm",(void*)f_5095},
{"f_5114:srfi_69_scm",(void*)f_5114},
{"f_5053:srfi_69_scm",(void*)f_5053},
{"f_4027:srfi_69_scm",(void*)f_4027},
{"f_4994:srfi_69_scm",(void*)f_4994},
{"f_5001:srfi_69_scm",(void*)f_5001},
{"f_5006:srfi_69_scm",(void*)f_5006},
{"f_5014:srfi_69_scm",(void*)f_5014},
{"f_4982:srfi_69_scm",(void*)f_4982},
{"f_4989:srfi_69_scm",(void*)f_4989},
{"f_4970:srfi_69_scm",(void*)f_4970},
{"f_4977:srfi_69_scm",(void*)f_4977},
{"f_4958:srfi_69_scm",(void*)f_4958},
{"f_4965:srfi_69_scm",(void*)f_4965},
{"f_4892:srfi_69_scm",(void*)f_4892},
{"f_4904:srfi_69_scm",(void*)f_4904},
{"f_4920:srfi_69_scm",(void*)f_4920},
{"f_4948:srfi_69_scm",(void*)f_4948},
{"f_4827:srfi_69_scm",(void*)f_4827},
{"f_4839:srfi_69_scm",(void*)f_4839},
{"f_4862:srfi_69_scm",(void*)f_4862},
{"f_4875:srfi_69_scm",(void*)f_4875},
{"f_4849:srfi_69_scm",(void*)f_4849},
{"f_4762:srfi_69_scm",(void*)f_4762},
{"f_4777:srfi_69_scm",(void*)f_4777},
{"f_4793:srfi_69_scm",(void*)f_4793},
{"f_4697:srfi_69_scm",(void*)f_4697},
{"f_4712:srfi_69_scm",(void*)f_4712},
{"f_4728:srfi_69_scm",(void*)f_4728},
{"f_4652:srfi_69_scm",(void*)f_4652},
{"f_4659:srfi_69_scm",(void*)f_4659},
{"f_4664:srfi_69_scm",(void*)f_4664},
{"f_4680:srfi_69_scm",(void*)f_4680},
{"f_4662:srfi_69_scm",(void*)f_4662},
{"f_4579:srfi_69_scm",(void*)f_4579},
{"f_4594:srfi_69_scm",(void*)f_4594},
{"f_4610:srfi_69_scm",(void*)f_4610},
{"f_4563:srfi_69_scm",(void*)f_4563},
{"f_4577:srfi_69_scm",(void*)f_4577},
{"f_4551:srfi_69_scm",(void*)f_4551},
{"f_4486:srfi_69_scm",(void*)f_4486},
{"f_4498:srfi_69_scm",(void*)f_4498},
{"f_4521:srfi_69_scm",(void*)f_4521},
{"f_4534:srfi_69_scm",(void*)f_4534},
{"f_4508:srfi_69_scm",(void*)f_4508},
{"f_4470:srfi_69_scm",(void*)f_4470},
{"f_4477:srfi_69_scm",(void*)f_4477},
{"f_4374:srfi_69_scm",(void*)f_4374},
{"f_4381:srfi_69_scm",(void*)f_4381},
{"f_4395:srfi_69_scm",(void*)f_4395},
{"f_4421:srfi_69_scm",(void*)f_4421},
{"f_4440:srfi_69_scm",(void*)f_4440},
{"f_4408:srfi_69_scm",(void*)f_4408},
{"f_4243:srfi_69_scm",(void*)f_4243},
{"f_4259:srfi_69_scm",(void*)f_4259},
{"f_4326:srfi_69_scm",(void*)f_4326},
{"f_4345:srfi_69_scm",(void*)f_4345},
{"f_4279:srfi_69_scm",(void*)f_4279},
{"f_4135:srfi_69_scm",(void*)f_4135},
{"f_4151:srfi_69_scm",(void*)f_4151},
{"f_4206:srfi_69_scm",(void*)f_4206},
{"f_4219:srfi_69_scm",(void*)f_4219},
{"f_4166:srfi_69_scm",(void*)f_4166},
{"f_4029:srfi_69_scm",(void*)f_4029},
{"f_4045:srfi_69_scm",(void*)f_4045},
{"f_4099:srfi_69_scm",(void*)f_4099},
{"f_4115:srfi_69_scm",(void*)f_4115},
{"f_4060:srfi_69_scm",(void*)f_4060},
{"f_3832:srfi_69_scm",(void*)f_3832},
{"f_4015:srfi_69_scm",(void*)f_4015},
{"f_4007:srfi_69_scm",(void*)f_4007},
{"f_3860:srfi_69_scm",(void*)f_3860},
{"f_3875:srfi_69_scm",(void*)f_3875},
{"f_3941:srfi_69_scm",(void*)f_3941},
{"f_3971:srfi_69_scm",(void*)f_3971},
{"f_3892:srfi_69_scm",(void*)f_3892},
{"f_3881:srfi_69_scm",(void*)f_3881},
{"f_3820:srfi_69_scm",(void*)f_3820},
{"f_3827:srfi_69_scm",(void*)f_3827},
{"f_3613:srfi_69_scm",(void*)f_3613},
{"f_3810:srfi_69_scm",(void*)f_3810},
{"f_3802:srfi_69_scm",(void*)f_3802},
{"f_3638:srfi_69_scm",(void*)f_3638},
{"f_3653:srfi_69_scm",(void*)f_3653},
{"f_3726:srfi_69_scm",(void*)f_3726},
{"f_3759:srfi_69_scm",(void*)f_3759},
{"f_3762:srfi_69_scm",(void*)f_3762},
{"f_3736:srfi_69_scm",(void*)f_3736},
{"f_3667:srfi_69_scm",(void*)f_3667},
{"f_3703:srfi_69_scm",(void*)f_3703},
{"f_3677:srfi_69_scm",(void*)f_3677},
{"f_3323:srfi_69_scm",(void*)f_3323},
{"f_3565:srfi_69_scm",(void*)f_3565},
{"f_3548:srfi_69_scm",(void*)f_3548},
{"f_3560:srfi_69_scm",(void*)f_3560},
{"f_3325:srfi_69_scm",(void*)f_3325},
{"f_3332:srfi_69_scm",(void*)f_3332},
{"f_3335:srfi_69_scm",(void*)f_3335},
{"f_3539:srfi_69_scm",(void*)f_3539},
{"f_3531:srfi_69_scm",(void*)f_3531},
{"f_3359:srfi_69_scm",(void*)f_3359},
{"f_3374:srfi_69_scm",(void*)f_3374},
{"f_3451:srfi_69_scm",(void*)f_3451},
{"f_3488:srfi_69_scm",(void*)f_3488},
{"f_3491:srfi_69_scm",(void*)f_3491},
{"f_3479:srfi_69_scm",(void*)f_3479},
{"f_3461:srfi_69_scm",(void*)f_3461},
{"f_3388:srfi_69_scm",(void*)f_3388},
{"f_3428:srfi_69_scm",(void*)f_3428},
{"f_3416:srfi_69_scm",(void*)f_3416},
{"f_3398:srfi_69_scm",(void*)f_3398},
{"f_3314:srfi_69_scm",(void*)f_3314},
{"f_3202:srfi_69_scm",(void*)f_3202},
{"f_3212:srfi_69_scm",(void*)f_3212},
{"f_3217:srfi_69_scm",(void*)f_3217},
{"f_3279:srfi_69_scm",(void*)f_3279},
{"f_3300:srfi_69_scm",(void*)f_3300},
{"f_3273:srfi_69_scm",(void*)f_3273},
{"f_3176:srfi_69_scm",(void*)f_3176},
{"f_3183:srfi_69_scm",(void*)f_3183},
{"f_3186:srfi_69_scm",(void*)f_3186},
{"f_3109:srfi_69_scm",(void*)f_3109},
{"f_3132:srfi_69_scm",(void*)f_3132},
{"f_3148:srfi_69_scm",(void*)f_3148},
{"f_3119:srfi_69_scm",(void*)f_3119},
{"f_3189:srfi_69_scm",(void*)f_3189},
{"f_3082:srfi_69_scm",(void*)f_3082},
{"f_3070:srfi_69_scm",(void*)f_3070},
{"f_3061:srfi_69_scm",(void*)f_3061},
{"f_3052:srfi_69_scm",(void*)f_3052},
{"f_3043:srfi_69_scm",(void*)f_3043},
{"f_3034:srfi_69_scm",(void*)f_3034},
{"f_3025:srfi_69_scm",(void*)f_3025},
{"f_3016:srfi_69_scm",(void*)f_3016},
{"f_3007:srfi_69_scm",(void*)f_3007},
{"f_3001:srfi_69_scm",(void*)f_3001},
{"f_2638:srfi_69_scm",(void*)f_2638},
{"f_2991:srfi_69_scm",(void*)f_2991},
{"f_2994:srfi_69_scm",(void*)f_2994},
{"f_2716:srfi_69_scm",(void*)f_2716},
{"f_2971:srfi_69_scm",(void*)f_2971},
{"f_2974:srfi_69_scm",(void*)f_2974},
{"f_2719:srfi_69_scm",(void*)f_2719},
{"f_2939:srfi_69_scm",(void*)f_2939},
{"f_2945:srfi_69_scm",(void*)f_2945},
{"f_2722:srfi_69_scm",(void*)f_2722},
{"f_2757:srfi_69_scm",(void*)f_2757},
{"f_2778:srfi_69_scm",(void*)f_2778},
{"f_2784:srfi_69_scm",(void*)f_2784},
{"f_2876:srfi_69_scm",(void*)f_2876},
{"f_2879:srfi_69_scm",(void*)f_2879},
{"f_2851:srfi_69_scm",(void*)f_2851},
{"f_2854:srfi_69_scm",(void*)f_2854},
{"f_2841:srfi_69_scm",(void*)f_2841},
{"f_2823:srfi_69_scm",(void*)f_2823},
{"f_2810:srfi_69_scm",(void*)f_2810},
{"f_2800:srfi_69_scm",(void*)f_2800},
{"f_2787:srfi_69_scm",(void*)f_2787},
{"f_2768:srfi_69_scm",(void*)f_2768},
{"f_2725:srfi_69_scm",(void*)f_2725},
{"f_2728:srfi_69_scm",(void*)f_2728},
{"f_2732:srfi_69_scm",(void*)f_2732},
{"f_2748:srfi_69_scm",(void*)f_2748},
{"f_2640:srfi_69_scm",(void*)f_2640},
{"f_2607:srfi_69_scm",(void*)f_2607},
{"f_2611:srfi_69_scm",(void*)f_2611},
{"f_2577:srfi_69_scm",(void*)f_2577},
{"f_2583:srfi_69_scm",(void*)f_2583},
{"f_2450:srfi_69_scm",(void*)f_2450},
{"f_2515:srfi_69_scm",(void*)f_2515},
{"f_2506:srfi_69_scm",(void*)f_2506},
{"f_2487:srfi_69_scm",(void*)f_2487},
{"f_2491:srfi_69_scm",(void*)f_2491},
{"f_2494:srfi_69_scm",(void*)f_2494},
{"f_2466:srfi_69_scm",(void*)f_2466},
{"f_2325:srfi_69_scm",(void*)f_2325},
{"f_2390:srfi_69_scm",(void*)f_2390},
{"f_2381:srfi_69_scm",(void*)f_2381},
{"f_2362:srfi_69_scm",(void*)f_2362},
{"f_2366:srfi_69_scm",(void*)f_2366},
{"f_2369:srfi_69_scm",(void*)f_2369},
{"f_2341:srfi_69_scm",(void*)f_2341},
{"f_2276:srfi_69_scm",(void*)f_2276},
{"f_2280:srfi_69_scm",(void*)f_2280},
{"f_2286:srfi_69_scm",(void*)f_2286},
{"f_1942:srfi_69_scm",(void*)f_1942},
{"f_2041:srfi_69_scm",(void*)f_2041},
{"f_2254:srfi_69_scm",(void*)f_2254},
{"f_2233:srfi_69_scm",(void*)f_2233},
{"f_2225:srfi_69_scm",(void*)f_2225},
{"f_2204:srfi_69_scm",(void*)f_2204},
{"f_2178:srfi_69_scm",(void*)f_2178},
{"f_2010:srfi_69_scm",(void*)f_2010},
{"f_2026:srfi_69_scm",(void*)f_2026},
{"f_1945:srfi_69_scm",(void*)f_1945},
{"f_1962:srfi_69_scm",(void*)f_1962},
{"f_1996:srfi_69_scm",(void*)f_1996},
{"f_1894:srfi_69_scm",(void*)f_1894},
{"f_1898:srfi_69_scm",(void*)f_1898},
{"f_1883:srfi_69_scm",(void*)f_1883},
{"f_1904:srfi_69_scm",(void*)f_1904},
{"f_1703:srfi_69_scm",(void*)f_1703},
{"f_1707:srfi_69_scm",(void*)f_1707},
{"f_1713:srfi_69_scm",(void*)f_1713},
{"f_1592:srfi_69_scm",(void*)f_1592},
{"f_1596:srfi_69_scm",(void*)f_1596},
{"f_1599:srfi_69_scm",(void*)f_1599},
{"f_1566:srfi_69_scm",(void*)f_1566},
{"f_1573:srfi_69_scm",(void*)f_1573},
{"f_1515:srfi_69_scm",(void*)f_1515},
{"f_1519:srfi_69_scm",(void*)f_1519},
{"f_1467:srfi_69_scm",(void*)f_1467},
{"f_1471:srfi_69_scm",(void*)f_1471},
{"f_1477:srfi_69_scm",(void*)f_1477},
{"f_1331:srfi_69_scm",(void*)f_1331},
{"f_1335:srfi_69_scm",(void*)f_1335},
{"f_1338:srfi_69_scm",(void*)f_1338},
{"f_1440:srfi_69_scm",(void*)f_1440},
{"f_1344:srfi_69_scm",(void*)f_1344},
{"f_1325:srfi_69_scm",(void*)f_1325},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
