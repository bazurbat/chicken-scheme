/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-28 22:55
   Version 4.1.4 - SVN rev. 15427
   linux-unix-gnu-x86 [ ptables applyhook ]
   compiled 2009-08-13 on x (Linux)
   command line: batch-driver.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature debugbuild -scrutinize -types ./types.db -no-lambda-info -local -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[399];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1053)
static void C_ccall f_1053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1057)
static void C_ccall f_1057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1065)
static void C_ccall f_1065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1119)
static void C_ccall f_1119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_fcall f_1128(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_fcall f_1578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1581)
static void C_fcall f_1581(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_fcall f_1599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1602)
static void C_fcall f_1602(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_fcall f_1608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_fcall f_1614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_fcall f_1617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_fcall f_1620(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1623)
static void C_fcall f_1623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_fcall f_1626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_fcall f_1633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_fcall f_1636(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_fcall f_1639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_fcall f_1642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_fcall f_1645(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_fcall f_1648(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_fcall f_1651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_fcall f_1654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_fcall f_1657(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_fcall f_1663(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_fcall f_1669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3300)
static void C_ccall f_3300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_fcall f_1703(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1706)
static void C_fcall f_1706(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_fcall f_1709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static void C_fcall f_1712(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3203)
static void C_fcall f_3203(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_fcall f_3124(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3113)
static void C_ccall f_3113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_fcall f_3082(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_fcall f_3049(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1757)
static void C_ccall f_1757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_fcall f_1764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_fcall f_1798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_fcall f_1828(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_fcall f_2793(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_fcall f_1904(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_fcall f_1913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_fcall f_2597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_fcall f_2451(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2429)
static void C_ccall f_2429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_fcall f_1972(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_fcall f_1975(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_fcall f_2325(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_fcall f_2293(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_fcall f_2013(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f3831)
static void C_ccall f3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1499)
static void C_fcall f_1499(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1529)
static void C_fcall f_1529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_fcall f_1524(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1501)
static void C_fcall f_1501(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_fcall f_1493(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1464)
static void C_fcall f_1464(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static C_word C_fcall f_1454(C_word t0);
C_noret_decl(f_1424)
static void C_fcall f_1424(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1430)
static void C_fcall f_1430(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1344)
static void C_fcall f_1344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1305)
static void C_fcall f_1305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_fcall f_1260(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_fcall f_1272(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_fcall f_1236(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1252)
static void C_ccall f_1252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_fcall f_1214(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1221)
static void C_ccall f_1221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_fcall f_1190(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1206)
static void C_ccall f_1206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_fcall f_1175(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_fcall f_1070(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1128)
static void C_fcall trf_1128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1128(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1128(t0,t1);}

C_noret_decl(trf_1578)
static void C_fcall trf_1578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1578(t0,t1);}

C_noret_decl(trf_1581)
static void C_fcall trf_1581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1581(t0,t1);}

C_noret_decl(trf_1599)
static void C_fcall trf_1599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1599(t0,t1);}

C_noret_decl(trf_1602)
static void C_fcall trf_1602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1602(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1602(t0,t1);}

C_noret_decl(trf_1608)
static void C_fcall trf_1608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1608(t0,t1);}

C_noret_decl(trf_1614)
static void C_fcall trf_1614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1614(t0,t1);}

C_noret_decl(trf_1617)
static void C_fcall trf_1617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1617(t0,t1);}

C_noret_decl(trf_1620)
static void C_fcall trf_1620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1620(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1620(t0,t1);}

C_noret_decl(trf_1623)
static void C_fcall trf_1623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1623(t0,t1);}

C_noret_decl(trf_1626)
static void C_fcall trf_1626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1626(t0,t1);}

C_noret_decl(trf_1633)
static void C_fcall trf_1633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1633(t0,t1);}

C_noret_decl(trf_1636)
static void C_fcall trf_1636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1636(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1636(t0,t1);}

C_noret_decl(trf_1639)
static void C_fcall trf_1639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1639(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1639(t0,t1);}

C_noret_decl(trf_1642)
static void C_fcall trf_1642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1642(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1642(t0,t1);}

C_noret_decl(trf_1645)
static void C_fcall trf_1645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1645(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1645(t0,t1);}

C_noret_decl(trf_1648)
static void C_fcall trf_1648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1648(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1648(t0,t1);}

C_noret_decl(trf_1651)
static void C_fcall trf_1651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1651(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1651(t0,t1);}

C_noret_decl(trf_1654)
static void C_fcall trf_1654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1654(t0,t1);}

C_noret_decl(trf_1657)
static void C_fcall trf_1657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1657(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1657(t0,t1);}

C_noret_decl(trf_1663)
static void C_fcall trf_1663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1663(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1663(t0,t1);}

C_noret_decl(trf_1669)
static void C_fcall trf_1669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1669(t0,t1);}

C_noret_decl(trf_1703)
static void C_fcall trf_1703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1703(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1703(t0,t1);}

C_noret_decl(trf_1706)
static void C_fcall trf_1706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1706(t0,t1);}

C_noret_decl(trf_1709)
static void C_fcall trf_1709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1709(t0,t1);}

C_noret_decl(trf_1712)
static void C_fcall trf_1712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1712(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1712(t0,t1);}

C_noret_decl(trf_3203)
static void C_fcall trf_3203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3203(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3203(t0,t1,t2);}

C_noret_decl(trf_3124)
static void C_fcall trf_3124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3124(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3124(t0,t1,t2);}

C_noret_decl(trf_3082)
static void C_fcall trf_3082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3082(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3082(t0,t1,t2);}

C_noret_decl(trf_3049)
static void C_fcall trf_3049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3049(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3049(t0,t1,t2);}

C_noret_decl(trf_1764)
static void C_fcall trf_1764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1764(t0,t1);}

C_noret_decl(trf_1798)
static void C_fcall trf_1798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1798(t0,t1);}

C_noret_decl(trf_1828)
static void C_fcall trf_1828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1828(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1828(t0,t1);}

C_noret_decl(trf_2793)
static void C_fcall trf_2793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2793(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2793(t0,t1,t2);}

C_noret_decl(trf_2848)
static void C_fcall trf_2848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2848(t0,t1,t2);}

C_noret_decl(trf_1904)
static void C_fcall trf_1904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1904(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1904(t0,t1);}

C_noret_decl(trf_1913)
static void C_fcall trf_1913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1913(t0,t1);}

C_noret_decl(trf_2597)
static void C_fcall trf_2597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2597(t0,t1);}

C_noret_decl(trf_2539)
static void C_fcall trf_2539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2539(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2539(t0,t1,t2);}

C_noret_decl(trf_2451)
static void C_fcall trf_2451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2451(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2451(t0,t1,t2);}

C_noret_decl(trf_1972)
static void C_fcall trf_1972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1972(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1972(t0,t1);}

C_noret_decl(trf_1975)
static void C_fcall trf_1975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1975(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1975(t0,t1);}

C_noret_decl(trf_2325)
static void C_fcall trf_2325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2325(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2325(t0,t1,t2);}

C_noret_decl(trf_2293)
static void C_fcall trf_2293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2293(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2293(t0,t1,t2);}

C_noret_decl(trf_2013)
static void C_fcall trf_2013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2013(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2013(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1499)
static void C_fcall trf_1499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1499(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1499(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1529)
static void C_fcall trf_1529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1529(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1529(t0,t1);}

C_noret_decl(trf_1524)
static void C_fcall trf_1524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1524(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1524(t0,t1,t2);}

C_noret_decl(trf_1501)
static void C_fcall trf_1501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1501(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1501(t0,t1,t2,t3);}

C_noret_decl(trf_1493)
static void C_fcall trf_1493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1493(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1493(t0,t1,t2);}

C_noret_decl(trf_1464)
static void C_fcall trf_1464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1464(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1464(t0,t1,t2);}

C_noret_decl(trf_1424)
static void C_fcall trf_1424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1424(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1424(t0,t1,t2);}

C_noret_decl(trf_1430)
static void C_fcall trf_1430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1430(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1430(t0,t1,t2);}

C_noret_decl(trf_1344)
static void C_fcall trf_1344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1344(t0,t1);}

C_noret_decl(trf_1305)
static void C_fcall trf_1305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1305(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1305(t0,t1);}

C_noret_decl(trf_1260)
static void C_fcall trf_1260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1260(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1260(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1272)
static void C_fcall trf_1272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1272(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1272(t0,t1,t2);}

C_noret_decl(trf_1236)
static void C_fcall trf_1236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1236(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1236(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1214)
static void C_fcall trf_1214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1214(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1214(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1190)
static void C_fcall trf_1190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1190(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1190(t0,t1,t2,t3);}

C_noret_decl(trf_1175)
static void C_fcall trf_1175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1175(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1175(t0,t1,t2,t3);}

C_noret_decl(trf_1070)
static void C_fcall trf_1070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1070(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1070(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3105)){
C_save(t1);
C_rereclaim2(3105*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,399);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],17,"user-options-pass");
lf[3]=C_h_intern(&lf[3],14,"user-read-pass");
lf[4]=C_h_intern(&lf[4],22,"user-preprocessor-pass");
lf[5]=C_h_intern(&lf[5],9,"user-pass");
lf[6]=C_h_intern(&lf[6],23,"user-post-analysis-pass");
lf[7]=C_h_intern(&lf[7],19,"compile-source-file");
lf[8]=C_h_intern(&lf[8],4,"quit");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[11]=C_h_intern(&lf[11],12,"explicit-use");
lf[12]=C_h_intern(&lf[12],26,"\010compilerexplicit-use-flag");
lf[13]=C_h_intern(&lf[13],12,"\004coredeclare");
lf[14]=C_h_intern(&lf[14],7,"verbose");
lf[15]=C_h_intern(&lf[15],11,"output-file");
lf[16]=C_h_intern(&lf[16],36,"\010compilerdefault-optimization-passes");
lf[17]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[18]=C_h_intern(&lf[18],7,"profile");
lf[19]=C_h_intern(&lf[19],12,"profile-name");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[21]=C_h_intern(&lf[21],9,"heap-size");
lf[22]=C_h_intern(&lf[22],17,"heap-initial-size");
lf[23]=C_h_intern(&lf[23],11,"heap-growth");
lf[24]=C_h_intern(&lf[24],14,"heap-shrinkage");
lf[25]=C_h_intern(&lf[25],13,"keyword-style");
lf[26]=C_h_intern(&lf[26],4,"unit");
lf[27]=C_h_intern(&lf[27],12,"analyze-only");
lf[28]=C_h_intern(&lf[28],7,"dynamic");
lf[29]=C_h_intern(&lf[29],7,"nursery");
lf[30]=C_h_intern(&lf[30],10,"stack-size");
lf[31]=C_h_intern(&lf[31],19,"\003sysstandard-output");
lf[32]=C_h_intern(&lf[32],16,"\003sysflush-output");
lf[33]=C_h_intern(&lf[33],19,"\003syswrite-char/port");
lf[34]=C_h_intern(&lf[34],7,"fprintf");
lf[35]=C_h_intern(&lf[35],26,"\010compilerdebugging-chicken");
lf[36]=C_h_intern(&lf[36],7,"display");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\010pass: ~a");
lf[38]=C_h_intern(&lf[38],19,"\010compilerdump-nodes");
lf[39]=C_h_intern(&lf[39],12,"pretty-print");
lf[40]=C_h_intern(&lf[40],30,"\010compilerbuild-expression-tree");
lf[41]=C_h_intern(&lf[41],34,"\010compilerdisplay-analysis-database");
lf[42]=C_h_intern(&lf[42],5,"write");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\013(iteration ");
lf[44]=C_h_intern(&lf[44],19,"\003syshash-table-set!");
lf[45]=C_h_intern(&lf[45],24,"\003sysline-number-database");
lf[46]=C_h_intern(&lf[46],10,"alist-cons");
lf[47]=C_h_intern(&lf[47],18,"\003syshash-table-ref");
lf[48]=C_h_intern(&lf[48],9,"list-info");
lf[49]=C_h_intern(&lf[49],26,"\003sysdefault-read-info-hook");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[51]=C_h_intern(&lf[51],9,"substring");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\003: \011");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\030milliseconds needed for ");
lf[54]=C_h_intern(&lf[54],8,"\003sysread");
lf[55]=C_h_intern(&lf[55],12,"\010compilerget");
lf[56]=C_h_intern(&lf[56],13,"\010compilerput!");
lf[57]=C_h_intern(&lf[57],27,"\010compileranalyze-expression");
lf[58]=C_h_intern(&lf[58],9,"\003syserror");
lf[59]=C_h_intern(&lf[59],1,"D");
lf[60]=C_h_intern(&lf[60],25,"\010compilerimport-libraries");
lf[61]=C_h_intern(&lf[61],26,"\010compilerdisabled-warnings");
lf[62]=C_h_intern(&lf[62],16,"emit-inline-file");
lf[63]=C_h_intern(&lf[63],12,"inline-limit");
lf[64]=C_h_intern(&lf[64],21,"\010compilerverbose-mode");
lf[65]=C_h_intern(&lf[65],31,"\003sysread-error-with-line-number");
lf[66]=C_h_intern(&lf[66],21,"\003sysinclude-pathnames");
lf[67]=C_h_intern(&lf[67],19,"\000compiler-extension");
lf[68]=C_h_intern(&lf[68],12,"\003sysfeatures");
lf[69]=C_h_intern(&lf[69],10,"\000compiling");
lf[70]=C_h_intern(&lf[70],28,"\003sysexplicit-library-modules");
lf[71]=C_h_intern(&lf[71],25,"\010compilertarget-heap-size");
lf[72]=C_h_intern(&lf[72],33,"\010compilertarget-initial-heap-size");
lf[73]=C_h_intern(&lf[73],27,"\010compilertarget-heap-growth");
lf[74]=C_h_intern(&lf[74],30,"\010compilertarget-heap-shrinkage");
lf[75]=C_h_intern(&lf[75],26,"\010compilertarget-stack-size");
lf[76]=C_h_intern(&lf[76],8,"no-trace");
lf[77]=C_h_intern(&lf[77],24,"\010compileremit-trace-info");
lf[78]=C_h_intern(&lf[78],29,"disable-stack-overflow-checks");
lf[79]=C_h_intern(&lf[79],40,"\010compilerdisable-stack-overflow-checking");
lf[80]=C_h_intern(&lf[80],7,"version");
lf[81]=C_h_intern(&lf[81],7,"newline");
lf[82]=C_h_intern(&lf[82],22,"\010compilerprint-version");
lf[83]=C_h_intern(&lf[83],4,"help");
lf[84]=C_h_intern(&lf[84],20,"\010compilerprint-usage");
lf[85]=C_h_intern(&lf[85],7,"release");
lf[86]=C_h_intern(&lf[86],15,"chicken-version");
lf[87]=C_h_intern(&lf[87],24,"\010compilersource-filename");
lf[88]=C_h_intern(&lf[88],28,"\010compilerprofile-lambda-list");
lf[89]=C_h_intern(&lf[89],31,"\010compilerline-number-database-2");
lf[90]=C_h_intern(&lf[90],4,"node");
lf[91]=C_h_intern(&lf[91],6,"lambda");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[93]=C_h_intern(&lf[93],23,"\010compilerconstant-table");
lf[94]=C_h_intern(&lf[94],21,"\010compilerinline-table");
lf[95]=C_h_intern(&lf[95],23,"\010compilerfirst-analysis");
lf[96]=C_h_intern(&lf[96],41,"\010compilerperform-high-level-optimizations");
lf[97]=C_h_intern(&lf[97],37,"\010compilerinline-substitutions-enabled");
lf[98]=C_h_intern(&lf[98],22,"optimize-leaf-routines");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[100]=C_h_intern(&lf[100],34,"\010compilertransform-direct-lambdas!");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[102]=C_h_intern(&lf[102],4,"leaf");
lf[103]=C_h_intern(&lf[103],18,"\010compilerdebugging");
lf[104]=C_h_intern(&lf[104],1,"p");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[107]=C_h_intern(&lf[107],1,"5");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[110]=C_h_intern(&lf[110],36,"\010compilerprepare-for-code-generation");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\025compilation finished.");
lf[112]=C_h_intern(&lf[112],30,"\010compilercompiler-cleanup-hook");
lf[113]=C_h_intern(&lf[113],1,"t");
lf[114]=C_h_intern(&lf[114],17,"\003sysdisplay-times");
lf[115]=C_h_intern(&lf[115],14,"\003sysstop-timer");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[117]=C_h_intern(&lf[117],17,"close-output-port");
lf[118]=C_h_intern(&lf[118],22,"\010compilergenerate-code");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\023generating `~A\047 ...");
lf[120]=C_h_intern(&lf[120],16,"open-output-file");
lf[121]=C_h_intern(&lf[121],19,"current-output-port");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[124]=C_h_intern(&lf[124],1,"9");
lf[125]=C_h_intern(&lf[125],4,"exit");
lf[126]=C_h_intern(&lf[126],20,"\003syswarnings-enabled");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[129]=C_h_intern(&lf[129],1,"8");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[131]=C_h_intern(&lf[131],35,"\010compilerperform-closure-conversion");
lf[132]=C_h_intern(&lf[132],27,"\010compilerinline-output-file");
lf[133]=C_h_intern(&lf[133],32,"\010compileremit-global-inline-file");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000&Generating global inline file `~a\047 ...");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[136]=C_h_intern(&lf[136],1,"7");
lf[137]=C_h_intern(&lf[137],1,"s");
lf[138]=C_h_intern(&lf[138],33,"\010compilerprint-program-statistics");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[140]=C_h_intern(&lf[140],1,"4");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[142]=C_h_intern(&lf[142],1,"v");
lf[143]=C_h_intern(&lf[143],25,"\010compilerdump-global-refs");
lf[144]=C_h_intern(&lf[144],1,"d");
lf[145]=C_h_intern(&lf[145],29,"\010compilerdump-defined-globals");
lf[146]=C_h_intern(&lf[146],1,"u");
lf[147]=C_h_intern(&lf[147],31,"\010compilerdump-undefined-globals");
lf[148]=C_h_intern(&lf[148],3,"opt");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[150]=C_h_intern(&lf[150],1,"3");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[152]=C_h_intern(&lf[152],31,"\010compilerperform-cps-conversion");
lf[153]=C_h_intern(&lf[153],6,"unsafe");
lf[154]=C_h_intern(&lf[154],34,"\010compilerscan-toplevel-assignments");
lf[155]=C_h_intern(&lf[155],24,"\010compilerinline-globally");
lf[156]=C_h_intern(&lf[156],23,"\010compilerinline-locally");
lf[157]=C_h_intern(&lf[157],25,"\010compilerload-inline-file");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[159]=C_h_intern(&lf[159],19,"consult-inline-file");
lf[160]=C_h_intern(&lf[160],28,"\010compilerenable-inline-files");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[162]=C_h_intern(&lf[162],12,"file-exists\077");
lf[163]=C_h_intern(&lf[163],28,"\003sysresolve-include-filename");
lf[164]=C_h_intern(&lf[164],13,"make-pathname");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[166]=C_h_intern(&lf[166],14,"symbol->string");
lf[167]=C_h_intern(&lf[167],11,"concatenate");
lf[168]=C_h_intern(&lf[168],7,"\003sysmap");
lf[169]=C_h_intern(&lf[169],3,"cdr");
lf[170]=C_h_intern(&lf[170],2,"pp");
lf[171]=C_h_intern(&lf[171],1,"M");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[173]=C_h_intern(&lf[173],12,"vector->list");
lf[174]=C_h_intern(&lf[174],26,"\010compilerfile-requirements");
lf[175]=C_h_intern(&lf[175],26,"\010compilerdo-lambda-lifting");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[177]=C_h_intern(&lf[177],1,"L");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[179]=C_h_intern(&lf[179],32,"\010compilerperform-lambda-lifting!");
lf[180]=C_h_intern(&lf[180],22,"\010compilerdo-scrutinize");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\032pre-analysis (lambda-lift)");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[183]=C_h_intern(&lf[183],1,"0");
lf[184]=C_h_intern(&lf[184],4,"lift");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\010scrutiny");
lf[186]=C_h_intern(&lf[186],19,"\010compilerscrutinize");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\023performing scrutiny");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[190]=C_h_intern(&lf[190],8,"scrutiny");
lf[191]=C_h_intern(&lf[191],27,"\010compilerload-type-database");
lf[192]=C_h_intern(&lf[192],5,"types");
lf[193]=C_h_intern(&lf[193],17,"ignore-repository");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\010types.db");
lf[195]=C_h_intern(&lf[195],37,"\010compilerinitialize-analysis-database");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\021initial node tree");
lf[197]=C_h_intern(&lf[197],1,"T");
lf[198]=C_h_intern(&lf[198],25,"\010compilerbuild-node-graph");
lf[199]=C_h_intern(&lf[199],32,"\010compilercanonicalize-begin-body");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\014User pass...");
lf[202]=C_h_intern(&lf[202],12,"check-syntax");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[204]=C_h_intern(&lf[204],1,"2");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[206]=C_h_intern(&lf[206],25,"\010compilercompiler-warning");
lf[207]=C_h_intern(&lf[207],5,"style");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000Icompiling extensions in unsafe mode is bad practice and should be avoided");
lf[209]=C_h_intern(&lf[209],8,"feature\077");
lf[210]=C_h_intern(&lf[210],19,"compiling-extension");
lf[211]=C_h_intern(&lf[211],18,"\010compilerunit-name");
lf[212]=C_h_intern(&lf[212],5,"usage");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[214]=C_h_intern(&lf[214],37,"\010compilerdisplay-line-number-database");
lf[215]=C_h_intern(&lf[215],1,"n");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[217]=C_h_intern(&lf[217],32,"\010compilerdisplay-real-name-table");
lf[218]=C_h_intern(&lf[218],1,"N");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\002\011\011");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[222]=C_h_intern(&lf[222],35,"\010compilercompiler-syntax-statistics");
lf[223]=C_h_intern(&lf[223],1,"o");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\030applied compiler syntax:");
lf[225]=C_h_intern(&lf[225],6,"append");
lf[226]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[227]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[228]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[229]=C_h_intern(&lf[229],5,"quote");
lf[230]=C_h_intern(&lf[230],33,"\010compilerprofile-info-vector-name");
lf[231]=C_h_intern(&lf[231],28,"\003sysset-profile-info-vector!");
lf[232]=C_h_intern(&lf[232],21,"\010compileremit-profile");
lf[233]=C_h_intern(&lf[233],25,"\003sysregister-profile-info");
lf[234]=C_h_intern(&lf[234],4,"set!");
lf[235]=C_h_intern(&lf[235],13,"\004corecallunit");
lf[236]=C_h_intern(&lf[236],19,"\010compilerused-units");
lf[237]=C_h_intern(&lf[237],28,"\010compilerimmutable-constants");
lf[238]=C_h_intern(&lf[238],6,"gensym");
lf[239]=C_h_intern(&lf[239],32,"\010compilercanonicalize-expression");
lf[240]=C_h_intern(&lf[240],4,"uses");
lf[241]=C_h_intern(&lf[241],7,"declare");
lf[242]=C_h_intern(&lf[242],10,"\003sysappend");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[244]=C_h_intern(&lf[244],1,"1");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\032User preprocessing pass...");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\021User read pass...");
lf[247]=C_h_intern(&lf[247],21,"\010compilerstring->expr");
lf[248]=C_h_intern(&lf[248],7,"reverse");
lf[249]=C_h_intern(&lf[249],27,"\003syscurrent-source-filename");
lf[250]=C_h_intern(&lf[250],33,"\010compilerclose-checked-input-file");
lf[251]=C_h_intern(&lf[251],16,"\003sysdynamic-wind");
lf[252]=C_h_intern(&lf[252],34,"\010compilercheck-and-open-input-file");
lf[253]=C_h_intern(&lf[253],8,"epilogue");
lf[254]=C_h_intern(&lf[254],8,"prologue");
lf[255]=C_h_intern(&lf[255],8,"postlude");
lf[256]=C_h_intern(&lf[256],7,"prelude");
lf[257]=C_h_intern(&lf[257],11,"make-vector");
lf[258]=C_h_intern(&lf[258],34,"\010compilerline-number-database-size");
lf[259]=C_h_intern(&lf[259],1,"r");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\022compiling `~a\047 ...");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[266]=C_h_intern(&lf[266],5,"-help");
lf[267]=C_h_intern(&lf[267],1,"h");
lf[268]=C_h_intern(&lf[268],2,"-h");
lf[269]=C_h_intern(&lf[269],33,"\010compilerload-identifier-database");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[271]=C_h_intern(&lf[271],18,"accumulate-profile");
lf[272]=C_h_intern(&lf[272],28,"\010compilerprofiled-procedures");
lf[273]=C_h_intern(&lf[273],3,"all");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\024Generating ~aprofile");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[277]=C_h_intern(&lf[277],39,"\010compilerdefault-profiling-declarations");
lf[278]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\022debugging info: ~A");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[282]=C_h_intern(&lf[282],21,"no-usual-integrations");
lf[283]=C_h_intern(&lf[283],17,"standard-bindings");
lf[284]=C_h_intern(&lf[284],34,"\010compilerdefault-standard-bindings");
lf[285]=C_h_intern(&lf[285],17,"extended-bindings");
lf[286]=C_h_intern(&lf[286],34,"\010compilerdefault-extended-bindings");
lf[287]=C_h_intern(&lf[287],1,"m");
lf[288]=C_h_intern(&lf[288],14,"set-gc-report!");
lf[289]=C_h_intern(&lf[289],42,"\010compilerdefault-default-target-stack-size");
lf[290]=C_h_intern(&lf[290],41,"\010compilerdefault-default-target-heap-size");
lf[291]=C_h_intern(&lf[291],14,"compile-syntax");
lf[292]=C_h_intern(&lf[292],25,"\003sysenable-runtime-macros");
lf[293]=C_h_intern(&lf[293],22,"\004corerequire-extension");
lf[294]=C_h_intern(&lf[294],14,"string->symbol");
lf[295]=C_h_intern(&lf[295],17,"require-extension");
lf[296]=C_h_intern(&lf[296],16,"static-extension");
lf[297]=C_h_intern(&lf[297],28,"\010compilerpostponed-initforms");
lf[298]=C_h_intern(&lf[298],6,"delete");
lf[299]=C_h_intern(&lf[299],3,"eq\077");
lf[300]=C_h_intern(&lf[300],4,"load");
lf[301]=C_h_intern(&lf[301],12,"load-verbose");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\036Loading compiler extensions...");
lf[303]=C_h_intern(&lf[303],6,"extend");
lf[304]=C_h_intern(&lf[304],17,"register-feature!");
lf[305]=C_h_intern(&lf[305],12,"string-split");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[307]=C_h_intern(&lf[307],10,"append-map");
lf[308]=C_h_intern(&lf[308],7,"feature");
lf[309]=C_h_intern(&lf[309],38,"no-procedure-checks-for-usual-bindings");
lf[310]=C_h_intern(&lf[310],8,"\003sysput!");
lf[311]=C_h_intern(&lf[311],21,"\010compileralways-bound");
lf[312]=C_h_intern(&lf[312],34,"\010compileralways-bound-to-procedure");
lf[313]=C_h_intern(&lf[313],19,"no-procedure-checks");
lf[314]=C_h_intern(&lf[314],28,"\010compilerno-procedure-checks");
lf[315]=C_h_intern(&lf[315],15,"no-bound-checks");
lf[316]=C_h_intern(&lf[316],24,"\010compilerno-bound-checks");
lf[317]=C_h_intern(&lf[317],14,"no-argc-checks");
lf[318]=C_h_intern(&lf[318],23,"\010compilerno-argc-checks");
lf[319]=C_h_intern(&lf[319],20,"keep-shadowed-macros");
lf[320]=C_h_intern(&lf[320],33,"\010compilerundefine-shadowed-macros");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[322]=C_h_intern(&lf[322],23,"\010compilerchop-separator");
lf[323]=C_h_intern(&lf[323],12,"include-path");
lf[324]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[325]=C_h_intern(&lf[325],13,"symbol-escape");
lf[326]=C_h_intern(&lf[326],20,"parentheses-synonyms");
lf[327]=C_h_intern(&lf[327],5,"\000none");
lf[328]=C_h_intern(&lf[328],14,"case-sensitive");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000.Disabled the Chicken extensions to R5RS syntax");
lf[330]=C_h_intern(&lf[330],16,"no-symbol-escape");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000$Disabled support for escaped symbols");
lf[332]=C_h_intern(&lf[332],23,"no-parenthesis-synonyms");
lf[333]=C_h_intern(&lf[333],20,"parenthesis-synonyms");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000)Disabled support for parenthesis synonyms");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[336]=C_h_intern(&lf[336],7,"\000prefix");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[339]=C_h_intern(&lf[339],7,"\000suffix");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[341]=C_h_intern(&lf[341],17,"compress-literals");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[343]=C_h_intern(&lf[343],16,"case-insensitive");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000,Identifiers and symbols are case insensitive");
lf[345]=C_h_intern(&lf[345],24,"\010compilerinline-max-size");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[347]=C_h_intern(&lf[347],26,"\010compilerlocal-definitions");
lf[348]=C_h_intern(&lf[348],6,"inline");
lf[349]=C_h_intern(&lf[349],30,"emit-external-prototypes-first");
lf[350]=C_h_intern(&lf[350],30,"\010compilerexternal-protos-first");
lf[351]=C_h_intern(&lf[351],5,"block");
lf[352]=C_h_intern(&lf[352],26,"\010compilerblock-compilation");
lf[353]=C_h_intern(&lf[353],17,"fixnum-arithmetic");
lf[354]=C_h_intern(&lf[354],11,"number-type");
lf[355]=C_h_intern(&lf[355],6,"fixnum");
lf[356]=C_h_intern(&lf[356],18,"disable-interrupts");
lf[357]=C_h_intern(&lf[357],28,"\010compilerinsert-timer-checks");
lf[358]=C_h_intern(&lf[358],16,"unsafe-libraries");
lf[359]=C_h_intern(&lf[359],27,"\010compileremit-unsafe-marker");
lf[360]=C_h_intern(&lf[360],11,"no-warnings");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\025Warnings are disabled");
lf[362]=C_h_intern(&lf[362],15,"disable-warning");
lf[363]=C_h_intern(&lf[363],13,"inline-global");
lf[364]=C_h_intern(&lf[364],5,"local");
lf[365]=C_h_intern(&lf[365],18,"no-compiler-syntax");
lf[366]=C_h_intern(&lf[366],32,"\010compilercompiler-syntax-enabled");
lf[367]=C_h_intern(&lf[367],14,"no-lambda-info");
lf[368]=C_h_intern(&lf[368],26,"\010compileremit-closure-info");
lf[369]=C_h_intern(&lf[369],3,"raw");
lf[370]=C_h_intern(&lf[370],12,"emit-exports");
lf[371]=C_h_intern(&lf[371],7,"warning");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[373]=C_h_intern(&lf[373],1,"b");
lf[374]=C_h_intern(&lf[374],15,"\003sysstart-timer");
lf[375]=C_h_intern(&lf[375],10,"scrutinize");
lf[376]=C_h_intern(&lf[376],11,"lambda-lift");
lf[377]=C_h_intern(&lf[377],13,"string-append");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[379]=C_h_intern(&lf[379],19,"emit-import-library");
lf[380]=C_h_intern(&lf[380],16,"\003sysstring->list");
lf[381]=C_h_intern(&lf[381],5,"debug");
lf[382]=C_h_intern(&lf[382],18,"\003sysdload-disabled");
lf[383]=C_h_intern(&lf[383],15,"repository-path");
lf[384]=C_h_intern(&lf[384],30,"\010compilerstandalone-executable");
lf[385]=C_h_intern(&lf[385],29,"\010compilerstring->c-identifier");
lf[386]=C_h_intern(&lf[386],18,"\010compilerstringify");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[389]=C_h_intern(&lf[389],24,"get-environment-variable");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[391]=C_h_intern(&lf[391],9,"to-stdout");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[393]=C_h_intern(&lf[393],13,"pathname-file");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[395]=C_h_intern(&lf[395],29,"\010compilerdefault-declarations");
lf[396]=C_h_intern(&lf[396],30,"\010compilerunits-used-by-default");
lf[397]=C_h_intern(&lf[397],28,"\010compilerinitialize-compiler");
lf[398]=C_h_intern(&lf[398],14,"make-parameter");
C_register_lf2(lf,399,create_ptable());
t2=C_mutate(&lf[0] /* (set! c301 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1029,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1027 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1030 in k1027 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1035,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1033 in k1030 in k1027 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1044,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 38   make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[398]))(3,*((C_word*)lf[398]+1),t2,C_SCHEME_FALSE);}

/* k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1049,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1053,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 39   make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[398]))(3,*((C_word*)lf[398]+1),t3,C_SCHEME_FALSE);}

/* k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1053,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1057,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 40   make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[398]))(3,*((C_word*)lf[398]+1),t3,C_SCHEME_FALSE);}

/* k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1061,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 41   make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[398]))(3,*((C_word*)lf[398]+1),t3,C_SCHEME_FALSE);}

/* k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1061,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1065,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 42   make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[398]))(3,*((C_word*)lf[398]+1),t3,C_SCHEME_FALSE);}

/* k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1065,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate((C_word*)lf[7]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1067,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1067r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1067r(t0,t1,t2,t3);}}

static void C_ccall f_1067r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1070,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1103,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("batch-driver.scm: 55   initialize-compiler");
((C_proc2)C_retrieve_symbol_proc(lf[397]))(2,*((C_word*)lf[397]+1),t5);}

/* k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
t2=(C_word)C_i_memq(lf[11],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[12]+1 /* (set! explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3651,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[12]))){
C_trace("batch-driver.scm: 58   append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),t5,C_retrieve(lf[395]),C_SCHEME_END_OF_LIST);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3666,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#append");
t7=*((C_word*)lf[242]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[396]),C_SCHEME_END_OF_LIST);}}

/* k3664 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3666,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[240],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
C_trace("batch-driver.scm: 58   append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),((C_word*)t0)[2],C_retrieve(lf[395]),t3);}

/* k3649 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[242]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3647,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[13],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[14],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[15],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3614,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 66   option-arg");
f_1070(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[391],((C_word*)t0)[5]))){
t9=t8;
f_1119(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3636,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("batch-driver.scm: 71   pathname-file");
((C_proc3)C_retrieve_symbol_proc(lf[393]))(3,*((C_word*)lf[393]+1),t9,((C_word*)t0)[2]);}
else{
C_trace("batch-driver.scm: 71   make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[164]))(5,*((C_word*)lf[164]+1),t8,C_SCHEME_FALSE,lf[394],lf[392]);}}}}

/* k3634 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 71   make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[164]))(5,*((C_word*)lf[164]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[392]);}

/* k3612 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
C_trace("batch-driver.scm: 68   symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),((C_word*)t0)[2],t1);}
else{
t2=t1;
t3=((C_word*)t0)[2];
f_1119(2,t3,t2);}}

/* k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1122,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3604,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3608,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 72   get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[389]))(3,*((C_word*)lf[389]+1),t4,lf[390]);}

/* k3606 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
C_trace("batch-driver.scm: 72   string-split");
((C_proc4)C_retrieve_symbol_proc(lf[305]))(4,*((C_word*)lf[305]+1),((C_word*)t0)[2],t2,lf[387]);}
else{
C_trace("batch-driver.scm: 72   string-split");
((C_proc4)C_retrieve_symbol_proc(lf[305]))(4,*((C_word*)lf[305]+1),((C_word*)t0)[2],lf[388],lf[387]);}}

/* k3602 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[322]),t1);}

/* k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1122,2,t0,t1);}
t2=C_retrieve(lf[16]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[17];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[18],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1128,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1128(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[271],((C_word*)t0)[8]);
t14=t12;
f_1128(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[19],((C_word*)t0)[8])));}}

/* k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1128(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[92],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1128,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[19],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[20]);
t5=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[28],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_FALSE;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=(C_word)C_i_memq(lf[29],((C_word*)t0)[13]);
t22=(C_truep(t21)?t21:(C_word)C_i_memq(lf[30],((C_word*)t0)[13]));
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1190,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1214,a[2]=t24,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1236,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1260,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1295,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1344,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1464,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1493,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1499,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t29,a[11]=t22,a[12]=t1,a[13]=t33,a[14]=((C_word*)t0)[3],a[15]=t4,a[16]=((C_word*)t0)[4],a[17]=t27,a[18]=t30,a[19]=t26,a[20]=t13,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t23,a[24]=t25,a[25]=t34,a[26]=t32,a[27]=t31,a[28]=t18,a[29]=((C_word*)t0)[6],a[30]=((C_word*)t0)[7],a[31]=((C_word*)t0)[8],a[32]=t20,a[33]=t11,a[34]=((C_word*)t0)[12],a[35]=((C_word*)t0)[13],a[36]=t16,tmp=(C_word)a,a+=37,tmp);
if(C_truep(t12)){
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3577,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3581,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3585,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 169  option-arg");
f_1070(t38,t12);}
else{
t36=t35;
f_1578(t36,C_SCHEME_UNDEFINED);}}

/* k3583 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 169  stringify");
((C_proc3)C_retrieve_symbol_proc(lf[386]))(3,*((C_word*)lf[386]+1),((C_word*)t0)[2],t1);}

/* k3579 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 169  string->c-identifier");
((C_proc3)C_retrieve_symbol_proc(lf[385]))(3,*((C_word*)lf[385]+1),((C_word*)t0)[2],t1);}

/* k3575 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[211]+1 /* (set! unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1578(t3,t2);}

/* k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1578,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=C_retrieve(lf[211]);
if(C_truep(t3)){
if(C_truep(t3)){
t4=C_set_block_item(lf[384] /* standalone-executable */,0,C_SCHEME_FALSE);
t5=t2;
f_1581(t5,t4);}
else{
t4=t2;
f_1581(t4,C_SCHEME_UNDEFINED);}}
else{
if(C_truep(((C_word*)t0)[21])){
t4=C_set_block_item(lf[384] /* standalone-executable */,0,C_SCHEME_FALSE);
t5=t2;
f_1581(t5,t4);}
else{
t4=t2;
f_1581(t4,C_SCHEME_UNDEFINED);}}}

/* k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1581,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[193],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[382] /* dload-disabled */,0,C_SCHEME_TRUE);
C_trace("batch-driver.scm: 174  repository-path");
((C_proc3)C_retrieve_symbol_proc(lf[383]))(3,*((C_word*)lf[383]+1),t2,C_SCHEME_FALSE);}
else{
t3=t2;
f_1584(2,t3,C_SCHEME_UNDEFINED);}}

/* k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3540,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3562,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 180  collect-options");
t5=((C_word*)t0)[18];
f_1424(t5,t4,lf[381]);}

/* k3560 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 176  append-map");
((C_proc4)C_retrieve_symbol_proc(lf[307]))(4,*((C_word*)lf[307]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3539 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3540,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3546,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3558,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("string->list");
t5=C_retrieve(lf[380]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3556 in a3539 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3545 in a3539 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3546,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
C_trace("batch-driver.scm: 178  string->symbol");
((C_proc3)C_retrieve_proc(*((C_word*)lf[294]+1)))(3,*((C_word*)lf[294]+1),t1,t3);}

/* k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1588,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1 /* (set! debugging-chicken ...) */,t1);
t3=(C_word)C_i_memq(lf[59],C_retrieve(lf[35]));
t4=C_mutate(((C_word *)((C_word*)t0)[36])+1,t3);
t5=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3522,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3538,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 186  collect-options");
t8=((C_word*)t0)[18];
f_1424(t8,t7,lf[379]);}

/* k3536 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3521 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3522,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3530,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 184  string->symbol");
((C_proc3)C_retrieve_proc(*((C_word*)lf[294]+1)))(3,*((C_word*)lf[294]+1),t3,t2);}

/* k3528 in a3521 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3534,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 185  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[377]+1)))(4,*((C_word*)lf[377]+1),t2,((C_word*)t0)[2],lf[378]);}

/* k3532 in k3528 in a3521 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3534,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* (set! import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[376],((C_word*)t0)[35]))){
t4=C_set_block_item(lf[175] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t5=t3;
f_1599(t5,t4);}
else{
t4=t3;
f_1599(t4,C_SCHEME_UNDEFINED);}}

/* k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1599,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[375],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[180] /* do-scrutinize */,0,C_SCHEME_TRUE);
t4=t2;
f_1602(t4,t3);}
else{
t3=t2;
f_1602(t3,C_SCHEME_UNDEFINED);}}

/* k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1602(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1602,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[113],C_retrieve(lf[35])))){
C_trace("batch-driver.scm: 189  ##sys#start-timer");
t3=*((C_word*)lf[374]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1605(2,t3,C_SCHEME_UNDEFINED);}}

/* k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[373],C_retrieve(lf[35])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1608(t4,t3);}
else{
t3=t2;
f_1608(t3,C_SCHEME_UNDEFINED);}}

/* k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1608,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[370],((C_word*)t0)[34]))){
C_trace("batch-driver.scm: 192  warning");
((C_proc3)C_retrieve_symbol_proc(lf[371]))(3,*((C_word*)lf[371]+1),t2,lf[372]);}
else{
t3=t2;
f_1611(2,t3,C_SCHEME_UNDEFINED);}}

/* k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[369],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[12] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[30],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1614(t6,t5);}
else{
t3=t2;
f_1614(t3,C_SCHEME_UNDEFINED);}}

/* k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1614,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[367],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[368] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1617(t4,t3);}
else{
t3=t2;
f_1617(t3,C_SCHEME_UNDEFINED);}}

/* k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1617,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[365],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[366] /* compiler-syntax-enabled */,0,C_SCHEME_FALSE);
t4=t2;
f_1620(t4,t3);}
else{
t3=t2;
f_1620(t3,C_SCHEME_UNDEFINED);}}

/* k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1620(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1620,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[364],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[347] /* local-definitions */,0,C_SCHEME_TRUE);
t4=t2;
f_1623(t4,t3);}
else{
t3=t2;
f_1623(t3,C_SCHEME_UNDEFINED);}}

/* k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1623,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[363],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[160] /* enable-inline-files */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[155] /* inline-globally */,0,C_SCHEME_TRUE);
t6=t2;
f_1626(t6,t5);}
else{
t3=t2;
f_1626(t3,C_SCHEME_UNDEFINED);}}

/* k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1626,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3472,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 207  collect-options");
t4=((C_word*)t0)[17];
f_1424(t4,t3,lf[362]);}

/* k3470 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[294]+1),t1);}

/* k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1630,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[360],((C_word*)t0)[34]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3467,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 209  dribble");
t5=((C_word*)t0)[22];
f_1175(t5,t4,lf[361],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_1633(t4,C_SCHEME_UNDEFINED);}}

/* k3465 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[126] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1633(t3,t2);}

/* k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1633,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[98],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[98] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1636(t4,t3);}
else{
t3=t2;
f_1636(t3,C_SCHEME_UNDEFINED);}}

/* k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1636(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1636,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[153],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[153] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1639(t4,t3);}
else{
t3=t2;
f_1639(t3,C_SCHEME_UNDEFINED);}}

/* k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1639,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(((C_word*)t0)[20])){
if(C_truep((C_word)C_i_memq(lf[358],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[359] /* emit-unsafe-marker */,0,C_SCHEME_TRUE);
t4=t2;
f_1642(t4,t3);}
else{
t3=t2;
f_1642(t3,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1642(t3,C_SCHEME_UNDEFINED);}}

/* k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1642(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1642,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[356],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[357] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1645(t4,t3);}
else{
t3=t2;
f_1645(t3,C_SCHEME_UNDEFINED);}}

/* k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1645(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1645,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[353],((C_word*)t0)[34]))){
t3=C_mutate((C_word*)lf[354]+1 /* (set! number-type ...) */,lf[355]);
t4=t2;
f_1648(t4,t3);}
else{
t3=t2;
f_1648(t3,C_SCHEME_UNDEFINED);}}

/* k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1648(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1648,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[351],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[352] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1651(t4,t3);}
else{
t3=t2;
f_1651(t3,C_SCHEME_UNDEFINED);}}

/* k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1651,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[349],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[350] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1654(t4,t3);}
else{
t3=t2;
f_1654(t3,C_SCHEME_UNDEFINED);}}

/* k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1654,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[348],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t4=t2;
f_1657(t4,t3);}
else{
t3=t2;
f_1657(t3,C_SCHEME_UNDEFINED);}}

/* k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1657(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1657,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[62],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[347] /* local-definitions */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3426,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 225  option-arg");
f_1070(t6,t2);}
else{
t4=t3;
f_1663(t4,C_SCHEME_FALSE);}}

/* k3424 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[132]+1 /* (set! inline-output-file ...) */,t1);
t3=((C_word*)t0)[2];
f_1663(t3,t2);}

/* k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1663(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1663,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[63],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[34],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3411,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 228  option-arg");
f_1070(t4,t2);}
else{
t4=t3;
f_1669(t4,C_SCHEME_FALSE);}}

/* k3409 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3414,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 229  string->number");
C_string_to_number(3,0,t2,t1);}

/* k3412 in k3409 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3417,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t1;
t4=C_mutate((C_word*)lf[345]+1 /* (set! inline-max-size ...) */,t3);
t5=((C_word*)t0)[3];
f_1669(t5,t4);}
else{
C_trace("batch-driver.scm: 230  quit");
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t2,lf[346],((C_word*)t0)[2]);}}

/* k3415 in k3412 in k3409 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[345]+1 /* (set! inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1669(t3,t2);}

/* k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1669,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[343],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3401,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 232  dribble");
t4=((C_word*)t0)[22];
f_1175(t4,t3,lf[344],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1672(2,t3,C_SCHEME_UNDEFINED);}}

/* k3399 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 233  register-feature!");
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t2,lf[343]);}

/* k3402 in k3399 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 234  case-sensitive");
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[341],((C_word*)t0)[30]))){
C_trace("batch-driver.scm: 236  compiler-warning");
((C_proc4)C_retrieve_symbol_proc(lf[206]))(4,*((C_word*)lf[206]+1),t2,lf[212],lf[342]);}
else{
t3=t2;
f_1675(2,t3,C_SCHEME_UNDEFINED);}}

/* k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3359,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 238  option-arg");
f_1070(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1678(2,t3,C_SCHEME_UNDEFINED);}}

/* k3357 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[335],t1))){
C_trace("batch-driver.scm: 239  keyword-style");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[336]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[337],t1))){
C_trace("batch-driver.scm: 240  keyword-style");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[327]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[338],t1))){
C_trace("batch-driver.scm: 241  keyword-style");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[339]);}
else{
C_trace("batch-driver.scm: 242  quit");
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[340]);}}}}

/* k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[332],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3353,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 244  dribble");
t4=((C_word*)t0)[21];
f_1175(t4,t3,lf[334],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1681(2,t3,C_SCHEME_UNDEFINED);}}

/* k3351 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 245  parenthesis-synonyms");
((C_proc3)C_retrieve_symbol_proc(lf[333]))(3,*((C_word*)lf[333]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[330],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3344,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 247  dribble");
t4=((C_word*)t0)[21];
f_1175(t4,t3,lf[331],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1684(2,t3,C_SCHEME_UNDEFINED);}}

/* k3342 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 248  symbol-escape");
((C_proc3)C_retrieve_symbol_proc(lf[325]))(3,*((C_word*)lf[325]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[324],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3326,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 250  dribble");
t4=((C_word*)t0)[21];
f_1175(t4,t3,lf[329],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1687(2,t3,C_SCHEME_UNDEFINED);}}

/* k3324 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3329,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 251  case-sensitive");
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),t2,C_SCHEME_FALSE);}

/* k3327 in k3324 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 252  keyword-style");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t2,lf[327]);}

/* k3330 in k3327 in k3324 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 253  parentheses-synonyms");
((C_proc3)C_retrieve_symbol_proc(lf[326]))(3,*((C_word*)lf[326]+1),t2,C_SCHEME_FALSE);}

/* k3333 in k3330 in k3327 in k3324 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 254  symbol-escape");
((C_proc3)C_retrieve_symbol_proc(lf[325]))(3,*((C_word*)lf[325]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1687,2,t0,t1);}
t2=C_mutate((C_word*)lf[64]+1 /* (set! verbose-mode ...) */,((C_word*)t0)[33]);
t3=C_set_block_item(lf[65] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[33],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3320,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 258  collect-options");
t7=((C_word*)t0)[16];
f_1424(t7,t6,lf[323]);}

/* k3318 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[322]),t1);}

/* k3314 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 258  append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[225]+1)))(5,*((C_word*)lf[225]+1),((C_word*)t0)[3],t1,C_retrieve(lf[66]),((C_word*)t0)[2]);}

/* k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1693,2,t0,t1);}
t2=C_mutate((C_word*)lf[66]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[20])){
if(C_truep(((C_word*)t0)[27])){
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[20],((C_word*)t0)[27]))){
C_trace("batch-driver.scm: 262  quit");
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t3,lf[321]);}
else{
t4=t3;
f_1696(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1696(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1696(2,t4,C_SCHEME_UNDEFINED);}}

/* k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3300,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 263  collect-options");
t4=((C_word*)t0)[16];
f_1424(t4,t3,lf[240]);}

/* k3298 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[294]+1),t1);}

/* k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1700,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[32],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[319],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[320] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1703(t5,t4);}
else{
t4=t3;
f_1703(t4,C_SCHEME_UNDEFINED);}}

/* k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1703(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1703,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[317],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[318] /* no-argc-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1706(t4,t3);}
else{
t3=t2;
f_1706(t3,C_SCHEME_UNDEFINED);}}

/* k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1706,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[315],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[316] /* no-bound-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1709(t4,t3);}
else{
t3=t2;
f_1709(t3,C_SCHEME_UNDEFINED);}}

/* k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1709,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[313],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[314] /* no-procedure-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1712(t4,t3);}
else{
t3=t2;
f_1712(t3,C_SCHEME_UNDEFINED);}}

/* k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1712(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1712,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[309],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3119,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3203,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3203(t7,t3,C_retrieve(lf[284]));}
else{
t3=t2;
f_1715(2,t3,C_SCHEME_UNDEFINED);}}

/* loop421 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_3203(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3203,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3243,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3218,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),t4,t3,lf[312],C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_car(t5);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),t4,t3,lf[312],t8);}
else{
C_trace("##sys#error");
t8=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3216 in loop421 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[312],t1);}

/* k3241 in loop421 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3248,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),t2,((C_word*)t0)[2],lf[311],C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),t2,((C_word*)t0)[2],lf[311],t6);}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3246 in k3241 in loop421 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[311],t1);}

/* k3271 in k3241 in loop421 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3203(t3,((C_word*)t0)[2],t2);}

/* k3117 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3119,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3124,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3124(t5,((C_word*)t0)[2],C_retrieve(lf[286]));}

/* loop462 in k3117 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_3124(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3124,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3164,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3139,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),t4,t3,lf[312],C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_car(t5);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),t4,t3,lf[312],t8);}
else{
C_trace("##sys#error");
t8=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3137 in loop462 in k3117 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[312],t1);}

/* k3162 in loop462 in k3117 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3194,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3169,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),t2,((C_word*)t0)[2],lf[311],C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),t2,((C_word*)t0)[2],lf[311],t6);}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3167 in k3162 in loop462 in k3117 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#put!");
((C_proc5)C_retrieve_symbol_proc(lf[310]))(5,*((C_word*)lf[310]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[311],t1);}

/* k3192 in k3162 in loop462 in k3117 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3124(t3,((C_word*)t0)[2],t2);}

/* k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3080,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3105,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3113,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 287  collect-options");
t6=((C_word*)t0)[17];
f_1424(t6,t5,lf[308]);}

/* k3111 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 287  append-map");
((C_proc4)C_retrieve_symbol_proc(lf[307]))(4,*((C_word*)lf[307]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3104 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3105,3,t0,t1,t2);}
C_trace("string-split");
((C_proc4)C_retrieve_symbol_proc(lf[305]))(4,*((C_word*)lf[305]+1),t1,t2,lf[306]);}

/* k3078 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3080,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3082(t5,((C_word*)t0)[2],t1);}

/* loop504 in k3078 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_3082(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3082,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3092,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("register-feature!");
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3090 in loop504 in k3078 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3082(t3,((C_word*)t0)[2],t2);}

/* k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1718,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[67],C_retrieve(lf[68]));
t3=C_mutate((C_word*)lf[68]+1 /* (set! features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
C_trace("batch-driver.scm: 291  collect-options");
t5=((C_word*)t0)[17];
f_1424(t5,t4,lf[303]);}

/* k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1728,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
C_trace("batch-driver.scm: 292  dribble");
t3=((C_word*)t0)[22];
f_1175(t3,t2,lf[302],C_SCHEME_END_OF_LIST);}

/* k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("batch-driver.scm: 293  load-verbose");
((C_proc3)C_retrieve_symbol_proc(lf[301]))(3,*((C_word*)lf[301]+1),t2,C_SCHEME_TRUE);}
else{
t3=t2;
f_1731(2,t3,C_SCHEME_UNDEFINED);}}

/* k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3049,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3049(t6,t2,((C_word*)t0)[2]);}

/* loop523 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_3049(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3049,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3062,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3073,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 295  ##sys#resolve-include-filename");
((C_proc5)C_retrieve_symbol_proc(lf[163]))(5,*((C_word*)lf[163]+1),t5,t3,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3071 in loop523 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 295  load");
((C_proc3)C_retrieve_symbol_proc(lf[300]))(3,*((C_word*)lf[300]+1),((C_word*)t0)[2],t1);}

/* k3060 in loop523 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3049(t3,((C_word*)t0)[2],t2);}

/* k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
C_trace("batch-driver.scm: 297  delete");
((C_proc5)C_retrieve_symbol_proc(lf[298]))(5,*((C_word*)lf[298]+1),t2,lf[67],C_retrieve(lf[68]),*((C_word*)lf[299]+1));}

/* k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1738,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1 /* (set! features ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[69],C_retrieve(lf[68]));
t4=C_mutate((C_word*)lf[68]+1 /* (set! features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
C_trace("batch-driver.scm: 300  user-post-analysis-pass");
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t5);}

/* k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1746,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
C_trace("batch-driver.scm: 303  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),t3,((C_word*)((C_word*)t0)[30])[1],C_retrieve(lf[297]));}

/* k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1750,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[30])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3047,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 305  collect-options");
t5=((C_word*)t0)[16];
f_1424(t5,t4,lf[296]);}

/* k3045 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[294]+1),t1);}

/* k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1757,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3013,a[2]=((C_word*)t0)[30],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3015,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3035,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3039,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3043,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 311  collect-options");
t8=((C_word*)t0)[16];
f_1424(t8,t7,lf[295]);}

/* k3041 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[294]+1),t1);}

/* k3037 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 311  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3033 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3014 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3015,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[293],t5));}

/* k3011 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 308  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1757,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1761,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[31],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
C_trace("batch-driver.scm: 315  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),t3,C_retrieve(lf[70]),((C_word*)t0)[2]);}

/* k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1761,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep((C_word)C_i_memq(lf[291],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[292] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1764(t5,t4);}
else{
t4=t3;
f_1764(t4,C_SCHEME_UNDEFINED);}}

/* k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1764,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1768,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2992,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 321  option-arg");
f_1070(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[290]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1768(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1768(2,t4,C_SCHEME_FALSE);}}}

/* k2990 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 321  arg-val");
f_1344(((C_word*)t0)[2],t1);}

/* k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1768,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* (set! target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2985,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 325  option-arg");
f_1070(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1772(2,t4,C_SCHEME_FALSE);}}

/* k2983 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 325  arg-val");
f_1344(((C_word*)t0)[2],t1);}

/* k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1772,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1 /* (set! target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2978,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 326  option-arg");
f_1070(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1776(2,t4,C_SCHEME_FALSE);}}

/* k2976 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 326  arg-val");
f_1344(((C_word*)t0)[2],t1);}

/* k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1 /* (set! target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2971,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 327  option-arg");
f_1070(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1780(2,t4,C_SCHEME_FALSE);}}

/* k2969 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 327  arg-val");
f_1344(((C_word*)t0)[2],t1);}

/* k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1780,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2951,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 330  option-arg");
f_1070(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[289]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1784(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1784(2,t5,C_SCHEME_FALSE);}}}

/* k2949 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 330  arg-val");
f_1344(((C_word*)t0)[2],t1);}

/* k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! target-stack-size ...) */,t1);
t3=(C_word)C_i_memq(lf[76],((C_word*)t0)[23]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[77]+1 /* (set! emit-trace-info ...) */,t4);
t6=(C_word)C_i_memq(lf[78],((C_word*)t0)[23]);
t7=C_mutate((C_word*)lf[79]+1 /* (set! disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[287],C_retrieve(lf[35])))){
C_trace("batch-driver.scm: 336  set-gc-report!");
((C_proc3)C_retrieve_symbol_proc(lf[288]))(3,*((C_word*)lf[288]+1),t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1795(2,t9,C_SCHEME_UNDEFINED);}}

/* k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[282],((C_word*)t0)[23]))){
t3=t2;
f_1798(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[283]+1 /* (set! standard-bindings ...) */,C_retrieve(lf[284]));
t4=C_mutate((C_word*)lf[285]+1 /* (set! extended-bindings ...) */,C_retrieve(lf[286]));
t5=t2;
f_1798(t5,t4);}}

/* k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1798,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(C_retrieve(lf[77]))){
C_trace("batch-driver.scm: 340  dribble");
t3=((C_word*)t0)[15];
f_1175(t3,t2,lf[279],(C_word)C_a_i_list(&a,1,lf[280]));}
else{
C_trace("batch-driver.scm: 340  dribble");
t3=((C_word*)t0)[15];
f_1175(t3,t2,lf[279],(C_word)C_a_i_list(&a,1,lf[281]));}}

/* k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[271],t3);
t5=C_set_block_item(lf[232] /* emit-profile */,0,C_SCHEME_TRUE);
t6=C_mutate((C_word*)lf[272]+1 /* (set! profiled-procedures ...) */,lf[273]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2910,a[2]=t2,a[3]=((C_word*)t0)[15],a[4]=t4,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
C_trace("batch-driver.scm: 349  append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[225]+1)))(5,*((C_word*)lf[225]+1),t7,((C_word*)((C_word*)t0)[6])[1],C_retrieve(lf[277]),lf[278]);}
else{
C_trace("batch-driver.scm: 349  append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[225]+1)))(5,*((C_word*)lf[225]+1),t7,((C_word*)((C_word*)t0)[6])[1],C_retrieve(lf[277]),C_SCHEME_END_OF_LIST);}}
else{
t3=t2;
f_1804(2,t3,C_SCHEME_UNDEFINED);}}

/* k2908 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
C_trace("batch-driver.scm: 355  dribble");
t3=((C_word*)t0)[3];
f_1175(t3,((C_word*)t0)[2],lf[274],(C_word)C_a_i_list(&a,1,lf[275]));}
else{
C_trace("batch-driver.scm: 355  dribble");
t3=((C_word*)t0)[3];
f_1175(t3,((C_word*)t0)[2],lf[274],(C_word)C_a_i_list(&a,1,lf[276]));}}

/* k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_trace("batch-driver.scm: 358  load-identifier-database");
((C_proc3)C_retrieve_symbol_proc(lf[269]))(3,*((C_word*)lf[269]+1),t2,lf[270]);}

/* k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1807,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[80],((C_word*)t0)[22]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1816,a[2]=((C_word*)t0)[21],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 361  print-version");
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[83],((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t2)){
t4=t3;
f_1828(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[266],((C_word*)t0)[22]);
if(C_truep(t4)){
t5=t3;
f_1828(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[267],((C_word*)t0)[22]);
t6=t3;
f_1828(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[268],((C_word*)t0)[22])));}}}}

/* k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1828(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1828,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("batch-driver.scm: 364  print-usage");
((C_proc2)C_retrieve_symbol_proc(lf[84]))(2,*((C_word*)lf[84]+1),((C_word*)t0)[22]);}
else{
if(C_truep((C_word)C_i_memq(lf[85],((C_word*)t0)[21]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1847,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 366  chicken-version");
((C_proc2)C_retrieve_symbol_proc(lf[86]))(2,*((C_word*)lf[86]+1),t3);}
else{
t2=((C_word*)t0)[20];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[21],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[22],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
C_trace("batch-driver.scm: 374  dribble");
t4=((C_word*)t0)[14];
f_1175(t4,t3,lf[264],(C_word)C_a_i_list(&a,1,((C_word*)t0)[20]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 369  print-version");
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t3,C_SCHEME_TRUE);}}}}

/* k1854 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 370  display");
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],lf[265]);}

/* k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! source-filename ...) */,((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[22],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
C_trace("batch-driver.scm: 376  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[103]))(5,*((C_word*)lf[103]+1),t3,lf[259],lf[263],((C_word*)t0)[9]);}

/* k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_trace("batch-driver.scm: 377  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[103]))(5,*((C_word*)lf[103]+1),t2,lf[259],lf[262],C_retrieve(lf[35]));}

/* k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_trace("batch-driver.scm: 378  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[103]))(5,*((C_word*)lf[103]+1),t2,lf[259],lf[261],C_retrieve(lf[71]));}

/* k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_trace("batch-driver.scm: 379  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[103]))(5,*((C_word*)lf[103]+1),t2,lf[259],lf[260],C_retrieve(lf[75]));}

/* k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1875,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(6));
t3=C_mutate(((C_word *)((C_word*)t0)[22])+1,t2);
t4=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[22],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
C_trace("batch-driver.scm: 383  make-vector");
((C_proc4)C_retrieve_proc(*((C_word*)lf[257]+1)))(4,*((C_word*)lf[257]+1),t4,C_retrieve(lf[258]),C_SCHEME_END_OF_LIST);}

/* k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_trace("batch-driver.scm: 384  collect-options");
t4=((C_word*)t0)[10];
f_1424(t4,t3,lf[256]);}

/* k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
C_trace("batch-driver.scm: 385  collect-options");
t3=((C_word*)t0)[10];
f_1424(t3,t2,lf[255]);}

/* k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[11],a[3]=t2,a[4]=((C_word*)t0)[17],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 387  collect-options");
t4=((C_word*)t0)[11];
f_1424(t4,t3,lf[254]);}

/* k2876 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2878,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2886,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 389  collect-options");
t4=((C_word*)t0)[2];
f_1424(t4,t3,lf[253]);}

/* k2884 in k2876 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 386  append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[225]+1)))(5,*((C_word*)lf[225]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
C_trace("batch-driver.scm: 391  user-read-pass");
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}

/* k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1898,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],a[21]=((C_word*)t0)[25],tmp=(C_word)a,a+=22,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 393  dribble");
t4=((C_word*)t0)[21];
f_1175(t4,t3,lf[246],C_SCHEME_END_OF_LIST);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2793(t6,t2,((C_word*)t0)[4]);}}

/* doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_2793(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2793,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2804,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t5=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[247]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 403  check-and-open-input-file");
((C_proc3)C_retrieve_symbol_proc(lf[252]))(3,*((C_word*)lf[252]+1),t4,t3);}}

/* k2820 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2834,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2871,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#dynamic-wind");
t10=*((C_word*)lf[251]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2870 in k2820 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[249]));
t3=C_mutate((C_word*)lf[249]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2838 in k2820 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2843,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("batch-driver.scm: 405  read-form");
t3=((C_word*)t0)[2];
f_1493(t3,t2,((C_word*)t0)[5]);}

/* k2841 in a2838 in k2820 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2843,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2848(t5,((C_word*)t0)[2],t1);}

/* doloop621 in k2841 in a2838 in k2820 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2848,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
C_trace("batch-driver.scm: 408  close-checked-input-file");
((C_proc4)C_retrieve_symbol_proc(lf[250]))(4,*((C_word*)lf[250]+1),t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2869,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 406  read-form");
t6=((C_word*)t0)[2];
f_1493(t6,t5,((C_word*)t0)[6]);}}

/* k2867 in doloop621 in k2841 in a2838 in k2820 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2848(t2,((C_word*)t0)[2],t1);}

/* a2833 in k2820 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2834,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[249]));
t3=C_mutate((C_word*)lf[249]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2823 in k2820 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2793(t3,((C_word*)t0)[2],t2);}

/* k2806 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 400  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[248]+1)))(3,*((C_word*)lf[248]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2810 in k2806 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2816,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t3=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[247]),((C_word*)t0)[2]);}

/* k2814 in k2810 in k2806 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 399  append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[225]+1)))(5,*((C_word*)lf[225]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2802 in doloop602 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2782 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 394  proc");
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2786 in k2782 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1898(2,t3,t2);}

/* k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
C_trace("batch-driver.scm: 412  user-preprocessor-pass");
((C_proc2)C_retrieve_symbol_proc(lf[4]))(2,*((C_word*)lf[4]+1),t2);}

/* k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2777,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 414  dribble");
t4=((C_word*)t0)[17];
f_1175(t4,t3,lf[245],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1904(t3,C_SCHEME_UNDEFINED);}}

/* k2775 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2779 in k2775 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1904(t3,t2);}

/* k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1904(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1904,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
C_trace("batch-driver.scm: 417  print-expr");
t3=((C_word*)t0)[7];
f_1260(t3,t2,lf[243],lf[244],((C_word*)((C_word*)t0)[3])[1]);}

/* k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1907,2,t0,t1);}
t2=f_1454(((C_word*)t0)[21]);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1913(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2754,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 420  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),t4,C_retrieve(lf[70]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k2752 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[242]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k2772 in k2752 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2774,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[240],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[241],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1913(t7,t6);}

/* k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1913,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2747,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 422  append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[225]+1)))(4,*((C_word*)lf[225]+1),t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2745 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[239]),t1);}

/* k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
C_trace("batch-driver.scm: 423  gensym");
((C_proc2)C_retrieve_symbol_proc(lf[238]))(2,*((C_word*)lf[238]+1),t2);}

/* k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1919,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[88]));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],tmp=(C_word)a,a+=17,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2715,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t6=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[237]));}

/* a2714 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2715,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[229],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[234],t8));}

/* k2587 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2705,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t4=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[236]));}

/* a2704 in k2587 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2705,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[235],t3));}

/* k2591 in k2587 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2597,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[232]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[229],t3);
t5=(C_truep(C_retrieve(lf[211]))?(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST):(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST));
t6=(C_word)C_a_i_cons(&a,2,lf[229],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[233],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[230]),t10);
t12=(C_word)C_a_i_cons(&a,2,lf[234],t11);
t13=t2;
f_2597(t13,(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2597(t3,C_SCHEME_END_OF_LIST);}}

/* k2595 in k2591 in k2587 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_2597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2597,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2616,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t4=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[88]));}

/* a2615 in k2595 in k2591 in k2587 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2616,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[229],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[229],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[230]),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[231],t11));}

/* k2599 in k2595 in k2591 in k2587 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_retrieve(lf[211]);
if(C_truep(t2)){
C_trace("batch-driver.scm: 425  append");
((C_proc9)C_retrieve_proc(*((C_word*)lf[225]+1)))(9,*((C_word*)lf[225]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,lf[226]);}
else{
if(C_truep(((C_word*)t0)[3])){
C_trace("batch-driver.scm: 425  append");
((C_proc9)C_retrieve_proc(*((C_word*)lf[225]+1)))(9,*((C_word*)lf[225]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,lf[227]);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
C_trace("batch-driver.scm: 425  append");
((C_proc9)C_retrieve_proc(*((C_word*)lf[225]+1)))(9,*((C_word*)lf[225]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,lf[228]);}}}

/* k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2534,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[222])))){
C_trace("batch-driver.scm: 447  debugging");
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t5,lf[223],lf[224]);}
else{
t6=t5;
f_2534(2,t6,C_SCHEME_FALSE);}}

/* k2532 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2539,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2539(t5,((C_word*)t0)[2],C_retrieve(lf[222]));}
else{
t2=((C_word*)t0)[2];
f_1928(2,t2,C_SCHEME_UNDEFINED);}}

/* loop675 in k2532 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2539,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=*((C_word*)lf[31]+1);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2552,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t5,lf[221],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2550 in loop675 in k2532 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,t3,((C_word*)t0)[3]);}

/* k2553 in k2550 in loop675 in k2532 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,lf[220],((C_word*)t0)[3]);}

/* k2556 in k2553 in k2550 in loop675 in k2532 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,t3,((C_word*)t0)[3]);}

/* k2559 in k2556 in k2553 in k2550 in loop675 in k2532 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2564,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2562 in k2559 in k2556 in k2553 in k2550 in loop675 in k2532 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2539(t3,((C_word*)t0)[2],t2);}

/* k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2528,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 451  debugging");
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t3,lf[218],lf[219]);}

/* k2526 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("batch-driver.scm: 452  display-real-name-table");
((C_proc2)C_retrieve_symbol_proc(lf[217]))(2,*((C_word*)lf[217]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1931(2,t2,C_SCHEME_UNDEFINED);}}

/* k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2522,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 453  debugging");
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t3,lf[215],lf[216]);}

/* k2520 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("batch-driver.scm: 454  display-line-number-database");
((C_proc2)C_retrieve_symbol_proc(lf[214]))(2,*((C_word*)lf[214]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1934(2,t2,C_SCHEME_UNDEFINED);}}

/* k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(C_retrieve(lf[211]))){
if(C_truep(((C_word*)t0)[10])){
C_trace("batch-driver.scm: 457  compiler-warning");
((C_proc5)C_retrieve_symbol_proc(lf[206]))(5,*((C_word*)lf[206]+1),t2,lf[212],lf[213],C_retrieve(lf[211]));}
else{
t3=t2;
f_1937(2,t3,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1937(2,t3,C_SCHEME_UNDEFINED);}}

/* k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2507,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[153]))){
C_trace("batch-driver.scm: 459  feature?");
((C_proc3)C_retrieve_symbol_proc(lf[209]))(3,*((C_word*)lf[209]+1),t3,lf[210]);}
else{
t4=t2;
f_1940(2,t4,C_SCHEME_UNDEFINED);}}

/* k2505 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("batch-driver.scm: 460  compiler-warning");
((C_proc4)C_retrieve_symbol_proc(lf[206]))(4,*((C_word*)lf[206]+1),((C_word*)t0)[2],lf[207],lf[208]);}
else{
t2=((C_word*)t0)[2];
f_1940(2,t2,C_SCHEME_UNDEFINED);}}

/* k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! line-number-database ...) */,C_retrieve(lf[89]));
t3=C_set_block_item(lf[89] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
C_trace("batch-driver.scm: 467  end-time");
t5=((C_word*)t0)[16];
f_1464(t5,t4,lf[205]);}

/* k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
C_trace("batch-driver.scm: 468  print-expr");
t3=((C_word*)t0)[2];
f_1260(t3,t2,lf[203],lf[204],((C_word*)((C_word*)t0)[3])[1]);}

/* k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_memq(lf[202],((C_word*)t0)[3]))){
C_trace("batch-driver.scm: 470  exit");
((C_proc2)C_retrieve_symbol_proc(lf[125]))(2,*((C_word*)lf[125]+1),t2);}
else{
t3=t2;
f_1951(2,t3,C_SCHEME_UNDEFINED);}}

/* k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
C_trace("batch-driver.scm: 472  user-pass");
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t2);}

/* k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2488,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
C_trace("batch-driver.scm: 474  dribble");
t4=((C_word*)t0)[12];
f_1175(t4,t3,lf[201],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1957(2,t3,C_SCHEME_UNDEFINED);}}

/* k2486 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
t2=f_1454(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t4=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k2493 in k2486 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
C_trace("batch-driver.scm: 477  end-time");
t3=((C_word*)t0)[3];
f_1464(t3,((C_word*)t0)[2],lf[200]);}

/* k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2485,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 482  canonicalize-begin-body");
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2483 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 481  build-node-graph");
((C_proc3)C_retrieve_symbol_proc(lf[198]))(3,*((C_word*)lf[198]+1),((C_word*)t0)[2],t1);}

/* k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2481,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[90],lf[91],lf[92],t2);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
C_trace("batch-driver.scm: 485  print-node");
t7=((C_word*)t0)[12];
f_1214(t7,t6,lf[196],lf[197],t3);}

/* k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
C_trace("batch-driver.scm: 486  initialize-analysis-database");
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t2);}

/* k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[180]))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[16],a[7]=t2,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[17],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_memq(lf[193],((C_word*)t0)[2]))){
t4=t3;
f_2415(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("batch-driver.scm: 491  load-type-database");
((C_proc3)C_retrieve_symbol_proc(lf[191]))(3,*((C_word*)lf[191]+1),t3,lf[194]);}}
else{
t3=t2;
f_1972(t3,C_SCHEME_UNDEFINED);}}

/* k2413 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2418,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2449,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 492  collect-options");
t4=((C_word*)t0)[2];
f_1424(t4,t3,lf[192]);}

/* k2447 in k2413 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2449,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2451,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2451(t5,((C_word*)t0)[2],t1);}

/* loop721 in k2447 in k2413 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_2451(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2451,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2464,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##compiler#load-type-database");
((C_proc4)C_retrieve_symbol_proc(lf[191]))(4,*((C_word*)lf[191]+1),t4,t3,C_SCHEME_FALSE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2462 in loop721 in k2447 in k2413 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2451(t3,((C_word*)t0)[2],t2);}

/* k2416 in k2413 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=f_1454(((C_word*)t0)[8]);
t3=C_set_block_item(lf[95] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2426,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 495  analyze");
t5=((C_word*)t0)[2];
f_1499(t5,t4,lf[190],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* k2424 in k2416 in k2413 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2426,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2429,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("batch-driver.scm: 496  print-db");
t4=((C_word*)t0)[2];
f_1236(t4,t3,lf[189],lf[183],((C_word*)((C_word*)t0)[7])[1],C_fix(0));}

/* k2427 in k2424 in k2416 in k2413 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("batch-driver.scm: 497  end-time");
t3=((C_word*)t0)[4];
f_1464(t3,t2,lf[188]);}

/* k2430 in k2427 in k2424 in k2416 in k2413 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2432,2,t0,t1);}
t2=f_1454(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("batch-driver.scm: 499  debugging");
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t3,lf[104],lf[187]);}

/* k2436 in k2430 in k2427 in k2424 in k2416 in k2413 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 500  scrutinize");
((C_proc4)C_retrieve_symbol_proc(lf[186]))(4,*((C_word*)lf[186]+1),t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2439 in k2436 in k2430 in k2427 in k2424 in k2416 in k2413 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 501  end-time");
t3=((C_word*)t0)[2];
f_1464(t3,t2,lf[185]);}

/* k2442 in k2439 in k2436 in k2430 in k2427 in k2424 in k2416 in k2413 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[95] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1972(t3,t2);}

/* k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1972(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1972,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[175]))){
t3=f_1454(((C_word*)t0)[16]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[13],a[6]=t2,a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[180]))){
t5=t4;
f_2388(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=C_set_block_item(lf[95] /* first-analysis */,0,C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("batch-driver.scm: 508  analyze");
t7=((C_word*)t0)[14];
f_1499(t7,t6,lf[184],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}
else{
t3=t2;
f_1975(t3,C_SCHEME_UNDEFINED);}}

/* k2404 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2406,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 509  print-db");
t4=((C_word*)t0)[2];
f_1236(t4,t3,lf[182],lf[183],((C_word*)((C_word*)t0)[5])[1],C_fix(0));}

/* k2407 in k2404 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 510  end-time");
t2=((C_word*)t0)[3];
f_1464(t2,((C_word*)t0)[2],lf[181]);}

/* k2386 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=f_1454(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("batch-driver.scm: 512  perform-lambda-lifting!");
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2392 in k2386 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 513  end-time");
t3=((C_word*)t0)[2];
f_1464(t3,t2,lf[178]);}

/* k2395 in k2392 in k2386 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 514  print-node");
t3=((C_word*)t0)[3];
f_1214(t3,t2,lf[176],lf[177],((C_word*)t0)[2]);}

/* k2398 in k2395 in k2392 in k2386 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[95] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_1975(t3,t2);}

/* k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1975(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1975,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 517  vector->list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[173]+1)))(3,*((C_word*)lf[173]+1),t3,C_retrieve(lf[174]));}

/* k2380 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 517  concatenate");
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),((C_word*)t0)[2],t1);}

/* k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1981,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2375,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 518  debugging");
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t3,lf[171],lf[172]);}

/* k2373 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("batch-driver.scm: 519  pp");
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1981(2,t2,C_SCHEME_UNDEFINED);}}

/* k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[160]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2323,a[2]=t2,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2372,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t5=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[169]+1),((C_word*)t0)[2]);}
else{
t3=t2;
f_1984(2,t3,C_SCHEME_UNDEFINED);}}

/* k2370 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 529  concatenate");
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),((C_word*)t0)[2],t1);}

/* k2321 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2323,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2325,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2325(t5,((C_word*)t0)[2],t1);}

/* loop766 in k2321 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_2325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2325,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2338,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2364,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2368,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 524  symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t6,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2366 in loop766 in k2321 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 524  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[164]))(5,*((C_word*)lf[164]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[165]);}

/* k2362 in loop766 in k2321 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 523  ##sys#resolve-include-filename");
((C_proc5)C_retrieve_symbol_proc(lf[163]))(5,*((C_word*)lf[163]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2336 in loop766 in k2321 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 526  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[162]))(3,*((C_word*)lf[162]+1),t3,t1);}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2325(t4,((C_word*)t0)[3],t3);}}

/* k2352 in k2336 in loop766 in k2321 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2354,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 527  dribble");
t3=((C_word*)t0)[5];
f_1175(t3,t2,lf[161],(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2325(t3,((C_word*)t0)[2],t2);}}

/* k2355 in k2352 in k2336 in loop766 in k2321 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 528  load-inline-file");
((C_proc3)C_retrieve_symbol_proc(lf[157]))(3,*((C_word*)lf[157]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2339 in k2336 in loop766 in k2321 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2325(t3,((C_word*)t0)[2],t2);}

/* k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
C_trace("batch-driver.scm: 530  collect-options");
t3=((C_word*)t0)[2];
f_1424(t3,t2,lf[159]);}

/* k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_1990(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(lf[155] /* inline-globally */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[156] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2293,a[2]=((C_word*)t0)[10],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2293(t8,t2,t1);}}

/* loop784 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_2293(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2293,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2306,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("batch-driver.scm: 536  dribble");
t5=((C_word*)t0)[2];
f_1175(t5,t4,lf[158],(C_word)C_a_i_list(&a,1,t3));}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2304 in loop784 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 537  load-inline-file");
((C_proc3)C_retrieve_symbol_proc(lf[157]))(3,*((C_word*)lf[157]+1),t2,((C_word*)t0)[2]);}

/* k2307 in k2304 in loop784 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2293(t3,((C_word*)t0)[2],t2);}

/* k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
t2=C_set_block_item(lf[45] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[93] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[94] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[153]))){
t6=t5;
f_1996(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
t7=(C_word)C_i_car(t6);
C_trace("batch-driver.scm: 544  scan-toplevel-assignments");
((C_proc3)C_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),t5,t7);}}

/* k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
t2=f_1454(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
C_trace("batch-driver.scm: 547  perform-cps-conversion");
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),t3,((C_word*)t0)[2]);}

/* k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2005,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
C_trace("batch-driver.scm: 548  end-time");
t3=((C_word*)t0)[12];
f_1464(t3,t2,lf[151]);}

/* k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
C_trace("batch-driver.scm: 549  print-node");
t3=((C_word*)t0)[11];
f_1214(t3,t2,lf[149],lf[150],((C_word*)t0)[2]);}

/* k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t3,a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp));
t5=((C_word*)t3)[1];
f_2013(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_2013(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2013,NULL,5,t0,t1,t2,t3,t4);}
t5=f_1454(((C_word*)t0)[13]);
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=t3,a[16]=((C_word*)t0)[13],a[17]=t4,tmp=(C_word)a,a+=18,tmp);
C_trace("batch-driver.scm: 555  analyze");
t7=((C_word*)t0)[10];
f_1499(t7,t6,lf[148],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t1,a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
if(C_truep(C_retrieve(lf[95]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2248,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[146],C_retrieve(lf[35])))){
C_trace("batch-driver.scm: 558  dump-undefined-globals");
((C_proc3)C_retrieve_symbol_proc(lf[147]))(3,*((C_word*)lf[147]+1),t3,t1);}
else{
t4=t3;
f_2248(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2023(2,t3,C_SCHEME_UNDEFINED);}}

/* k2246 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[144],C_retrieve(lf[35])))){
C_trace("batch-driver.scm: 560  dump-defined-globals");
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2251(2,t3,C_SCHEME_UNDEFINED);}}

/* k2249 in k2246 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_memq(lf[142],C_retrieve(lf[35])))){
C_trace("batch-driver.scm: 562  dump-global-refs");
((C_proc3)C_retrieve_symbol_proc(lf[143]))(3,*((C_word*)lf[143]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_2023(2,t3,t2);}}

/* k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
t2=C_set_block_item(lf[95] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
C_trace("batch-driver.scm: 564  end-time");
t4=((C_word*)t0)[12];
f_1464(t4,t3,lf[141]);}

/* k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
C_trace("batch-driver.scm: 565  print-db");
t3=((C_word*)t0)[2];
f_1236(t3,t2,lf[139],lf[140],((C_word*)t0)[15],((C_word*)t0)[14]);}

/* k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_memq(lf[137],C_retrieve(lf[35])))){
C_trace("batch-driver.scm: 567  print-program-statistics");
((C_proc3)C_retrieve_symbol_proc(lf[138]))(3,*((C_word*)lf[138]+1),t2,((C_word*)t0)[15]);}
else{
t3=t2;
f_2033(2,t3,C_SCHEME_UNDEFINED);}}

/* k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
if(C_truep(((C_word*)t0)[18])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[16],a[10]=((C_word*)t0)[17],tmp=(C_word)a,a+=11,tmp);
C_trace("batch-driver.scm: 570  debugging");
((C_proc5)C_retrieve_symbol_proc(lf[103]))(5,*((C_word*)lf[103]+1),t2,lf[104],lf[109],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2125,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
C_trace("batch-driver.scm: 594  print-node");
t3=((C_word*)t0)[10];
f_1214(t3,t2,lf[135],lf[136],((C_word*)t0)[16]);}}

/* k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[132]))){
t3=C_retrieve(lf[132]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[14],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 598  dribble");
t5=((C_word*)t0)[13];
f_1175(t5,t4,lf[134],(C_word)C_a_i_list(&a,1,t3));}
else{
t3=t2;
f_2128(2,t3,C_SCHEME_UNDEFINED);}}

/* k2234 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 599  emit-global-inline-file");
((C_proc4)C_retrieve_symbol_proc(lf[133]))(4,*((C_word*)lf[133]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2128,2,t0,t1);}
t2=f_1454(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
C_trace("batch-driver.scm: 602  perform-closure-conversion");
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),t3,((C_word*)t0)[2],((C_word*)t0)[14]);}

/* k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t1,a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
C_trace("batch-driver.scm: 603  end-time");
t3=((C_word*)t0)[11];
f_1464(t3,t2,lf[130]);}

/* k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
C_trace("batch-driver.scm: 604  print-db");
t3=((C_word*)t0)[3];
f_1236(t3,t2,lf[128],lf[129],((C_word*)t0)[13],((C_word*)t0)[2]);}

/* k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_retrieve(lf[126]))){
t3=(C_word)C_fudge(C_fix(6));
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(60000)))){
C_trace("batch-driver.scm: 606  display");
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,lf[127]);}
else{
t5=t2;
f_2143(2,t5,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2143(2,t3,C_SCHEME_UNDEFINED);}}

/* k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("batch-driver.scm: 607  exit");
((C_proc3)C_retrieve_symbol_proc(lf[125]))(3,*((C_word*)lf[125]+1),t2,C_fix(0));}
else{
t3=t2;
f_2146(2,t3,C_SCHEME_UNDEFINED);}}

/* k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
C_trace("batch-driver.scm: 608  print-node");
t3=((C_word*)t0)[2];
f_1214(t3,t2,lf[123],lf[124],((C_word*)t0)[10]);}

/* k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2149,2,t0,t1);}
t2=f_1454(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2162 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2163,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
C_trace("batch-driver.scm: 613  end-time");
t7=((C_word*)t0)[6];
f_1464(t7,t6,lf[122]);}

/* k2165 in a2162 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2167,2,t0,t1);}
t2=f_1454(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[8])){
C_trace("batch-driver.scm: 616  open-output-file");
((C_proc3)C_retrieve_proc(*((C_word*)lf[120]+1)))(3,*((C_word*)lf[120]+1),t3,((C_word*)t0)[8]);}
else{
C_trace("batch-driver.scm: 616  current-output-port");
((C_proc2)C_retrieve_proc(*((C_word*)lf[121]+1)))(2,*((C_word*)lf[121]+1),t3);}}

/* k2171 in k2165 in a2162 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("batch-driver.scm: 617  dribble");
t3=((C_word*)t0)[11];
f_1175(t3,t2,lf[119],(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]));}

/* k2174 in k2171 in k2165 in a2162 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
C_trace("batch-driver.scm: 618  generate-code");
((C_proc9)C_retrieve_symbol_proc(lf[118]))(9,*((C_word*)lf[118]+1),t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2177 in k2174 in k2171 in k2165 in a2162 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2182,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("batch-driver.scm: 619  close-output-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[117]+1)))(3,*((C_word*)lf[117]+1),t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2182(2,t3,C_SCHEME_UNDEFINED);}}

/* k2180 in k2177 in k2174 in k2171 in k2165 in a2162 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 620  end-time");
t3=((C_word*)t0)[2];
f_1464(t3,t2,lf[116]);}

/* k2183 in k2180 in k2177 in k2174 in k2171 in k2165 in a2162 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[113],C_retrieve(lf[35])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2204,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 621  ##sys#stop-timer");
t4=*((C_word*)lf[115]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 622  compiler-cleanup-hook");
((C_proc2)C_retrieve_symbol_proc(lf[112]))(2,*((C_word*)lf[112]+1),t3);}}

/* f3831 in k2183 in k2180 in k2177 in k2174 in k2171 in k2165 in a2162 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 623  dribble");
t2=((C_word*)t0)[3];
f_1175(t2,((C_word*)t0)[2],lf[111],C_SCHEME_END_OF_LIST);}

/* k2202 in k2183 in k2180 in k2177 in k2174 in k2171 in k2165 in a2162 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 621  ##sys#display-times");
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),((C_word*)t0)[2],t1);}

/* k2186 in k2183 in k2180 in k2177 in k2174 in k2171 in k2165 in a2162 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 622  compiler-cleanup-hook");
((C_proc2)C_retrieve_symbol_proc(lf[112]))(2,*((C_word*)lf[112]+1),t2);}

/* k2189 in k2186 in k2183 in k2180 in k2177 in k2174 in k2171 in k2165 in a2162 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 623  dribble");
t2=((C_word*)t0)[3];
f_1175(t2,((C_word*)t0)[2],lf[111],C_SCHEME_END_OF_LIST);}

/* a2156 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2126 in k2123 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2157,2,t0,t1);}
C_trace("batch-driver.scm: 612  prepare-for-code-generation");
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2037 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2039,2,t0,t1);}
t2=f_1454(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2047,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2052 in k2037 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2053,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
C_trace("batch-driver.scm: 575  end-time");
t5=((C_word*)t0)[4];
f_1464(t5,t4,lf[108]);}

/* k2055 in a2052 in k2037 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("batch-driver.scm: 576  print-node");
t3=((C_word*)t0)[2];
f_1214(t3,t2,lf[106],lf[107],((C_word*)t0)[6]);}

/* k2058 in k2055 in a2052 in k2037 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2060,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
C_trace("batch-driver.scm: 578  loop");
t3=((C_word*)((C_word*)t0)[7])[1];
f_2013(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[97]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[98]))){
t3=f_1454(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 585  analyze");
t5=((C_word*)t0)[2];
f_1499(t5,t4,lf[102],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
C_trace("batch-driver.scm: 591  loop");
t4=((C_word*)((C_word*)t0)[7])[1];
f_2013(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
C_trace("batch-driver.scm: 580  debugging");
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t3,lf[104],lf[105]);}}}

/* k2077 in k2058 in k2055 in a2052 in k2037 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[97] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
C_trace("batch-driver.scm: 582  loop");
t4=((C_word*)((C_word*)t0)[4])[1];
f_2013(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2094 in k2058 in k2055 in a2052 in k2037 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2099,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("batch-driver.scm: 586  end-time");
t3=((C_word*)t0)[2];
f_1464(t3,t2,lf[101]);}

/* k2097 in k2094 in k2058 in k2055 in a2052 in k2037 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2099,2,t0,t1);}
t2=f_1454(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("batch-driver.scm: 588  transform-direct-lambdas!");
((C_proc4)C_retrieve_symbol_proc(lf[100]))(4,*((C_word*)lf[100]+1),t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2103 in k2097 in k2094 in k2058 in k2055 in a2052 in k2037 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2108,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("batch-driver.scm: 589  end-time");
t3=((C_word*)t0)[2];
f_1464(t3,t2,lf[99]);}

/* k2106 in k2103 in k2097 in k2094 in k2058 in k2055 in a2052 in k2037 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
C_trace("batch-driver.scm: 590  loop");
t3=((C_word*)((C_word*)t0)[5])[1];
f_2013(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2046 in k2037 in k2031 in k2028 in k2025 in k2021 in k2018 in loop in k2006 in k2003 in k2000 in k1994 in k1988 in k1985 in k1982 in k1979 in k1976 in k1973 in k1970 in k1967 in k1964 in k2479 in k1955 in k1952 in k1949 in k1946 in k1943 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1917 in k1914 in k1911 in k1905 in k1902 in k1899 in k1896 in k1893 in k1890 in k1887 in k1884 in k1881 in k1873 in k1870 in k1867 in k1864 in k1860 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2047,2,t0,t1);}
C_trace("batch-driver.scm: 574  perform-high-level-optimizations");
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1845 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 366  display");
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],t1);}

/* k1838 in k1826 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 367  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[81]+1)))(2,*((C_word*)lf[81]+1),((C_word*)t0)[2]);}

/* k1814 in k1805 in k1802 in k1799 in k1796 in k1793 in k1782 in k1778 in k1774 in k1770 in k1766 in k1762 in k1759 in k1755 in k1751 in k1748 in k1744 in k1736 in k1732 in k1729 in k1726 in k1723 in k1716 in k1713 in k1710 in k1707 in k1704 in k1701 in k1698 in k1694 in k1691 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1661 in k1655 in k1652 in k1649 in k1646 in k1643 in k1640 in k1637 in k1634 in k1631 in k1628 in k1624 in k1621 in k1618 in k1615 in k1612 in k1609 in k1606 in k1603 in k1600 in k1597 in k1594 in k1586 in k1582 in k1579 in k1576 in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 362  newline");
((C_proc2)C_retrieve_proc(*((C_word*)lf[81]+1)))(2,*((C_word*)lf[81]+1),((C_word*)t0)[2]);}

/* analyze in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1499(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1499,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1501,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1524,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1529,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-no258296");
t8=t7;
f_1529(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("def-contf259294");
t10=t6;
f_1524(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("body256264");
t12=t5;
f_1501(t12,t1,t8,t10);}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-no258 in analyze in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1529,NULL,2,t0,t1);}
C_trace("def-contf259294");
t2=((C_word*)t0)[2];
f_1524(t2,t1,C_fix(0));}

/* def-contf259 in analyze in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1524(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1524,NULL,3,t0,t1,t2);}
C_trace("body256264");
t3=((C_word*)t0)[2];
f_1501(t3,t1,t2,C_SCHEME_TRUE);}

/* body256 in analyze in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1501(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1501,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1505,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("batch-driver.scm: 160  analyze-expression");
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t4,((C_word*)t0)[2]);}

/* k1503 in body256 in analyze in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1508,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1513,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1519,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 162  upap");
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* a1518 in k1503 in body256 in analyze in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1519,5,t0,t1,t2,t3,t4);}
C_trace("##compiler#put!");
((C_proc6)C_retrieve_symbol_proc(lf[56]))(6,*((C_word*)lf[56]+1),t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1512 in k1503 in body256 in analyze in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1513,4,t0,t1,t2,t3);}
C_trace("##compiler#get");
((C_proc5)C_retrieve_symbol_proc(lf[55]))(5,*((C_word*)lf[55]+1),t1,((C_word*)t0)[2],t2,t3);}

/* k1506 in k1503 in body256 in analyze in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1493(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1493,NULL,3,t0,t1,t2);}
C_trace("batch-driver.scm: 156  ##sys#read");
((C_proc4)C_retrieve_symbol_proc(lf[54]))(4,*((C_word*)lf[54]+1),t1,t2,((C_word*)t0)[2]);}

/* end-time in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1464(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1464,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=*((C_word*)lf[31]+1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1471,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t4,lf[53],t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1469 in end-time in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k1472 in k1469 in end-time in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,lf[52],((C_word*)t0)[3]);}

/* k1475 in k1472 in k1469 in end-time in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1480,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fudge(C_fix(6));
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),t2,t4,((C_word*)t0)[3]);}

/* k1478 in k1475 in k1472 in k1469 in end-time in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* begin-time in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static C_word C_fcall f_1454(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t1=(C_word)C_fudge(C_fix(6));
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
t1=C_SCHEME_UNDEFINED;
return(t1);}}

/* collect-options in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1424(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1424,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1430,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1430(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1430(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1430,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1444,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 145  option-arg");
f_1070(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1442 in loop in collect-options in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1448,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
C_trace("batch-driver.scm: 145  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_1430(t4,t2,t3);}

/* k1446 in k1442 in loop in collect-options in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1448,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1344(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1344,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1354,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
C_trace("batch-driver.scm: 136  string->number");
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1385,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1393,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 138  substring");
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1409,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1413,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 139  substring");
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t12,t2,C_fix(0),t4);}
else{
C_trace("batch-driver.scm: 140  string->number");
C_string_to_number(3,0,t5,t2);}}}}

/* k1411 in arg-val in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 139  string->number");
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1407 in arg-val in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_times(t1,C_fix(1024));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
C_trace("batch-driver.scm: 141  quit");
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[50],((C_word*)t0)[2]);}}

/* k1391 in arg-val in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 138  string->number");
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1383 in arg-val in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_times(t1,C_fix(1048576));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
C_trace("batch-driver.scm: 141  quit");
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[50],((C_word*)t0)[2]);}}

/* k1352 in arg-val in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
C_trace("batch-driver.scm: 141  quit");
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[50],((C_word*)t0)[2]);}}

/* infohook in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1295,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1299,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[49]);
if(C_truep(t6)){
t7=t6;
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t2,t3,t4);}
else{
t7=t3;
t8=t5;
f_1299(2,t8,t7);}}

/* k1297 in infohook in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1302,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1305,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(lf[48],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_1305(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_1305(t5,C_SCHEME_FALSE);}}

/* k1303 in k1297 in infohook in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1305(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1305,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1316,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("batch-driver.scm: 128  ##sys#hash-table-ref");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t4,C_retrieve(lf[45]),t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* k1318 in k1303 in k1297 in infohook in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
C_trace("batch-driver.scm: 127  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[46]))(5,*((C_word*)lf[46]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
C_trace("batch-driver.scm: 127  alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[46]))(5,*((C_word*)lf[46]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k1314 in k1303 in k1297 in infohook in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 124  ##sys#hash-table-set!");
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[3],C_retrieve(lf[45]),((C_word*)t0)[2],t1);}

/* k1300 in k1297 in infohook in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1260(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1260,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1267,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("batch-driver.scm: 118  print-header");
t6=((C_word*)t0)[2];
f_1190(t6,t5,t2,t3);}

/* k1265 in print-expr in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1267,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1272,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1272(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop169 in k1265 in print-expr in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1272(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1272,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1282,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("pretty-print");
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1280 in loop169 in k1265 in print-expr in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1272(t3,((C_word*)t0)[2],t2);}

/* print-db in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1236(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1236,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1243,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 113  print-header");
t7=((C_word*)t0)[2];
f_1190(t7,t6,t2,t3);}

/* k1241 in print-db in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1243,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[31]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1246,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t3,lf[43],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1244 in k1241 in print-db in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1247 in k1244 in k1241 in print-db in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k1250 in k1247 in k1244 in k1241 in print-db in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1253 in k1250 in k1247 in k1244 in k1241 in print-db in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 115  display-analysis-database");
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1214(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1214,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1221,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 107  print-header");
t6=((C_word*)t0)[2];
f_1190(t6,t5,t2,t3);}

/* k1219 in print-node in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1221,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
C_trace("batch-driver.scm: 109  dump-nodes");
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1234,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("batch-driver.scm: 110  build-expression-tree");
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2]);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1232 in k1219 in print-node in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("batch-driver.scm: 110  pretty-print");
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t1);}

/* print-header in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1190(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1190,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1194,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("batch-driver.scm: 100  dribble");
t5=((C_word*)t0)[2];
f_1175(t5,t4,lf[37],(C_word)C_a_i_list(&a,1,t2));}

/* k1192 in print-header in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1194,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[35])))){
t2=*((C_word*)lf[31]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t4=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(91),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1201 in k1192 in print-header in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1204 in k1201 in k1192 in print-header in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(93),((C_word*)t0)[2]);}

/* k1207 in k1204 in k1201 in k1192 in print-header in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1210 in k1207 in k1204 in k1201 in k1192 in print-header in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* dribble in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1175(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1175,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
t4=*((C_word*)lf[31]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1182,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t5,C_retrieve(lf[34]),t4,t2,t3);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1180 in dribble in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1183 in k1180 in dribble in k1126 in k1120 in k1117 in k3645 in k1101 in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#flush-output");
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* option-arg in compile-source-file in k1063 in k1059 in k1055 in k1051 in k1047 in k1042 in k1039 in k1036 in k1033 in k1030 in k1027 */
static void C_fcall f_1070(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1070,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
C_trace("batch-driver.scm: 50   quit");
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t1,lf[9],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
C_trace("batch-driver.scm: 53   quit");
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t1,lf[10],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[361] = {
{"toplevel:batch_driver_scm",(void*)C_driver_toplevel},
{"f_1029:batch_driver_scm",(void*)f_1029},
{"f_1032:batch_driver_scm",(void*)f_1032},
{"f_1035:batch_driver_scm",(void*)f_1035},
{"f_1038:batch_driver_scm",(void*)f_1038},
{"f_1041:batch_driver_scm",(void*)f_1041},
{"f_1044:batch_driver_scm",(void*)f_1044},
{"f_1049:batch_driver_scm",(void*)f_1049},
{"f_1053:batch_driver_scm",(void*)f_1053},
{"f_1057:batch_driver_scm",(void*)f_1057},
{"f_1061:batch_driver_scm",(void*)f_1061},
{"f_1065:batch_driver_scm",(void*)f_1065},
{"f_1067:batch_driver_scm",(void*)f_1067},
{"f_1103:batch_driver_scm",(void*)f_1103},
{"f_3666:batch_driver_scm",(void*)f_3666},
{"f_3651:batch_driver_scm",(void*)f_3651},
{"f_3647:batch_driver_scm",(void*)f_3647},
{"f_3636:batch_driver_scm",(void*)f_3636},
{"f_3614:batch_driver_scm",(void*)f_3614},
{"f_1119:batch_driver_scm",(void*)f_1119},
{"f_3608:batch_driver_scm",(void*)f_3608},
{"f_3604:batch_driver_scm",(void*)f_3604},
{"f_1122:batch_driver_scm",(void*)f_1122},
{"f_1128:batch_driver_scm",(void*)f_1128},
{"f_3585:batch_driver_scm",(void*)f_3585},
{"f_3581:batch_driver_scm",(void*)f_3581},
{"f_3577:batch_driver_scm",(void*)f_3577},
{"f_1578:batch_driver_scm",(void*)f_1578},
{"f_1581:batch_driver_scm",(void*)f_1581},
{"f_1584:batch_driver_scm",(void*)f_1584},
{"f_3562:batch_driver_scm",(void*)f_3562},
{"f_3540:batch_driver_scm",(void*)f_3540},
{"f_3558:batch_driver_scm",(void*)f_3558},
{"f_3546:batch_driver_scm",(void*)f_3546},
{"f_1588:batch_driver_scm",(void*)f_1588},
{"f_3538:batch_driver_scm",(void*)f_3538},
{"f_3522:batch_driver_scm",(void*)f_3522},
{"f_3530:batch_driver_scm",(void*)f_3530},
{"f_3534:batch_driver_scm",(void*)f_3534},
{"f_1596:batch_driver_scm",(void*)f_1596},
{"f_1599:batch_driver_scm",(void*)f_1599},
{"f_1602:batch_driver_scm",(void*)f_1602},
{"f_1605:batch_driver_scm",(void*)f_1605},
{"f_1608:batch_driver_scm",(void*)f_1608},
{"f_1611:batch_driver_scm",(void*)f_1611},
{"f_1614:batch_driver_scm",(void*)f_1614},
{"f_1617:batch_driver_scm",(void*)f_1617},
{"f_1620:batch_driver_scm",(void*)f_1620},
{"f_1623:batch_driver_scm",(void*)f_1623},
{"f_1626:batch_driver_scm",(void*)f_1626},
{"f_3472:batch_driver_scm",(void*)f_3472},
{"f_1630:batch_driver_scm",(void*)f_1630},
{"f_3467:batch_driver_scm",(void*)f_3467},
{"f_1633:batch_driver_scm",(void*)f_1633},
{"f_1636:batch_driver_scm",(void*)f_1636},
{"f_1639:batch_driver_scm",(void*)f_1639},
{"f_1642:batch_driver_scm",(void*)f_1642},
{"f_1645:batch_driver_scm",(void*)f_1645},
{"f_1648:batch_driver_scm",(void*)f_1648},
{"f_1651:batch_driver_scm",(void*)f_1651},
{"f_1654:batch_driver_scm",(void*)f_1654},
{"f_1657:batch_driver_scm",(void*)f_1657},
{"f_3426:batch_driver_scm",(void*)f_3426},
{"f_1663:batch_driver_scm",(void*)f_1663},
{"f_3411:batch_driver_scm",(void*)f_3411},
{"f_3414:batch_driver_scm",(void*)f_3414},
{"f_3417:batch_driver_scm",(void*)f_3417},
{"f_1669:batch_driver_scm",(void*)f_1669},
{"f_3401:batch_driver_scm",(void*)f_3401},
{"f_3404:batch_driver_scm",(void*)f_3404},
{"f_1672:batch_driver_scm",(void*)f_1672},
{"f_1675:batch_driver_scm",(void*)f_1675},
{"f_3359:batch_driver_scm",(void*)f_3359},
{"f_1678:batch_driver_scm",(void*)f_1678},
{"f_3353:batch_driver_scm",(void*)f_3353},
{"f_1681:batch_driver_scm",(void*)f_1681},
{"f_3344:batch_driver_scm",(void*)f_3344},
{"f_1684:batch_driver_scm",(void*)f_1684},
{"f_3326:batch_driver_scm",(void*)f_3326},
{"f_3329:batch_driver_scm",(void*)f_3329},
{"f_3332:batch_driver_scm",(void*)f_3332},
{"f_3335:batch_driver_scm",(void*)f_3335},
{"f_1687:batch_driver_scm",(void*)f_1687},
{"f_3320:batch_driver_scm",(void*)f_3320},
{"f_3316:batch_driver_scm",(void*)f_3316},
{"f_1693:batch_driver_scm",(void*)f_1693},
{"f_1696:batch_driver_scm",(void*)f_1696},
{"f_3300:batch_driver_scm",(void*)f_3300},
{"f_1700:batch_driver_scm",(void*)f_1700},
{"f_1703:batch_driver_scm",(void*)f_1703},
{"f_1706:batch_driver_scm",(void*)f_1706},
{"f_1709:batch_driver_scm",(void*)f_1709},
{"f_1712:batch_driver_scm",(void*)f_1712},
{"f_3203:batch_driver_scm",(void*)f_3203},
{"f_3218:batch_driver_scm",(void*)f_3218},
{"f_3243:batch_driver_scm",(void*)f_3243},
{"f_3248:batch_driver_scm",(void*)f_3248},
{"f_3273:batch_driver_scm",(void*)f_3273},
{"f_3119:batch_driver_scm",(void*)f_3119},
{"f_3124:batch_driver_scm",(void*)f_3124},
{"f_3139:batch_driver_scm",(void*)f_3139},
{"f_3164:batch_driver_scm",(void*)f_3164},
{"f_3169:batch_driver_scm",(void*)f_3169},
{"f_3194:batch_driver_scm",(void*)f_3194},
{"f_1715:batch_driver_scm",(void*)f_1715},
{"f_3113:batch_driver_scm",(void*)f_3113},
{"f_3105:batch_driver_scm",(void*)f_3105},
{"f_3080:batch_driver_scm",(void*)f_3080},
{"f_3082:batch_driver_scm",(void*)f_3082},
{"f_3092:batch_driver_scm",(void*)f_3092},
{"f_1718:batch_driver_scm",(void*)f_1718},
{"f_1725:batch_driver_scm",(void*)f_1725},
{"f_1728:batch_driver_scm",(void*)f_1728},
{"f_1731:batch_driver_scm",(void*)f_1731},
{"f_3049:batch_driver_scm",(void*)f_3049},
{"f_3073:batch_driver_scm",(void*)f_3073},
{"f_3062:batch_driver_scm",(void*)f_3062},
{"f_1734:batch_driver_scm",(void*)f_1734},
{"f_1738:batch_driver_scm",(void*)f_1738},
{"f_1746:batch_driver_scm",(void*)f_1746},
{"f_1750:batch_driver_scm",(void*)f_1750},
{"f_3047:batch_driver_scm",(void*)f_3047},
{"f_1753:batch_driver_scm",(void*)f_1753},
{"f_3043:batch_driver_scm",(void*)f_3043},
{"f_3039:batch_driver_scm",(void*)f_3039},
{"f_3035:batch_driver_scm",(void*)f_3035},
{"f_3015:batch_driver_scm",(void*)f_3015},
{"f_3013:batch_driver_scm",(void*)f_3013},
{"f_1757:batch_driver_scm",(void*)f_1757},
{"f_1761:batch_driver_scm",(void*)f_1761},
{"f_1764:batch_driver_scm",(void*)f_1764},
{"f_2992:batch_driver_scm",(void*)f_2992},
{"f_1768:batch_driver_scm",(void*)f_1768},
{"f_2985:batch_driver_scm",(void*)f_2985},
{"f_1772:batch_driver_scm",(void*)f_1772},
{"f_2978:batch_driver_scm",(void*)f_2978},
{"f_1776:batch_driver_scm",(void*)f_1776},
{"f_2971:batch_driver_scm",(void*)f_2971},
{"f_1780:batch_driver_scm",(void*)f_1780},
{"f_2951:batch_driver_scm",(void*)f_2951},
{"f_1784:batch_driver_scm",(void*)f_1784},
{"f_1795:batch_driver_scm",(void*)f_1795},
{"f_1798:batch_driver_scm",(void*)f_1798},
{"f_1801:batch_driver_scm",(void*)f_1801},
{"f_2910:batch_driver_scm",(void*)f_2910},
{"f_1804:batch_driver_scm",(void*)f_1804},
{"f_1807:batch_driver_scm",(void*)f_1807},
{"f_1828:batch_driver_scm",(void*)f_1828},
{"f_1856:batch_driver_scm",(void*)f_1856},
{"f_1862:batch_driver_scm",(void*)f_1862},
{"f_1866:batch_driver_scm",(void*)f_1866},
{"f_1869:batch_driver_scm",(void*)f_1869},
{"f_1872:batch_driver_scm",(void*)f_1872},
{"f_1875:batch_driver_scm",(void*)f_1875},
{"f_1883:batch_driver_scm",(void*)f_1883},
{"f_1886:batch_driver_scm",(void*)f_1886},
{"f_1889:batch_driver_scm",(void*)f_1889},
{"f_2878:batch_driver_scm",(void*)f_2878},
{"f_2886:batch_driver_scm",(void*)f_2886},
{"f_1892:batch_driver_scm",(void*)f_1892},
{"f_1895:batch_driver_scm",(void*)f_1895},
{"f_2793:batch_driver_scm",(void*)f_2793},
{"f_2822:batch_driver_scm",(void*)f_2822},
{"f_2871:batch_driver_scm",(void*)f_2871},
{"f_2839:batch_driver_scm",(void*)f_2839},
{"f_2843:batch_driver_scm",(void*)f_2843},
{"f_2848:batch_driver_scm",(void*)f_2848},
{"f_2869:batch_driver_scm",(void*)f_2869},
{"f_2834:batch_driver_scm",(void*)f_2834},
{"f_2825:batch_driver_scm",(void*)f_2825},
{"f_2808:batch_driver_scm",(void*)f_2808},
{"f_2812:batch_driver_scm",(void*)f_2812},
{"f_2816:batch_driver_scm",(void*)f_2816},
{"f_2804:batch_driver_scm",(void*)f_2804},
{"f_2784:batch_driver_scm",(void*)f_2784},
{"f_2788:batch_driver_scm",(void*)f_2788},
{"f_1898:batch_driver_scm",(void*)f_1898},
{"f_1901:batch_driver_scm",(void*)f_1901},
{"f_2777:batch_driver_scm",(void*)f_2777},
{"f_2781:batch_driver_scm",(void*)f_2781},
{"f_1904:batch_driver_scm",(void*)f_1904},
{"f_1907:batch_driver_scm",(void*)f_1907},
{"f_2754:batch_driver_scm",(void*)f_2754},
{"f_2774:batch_driver_scm",(void*)f_2774},
{"f_1913:batch_driver_scm",(void*)f_1913},
{"f_2747:batch_driver_scm",(void*)f_2747},
{"f_1916:batch_driver_scm",(void*)f_1916},
{"f_1919:batch_driver_scm",(void*)f_1919},
{"f_2715:batch_driver_scm",(void*)f_2715},
{"f_2589:batch_driver_scm",(void*)f_2589},
{"f_2705:batch_driver_scm",(void*)f_2705},
{"f_2593:batch_driver_scm",(void*)f_2593},
{"f_2597:batch_driver_scm",(void*)f_2597},
{"f_2616:batch_driver_scm",(void*)f_2616},
{"f_2601:batch_driver_scm",(void*)f_2601},
{"f_1925:batch_driver_scm",(void*)f_1925},
{"f_2534:batch_driver_scm",(void*)f_2534},
{"f_2539:batch_driver_scm",(void*)f_2539},
{"f_2552:batch_driver_scm",(void*)f_2552},
{"f_2555:batch_driver_scm",(void*)f_2555},
{"f_2558:batch_driver_scm",(void*)f_2558},
{"f_2561:batch_driver_scm",(void*)f_2561},
{"f_2564:batch_driver_scm",(void*)f_2564},
{"f_1928:batch_driver_scm",(void*)f_1928},
{"f_2528:batch_driver_scm",(void*)f_2528},
{"f_1931:batch_driver_scm",(void*)f_1931},
{"f_2522:batch_driver_scm",(void*)f_2522},
{"f_1934:batch_driver_scm",(void*)f_1934},
{"f_1937:batch_driver_scm",(void*)f_1937},
{"f_2507:batch_driver_scm",(void*)f_2507},
{"f_1940:batch_driver_scm",(void*)f_1940},
{"f_1945:batch_driver_scm",(void*)f_1945},
{"f_1948:batch_driver_scm",(void*)f_1948},
{"f_1951:batch_driver_scm",(void*)f_1951},
{"f_1954:batch_driver_scm",(void*)f_1954},
{"f_2488:batch_driver_scm",(void*)f_2488},
{"f_2495:batch_driver_scm",(void*)f_2495},
{"f_1957:batch_driver_scm",(void*)f_1957},
{"f_2485:batch_driver_scm",(void*)f_2485},
{"f_2481:batch_driver_scm",(void*)f_2481},
{"f_1966:batch_driver_scm",(void*)f_1966},
{"f_1969:batch_driver_scm",(void*)f_1969},
{"f_2415:batch_driver_scm",(void*)f_2415},
{"f_2449:batch_driver_scm",(void*)f_2449},
{"f_2451:batch_driver_scm",(void*)f_2451},
{"f_2464:batch_driver_scm",(void*)f_2464},
{"f_2418:batch_driver_scm",(void*)f_2418},
{"f_2426:batch_driver_scm",(void*)f_2426},
{"f_2429:batch_driver_scm",(void*)f_2429},
{"f_2432:batch_driver_scm",(void*)f_2432},
{"f_2438:batch_driver_scm",(void*)f_2438},
{"f_2441:batch_driver_scm",(void*)f_2441},
{"f_2444:batch_driver_scm",(void*)f_2444},
{"f_1972:batch_driver_scm",(void*)f_1972},
{"f_2406:batch_driver_scm",(void*)f_2406},
{"f_2409:batch_driver_scm",(void*)f_2409},
{"f_2388:batch_driver_scm",(void*)f_2388},
{"f_2394:batch_driver_scm",(void*)f_2394},
{"f_2397:batch_driver_scm",(void*)f_2397},
{"f_2400:batch_driver_scm",(void*)f_2400},
{"f_1975:batch_driver_scm",(void*)f_1975},
{"f_2382:batch_driver_scm",(void*)f_2382},
{"f_1978:batch_driver_scm",(void*)f_1978},
{"f_2375:batch_driver_scm",(void*)f_2375},
{"f_1981:batch_driver_scm",(void*)f_1981},
{"f_2372:batch_driver_scm",(void*)f_2372},
{"f_2323:batch_driver_scm",(void*)f_2323},
{"f_2325:batch_driver_scm",(void*)f_2325},
{"f_2368:batch_driver_scm",(void*)f_2368},
{"f_2364:batch_driver_scm",(void*)f_2364},
{"f_2338:batch_driver_scm",(void*)f_2338},
{"f_2354:batch_driver_scm",(void*)f_2354},
{"f_2357:batch_driver_scm",(void*)f_2357},
{"f_2341:batch_driver_scm",(void*)f_2341},
{"f_1984:batch_driver_scm",(void*)f_1984},
{"f_1987:batch_driver_scm",(void*)f_1987},
{"f_2293:batch_driver_scm",(void*)f_2293},
{"f_2306:batch_driver_scm",(void*)f_2306},
{"f_2309:batch_driver_scm",(void*)f_2309},
{"f_1990:batch_driver_scm",(void*)f_1990},
{"f_1996:batch_driver_scm",(void*)f_1996},
{"f_2002:batch_driver_scm",(void*)f_2002},
{"f_2005:batch_driver_scm",(void*)f_2005},
{"f_2008:batch_driver_scm",(void*)f_2008},
{"f_2013:batch_driver_scm",(void*)f_2013},
{"f_2020:batch_driver_scm",(void*)f_2020},
{"f_2248:batch_driver_scm",(void*)f_2248},
{"f_2251:batch_driver_scm",(void*)f_2251},
{"f_2023:batch_driver_scm",(void*)f_2023},
{"f_2027:batch_driver_scm",(void*)f_2027},
{"f_2030:batch_driver_scm",(void*)f_2030},
{"f_2033:batch_driver_scm",(void*)f_2033},
{"f_2125:batch_driver_scm",(void*)f_2125},
{"f_2236:batch_driver_scm",(void*)f_2236},
{"f_2128:batch_driver_scm",(void*)f_2128},
{"f_2134:batch_driver_scm",(void*)f_2134},
{"f_2137:batch_driver_scm",(void*)f_2137},
{"f_2140:batch_driver_scm",(void*)f_2140},
{"f_2143:batch_driver_scm",(void*)f_2143},
{"f_2146:batch_driver_scm",(void*)f_2146},
{"f_2149:batch_driver_scm",(void*)f_2149},
{"f_2163:batch_driver_scm",(void*)f_2163},
{"f_2167:batch_driver_scm",(void*)f_2167},
{"f_2173:batch_driver_scm",(void*)f_2173},
{"f_2176:batch_driver_scm",(void*)f_2176},
{"f_2179:batch_driver_scm",(void*)f_2179},
{"f_2182:batch_driver_scm",(void*)f_2182},
{"f_2185:batch_driver_scm",(void*)f_2185},
{"f3831:batch_driver_scm",(void*)f3831},
{"f_2204:batch_driver_scm",(void*)f_2204},
{"f_2188:batch_driver_scm",(void*)f_2188},
{"f_2191:batch_driver_scm",(void*)f_2191},
{"f_2157:batch_driver_scm",(void*)f_2157},
{"f_2039:batch_driver_scm",(void*)f_2039},
{"f_2053:batch_driver_scm",(void*)f_2053},
{"f_2057:batch_driver_scm",(void*)f_2057},
{"f_2060:batch_driver_scm",(void*)f_2060},
{"f_2079:batch_driver_scm",(void*)f_2079},
{"f_2096:batch_driver_scm",(void*)f_2096},
{"f_2099:batch_driver_scm",(void*)f_2099},
{"f_2105:batch_driver_scm",(void*)f_2105},
{"f_2108:batch_driver_scm",(void*)f_2108},
{"f_2047:batch_driver_scm",(void*)f_2047},
{"f_1847:batch_driver_scm",(void*)f_1847},
{"f_1840:batch_driver_scm",(void*)f_1840},
{"f_1816:batch_driver_scm",(void*)f_1816},
{"f_1499:batch_driver_scm",(void*)f_1499},
{"f_1529:batch_driver_scm",(void*)f_1529},
{"f_1524:batch_driver_scm",(void*)f_1524},
{"f_1501:batch_driver_scm",(void*)f_1501},
{"f_1505:batch_driver_scm",(void*)f_1505},
{"f_1519:batch_driver_scm",(void*)f_1519},
{"f_1513:batch_driver_scm",(void*)f_1513},
{"f_1508:batch_driver_scm",(void*)f_1508},
{"f_1493:batch_driver_scm",(void*)f_1493},
{"f_1464:batch_driver_scm",(void*)f_1464},
{"f_1471:batch_driver_scm",(void*)f_1471},
{"f_1474:batch_driver_scm",(void*)f_1474},
{"f_1477:batch_driver_scm",(void*)f_1477},
{"f_1480:batch_driver_scm",(void*)f_1480},
{"f_1454:batch_driver_scm",(void*)f_1454},
{"f_1424:batch_driver_scm",(void*)f_1424},
{"f_1430:batch_driver_scm",(void*)f_1430},
{"f_1444:batch_driver_scm",(void*)f_1444},
{"f_1448:batch_driver_scm",(void*)f_1448},
{"f_1344:batch_driver_scm",(void*)f_1344},
{"f_1413:batch_driver_scm",(void*)f_1413},
{"f_1409:batch_driver_scm",(void*)f_1409},
{"f_1393:batch_driver_scm",(void*)f_1393},
{"f_1385:batch_driver_scm",(void*)f_1385},
{"f_1354:batch_driver_scm",(void*)f_1354},
{"f_1295:batch_driver_scm",(void*)f_1295},
{"f_1299:batch_driver_scm",(void*)f_1299},
{"f_1305:batch_driver_scm",(void*)f_1305},
{"f_1320:batch_driver_scm",(void*)f_1320},
{"f_1316:batch_driver_scm",(void*)f_1316},
{"f_1302:batch_driver_scm",(void*)f_1302},
{"f_1260:batch_driver_scm",(void*)f_1260},
{"f_1267:batch_driver_scm",(void*)f_1267},
{"f_1272:batch_driver_scm",(void*)f_1272},
{"f_1282:batch_driver_scm",(void*)f_1282},
{"f_1236:batch_driver_scm",(void*)f_1236},
{"f_1243:batch_driver_scm",(void*)f_1243},
{"f_1246:batch_driver_scm",(void*)f_1246},
{"f_1249:batch_driver_scm",(void*)f_1249},
{"f_1252:batch_driver_scm",(void*)f_1252},
{"f_1255:batch_driver_scm",(void*)f_1255},
{"f_1214:batch_driver_scm",(void*)f_1214},
{"f_1221:batch_driver_scm",(void*)f_1221},
{"f_1234:batch_driver_scm",(void*)f_1234},
{"f_1190:batch_driver_scm",(void*)f_1190},
{"f_1194:batch_driver_scm",(void*)f_1194},
{"f_1203:batch_driver_scm",(void*)f_1203},
{"f_1206:batch_driver_scm",(void*)f_1206},
{"f_1209:batch_driver_scm",(void*)f_1209},
{"f_1212:batch_driver_scm",(void*)f_1212},
{"f_1175:batch_driver_scm",(void*)f_1175},
{"f_1182:batch_driver_scm",(void*)f_1182},
{"f_1185:batch_driver_scm",(void*)f_1185},
{"f_1070:batch_driver_scm",(void*)f_1070},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
